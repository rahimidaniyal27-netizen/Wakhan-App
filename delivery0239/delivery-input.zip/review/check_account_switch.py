import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);c=await b.new_context(viewport={'width':393,'height':852});api=await p.request.new_context(base_url='http://127.0.0.1:8773');await api.post('/_test/control',data={'op':'reset'});pg=await c.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));await pg.goto('http://127.0.0.1:8773/?uid=1');await pg.wait_for_function('window.fixtureReady');await pg.evaluate('WakhanGames.open("chess")');await pg.frame_locator('.wk-games-frame').locator('[data-create]').wait_for();response_ready=asyncio.Event();release=asyncio.Event()
  async def delayed(route):
   response=await route.fetch();response_ready.set();await release.wait();await route.fulfill(response=response)
  await pg.route('**/api/app/games/create',delayed);await pg.evaluate('void WakhanGames.rpc("create",{game:"chess",public:false}).catch(e=>window.oldRequestError=e.code)');await response_ready.wait();await pg.evaluate('window.uid=20');await pg.wait_for_timeout(2200);release.set();await pg.wait_for_function('window.oldRequestError');assert await pg.evaluate('window.oldRequestError')=='account_changed';assert await pg.evaluate('WakhanGames.snapshot===null');await pg.evaluate('WakhanGames.openCatalog()');await pg.frame_locator('.wk-games-frame').locator('.game-grid').wait_for();assert not errors,errors;result=dict(delayed_previous_account_response_rejected=True,old_private_snapshot_purged=True,new_frame_rpc_not_blocked=True,errors=errors);Path(__file__).with_name('account-switch-results.json').write_text(json.dumps(result,indent=2));print(result);await b.close()
asyncio.run(main())
