import asyncio,json,uuid
from pathlib import Path
from playwright.async_api import async_playwright
BASE='http://127.0.0.1:8773'
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);api=await p.request.new_context(base_url=BASE);await api.post('/_test/control',data={'op':'reset'});c=await b.new_context(viewport={'width':320,'height':740},has_touch=True,is_mobile=True);pg=await c.new_page();pg.set_default_timeout(15000);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));await pg.goto(BASE+'/?uid=1');await pg.wait_for_function('window.fixtureReady');await pg.frame_locator('.wk-approved-home-frame').locator('[data-open-game=fiskot]').tap();f=pg.frame_locator('.wk-games-frame');await f.locator('[data-create]').tap();await f.locator('.dialog .primary').tap();await f.locator('[data-start]').wait_for();mid=await pg.evaluate('WakhanGames.snapshot.id');inst=await pg.evaluate('sessionStorage.wk_game_instance')
  async def get(uid):return await (await api.get('/api/app/games/'+mid+'?instance='+(inst if uid==1 else f'{uid:032x}'),headers={'X-Test-Uid':str(uid)})).json()
  async def post(uid,action=None,path='/action',version=None):
   body={'instance':inst if uid==1 else f'{uid:032x}','action_id':uuid.uuid4().hex}
   if action:body.update(expected_version=version,action=action)
   v=await (await api.post('/api/app/games/'+mid+path,data=body,headers={'X-Test-Uid':str(uid)})).json();assert v.get('ok'),v;return v
  for uid in [2,3,4]:await post(uid,path='/join')
  await pg.wait_for_function('WakhanGames.snapshot.count===4');await f.locator('[data-start]').tap();await f.locator('.hand-strip').wait_for();played=0;hands=set()
  while True:
   v=await get(1)
   if v['status']=='finished':break
   s=v['state'];hands.add(s['hand'])
   if s['phase']=='hand_end' or v['server_time']<s['collect_until']:
    delta=max(0,(s['deadline'] if s['phase']=='hand_end' else s['collect_until'])-v['server_time'])+.02;await api.post('/_test/control',data={'op':'advance','seconds':delta});await api.post('/_test/control',data={'op':'pulse'});continue
   uid=s['turn']+1;own=await get(uid);s=own['state'];a={'type':'trump','suit':'H'} if s['phase']=='trump' else {'type':'play','card':s['legal'][0]}
   if uid==1:
    await pg.wait_for_function('(version)=>WakhanGames.snapshot.version>=version',arg=own['version'])
    if a['type']=='trump':
     print('OWN TRUMP',s['hand'],played,await f.get_by_role('button',name='دل',exact=True).bounding_box(),flush=True);await pg.screenshot(path=str(Path(__file__).parent/'screenshots/fiskot-trump-320-debug.png'));await f.get_by_role('button',name='دل',exact=True).tap();await pg.wait_for_function('(version)=>WakhanGames.snapshot.version>version',arg=own['version'])
    else:
     card=f.locator('[data-card="'+str(a['card'])+'"]');await card.scroll_into_view_if_needed();await card.tap(position={'x':7,'y':15});await f.locator('[data-play]').tap();await pg.wait_for_function('(version)=>WakhanGames.snapshot.version>version',arg=own['version'])
   else:await post(uid,a,version=own['version'])
   played+=a['type']=='play';assert played<800
  await f.locator('.result').wait_for();assert not errors,errors;await pg.screenshot(path=str(Path(__file__).parent/'screenshots/fiskot-result.png'));r={'game':'fiskot','width':320,'all_cards_played':played,'hands':len(hands),'home_to_result':True,'own_card_corner_taps':True,'other_players':'three independent authenticated HTTP sessions','result':v['state']['result'],'errors':errors};Path(__file__).with_name('complete-ui-fiskot.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(r);await b.close()
asyncio.run(main())
