import asyncio,json,uuid
from pathlib import Path
from playwright.async_api import async_playwright
BASE='http://127.0.0.1:8773'
async def main():
 errors=[];out={}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);api=await p.request.new_context(base_url=BASE);await api.post('/_test/control',data={'op':'reset'});pages=[];contexts=[]
  for uid in [1,2]:
   c=await b.new_context(viewport={'width':393,'height':852});contexts.append(c);pg=await c.new_page();pg.on('pageerror',lambda e:errors.append(str(e)));pg.set_default_timeout(12000);await pg.goto(BASE+'/?uid='+str(uid));await pg.wait_for_function('window.fixtureReady');pages.append(pg)
  a,other=pages;await a.evaluate('WakhanGames.open("ludo",{origin:"TEST"})');f=a.frame_locator('.wk-games-frame');await f.locator('[data-create]').click();await f.locator('.dialog .primary').click();await f.locator('[data-start]').wait_for();mid=await a.evaluate('WakhanGames.snapshot.id');await other.evaluate('routeTo("c")');await a.evaluate('WakhanGames.rpc("invite",{version:WakhanGames.snapshot.version,targets:[2]})');await other.locator('.wk-game-invitation').wait_for();await other.get_by_role('button',name='لغو',exact=True).click();await other.wait_for_timeout(300);assert await a.evaluate('WakhanGames.snapshot.status')=='waiting';await a.evaluate('WakhanGames.rpc("invite",{version:WakhanGames.snapshot.version,targets:[2]})');await other.locator('.wk-game-invitation').wait_for();await other.get_by_role('button',name='پیوستن',exact=True).click();await other.frame_locator('.wk-games-frame').locator('.roster').wait_for();assert await other.evaluate('WakhanGames.snapshot.id')==mid;assert await other.evaluate('window.roomVoicePaused===true');out['salon_decline_resend_accept_same_match']=True
  # Deliberately missing match before its iframe finishes loading must return to catalog.
  c=await b.new_context(viewport={'width':393,'height':852});pg=await c.new_page();pg.on('pageerror',lambda e:errors.append(str(e)));await pg.goto(BASE+'/?uid=20');await pg.wait_for_function('window.fixtureReady');await pg.evaluate('WakhanGames.openMatch("f".repeat(32),{join:true})');await pg.frame_locator('.wk-games-frame').locator('.game-grid').wait_for();out['early_failed_match_does_not_stick_loading']=True;await c.close()
  assert not errors,errors;out['errors']=errors;Path(__file__).with_name('invitation-ui-results.json').write_text(json.dumps(out,indent=2));print(out);await b.close()
asyncio.run(main())
