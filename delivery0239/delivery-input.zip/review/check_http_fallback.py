import asyncio,json,uuid,math
from pathlib import Path
from playwright.async_api import async_playwright
BASE='http://127.0.0.1:8773'
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']);api=await p.request.new_context(base_url=BASE);await api.post('/_test/control',data={'op':'reset'})
  async def ctl(**kw):return await api.post('/_test/control',data=kw)
  async def post(path,uid,**kw):
   r=await api.post('/api/app/games'+path,data={'instance':f'{uid:032x}','action_id':uuid.uuid4().hex,**kw},headers={'X-Test-Uid':str(uid)});v=await r.json();assert v.get('ok'),v;return v
  async def state(mid,uid):return await (await api.get('/api/app/games/'+mid+'?instance='+f'{uid:032x}',headers={'X-Test-Uid':str(uid)})).json()
  v=await post('/create',1,game='patpal',public=True);mid=v['id']
  for uid in [2,3,4]:await post('/'+mid+'/join',uid)
  v=await state(mid,1);await post('/'+mid+'/action',1,expected_version=v['version'],action={'type':'start'});await ctl(op='advance',seconds=7.2);await ctl(op='pulse');uid=1
  for u in [1,2,3,4]:
   if (await state(mid,u))['state']['role']=='hider':uid=u;break
  c=await b.new_context(viewport={'width':393,'height':852});await c.add_init_script('sessionStorage.setItem("wk_game_instance","'+f'{uid:032x}'+'")');await c.route_web_socket('**/api/app/games/ws?*',lambda ws:ws.close());pg=await c.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));await pg.goto(BASE+'/?uid='+str(uid));await pg.wait_for_function('window.fixtureReady');await pg.evaluate('(id)=>WakhanGames.openMatch(id)',mid);f=pg.frame_locator('.wk-games-frame');await f.locator('canvas').wait_for();await pg.wait_for_timeout(1000);box=await f.locator('.joystick').bounding_box();before=(await state(mid,uid))['state']['self'];await pg.mouse.move(box['x']+54,box['y']+22);await pg.mouse.down();await pg.wait_for_timeout(1200);await pg.mouse.up();await pg.wait_for_timeout(200);after=(await state(mid,uid))['state']['self'];distance=math.hypot(after['x']-before['x'],after['z']-before['z']);assert distance>.08,distance;assert not errors,errors;out=dict(websocket_blocked=True,authenticated_http_state_and_motion_work=True,movement=distance,voice_does_not_auto_enable=True,errors=errors);Path(__file__).with_name('http-fallback-results.json').write_text(json.dumps(out,indent=2));print(out);await b.close()
asyncio.run(main())
