import sqlite3,time,types,unittest
from wakhan_games.rankings import Rankings

class RankingTests(unittest.TestCase):
 def setUp(self):
  db=sqlite3.connect(':memory:');db.executescript('CREATE TABLE wkg_result_people(match_id TEXT,uid INTEGER,game TEXT,outcome TEXT,position INTEGER,created REAL,test INTEGER);CREATE TABLE wka_accounts(uid INTEGER,done INTEGER,blocked INTEGER);CREATE TABLE wm70_blocks(actor INTEGER,target INTEGER);')
  for uid in [1,2,3]:db.execute('INSERT INTO wka_accounts VALUES(?,1,0)',(uid,))
  self.db=db;self.now=time.time();self.g=types.SimpleNamespace(db=db,n={},profile=lambda uid,viewer:dict(id=uid,name=str(uid),avatar=None));self.old=types.SimpleNamespace(leaderboard=lambda *a:dict(original=True),window=lambda *a:(0,self.now),rows=lambda *a:[(1,100,0),(2,0,100),(3,0,0)]);self.r=Rankings(self.g,self.old)
 def tearDown(self):self.db.close()
 def add(self,match,uid,game='ludo',outcome='win',test=0):self.db.execute('INSERT INTO wkg_result_people VALUES(?,?,?,?,1,?,?)',(match,uid,game,outcome,self.now-1,test))
 def test_only_valid_wins_count_and_game_filter_applies(self):
  self.add('a',1);self.add('b',1,game='chess');self.add('c',2,test=1);self.add('d',2,outcome='incomplete');self.add('e',3);self.db.execute('INSERT INTO wm70_blocks VALUES(1,3)');v=self.r.leaderboard(1,'games','month');self.assertEqual([(p['id'],p['score']) for p in v['items']],[(1,2)]);self.assertEqual(self.r.leaderboard(1,'games','month',game='ludo')['items'][0]['score'],1)
 def test_existing_overall_stays_unchanged_until_weight_selected(self):
  self.assertEqual(self.r.weights,dict(activity=50,purchase=50,games=0));self.assertTrue(self.r.leaderboard(1,'overall','month')['original'])
 def test_configured_combination_includes_game_winner(self):
  self.add('a',3);self.r.weights=dict(activity=30,purchase=30,games=40);v=self.r.leaderboard(1,'overall','month');self.assertEqual(v['items'][0]['id'],3)
