import hashlib,json,os,re,shutil,subprocess,tempfile,zipfile,struct,urllib.request,urllib.error,time,sqlite3
from pathlib import Path


FIELDS = {'store': ('storefile', 'keystorefile', 'keystorepath', 'storepath', 'keystore'), 'alias': ('keyalias', 'releasealias', 'alias'), 'store_pass': ('storepassword', 'keystorepassword', 'keystorepass', 'storepass', 'password'), 'key_pass': ('keypassword', 'keypass')}

def unescape(value):

    def decode(m):
        s = m.group(1)
        if s.startswith('u') and len(s) == 5:
            return chr(int(s[1:], 16))
        return {'t': '\t', 'n': '\n', 'r': '\r', 'f': '\x0c'}.get(s, s)
    return re.sub('\\\\(u[0-9a-fA-F]{4}|.)', decode, value)

def properties(text, env=False):
    result = {}
    pending = ''
    for raw in text.splitlines():
        line = pending + raw.lstrip() if pending else raw
        if len(line) - len(line.rstrip('\\')) & 1:
            pending = line[:-1]
            continue
        pending = ''
        line = line.lstrip()
        if not line or line.startswith(('#', '!')):
            continue
        if env and line.startswith('export '):
            line = line[7:].lstrip()
        m = re.match('((?:\\\\.|[^\\s:=])+)(?:\\s*[=:]\\s*|\\s+)(.*)\\Z', line)
        if not m:
            continue
        key, value = m.groups()
        if env and len(value) >= 2 and (value[0] == value[-1]) and (value[0] in ('"', "'")):
            quote = value[0]
            value = value[1:-1]
            if quote == '"':
                value = value.replace('\\"', '"').replace('\\\\', '\\')
        elif not env:
            value = unescape(value)
        result[unescape(key)] = value
    return result

def normalize(values):
    normalized = {re.sub('[^a-z0-9]', '', str(k).lower()): v for k, v in values.items() if isinstance(v, (str, Path))}
    output = {}
    for field, endings in FIELDS.items():
        found = []
        for key, value in normalized.items():
            if any((key == ending or (key.endswith(ending) and any((prefix in key for prefix in ('wakhan', 'android', 'release', 'upload', 'signing', 'myapp')))) for ending in endings)):
                found.append(str(value))
        unique = list(dict.fromkeys(found))
        if len(unique) == 1:
            output[field] = unique[0]
        elif len(unique) > 1:
            return None
    if 'store' not in output or 'store_pass' not in output:
        return None
    output.setdefault('key_pass', output['store_pass'])
    output.setdefault('alias', '')
    return output

def key_certificate(config):
    keytool = shutil.which('keytool')
    if not keytool:
        raise RuntimeError('JAVA_KEYTOOL_NOT_FOUND')
    env = {**os.environ, 'WAKHAN_SIGNING_STORE_PASS': config['store_pass']}
    try:
        if not config.get('alias'):
            listed = subprocess.run([keytool, '-J-Duser.language=en', '-list', '-rfc', '-keystore', config['store'], '-storepass:env', 'WAKHAN_SIGNING_STORE_PASS'], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
            if listed.returncode:
                return None
            aliases = re.findall('^Alias name: (.+)$', listed.stdout.decode('utf-8', 'replace'), re.M)
            if len(aliases) != 1:
                return None
            config['alias'] = aliases[0].strip()
        result = subprocess.run([keytool, '-exportcert', '-keystore', config['store'], '-alias', config['alias'], '-storepass:env', 'WAKHAN_SIGNING_STORE_PASS'], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
        return hashlib.sha256(result.stdout).hexdigest() if result.returncode == 0 else None
    finally:
        env.pop('WAKHAN_SIGNING_STORE_PASS', None)

def read_existing_configuration(path, expected_certificate):
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise RuntimeError('EXISTING_RELEASE_PROPERTIES_NOT_FOUND')
    config = normalize(properties(path.read_text()))
    if not config:
        raise RuntimeError('EXISTING_RELEASE_PROPERTIES_INVALID')
    store = Path(config['store'])
    if not store.is_absolute():
        store = path.parent / store
    if not store.is_file():
        raise RuntimeError('EXISTING_RELEASE_KEYSTORE_NOT_FOUND')
    config['store'] = str(store.resolve())
    if key_certificate(config) != expected_certificate:
        config.clear()
        raise RuntimeError('EXISTING_RELEASE_CERTIFICATE_MISMATCH')
    return config

def sign_release(apk, tools, work, config, run, report):
    aligned = work / 'aligned.apk'
    signed = work / 'signed.apk'
    run([tools / 'zipalign', '-f', '-P', '16', '4', apk, aligned], work, 'ALIGN_APK', report, 120)
    store_name = 'WAKHAN_BETA27_STORE_PASSWORD'
    key_name = 'WAKHAN_BETA27_KEY_PASSWORD'
    previous = {name: os.environ.get(name) for name in (store_name, key_name)}
    try:
        os.environ[store_name] = config['store_pass']
        os.environ[key_name] = config['key_pass']
        run([tools / 'apksigner', 'sign', '--ks', config['store'], '--ks-key-alias', config['alias'], '--ks-pass', 'env:' + store_name, '--key-pass', 'env:' + key_name, '--out', signed, aligned], work, 'SIGN_APK', report, 120)
    finally:
        for name, value in previous.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value
        config.clear()
    return signed

def lp(data, at=0):
    if at + 4 > len(data):
        raise ValueError('APK_SIGNATURE_TRUNCATED')
    size = struct.unpack_from('<I', data, at)[0]
    end = at + 4 + size
    if end > len(data):
        raise ValueError('APK_SIGNATURE_TRUNCATED')
    return (data[at + 4:end], end)

def signer_hashes(path):
    data = Path(path).read_bytes()
    eocd = data.rfind(b'PK\x05\x06', max(0, len(data) - 65557))
    if eocd < 0:
        raise ValueError('APK_DIRECTORY_NOT_FOUND')
    central = struct.unpack_from('<I', data, eocd + 16)[0]
    if data[central - 16:central] != b'APK Sig Block 42':
        raise ValueError('APK_SIGNING_BLOCK_NOT_FOUND')
    size = struct.unpack_from('<Q', data, central - 24)[0]
    start = central - size - 8
    if start < 0 or struct.unpack_from('<Q', data, start)[0] != size:
        raise ValueError('APK_SIGNING_BLOCK_INVALID')
    hashes = set()
    at = start + 8
    while at < central - 24:
        length = struct.unpack_from('<Q', data, at)[0]
        at += 8
        end = at + length
        if length < 4 or end > central - 24:
            raise ValueError('APK_SIGNATURE_TRUNCATED')
        kind = struct.unpack_from('<I', data, at)[0]
        value = data[at + 4:end]
        at = end
        if kind not in (1896449818, 4031998144):
            continue
        signers, _ = lp(value)
        pos = 0
        while pos < len(signers):
            signer, pos = lp(signers, pos)
            signed, _ = lp(signer)
            _, offset = lp(signed)
            certificates, _ = lp(signed, offset)
            certificate, _ = lp(certificates)
            hashes.add(hashlib.sha256(certificate).hexdigest())
    if not hashes:
        raise ValueError('APK_NO_SIGNER_CERTIFICATE')
    return sorted(hashes)

def sign_bundle(bundle, work, config, expected, run, report):
    try:
        return _sign_bundle(bundle, work, config, expected, run, report)
    finally:
        config.clear()

def _sign_bundle(bundle, work, config, expected, run, report):
    executable = shutil.which('jarsigner')
    java = shutil.which('java')
    keytool = shutil.which('keytool')
    jarsigner = [executable] if executable else [java, '-m', 'jdk.jartool/sun.security.tools.jarsigner.Main'] if java else []
    if not jarsigner or not keytool:
        raise RuntimeError('BUNDLE_SIGNING_TOOLS_NOT_FOUND')
    clean = work / 'unsigned-clean.aab'
    signed = work / 'signed.aab'
    with zipfile.ZipFile(bundle) as source, zipfile.ZipFile(clean, 'x', zipfile.ZIP_DEFLATED) as target:
        if 'BundleConfig.pb' not in source.namelist():
            raise RuntimeError('ANDROID_BUNDLE_INVALID')
        for entry in source.infolist():
            if entry.filename.upper() == 'META-INF/MANIFEST.MF' or re.fullmatch('META-INF/[^/]+\\.(SF|RSA|DSA|EC)', entry.filename, re.I):
                continue
            target.writestr(entry, source.read(entry))
    names = ('WAKHAN028_BUNDLE_STORE_PASSWORD', 'WAKHAN028_BUNDLE_KEY_PASSWORD')
    previous = {name: os.environ.get(name) for name in names}
    try:
        os.environ[names[0]] = config['store_pass']
        os.environ[names[1]] = config['key_pass']
        run([*jarsigner, '-keystore', config['store'], '-storepass:env', names[0], '-keypass:env', names[1], '-digestalg', 'SHA-256', '-signedjar', signed, clean, config['alias']], work, 'SIGN_AAB', report, 120)
        run([*jarsigner, '-verify', signed], work, 'VERIFY_AAB_SIGNATURE', report, 120)
        result = run([keytool, '-printcert', '-jarfile', signed], work, 'VERIFY_AAB_CERTIFICATE', report, 120).decode('utf-8', 'replace')
        certificates = {value.replace(':', '').lower() for value in re.findall('SHA256:\\s*([0-9A-Fa-f:]{64,95})', result)}
        if certificates != {expected}:
            raise RuntimeError('AAB_RELEASE_CERTIFICATE_MISMATCH')
    finally:
        for name, value in previous.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value
        config.clear()
    return signed

VERSION = '0.2.39-beta'
BUILD = 54
CERTIFICATE = 'eb3eab7d1e1b109187295ebe26e36d7ec4e260c12810f74c2c8114be8dbee1b4'
SHELL = '3e1769b70f31792c483901ef37c6def13846239c6c1481ae3eeeae29535c5cce'
SOURCE = Path('/opt/wakhan-android/wakhan-beta238-home-mm1sm60n/project')
STATE = Path('/root/wakhan-0239-state.json')
PATCHES = ['android/app/build.gradle', 'ios-assets/native/MainViewController.swift', 'package-lock.json', 'package.json', 'public/home-ui/src/home.js', 'public/home-ui/src/native-home.css', 'public/home-ui/src/native-link.js', 'public/wakhan-release.json', 'public/wakhan-shell.json', 'scripts/build.mjs', 'src/approved-home.mjs', 'src/main.mjs', 'tests/salon-patch-manifest.json', 'public/games-ui/app.css', 'public/games-ui/app.js', 'public/games-ui/assets/ART_PROVENANCE.md', 'public/games-ui/assets/card-C10.svg', 'public/games-ui/assets/card-C11.svg', 'public/games-ui/assets/card-C12.svg', 'public/games-ui/assets/card-C13.svg', 'public/games-ui/assets/card-C14.svg', 'public/games-ui/assets/card-C2.svg', 'public/games-ui/assets/card-C3.svg', 'public/games-ui/assets/card-C4.svg', 'public/games-ui/assets/card-C5.svg', 'public/games-ui/assets/card-C6.svg', 'public/games-ui/assets/card-C7.svg', 'public/games-ui/assets/card-C8.svg', 'public/games-ui/assets/card-C9.svg', 'public/games-ui/assets/card-D10.svg', 'public/games-ui/assets/card-D11.svg', 'public/games-ui/assets/card-D12.svg', 'public/games-ui/assets/card-D13.svg', 'public/games-ui/assets/card-D14.svg', 'public/games-ui/assets/card-D2.svg', 'public/games-ui/assets/card-D3.svg', 'public/games-ui/assets/card-D4.svg', 'public/games-ui/assets/card-D5.svg', 'public/games-ui/assets/card-D6.svg', 'public/games-ui/assets/card-D7.svg', 'public/games-ui/assets/card-D8.svg', 'public/games-ui/assets/card-D9.svg', 'public/games-ui/assets/card-H10.svg', 'public/games-ui/assets/card-H11.svg', 'public/games-ui/assets/card-H12.svg', 'public/games-ui/assets/card-H13.svg', 'public/games-ui/assets/card-H14.svg', 'public/games-ui/assets/card-H2.svg', 'public/games-ui/assets/card-H3.svg', 'public/games-ui/assets/card-H4.svg', 'public/games-ui/assets/card-H5.svg', 'public/games-ui/assets/card-H6.svg', 'public/games-ui/assets/card-H7.svg', 'public/games-ui/assets/card-H8.svg', 'public/games-ui/assets/card-H9.svg', 'public/games-ui/assets/card-S10.svg', 'public/games-ui/assets/card-S11.svg', 'public/games-ui/assets/card-S12.svg', 'public/games-ui/assets/card-S13.svg', 'public/games-ui/assets/card-S14.svg', 'public/games-ui/assets/card-S2.svg', 'public/games-ui/assets/card-S3.svg', 'public/games-ui/assets/card-S4.svg', 'public/games-ui/assets/card-S5.svg', 'public/games-ui/assets/card-S6.svg', 'public/games-ui/assets/card-S7.svg', 'public/games-ui/assets/card-S8.svg', 'public/games-ui/assets/card-S9.svg', 'public/games-ui/assets/card-back.svg', 'public/games-ui/assets/chess-bb.svg', 'public/games-ui/assets/chess-bk.svg', 'public/games-ui/assets/chess-bn.svg', 'public/games-ui/assets/chess-bp.svg', 'public/games-ui/assets/chess-bq.svg', 'public/games-ui/assets/chess-br.svg', 'public/games-ui/assets/chess-wb.svg', 'public/games-ui/assets/chess-wk.svg', 'public/games-ui/assets/chess-wn.svg', 'public/games-ui/assets/chess-wp.svg', 'public/games-ui/assets/chess-wq.svg', 'public/games-ui/assets/chess-wr.svg', 'public/games-ui/assets/ludo-geometry.json', 'public/games-ui/assets/ono-b-0.svg', 'public/games-ui/assets/ono-b-1.svg', 'public/games-ui/assets/ono-b-2.svg', 'public/games-ui/assets/ono-b-3.svg', 'public/games-ui/assets/ono-b-4.svg', 'public/games-ui/assets/ono-b-5.svg', 'public/games-ui/assets/ono-b-6.svg', 'public/games-ui/assets/ono-b-7.svg', 'public/games-ui/assets/ono-b-8.svg', 'public/games-ui/assets/ono-b-9.svg', 'public/games-ui/assets/ono-b-draw2.svg', 'public/games-ui/assets/ono-b-reverse.svg', 'public/games-ui/assets/ono-b-skip.svg', 'public/games-ui/assets/ono-back.svg', 'public/games-ui/assets/ono-g-0.svg', 'public/games-ui/assets/ono-g-1.svg', 'public/games-ui/assets/ono-g-2.svg', 'public/games-ui/assets/ono-g-3.svg', 'public/games-ui/assets/ono-g-4.svg', 'public/games-ui/assets/ono-g-5.svg', 'public/games-ui/assets/ono-g-6.svg', 'public/games-ui/assets/ono-g-7.svg', 'public/games-ui/assets/ono-g-8.svg', 'public/games-ui/assets/ono-g-9.svg', 'public/games-ui/assets/ono-g-draw2.svg', 'public/games-ui/assets/ono-g-reverse.svg', 'public/games-ui/assets/ono-g-skip.svg', 'public/games-ui/assets/ono-r-0.svg', 'public/games-ui/assets/ono-r-1.svg', 'public/games-ui/assets/ono-r-2.svg', 'public/games-ui/assets/ono-r-3.svg', 'public/games-ui/assets/ono-r-4.svg', 'public/games-ui/assets/ono-r-5.svg', 'public/games-ui/assets/ono-r-6.svg', 'public/games-ui/assets/ono-r-7.svg', 'public/games-ui/assets/ono-r-8.svg', 'public/games-ui/assets/ono-r-9.svg', 'public/games-ui/assets/ono-r-draw2.svg', 'public/games-ui/assets/ono-r-reverse.svg', 'public/games-ui/assets/ono-r-skip.svg', 'public/games-ui/assets/ono-w-wild.svg', 'public/games-ui/assets/ono-w-wild4.svg', 'public/games-ui/assets/ono-y-0.svg', 'public/games-ui/assets/ono-y-1.svg', 'public/games-ui/assets/ono-y-2.svg', 'public/games-ui/assets/ono-y-3.svg', 'public/games-ui/assets/ono-y-4.svg', 'public/games-ui/assets/ono-y-5.svg', 'public/games-ui/assets/ono-y-6.svg', 'public/games-ui/assets/ono-y-7.svg', 'public/games-ui/assets/ono-y-8.svg', 'public/games-ui/assets/ono-y-9.svg', 'public/games-ui/assets/ono-y-draw2.svg', 'public/games-ui/assets/ono-y-reverse.svg', 'public/games-ui/assets/ono-y-skip.svg', 'public/games-ui/bridge.js', 'public/games-ui/index.html', 'public/games-ui/renderers/cards.js', 'public/games-ui/renderers/chess.js', 'public/games-ui/renderers/ludo.js', 'public/games-ui/renderers/world.js', 'public/games-ui/ui.js', 'public/games-ui/vendor/THREE_LICENSE.txt', 'public/games-ui/vendor/THREE_PROVENANCE.json', 'public/games-ui/vendor/three.module.js', 'public/games-ui/voice.js', 'src/edge-canvas.css', 'src/games-controller.mjs']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def require(value, message):
    if not value:
        raise RuntimeError(message)

def run(args, cwd, phase, report, timeout=120):
    print(phase, flush=True)
    result = subprocess.run([str(a) for a in args], cwd=cwd, capture_output=True, timeout=timeout)
    require(result.returncode == 0, phase + '_FAILED')
    return result.stdout

def copy_atomic(source, target):
    stat = target.stat()
    fd, temporary = tempfile.mkstemp(prefix='.wakhan-0239-', dir=target.parent)
    try:
        with os.fdopen(fd, 'wb') as out, Path(source).open('rb') as inp:
            shutil.copyfileobj(inp, out)
            out.flush()
            os.fsync(out.fileno())
            os.fchown(out.fileno(), stat.st_uid, stat.st_gid)
            os.fchmod(out.fileno(), stat.st_mode & 0o777)
        os.replace(temporary, target)
    finally:
        Path(temporary).unlink(missing_ok=True)


BACKEND_ENTRY_SHA='7c55c6bac1c2c3851ec80c3beb83521d035a202457e14e17c451f64092dd67b0'
BACKEND_ANCHOR="    ns['WKH_RANKINGS'].routes(app)\n"
BACKEND_INSERT="    from wakhan_games import install as install_games\n    install_games(app, ns)\n"

def checked_backend_patch(raw):
    require(hashlib.sha256(raw).hexdigest()==BACKEND_ENTRY_SHA,'BACKEND_SOURCE_CHANGED')
    text=raw.decode('utf-8');require(text.count(BACKEND_ANCHOR)==1,'BACKEND_ANCHOR_CHANGED')
    new=text.replace(BACKEND_ANCHOR,BACKEND_ANCHOR+BACKEND_INSERT,1);compile(new,'native_wakhan2.py','exec');return new.encode()

def prepare_backend(directory,live,report):
    entry=live/'native_wakhan2.py';require(entry.is_file() and not entry.is_symlink(),'BACKEND_ENTRY_MISSING');patched=checked_backend_patch(entry.read_bytes())
    package=live/'wakhan_games';require(not package.exists(),'GAMES_PACKAGE_ALREADY_EXISTS')
    pid=int(subprocess.run(['systemctl','show','wakhan-app.service','-p','MainPID','--value'],capture_output=True,text=True,check=True).stdout.strip())
    command=Path('/proc')/str(pid)/'cmdline';args=command.read_bytes().split(b'\0');python=Path(os.fsdecode(args[0]));require(python.is_absolute() and python.is_file() and 'python' in python.name,'SERVICE_PYTHON_NOT_FOUND')
    work=Path(tempfile.mkdtemp(prefix='.wakhan-games239-',dir=live));os.chmod(work,0o700);staged=work/'wakhan_games';staged.mkdir(mode=0o755)
    with zipfile.ZipFile(directory/'Wakhan-0.2.39-source.zip') as z:
        verification=json.loads(z.read('source-verification.json'));hashes={}
        for name,digest in verification['backend_sha256'].items():
            relative=Path(name).relative_to('server/wakhan_games');require(not relative.is_absolute() and '..' not in relative.parts,'BACKEND_PATH_INVALID');data=z.read(name);require(hashlib.sha256(data).hexdigest()==digest,'BACKEND_FILE_CHANGED');target=staged/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);os.chmod(target,0o644);hashes[relative.as_posix()]=digest
    for folder in staged.rglob('*'):
        if folder.is_dir():os.chmod(folder,0o755)
    (work/'native_wakhan2.new.py').write_bytes(patched)
    run([python,'-c',"import pathlib,sys;root=pathlib.Path(sys.argv[1]);[compile(p.read_text(),str(p),'exec') for p in root.rglob('*.py')];sys.path.insert(0,str(root));import aiohttp;from wakhan_games.catalog import public_catalog;assert len(public_catalog())==6",work],work,'COMPILE_NEW_BACKEND_WITH_SERVICE_PYTHON',report)
    shutil.copy2(entry,work/'native_wakhan2.before.py');os.chmod(work/'native_wakhan2.before.py',0o600)
    latest=live/'releases/latest.json';require(not latest.is_symlink(),'LATEST_PATH_INVALID')
    if latest.exists():shutil.copy2(latest,work/'latest.before.json')
    require(sha(entry)==BACKEND_ENTRY_SHA,'BACKEND_CHANGED_DURING_PREFLIGHT')
    database=Path('/opt/wakhan-music/data/music.db');require(database.is_file() and not database.is_symlink(),'LIVE_DATABASE_MISSING')
    backup=Path('/root')/('wakhan-before-games239-'+str(int(time.time()))+'.sqlite');fd=os.open(backup,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.close(fd)
    source=sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True);destination=sqlite3.connect(backup)
    try:source.backup(destination)
    finally:source.close();destination.close()
    report['database_backup']=str(backup);report['backend_original_backup']=str(work/'native_wakhan2.before.py')
    return dict(live=live,work=work,package=package,sha256=hashes,entry=entry,changed=False,had_latest=latest.exists())

def check_health():
    with urllib.request.urlopen('http://127.0.0.1:10010/health',timeout=5) as r:require(json.load(r).get('ok') is True,'HEALTH_INVALID')
    for path in ('/api/app/games/catalog','/api/app/games/ws','/api/app/home/rankings?category=games&period=month'):
        try:
            with urllib.request.urlopen('http://127.0.0.1:10010'+path,timeout=5) as r:status=r.status
        except urllib.error.HTTPError as e:status=e.code
        require(status==401,'GAME_ROUTE_HEALTH_FAILED:'+path)

def commit_backend(state,report):
    require(sha(state['entry'])==BACKEND_ENTRY_SHA,'BACKEND_CHANGED_BEFORE_COMMIT')
    state['changed']=True;os.replace(state['work']/'wakhan_games',state['package']);copy_atomic(state['work']/'native_wakhan2.new.py',state['entry'])
    run(['systemctl','restart','wakhan-app.service'],state['live'],'RESTART_APP_WITH_GAMES',report)
    last=None
    for attempt in range(30):
        try:check_health();return
        except Exception as e:last=e;time.sleep(.5)
    raise RuntimeError('NEW_BACKEND_HEALTH_FAILED') from last

def rollback_backend(state,report):
    if not state.get('changed'):return
    report['backend_rollback_attempted']=True
    copy_atomic(state['work']/'native_wakhan2.before.py',state['entry'])
    if state['package'].exists():os.replace(state['package'],state['work']/'wakhan_games.not-active')
    latest=state['live']/'releases/latest.json'
    if state['had_latest']:
        if latest.exists():copy_atomic(state['work']/'latest.before.json',latest)
        else:shutil.copy2(state['work']/'latest.before.json',latest)
    elif latest.exists():latest.unlink()
    run(['systemctl','restart','wakhan-app.service'],state['live'],'RESTORE_PREVIOUS_BACKEND',report)
    report['backend_rolled_back']=True;report['additive_game_tables_retained']=True;state['changed']=False

def publish_latest(live,digest,state):
    target=live/'releases/latest.json';data=json.loads(target.read_text()) if target.exists() else {};data.update(version=VERSION,build=BUILD,sha256=digest,url='https://music.kabulcafe.uk/download/Wakhan.apk?build=54');new=state['work']/'latest.new.json';new.write_text(json.dumps(data,indent=2))
    if target.exists():copy_atomic(new,target)
    else:
        fd,name=tempfile.mkstemp(prefix='.latest-games239-',dir=target.parent)
        with os.fdopen(fd,'wb') as out:out.write(new.read_bytes());out.flush();os.fsync(out.fileno());os.fchmod(out.fileno(),0o644)
        os.replace(name,target)
    with urllib.request.urlopen('http://127.0.0.1:10010/api/app/latest',timeout=5) as r:value=json.load(r)
    require(value.get('build')==BUILD and value.get('version')==VERSION,'LATEST_API_MISMATCH')

def execute(directory, report):
    require(os.geteuid() == 0, 'RUN_AS_ROOT')
    manifest = json.loads((directory / 'PACKAGE.json').read_text())
    require(manifest.get('version') == VERSION and manifest.get('build') == BUILD, 'WRONG_PACKAGE')
    for name, digest in manifest['sha256'].items():
        path = directory / name
        require(not path.is_symlink() and path.resolve().is_relative_to(directory.resolve())
                and sha(path) == digest, 'PACKAGE_FILE_CHANGED')
    saved_state = STATE
    if saved_state.exists():
        require(not saved_state.is_symlink(), 'STATE_PATH_INVALID')
        saved = json.loads(saved_state.read_text())
        require(saved.get('package_sha256') == sha(directory / 'PACKAGE.json'), 'PREVIOUS_PACKAGE_DIFFERS')
        for field, digest in [('signed_apk', 'apk_sha256'), ('signed_aab', 'aab_sha256'), ('published_path', 'apk_sha256')]:
            path = Path(saved[field])
            require(not path.is_symlink() and path.is_file() and sha(path) == saved[digest], 'PREVIOUS_OUTPUT_CHANGED')
        if saved.get('backend_path'):
            live=Path(saved['backend_path']);require(sha(live/'native_wakhan2.py')==saved['backend_entry_sha256'],'PREVIOUS_BACKEND_CHANGED')
            for name,digest in saved['backend_package_sha256'].items():require(sha(live/'wakhan_games'/name)==digest,'PREVIOUS_BACKEND_PACKAGE_CHANGED')
            check_health()
        report.update(saved)
        print('ALREADY_COMPLETED_AND_VERIFIED', flush=True)
        return
    baseline = json.loads((directory / 'base0238.json').read_text())
    require(not SOURCE.is_symlink() and SOURCE.is_dir(), 'CURRENT_0238_SOURCE_MISSING')
    for name, digest in baseline.items():
        path = SOURCE / name
        require(path.is_file() and not path.is_symlink() and sha(path) == digest,
                'CURRENT_SOURCE_CHANGED:' + name)
    unsigned = directory / 'app-release-unsigned.apk'
    with zipfile.ZipFile(unsigned) as z:
        require(z.testzip() is None, 'ANDROID_ZIP_INVALID')
        require(hashlib.sha256(z.read('assets/public/wakhan-shell.json')).hexdigest() == SHELL,
                'ME_AND_SALON_SOURCE_DIFFER')
        release = json.loads(z.read('assets/public/wakhan-release.json'))
        require(release.get('version') == VERSION and release.get('build') == BUILD, 'APK_RELEASE_MISMATCH')
    service = subprocess.run(['systemctl', 'show', 'wakhan-app.service', '-p', 'WorkingDirectory', '--value'],
                             capture_output=True, text=True, check=True).stdout.strip()
    live = Path(service)
    require(live.is_absolute() and live.is_dir() and not live.is_symlink(), 'LIVE_APP_DIRECTORY_INVALID')
    releases = live / 'releases'
    target = releases / 'Wakhan.apk'
    require(releases.is_dir() and not releases.is_symlink() and target.is_file()
            and not target.is_symlink(), 'CURRENT_DOWNLOAD_MISSING')
    require(signer_hashes(target) == [CERTIFICATE], 'CURRENT_APK_SIGNER_DIFFERS')
    require(sha(target) == '9333706dfe6c5d28168b83cc27babfd0fabaab87a87d684f750565e3c7f29bbc', 'CURRENT_PUBLIC_APK_CHANGED')
    require(sha(live / 'wakhan_home_rankings.py') == '9abf0df62104653578d457124f4b468a932dc1d8dd0c1536524785da9ee67aa2', 'HOME_RANKINGS_SOURCE_CHANGED')
    sdk_roots = [Path(v) for v in (os.environ.get('ANDROID_HOME'), os.environ.get('ANDROID_SDK_ROOT')) if v]
    sdk_roots += [Path(v) for v in ('/opt/android-sdk', '/opt/android-sdk-linux', '/root/Android/Sdk',
                                  '/usr/lib/android-sdk', '/opt/wakhan-android/sdk', '/opt/wakhan-android/android-sdk')]
    tools = [p for sdk in sdk_roots for p in sdk.glob('build-tools/*/apksigner') if p.is_file()]
    require(tools, 'ANDROID_BUILD_TOOLS_NOT_FOUND')
    signer = sorted(tools, key=lambda p: [int(x) if x.isdigit() else x for x in re.split(r'(\d+)', str(p))])[-1]
    tool_dir = signer.parent
    require((tool_dir / 'aapt').is_file(), 'AAPT_NOT_FOUND')
    def check_apk(apk):
        value = run([tool_dir / 'aapt', 'dump', 'badging', apk], directory, 'CHECK_APK_VERSION', report).decode()
        match = re.search(r"package: name='([^']+)' versionCode='([^']+)' versionName='([^']+)'", value)
        require(match and match.groups() == ('app.wakhan.music', str(BUILD), VERSION), 'APK_BINARY_VERSION_MISMATCH')
    check_apk(unsigned)
    work = Path(tempfile.mkdtemp(prefix='wakhan-0239-sign-', dir='/opt/wakhan-android'))
    backend = prepare_backend(directory,live,report)
    config = read_existing_configuration('/opt/wakhan-android/keys/release.properties', CERTIFICATE)
    signed = sign_release(unsigned, tool_dir, work, config, run, report)
    run([signer, 'verify', '--verbose', signed], work, 'VERIFY_APK_SIGNATURE', report)
    require(signer_hashes(signed) == [CERTIFICATE], 'SIGNED_APK_CERTIFICATE_MISMATCH')
    check_apk(signed)
    config = read_existing_configuration('/opt/wakhan-android/keys/release.properties', CERTIFICATE)
    bundle = sign_bundle(directory / 'app-release.aab', work, config, CERTIFICATE, run, report)
    for artifact, filename in [(signed, 'Wakhan-0.2.39-beta-test.apk'), (bundle, 'Wakhan-0.2.39-beta-release.aab')]:
        destination = Path('/root') / filename
        require(not destination.is_symlink(),'OUTPUT_PATH_INVALID')
        if destination.exists() and sha(destination)!=sha(artifact):
            previous=destination.with_name(destination.name+'.before-retry-'+sha(destination)[:16]);require(not previous.exists(),'RETRY_BACKUP_CONFLICT');os.replace(destination,previous)
        if not destination.exists():
            with destination.open('xb') as out, artifact.open('rb') as inp:
                os.fchmod(out.fileno(), 0o600)
                shutil.copyfileobj(inp, out)
    ipa=directory/'Wakhan-0.2.39-beta.ipa'
    with zipfile.ZipFile(ipa) as z:require(z.testzip() is None,'IOS_ZIP_INVALID')
    ipa_target=Path('/root/Wakhan-0.2.39-beta.ipa')
    require(not ipa_target.exists() or not ipa_target.is_symlink() and sha(ipa_target)==sha(ipa),'DIFFERENT_IPA_ALREADY_EXISTS')
    if not ipa_target.exists():
        with ipa_target.open('xb') as out,ipa.open('rb') as inp:
            os.fchmod(out.fileno(),0o600);shutil.copyfileobj(inp,out)
    report['iphone_ipa']=str(ipa_target)
    report['iphone_requires_sideloadly']=True
    stage = Path(tempfile.mkdtemp(prefix='wakhan-beta239-games-', dir='/opt/wakhan-android')) / 'project'
    shutil.copytree(SOURCE, stage, symlinks=True,
                    ignore=shutil.ignore_patterns('node_modules', '.git', '.gradle', 'build', 'www', 'dist'))
    with zipfile.ZipFile(directory / 'Wakhan-0.2.39-source.zip') as z:
        for name in PATCHES:
            destination = stage / name
            require(not destination.is_symlink() and destination.resolve().is_relative_to(stage.resolve()), 'STAGE_PATH_INVALID')
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(z.read('project/' + name))
    assets = stage / 'android/app/src/main/assets'
    if (assets / 'public').exists():
        shutil.rmtree(assets / 'public')
    with zipfile.ZipFile(unsigned) as z:
        for name in z.namelist():
            if name.startswith('assets/') and not name.endswith('/'):
                relative = Path(name.removeprefix('assets/'))
                require(not relative.is_absolute() and '..' not in relative.parts, 'ASSET_PATH_INVALID')
                destination = assets / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(z.read(name))
    require(sha(stage / 'public/wakhan-shell.json') == SHELL, 'STAGE_SHELL_CHANGED')
    previous_sha = sha(target)
    backup = releases / ('Wakhan-before-0.2.39-' + previous_sha[:16] + '.apk')
    require(not backup.exists() or (not backup.is_symlink() and sha(backup) == previous_sha), 'BACKUP_CONFLICT')
    if not backup.exists():
        with backup.open('xb') as out, target.open('rb') as inp:
            os.fchmod(out.fileno(), target.stat().st_mode & 0o777)
            os.fchown(out.fileno(), target.stat().st_uid, target.stat().st_gid)
            shutil.copyfileobj(inp, out)
            out.flush()
            os.fsync(out.fileno())
    try:
        commit_backend(backend,report)
        copy_atomic(signed,target)
        publish_latest(live,sha(signed),backend)
    except BaseException:
        copy_atomic(backup,target)
        rollback_backend(backend,report)
        raise
    try:
        request = urllib.request.Request('http://127.0.0.1:10010/download/Wakhan.apk', headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=30) as response:
            digest = hashlib.sha256()
            while chunk := response.read(1024 * 1024):
                digest.update(chunk)
        require(digest.hexdigest() == sha(signed), 'PUBLISHED_DOWNLOAD_DIFFERS')
    except BaseException:
        copy_atomic(backup, target)
        report['download_rolled_back'] = True
        rollback_backend(backend,report)
        raise
    report.update(ok=True, version=VERSION, build=BUILD, original_signer_verified=True,
                  signed_apk='/root/Wakhan-0.2.39-beta-test.apk', apk_sha256=sha(signed),
                  signed_aab='/root/Wakhan-0.2.39-beta-release.aab', aab_sha256=sha(bundle),
                  source_project=str(stage), download_published=True, previous_apk_retained=True,
                  services_changed=True, database_changed=True, database_changes='additive-wkg-tables-only', server_health_verified=True, backend_path=str(live), backend_entry_sha256=sha(live/'native_wakhan2.py'), backend_package_sha256=backend['sha256'], physical_device_verified=False,
                  published_path=str(target), package_sha256=sha(directory / 'PACKAGE.json'))
    fd, temporary = tempfile.mkstemp(prefix='.wakhan-0239-state-', dir='/root')
    try:
        with os.fdopen(fd, 'w') as out:
            json.dump(report, out, indent=2)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, saved_state)
    except BaseException:
        copy_atomic(backup, target)
        report['ok'] = False
        report['download_rolled_back'] = True
        rollback_backend(backend,report)
        raise
    finally:
        Path(temporary).unlink(missing_ok=True)

if __name__ == '__main__':
    report = {'ok': False, 'services_changed': False, 'database_changed': False}
    try:
        import fcntl
        lock = open('/root/.wakhan-home0239.lock', 'a')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        execute(Path(__file__).resolve().parent, report)
    except Exception as error:
        report['ok'] = False
        report['error'] = str(error) if isinstance(error, RuntimeError) else type(error).__name__
        print('STOP:', report['error'], flush=True)
    finally:
        destination = Path('/root/wakhan-0239-result.zip')
        fd, temporary = tempfile.mkstemp(prefix='.wakhan-0239-report-', dir='/root')
        with os.fdopen(fd, 'wb') as handle, zipfile.ZipFile(handle, 'w', zipfile.ZIP_DEFLATED) as z:
            z.writestr('result.json', json.dumps(report, indent=2))
        os.replace(temporary, destination)
        print('REPORT:', destination, flush=True)
    if not report['ok']:
        raise SystemExit(1)
    print('ANDROID_READY: https://music.kabulcafe.uk/download/Wakhan.apk?build=54', flush=True)
