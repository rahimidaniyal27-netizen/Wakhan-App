"""Verify both unsigned native packages against the exact reviewed source archive."""
import hashlib,json,plistlib,sys,zipfile
from pathlib import Path
r=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(r/'Wakhan-0.2.41-source.zip') as source:
 assert source.testzip() is None
 manifest=json.loads(source.read('source-verification.json'))
 for n,h in manifest['source_sha256'].items():assert sha(source.read('project/'+n))==h,n
 assert manifest['backend_entry_sha256']=='53ea7252b344d2843ecf7c3f4f27be7a11df39dd258ae184d287f4ac19ccb8e2'
 native=source.read('project/ios-assets/native/MainViewController.swift');assert b'web.topAnchor.constraint(equalTo: view.topAnchor)' in native and b'safeAreaLayoutGuide' not in native
 result={'version':'0.2.41-beta','build':56,'source_sha256':sha((r/'Wakhan-0.2.41-source.zip').read_bytes()),'server_update_required':False,'physical_device_verified':False}
 for platform,filename in [('android','app-release-unsigned.apk'),('ios','Wakhan-0.2.41-beta.ipa')]:
  with zipfile.ZipFile(r/filename) as z:
   assert z.testzip() is None
   if platform=='ios':
    info=next(n for n in z.namelist() if n.count('/')==2 and n.endswith('.app/Info.plist'));v=plistlib.loads(z.read(info));base=info.rsplit('/',1)[0];assert v['CFBundleIdentifier']=='app.wakhan.music';assert v['CFBundleShortVersionString']=='0.2.41' and str(v['CFBundleVersion'])=='56';assert b'safeArea:' in z.read(base+'/'+v['CFBundleExecutable']);prefix=base+'/'
   else:prefix='assets/'
   release=json.loads(z.read(prefix+'public/wakhan-release.json'));assert release['version']=='0.2.41-beta' and release['build']==56 and release['games_available'] and release['server_update_required'] is False
   for n,h in manifest['source_sha256'].items():
    if n.startswith('public/') and n not in ('public/build-flags.json','public/wakhan-release.json'):assert sha(z.read(prefix+n))==h,platform+':'+n
   js=b''.join(z.read(n) for n in z.namelist() if n.startswith(prefix+'public/assets/index-') and n.endswith('.js'))
   for marker in (b'wk-shared-nav',b'wakhan-games-v1',b'account_changed',b'state-transport',b'wakhan-music-v1',b'data-audius-cover',b'/api/app/music/chart',b'rgba(49,41,67,.68)'):assert marker in js,(platform,marker)
   if platform=='ios':assert b'WakhanDownloadsPlugin' in z.read(base+'/'+v['CFBundleExecutable']), 'Native offline plugin missing'
   else:assert any(b'WakhanDownloads' in z.read(n) for n in z.namelist() if n.endswith('.dex')), 'Native offline plugin missing'
   result[platform+'_assets_match_source']=True
 result['sha256']={n:sha((r/n).read_bytes()) for n in ('Wakhan-0.2.41-beta.ipa','app-release-unsigned.apk','app-release.aab')}
(r/'native-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
