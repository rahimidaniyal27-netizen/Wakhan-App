import asyncio,json
from playwright.async_api import async_playwright
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=await b.new_page()
  await page.route('**/api/app/music/**',lambda r:r.fulfill(json={'ok':True,'items':[],'sources':[]}))
  await page.goto('http://127.0.0.1:8786/review/music-preview.html');await page.wait_for_function('window.ready')
  await page.evaluate('''()=>{window.mutations=0;window.loopDetected=false;const watch=new MutationObserver(events=>{mutations+=events.length;if(mutations>40){loopDetected=true;watch.disconnect();ui.dispose()}});watch.observe(document.body,{attributes:true,attributeFilter:['class']});route('h')}''')
  await page.wait_for_timeout(150);print(json.dumps(await page.evaluate('({loopDetected,mutations})')),flush=True);await b.close()
asyncio.run(main())
