import unittest,tempfile,hashlib,json,importlib.util
from pathlib import Path
from unittest.mock import patch
R=Path(__file__).resolve().parents[1];spec=importlib.util.spec_from_file_location('installer',R/'sign-and-publish.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class ClientOnly(unittest.TestCase):
 def fixture(self,root):
  (root/'releases').mkdir();(root/'releases/latest.json').write_text('{"build":55}');(root/'native_wakhan2.py').write_bytes(b'original server');(root/'wakhan_music').mkdir()
  for n in m.BACKEND_PACKAGE_SHA:(root/'wakhan_music'/n).write_bytes(b'original '+n.encode())
  hashes={n:m.sha(root/'wakhan_music'/n)for n in m.BACKEND_PACKAGE_SHA};return hashes
 def test_commit_verifies_without_service_or_db_writes(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);hashes=self.fixture(root);report={}
   with patch.object(m,'BACKEND_ENTRY_SHA',m.sha(root/'native_wakhan2.py')),patch.object(m,'BACKEND_PACKAGE_SHA',hashes),patch.object(m,'check_health'),patch.object(m.subprocess,'run')as process,patch.object(m.sqlite3,'connect')as database:
    state=m.prepare_backend(root,root,report);m.commit_backend(state,report);process.assert_not_called();database.assert_not_called()
   self.assertEqual((root/'native_wakhan2.py').read_bytes(),b'original server');self.assertTrue(report['existing_backend_verified']);self.assertFalse(state['changed'])
 def test_runtime_drift_stops_before_client_publication(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);self.fixture(root)
   with patch.object(m,'check_health')as health:
    with self.assertRaisesRegex(RuntimeError,'EXISTING_BACKEND_CHANGED'):m.prepare_backend(root,root,{})
    health.assert_not_called()
 def test_rollback_restores_latest_without_restart(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);hashes=self.fixture(root);report={}
   with patch.object(m,'BACKEND_ENTRY_SHA',m.sha(root/'native_wakhan2.py')),patch.object(m,'BACKEND_PACKAGE_SHA',hashes),patch.object(m,'check_health'),patch.object(m.subprocess,'run')as process:
    state=m.prepare_backend(root,root,report);state['latest_attempted']=True;(root/'releases/latest.json').write_text('{"build":56}');m.rollback_backend(state,report);process.assert_not_called()
   self.assertEqual(json.loads((root/'releases/latest.json').read_text())['build'],55);self.assertTrue(report['latest_rolled_back'])
if __name__=='__main__':unittest.main()
