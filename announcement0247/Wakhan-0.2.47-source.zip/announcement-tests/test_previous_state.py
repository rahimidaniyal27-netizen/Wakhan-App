import importlib.util,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('installer',ROOT/'sign-and-publish.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class PreviousState(unittest.TestCase):
 def valid(self):return dict(ok=True,version='0.2.46-beta',build=61,package_sha256='10e3a4887aabaef186a17f386055a19018ed3488685ff36dd613b6e656ddc028',apk_sha256='1c25ed88ddfeeea41127479d7f3db11f44e85c25d8369c7431a4519b39760621',original_signer_verified=True,backend_path='/opt/wakhan-app-0.2.11-li9z037x',backend_entry_sha256=m.BACKEND_ENTRY_SHA,source_project='/opt/wakhan-android/wakhan-beta246-restored-review/project')
 def check(self,value):
  with tempfile.TemporaryDirectory()as d:
   p=Path(d)/'state.json';p.write_text(json.dumps(value));real=Path
   with patch.object(m,'Path',side_effect=lambda v:p if v=='/root/wakhan-0246-state.json'else real(v)):return m.previous_source()
 def test_exact_completed_state_selects_source_without_guessing(self):self.assertEqual(str(self.check(self.valid())),self.valid()['source_project'])
 def test_incomplete_modified_or_future_state_fails_closed(self):
  for key,value in [('ok',False),('version','0.2.45-beta'),('build',62),('package_sha256','x'),('apk_sha256','x'),('original_signer_verified',False),('backend_path','/tmp/other'),('backend_entry_sha256','x'),('source_project','/tmp/project')]:
   with self.subTest(key=key),self.assertRaises(RuntimeError):self.check({**self.valid(),key:value})
if __name__=='__main__':unittest.main()
