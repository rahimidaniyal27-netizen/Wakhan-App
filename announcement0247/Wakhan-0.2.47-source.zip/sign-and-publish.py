import hashlib,json,os,re,shutil,subprocess,tempfile,zipfile,struct,urllib.request,urllib.error,time,sqlite3
from pathlib import Path


FIELDS = {'store': ('storefile', 'keystorefile', 'keystorepath', 'storepath', 'keystore'), 'alias': ('keyalias', 'releasealias', 'alias'), 'store_pass': ('storepassword', 'keystorepassword', 'keystorepass', 'storepass', 'password'), 'key_pass': ('keypassword', 'keypass')}

def unescape(value):

    def decode(m):
        s = m.group(1)
        if s.startswith('u') and len(s) == 5:
            return chr(int(s[1:], 16))
        return {'t': '\t', 'n': '\n', 'r': '\r', 'f': '\x0c'}.get(s, s)
    return re.sub('\\\\(u[0-9a-fA-F]{4}|.)', decode, value)

def properties(text, env=False):
    result = {}
    pending = ''
    for raw in text.splitlines():
        line = pending + raw.lstrip() if pending else raw
        if len(line) - len(line.rstrip('\\')) & 1:
            pending = line[:-1]
            continue
        pending = ''
        line = line.lstrip()
        if not line or line.startswith(('#', '!')):
            continue
        if env and line.startswith('export '):
            line = line[7:].lstrip()
        m = re.match('((?:\\\\.|[^\\s:=])+)(?:\\s*[=:]\\s*|\\s+)(.*)\\Z', line)
        if not m:
            continue
        key, value = m.groups()
        if env and len(value) >= 2 and (value[0] == value[-1]) and (value[0] in ('"', "'")):
            quote = value[0]
            value = value[1:-1]
            if quote == '"':
                value = value.replace('\\"', '"').replace('\\\\', '\\')
        elif not env:
            value = unescape(value)
        result[unescape(key)] = value
    return result

def normalize(values):
    normalized = {re.sub('[^a-z0-9]', '', str(k).lower()): v for k, v in values.items() if isinstance(v, (str, Path))}
    output = {}
    for field, endings in FIELDS.items():
        found = []
        for key, value in normalized.items():
            if any((key == ending or (key.endswith(ending) and any((prefix in key for prefix in ('wakhan', 'android', 'release', 'upload', 'signing', 'myapp')))) for ending in endings)):
                found.append(str(value))
        unique = list(dict.fromkeys(found))
        if len(unique) == 1:
            output[field] = unique[0]
        elif len(unique) > 1:
            return None
    if 'store' not in output or 'store_pass' not in output:
        return None
    output.setdefault('key_pass', output['store_pass'])
    output.setdefault('alias', '')
    return output

def key_certificate(config):
    keytool = shutil.which('keytool')
    if not keytool:
        raise RuntimeError('JAVA_KEYTOOL_NOT_FOUND')
    env = {**os.environ, 'WAKHAN_SIGNING_STORE_PASS': config['store_pass']}
    try:
        if not config.get('alias'):
            listed = subprocess.run([keytool, '-J-Duser.language=en', '-list', '-rfc', '-keystore', config['store'], '-storepass:env', 'WAKHAN_SIGNING_STORE_PASS'], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
            if listed.returncode:
                return None
            aliases = re.findall('^Alias name: (.+)$', listed.stdout.decode('utf-8', 'replace'), re.M)
            if len(aliases) != 1:
                return None
            config['alias'] = aliases[0].strip()
        result = subprocess.run([keytool, '-exportcert', '-keystore', config['store'], '-alias', config['alias'], '-storepass:env', 'WAKHAN_SIGNING_STORE_PASS'], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
        return hashlib.sha256(result.stdout).hexdigest() if result.returncode == 0 else None
    finally:
        env.pop('WAKHAN_SIGNING_STORE_PASS', None)

def read_existing_configuration(path, expected_certificate):
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise RuntimeError('EXISTING_RELEASE_PROPERTIES_NOT_FOUND')
    config = normalize(properties(path.read_text()))
    if not config:
        raise RuntimeError('EXISTING_RELEASE_PROPERTIES_INVALID')
    store = Path(config['store'])
    if not store.is_absolute():
        store = path.parent / store
    if not store.is_file():
        raise RuntimeError('EXISTING_RELEASE_KEYSTORE_NOT_FOUND')
    config['store'] = str(store.resolve())
    if key_certificate(config) != expected_certificate:
        config.clear()
        raise RuntimeError('EXISTING_RELEASE_CERTIFICATE_MISMATCH')
    return config

def sign_release(apk, tools, work, config, run, report):
    aligned = work / 'aligned.apk'
    signed = work / 'signed.apk'
    run([tools / 'zipalign', '-f', '-P', '16', '4', apk, aligned], work, 'ALIGN_APK', report, 120)
    store_name = 'WAKHAN_BETA27_STORE_PASSWORD'
    key_name = 'WAKHAN_BETA27_KEY_PASSWORD'
    previous = {name: os.environ.get(name) for name in (store_name, key_name)}
    try:
        os.environ[store_name] = config['store_pass']
        os.environ[key_name] = config['key_pass']
        run([tools / 'apksigner', 'sign', '--ks', config['store'], '--ks-key-alias', config['alias'], '--ks-pass', 'env:' + store_name, '--key-pass', 'env:' + key_name, '--out', signed, aligned], work, 'SIGN_APK', report, 120)
    finally:
        for name, value in previous.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value
        config.clear()
    return signed

def lp(data, at=0):
    if at + 4 > len(data):
        raise ValueError('APK_SIGNATURE_TRUNCATED')
    size = struct.unpack_from('<I', data, at)[0]
    end = at + 4 + size
    if end > len(data):
        raise ValueError('APK_SIGNATURE_TRUNCATED')
    return (data[at + 4:end], end)

def signer_hashes(path):
    data = Path(path).read_bytes()
    eocd = data.rfind(b'PK\x05\x06', max(0, len(data) - 65557))
    if eocd < 0:
        raise ValueError('APK_DIRECTORY_NOT_FOUND')
    central = struct.unpack_from('<I', data, eocd + 16)[0]
    if data[central - 16:central] != b'APK Sig Block 42':
        raise ValueError('APK_SIGNING_BLOCK_NOT_FOUND')
    size = struct.unpack_from('<Q', data, central - 24)[0]
    start = central - size - 8
    if start < 0 or struct.unpack_from('<Q', data, start)[0] != size:
        raise ValueError('APK_SIGNING_BLOCK_INVALID')
    hashes = set()
    at = start + 8
    while at < central - 24:
        length = struct.unpack_from('<Q', data, at)[0]
        at += 8
        end = at + length
        if length < 4 or end > central - 24:
            raise ValueError('APK_SIGNATURE_TRUNCATED')
        kind = struct.unpack_from('<I', data, at)[0]
        value = data[at + 4:end]
        at = end
        if kind not in (1896449818, 4031998144):
            continue
        signers, _ = lp(value)
        pos = 0
        while pos < len(signers):
            signer, pos = lp(signers, pos)
            signed, _ = lp(signer)
            _, offset = lp(signed)
            certificates, _ = lp(signed, offset)
            certificate, _ = lp(certificates)
            hashes.add(hashlib.sha256(certificate).hexdigest())
    if not hashes:
        raise ValueError('APK_NO_SIGNER_CERTIFICATE')
    return sorted(hashes)

def sign_bundle(bundle, work, config, expected, run, report):
    try:
        return _sign_bundle(bundle, work, config, expected, run, report)
    finally:
        config.clear()

def _sign_bundle(bundle, work, config, expected, run, report):
    executable = shutil.which('jarsigner')
    java = shutil.which('java')
    keytool = shutil.which('keytool')
    jarsigner = [executable] if executable else [java, '-m', 'jdk.jartool/sun.security.tools.jarsigner.Main'] if java else []
    if not jarsigner or not keytool:
        raise RuntimeError('BUNDLE_SIGNING_TOOLS_NOT_FOUND')
    clean = work / 'unsigned-clean.aab'
    signed = work / 'signed.aab'
    with zipfile.ZipFile(bundle) as source, zipfile.ZipFile(clean, 'x', zipfile.ZIP_DEFLATED) as target:
        if 'BundleConfig.pb' not in source.namelist():
            raise RuntimeError('ANDROID_BUNDLE_INVALID')
        for entry in source.infolist():
            if entry.filename.upper() == 'META-INF/MANIFEST.MF' or re.fullmatch('META-INF/[^/]+\\.(SF|RSA|DSA|EC)', entry.filename, re.I):
                continue
            target.writestr(entry, source.read(entry))
    names = ('WAKHAN028_BUNDLE_STORE_PASSWORD', 'WAKHAN028_BUNDLE_KEY_PASSWORD')
    previous = {name: os.environ.get(name) for name in names}
    try:
        os.environ[names[0]] = config['store_pass']
        os.environ[names[1]] = config['key_pass']
        run([*jarsigner, '-keystore', config['store'], '-storepass:env', names[0], '-keypass:env', names[1], '-digestalg', 'SHA-256', '-signedjar', signed, clean, config['alias']], work, 'SIGN_AAB', report, 120)
        run([*jarsigner, '-verify', signed], work, 'VERIFY_AAB_SIGNATURE', report, 120)
        result = run([keytool, '-printcert', '-jarfile', signed], work, 'VERIFY_AAB_CERTIFICATE', report, 120).decode('utf-8', 'replace')
        certificates = {value.replace(':', '').lower() for value in re.findall('SHA256:\\s*([0-9A-Fa-f:]{64,95})', result)}
        if certificates != {expected}:
            raise RuntimeError('AAB_RELEASE_CERTIFICATE_MISMATCH')
    finally:
        for name, value in previous.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value
        config.clear()
    return signed

VERSION = '0.2.47-beta'
BUILD = 62
CERTIFICATE = 'eb3eab7d1e1b109187295ebe26e36d7ec4e260c12810f74c2c8114be8dbee1b4'
SHELL = '2bf552f1503b97aa2717e2fdbb6574deae0154c624c8f7ba2dc8b5170bd1925b'
SOURCE = None
STATE = Path('/root/wakhan-0247-state.json')
PATCHES = ['android/app/build.gradle', 'package-lock.json', 'package.json', 'public/home-ui/src/home.js', 'public/wakhan-release.json', 'public/wakhan-shell.json', 'src/approved-home.mjs', 'src/main.mjs', 'src/salon-announcement.mjs', 'tests/cinema-chat-integration.test.mjs', 'tests/salon-patch-manifest.json', 'src/salon-announcement-feed.mjs', 'tests/salon-announcement-feed.test.mjs']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def require(value, message):
    if not value:
        raise RuntimeError(message)

def run(args, cwd, phase, report, timeout=120):
    print(phase, flush=True)
    result = subprocess.run([str(a) for a in args], cwd=cwd, capture_output=True, timeout=timeout)
    require(result.returncode == 0, phase + '_FAILED')
    return result.stdout

def copy_atomic(source, target):
    stat = target.stat()
    fd, temporary = tempfile.mkstemp(prefix='.wakhan-0247-', dir=target.parent)
    try:
        with os.fdopen(fd, 'wb') as out, Path(source).open('rb') as inp:
            shutil.copyfileobj(inp, out)
            out.flush()
            os.fsync(out.fileno())
            os.fchown(out.fileno(), stat.st_uid, stat.st_gid)
            os.fchmod(out.fileno(), stat.st_mode & 0o777)
        os.replace(temporary, target)
    finally:
        Path(temporary).unlink(missing_ok=True)


BACKEND_ENTRY_SHA='53ea7252b344d2843ecf7c3f4f27be7a11df39dd258ae184d287f4ac19ccb8e2'
BACKEND_PACKAGE_SHA={'__init__.py': '04b1a9897a129b626f4d294fd1584a8c0d71b7abda4b77bd79d642d0af4b89cb', 'discovery.py': 'dfc7e95cb8855ddb92b7fb96a58789f250dadeed92189cb8311664fc3113ef2c', 'preferences.py': 'd9782f97d04ce1b6d68be22e8acde84c04932e3a54e1bc36768925e147e78a22', 'providers.py': 'b37bf7f19770c1783539fad6fd60476ef3bb485f3464bf5ba43a31ee2ed02c48'}

def verify_existing_backend(live):
    entry=live/'native_wakhan2.py'
    require(entry.is_file() and not entry.is_symlink() and sha(entry)==BACKEND_ENTRY_SHA,'EXISTING_BACKEND_CHANGED')
    package=live/'wakhan_music'
    require(package.is_dir() and not package.is_symlink(),'EXISTING_MUSIC_PACKAGE_INVALID')
    require({p.name for p in package.glob('*.py')}==set(BACKEND_PACKAGE_SHA),'EXISTING_MUSIC_MODULE_SET_CHANGED')
    for name,digest in BACKEND_PACKAGE_SHA.items():
        path=live/'wakhan_music'/name
        require(path.is_file() and not path.is_symlink() and sha(path)==digest,'EXISTING_MUSIC_BACKEND_CHANGED:'+name)

def check_health():
    import announcement_backend
    announcement_backend.health()

def prepare_backend(directory,live,report):
    import announcement_backend
    verify_existing_backend(live)
    state=announcement_backend.prepare(directory,live,report,copy_atomic)
    state.update(package=live/'wakhan_music',sha256=BACKEND_PACKAGE_SHA,entry=live/'native_wakhan2.py')
    return state

def commit_backend(state,report):
    import announcement_backend
    announcement_backend.commit(state,report)

def rollback_backend(state,report):
    import announcement_backend
    announcement_backend.rollback(state,report)

def publish_latest(live,digest,state):
    state['latest_attempted']=True
    target=live/'releases/latest.json';data=json.loads(target.read_text()) if target.exists() else {};data.update(version=VERSION,build=BUILD,sha256=digest,url='https://music.kabulcafe.uk/download/Wakhan.apk?build=62');new=state['work']/'latest.new.json';new.write_text(json.dumps(data,indent=2))
    if target.exists():copy_atomic(new,target)
    else:
        fd,name=tempfile.mkstemp(prefix='.latest-cinema245-',dir=target.parent)
        with os.fdopen(fd,'wb') as out:out.write(new.read_bytes());out.flush();os.fsync(out.fileno());os.fchmod(out.fileno(),0o644)
        os.replace(name,target)
    with urllib.request.urlopen('http://127.0.0.1:10010/api/app/latest',timeout=5) as r:value=json.load(r)
    require(value.get('build')==BUILD and value.get('version')==VERSION,'LATEST_API_MISMATCH')

def previous_source():
    path=Path('/root/wakhan-0246-state.json')
    require(path.is_file()and not path.is_symlink(),'COMPLETED_0246_STATE_MISSING')
    value=json.loads(path.read_text())
    require(value.get('ok')is True and value.get('version')=='0.2.46-beta'and value.get('build')==61,'COMPLETED_0246_STATE_INVALID')
    require(value.get('package_sha256')=='10e3a4887aabaef186a17f386055a19018ed3488685ff36dd613b6e656ddc028','COMPLETED_0246_PACKAGE_DIFFERS')
    require(value.get('apk_sha256')=='1c25ed88ddfeeea41127479d7f3db11f44e85c25d8369c7431a4519b39760621'and value.get('original_signer_verified')is True,'COMPLETED_0246_APK_DIFFERS')
    require(value.get('backend_path')=='/opt/wakhan-app-0.2.11-li9z037x'and value.get('backend_entry_sha256')==BACKEND_ENTRY_SHA,'COMPLETED_0246_BACKEND_DIFFERS')
    source=Path(value.get('source_project',''))
    require(source.is_absolute()and source.name=='project'and source.parent.parent==Path('/opt/wakhan-android')and source.parent.name.startswith('wakhan-beta246-restored-')and source.resolve()==source,'COMPLETED_0246_SOURCE_INVALID')
    return source

def execute(directory, report):
    require(os.geteuid() == 0, 'RUN_AS_ROOT')
    manifest = json.loads((directory / 'PACKAGE.json').read_text())
    require(manifest.get('version') == VERSION and manifest.get('build') == BUILD, 'WRONG_PACKAGE')
    for name, digest in manifest['sha256'].items():
        path = directory / name
        require(not path.is_symlink() and path.resolve().is_relative_to(directory.resolve())
                and sha(path) == digest, 'PACKAGE_FILE_CHANGED')
    saved_state = STATE
    if saved_state.exists():
        require(not saved_state.is_symlink(), 'STATE_PATH_INVALID')
        saved = json.loads(saved_state.read_text())
        require(saved.get('ok')is True and saved.get('version')==VERSION and saved.get('build')==BUILD,'PREVIOUS_STATE_INCOMPLETE')
        require(saved.get('package_sha256') == sha(directory / 'PACKAGE.json'), 'PREVIOUS_PACKAGE_DIFFERS')
        for field, digest in [('signed_apk', 'apk_sha256'), ('signed_aab', 'aab_sha256'), ('published_path', 'apk_sha256')]:
            path = Path(saved[field])
            require(not path.is_symlink() and path.is_file() and sha(path) == saved[digest], 'PREVIOUS_OUTPUT_CHANGED')
        if saved.get('backend_path'):
            live=Path(saved['backend_path']);require(sha(live/'native_wakhan2.py')==saved['backend_entry_sha256'],'PREVIOUS_BACKEND_CHANGED')
            for name,digest in saved['backend_package_sha256'].items():require(sha(live/'wakhan_music'/name)==digest,'PREVIOUS_BACKEND_PACKAGE_CHANGED')
            for field in ['announcement_backend_sha256']:
                require(saved.get(field),'PREVIOUS_CINEMA_REPORT_INCOMPLETE')
                for name,digest in saved[field].items():
                    path=live/name
                    require(path.is_file()and not path.is_symlink()and sha(path)==digest,'PREVIOUS_CINEMA_SOURCE_CHANGED:'+name)
            check_health()
        report.update(saved)
        print('ALREADY_COMPLETED_AND_VERIFIED', flush=True)
        return
    source = SOURCE if SOURCE is not None else previous_source()
    baseline = json.loads((directory / 'base0246.json').read_text())
    require(not source.is_symlink() and source.is_dir(), 'CURRENT_0246_SOURCE_MISSING')
    build_only = {
        'android/gradle.properties', 'android/build.gradle', 'android/settings.gradle',
        'android/variables.gradle', 'android/capacitor.settings.gradle',
        'android/app/capacitor.build.gradle',
        'android/capacitor-cordova-android-plugins/build.gradle',
        'android/capacitor-cordova-android-plugins/cordova.variables.gradle',
        'ios-assets/native/add_files.rb',
    }
    require(not build_only.intersection(PATCHES), 'BUILD_CONFIG_PATCH_CONFLICT')
    differences = []
    for name, digest in baseline.items():
        path = source / name
        if not (path.is_file() and not path.is_symlink()
                and path.resolve().is_relative_to(source.resolve())):
            differences.append(name)
            continue
        if name in build_only:
            require(path.stat().st_size <= 1048576, 'LOCAL_BUILD_CONFIG_TOO_LARGE:' + name)
        actual = sha(path)
        if actual == digest:
            continue
        if name in build_only:
            report.setdefault('preserved_local_files', {})[name] = actual
        else:
            differences.append(name)
    report['blocked_source_files'] = differences
    require(not differences, 'CURRENT_SOURCE_CHANGED:' + ','.join(differences))
    unsigned = directory / 'app-release-unsigned.apk'
    with zipfile.ZipFile(unsigned) as z:
        require(z.testzip() is None, 'ANDROID_ZIP_INVALID')
        require(hashlib.sha256(z.read('assets/public/wakhan-shell.json')).hexdigest() == SHELL,
                'RESTORED_SOURCE_ASSET_MISMATCH')
        release = json.loads(z.read('assets/public/wakhan-release.json'))
        require(release.get('version') == VERSION and release.get('build') == BUILD, 'APK_RELEASE_MISMATCH')
    service = subprocess.run(['systemctl', 'show', 'wakhan-app.service', '-p', 'WorkingDirectory', '--value'],
                             capture_output=True, text=True, check=True).stdout.strip()
    live = Path(service)
    require(live.is_absolute() and live.is_dir() and not live.is_symlink(), 'LIVE_APP_DIRECTORY_INVALID')
    releases = live / 'releases'
    target = releases / 'Wakhan.apk'
    require(releases.is_dir() and not releases.is_symlink() and target.is_file()
            and not target.is_symlink(), 'CURRENT_DOWNLOAD_MISSING')
    require(signer_hashes(target) == [CERTIFICATE], 'CURRENT_APK_SIGNER_DIFFERS')
    require(sha(target) == '1c25ed88ddfeeea41127479d7f3db11f44e85c25d8369c7431a4519b39760621', 'CURRENT_PUBLIC_APK_CHANGED')
    require(sha(live / 'wakhan_home_rankings.py') == '9abf0df62104653578d457124f4b468a932dc1d8dd0c1536524785da9ee67aa2', 'HOME_RANKINGS_SOURCE_CHANGED')
    sdk_roots = [Path(v) for v in (os.environ.get('ANDROID_HOME'), os.environ.get('ANDROID_SDK_ROOT')) if v]
    sdk_roots += [Path(v) for v in ('/opt/android-sdk', '/opt/android-sdk-linux', '/root/Android/Sdk',
                                  '/usr/lib/android-sdk', '/opt/wakhan-android/sdk', '/opt/wakhan-android/android-sdk')]
    tools = [p for sdk in sdk_roots for p in sdk.glob('build-tools/*/apksigner') if p.is_file()]
    require(tools, 'ANDROID_BUILD_TOOLS_NOT_FOUND')
    signer = sorted(tools, key=lambda p: [int(x) if x.isdigit() else x for x in re.split(r'(\d+)', str(p))])[-1]
    tool_dir = signer.parent
    require((tool_dir / 'aapt').is_file(), 'AAPT_NOT_FOUND')
    def check_apk(apk):
        value = run([tool_dir / 'aapt', 'dump', 'badging', apk], directory, 'CHECK_APK_VERSION', report).decode()
        match = re.search(r"package: name='([^']+)' versionCode='([^']+)' versionName='([^']+)'", value)
        require(match and match.groups() == ('app.wakhan.music', str(BUILD), VERSION), 'APK_BINARY_VERSION_MISMATCH')
    check_apk(unsigned)
    work = Path(tempfile.mkdtemp(prefix='wakhan-0247-sign-', dir='/opt/wakhan-android'))
    backend = prepare_backend(directory,live,report)
    config = read_existing_configuration('/opt/wakhan-android/keys/release.properties', CERTIFICATE)
    signed = sign_release(unsigned, tool_dir, work, config, run, report)
    run([signer, 'verify', '--verbose', signed], work, 'VERIFY_APK_SIGNATURE', report)
    require(signer_hashes(signed) == [CERTIFICATE], 'SIGNED_APK_CERTIFICATE_MISMATCH')
    check_apk(signed)
    config = read_existing_configuration('/opt/wakhan-android/keys/release.properties', CERTIFICATE)
    bundle = sign_bundle(directory / 'app-release.aab', work, config, CERTIFICATE, run, report)
    for artifact, filename in [(signed, 'Wakhan-0.2.47-beta-test.apk'), (bundle, 'Wakhan-0.2.47-beta-release.aab')]:
        destination = Path('/root') / filename
        require(not destination.is_symlink(),'OUTPUT_PATH_INVALID')
        if destination.exists() and sha(destination)!=sha(artifact):
            previous=destination.with_name(destination.name+'.before-retry-'+sha(destination)[:16]);require(not previous.exists(),'RETRY_BACKUP_CONFLICT');os.replace(destination,previous)
        if not destination.exists():
            with destination.open('xb') as out, artifact.open('rb') as inp:
                os.fchmod(out.fileno(), 0o600)
                shutil.copyfileobj(inp, out)
    ipa=directory/'Wakhan-0.2.47-beta.ipa'
    with zipfile.ZipFile(ipa) as z:require(z.testzip() is None,'IOS_ZIP_INVALID')
    ipa_target=Path('/root/Wakhan-0.2.47-beta.ipa')
    require(not ipa_target.exists() or not ipa_target.is_symlink() and sha(ipa_target)==sha(ipa),'DIFFERENT_IPA_ALREADY_EXISTS')
    if not ipa_target.exists():
        with ipa_target.open('xb') as out,ipa.open('rb') as inp:
            os.fchmod(out.fileno(),0o600);shutil.copyfileobj(inp,out)
    report['iphone_ipa']=str(ipa_target)
    report['iphone_requires_sideloadly']=True
    stage = Path(tempfile.mkdtemp(prefix='wakhan-beta247-announcement-', dir='/opt/wakhan-android')) / 'project'
    shutil.copytree(source, stage, symlinks=True,
                    ignore=shutil.ignore_patterns('node_modules', '.git', '.gradle', 'build', 'www', 'dist'))
    for name, digest in report.get('preserved_local_files', {}).items():
        require(sha(stage / name) == digest, 'LOCAL_CONFIG_CHANGED_DURING_COPY:' + name)
    with zipfile.ZipFile(directory / 'Wakhan-0.2.47-source.zip') as z:
        for name in PATCHES:
            destination = stage / name
            require(not destination.is_symlink() and destination.resolve().is_relative_to(stage.resolve()), 'STAGE_PATH_INVALID')
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(z.read('project/' + name))
    deleted=json.loads((directory/'source-verification.json').read_text())['deleted_files']
    for name in deleted:
        require(name in baseline,'UNREVIEWED_SOURCE_DELETION')
        path=stage/name
        require(not path.is_symlink() and path.resolve().is_relative_to(stage.resolve()),'DELETION_PATH_INVALID')
        require(path.is_file() and sha(path)==baseline[name],'RETIRED_SOURCE_CHANGED:'+name)
        path.unlink()
    for name,digest in json.loads((directory/'source-verification.json').read_text())['source_sha256'].items():
        path=stage/name
        if name not in report.get('preserved_local_files',{}):require(path.is_file()and sha(path)==digest,'STAGED_SOURCE_DIFFERS:'+name)
    assets = stage / 'android/app/src/main/assets'
    if (assets / 'public').exists():
        shutil.rmtree(assets / 'public')
    with zipfile.ZipFile(unsigned) as z:
        for name in z.namelist():
            if name.startswith('assets/') and not name.endswith('/'):
                relative = Path(name.removeprefix('assets/'))
                require(not relative.is_absolute() and '..' not in relative.parts, 'ASSET_PATH_INVALID')
                destination = assets / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(z.read(name))
    require(sha(stage / 'public/wakhan-shell.json') == SHELL, 'STAGE_SHELL_CHANGED')
    previous_sha = sha(target)
    backup = releases / ('Wakhan-before-0.2.47-' + previous_sha[:16] + '.apk')
    require(not backup.exists() or (not backup.is_symlink() and sha(backup) == previous_sha), 'BACKUP_CONFLICT')
    if not backup.exists():
        with backup.open('xb') as out, target.open('rb') as inp:
            os.fchmod(out.fileno(), target.stat().st_mode & 0o777)
            os.fchown(out.fileno(), target.stat().st_uid, target.stat().st_gid)
            shutil.copyfileobj(inp, out)
            out.flush()
            os.fsync(out.fileno())
    try:
        commit_backend(backend,report)
        copy_atomic(signed,target)
        publish_latest(live,sha(signed),backend)
    except BaseException:
        copy_atomic(backup,target)
        rollback_backend(backend,report)
        raise
    try:
        request = urllib.request.Request('http://127.0.0.1:10010/download/Wakhan.apk', headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=30) as response:
            digest = hashlib.sha256()
            while chunk := response.read(1024 * 1024):
                digest.update(chunk)
        require(digest.hexdigest() == sha(signed), 'PUBLISHED_DOWNLOAD_DIFFERS')
    except BaseException:
        copy_atomic(backup, target)
        report['download_rolled_back'] = True
        rollback_backend(backend,report)
        raise
    report.update(ok=True, version=VERSION, build=BUILD, original_signer_verified=True,
                  signed_apk='/root/Wakhan-0.2.47-beta-test.apk', apk_sha256=sha(signed),
                  signed_aab='/root/Wakhan-0.2.47-beta-release.aab', aab_sha256=sha(bundle),
                  source_project=str(stage), download_published=True, previous_apk_retained=True,
                  services_changed=True, database_changed=False, database_changes='None; announcement subtitle only', server_health_verified=True, backend_path=str(live), backend_entry_sha256=sha(live/'native_wakhan2.py'), backend_package_sha256=backend['sha256'], physical_device_verified=False,
                  published_path=str(target), package_sha256=sha(directory / 'PACKAGE.json'))
    fd, temporary = tempfile.mkstemp(prefix='.wakhan-0247-state-', dir='/root')
    try:
        with os.fdopen(fd, 'w') as out:
            json.dump(report, out, indent=2)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, saved_state)
    except BaseException:
        copy_atomic(backup, target)
        report['ok'] = False
        report['download_rolled_back'] = True
        rollback_backend(backend,report)
        raise
    finally:
        Path(temporary).unlink(missing_ok=True)

if __name__ == '__main__':
    report = {'ok': False, 'services_changed': False, 'database_changed': False}
    try:
        import fcntl
        lock = open('/root/.wakhan-home0247.lock', 'a')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        execute(Path(__file__).resolve().parent, report)
    except Exception as error:
        report['ok'] = False
        report['error'] = str(error) if isinstance(error, RuntimeError) else type(error).__name__
        print('STOP:', report['error'], flush=True)
    finally:
        destination = Path('/root/wakhan-0247-result.zip')
        fd, temporary = tempfile.mkstemp(prefix='.wakhan-0247-report-', dir='/root')
        with os.fdopen(fd, 'wb') as handle, zipfile.ZipFile(handle, 'w', zipfile.ZIP_DEFLATED) as z:
            z.writestr('result.json', json.dumps(report, indent=2))
        os.replace(temporary, destination)
        print('REPORT:', destination, flush=True)
    if not report['ok']:
        raise SystemExit(1)
    print('ANDROID_READY: https://music.kabulcafe.uk/download/Wakhan.apk?build=62', flush=True)
