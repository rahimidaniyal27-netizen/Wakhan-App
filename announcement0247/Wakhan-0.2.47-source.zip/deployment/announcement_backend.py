"""Add only the announcement subtitle to existing Salon list responses.

Transform the exact installed source. No review fixture replaces production code.
No database migration or rollback is performed.
"""
import ast,hashlib,json,os,shutil,sqlite3,subprocess,tempfile,time,urllib.request,urllib.error,shlex,re
from pathlib import Path
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(value,code):
 if not value:raise RuntimeError(code)
def transform(source):
 tree=ast.parse(source);matches=[]
 for cls in tree.body:
  if isinstance(cls,ast.ClassDef):
   for fn in cls.body:
    if isinstance(fn,ast.FunctionDef)and fn.name=='row':
     for node in ast.walk(fn):
      if isinstance(node,ast.Assign)and len(node.targets)==1 and isinstance(node.targets[0],ast.Name)and node.targets[0].id=='out'and isinstance(node.value,ast.Dict):matches.append(node.value)
 require(len(matches)==1,'SALON_ROW_SHAPE_CHANGED');node=matches[0];keys=[getattr(k,'value',None)for k in node.keys];require('code'in keys and'topic'in keys and'notice'not in keys,'SALON_ROW_FIELDS_CHANGED')
 lines=source.splitlines(keepends=True);offset=sum(len(line)for line in lines[:node.lineno-1])+len(lines[node.lineno-1].encode()[:node.col_offset].decode())+1
 result=source[:offset]+"'notice': str(info.get('notice') or '')[:300], "+source[offset:];compile(result,'wakhan_salon.py','exec');return result

def verify(live,files):
 for name,digest in files.items():
  p=live/name;require(p.is_file()and not p.is_symlink()and sha(p)==digest,'ANNOUNCEMENT_SOURCE_CHANGED:'+name)
def health():
 with urllib.request.urlopen('http://127.0.0.1:10010/health',timeout=5)as r:require(json.load(r).get('ok')is True,'HEALTH_INVALID')
 for path in ['/api/app/music/chart','/api/app/games/catalog','/api/app/chat/inbox','/api/app/salon/home']:
  try:
   with urllib.request.urlopen('http://127.0.0.1:10010'+path,timeout=5)as r:status=r.status
  except urllib.error.HTTPError as e:status=e.code
  require(status==401,'ROUTE_HEALTH:'+path)
def configuration():
 raw=subprocess.run(['systemctl','show','wakhan-app.service','-p','ExecStart','--value'],check=True,capture_output=True,text=True).stdout
 m=re.search(r'argv\[\]=([^;]+)',raw);require(m,'SERVICE_COMMAND_UNRECOGNIZED');args=shlex.split(m[1]);require('--config'in args,'SERVICE_CONFIG_MISSING');path=Path(args[args.index('--config')+1]);require(path.is_file()and not path.is_symlink(),'SERVICE_CONFIG_INVALID');return Path(args[0]),json.loads(path.read_text())
def prepare(directory,live,report,copy_atomic):
 baseline=json.loads((directory/'announcement-baseline.json').read_text())['current'];verify(live,baseline)
 work=Path(tempfile.mkdtemp(prefix='.wakhan-announcement247-',dir=live));os.chmod(work,0o700);candidate=work/'candidate';candidate.mkdir();backup=work/'current';backup.mkdir(mode=0o700)
 for p in live.glob('*.py'):
  require(not p.is_symlink(),'SERVER_SYMLINK');shutil.copy2(p,candidate/p.name)
 for package in ['wakhan_games','wakhan_music']:shutil.copytree(live/package,candidate/package,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 shutil.copy2(live/'wakhan_salon.py',backup/'wakhan_salon.py');(candidate/'wakhan_salon.py').write_text(transform((live/'wakhan_salon.py').read_text()))
 python,config=configuration();database=Path(config['database']);require(database.is_file()and not database.is_symlink(),'DATABASE_INVALID');smoke_db=work/'smoke.sqlite'
 with sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True)as source,sqlite3.connect(smoke_db)as target:source.backup(target);require(target.execute('PRAGMA quick_check').fetchone()[0]=='ok','SMOKE_DB_INVALID')
 os.chmod(smoke_db,0o600);cfg=work/'smoke-config.json';cfg.write_text(json.dumps({**config,'base':str(candidate),'data':str(work/'smoke-data'),'database':str(smoke_db)}));os.chmod(cfg,0o600)
 script=work/'smoke.py';script.write_text('import asyncio,json,sys\nfrom pathlib import Path\nsys.path.insert(0,sys.argv[1])\nfrom native_runtime import create_app\nasync def main():\n app=create_app(json.loads(Path(sys.argv[2]).read_text()),workers=False);ns=app["wakhan_namespace"];assert "CIN"in ns and"CV"in ns and"WKC_CINEMA"not in ns;app.freeze();await app.startup();await app.cleanup()\nasyncio.run(main())\n')
 result=subprocess.run([str(python),str(script),str(candidate),str(cfg)],cwd=candidate,capture_output=True,timeout=90)
 if result.returncode:
  log=work/'preflight-errors.log';log.write_bytes(result.stderr);os.chmod(log,0o600);raise RuntimeError('ANNOUNCEMENT_PREFLIGHT_FAILED; log='+str(log))
 latest=live/'releases/latest.json';require(not latest.is_symlink(),'LATEST_PATH_INVALID')
 if latest.exists():shutil.copy2(latest,work/'latest.before.json')
 report.update(existing_backend_verified=True,backend_preflight_verified=True,backend_current_backup=str(backup));return dict(live=live,work=work,candidate=candidate,backup=backup,baseline=baseline,changed=False,had_latest=latest.exists(),latest_attempted=False,copy_atomic=copy_atomic)
def start_check():
 subprocess.run(['systemctl','start','wakhan-app.service'],check=True,timeout=45)
 for n in range(30):
  try:health();return
  except Exception:
   if n==29:raise
   time.sleep(.3)
def commit(state,report):
 verify(state['live'],state['baseline']);state['changed']=True;subprocess.run(['systemctl','stop','wakhan-app.service'],check=True,timeout=45)
 state['copy_atomic'](state['candidate']/'wakhan_salon.py',state['live']/'wakhan_salon.py');start_check();report.update(announcement_backend_sha256={n:sha(state['live']/n)for n in state['baseline']},services_changed=True,database_changed=False,database_changes='None; existing announcement is exposed in salon list responses')
def rollback(state,report):
 if state.get('changed'):
  subprocess.run(['systemctl','stop','wakhan-app.service'],check=True,timeout=45);state['copy_atomic'](state['backup']/'wakhan_salon.py',state['live']/'wakhan_salon.py');subprocess.run(['systemctl','start','wakhan-app.service'],check=True,timeout=45);state['changed']=False;report['backend_rolled_back']=True
 if state.get('latest_attempted'):
  target=state['live']/'releases/latest.json'
  if state['had_latest']:state['copy_atomic'](state['work']/'latest.before.json',target)
  else:target.unlink(missing_ok=True)
  state['latest_attempted']=False
