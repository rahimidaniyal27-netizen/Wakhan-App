import importlib.util,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('home_installer',Path(__file__).resolve().parents[1]/'sign-and-publish.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Safety(unittest.TestCase):
 def test_failed_copy_keeps_current_download(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);old=root/'Wakhan.apk';old.write_bytes(b'current');new=root/'new.apk';new.write_bytes(b'new')
   with patch.object(m.shutil,'copyfileobj',side_effect=OSError('disk write failed')):
    with self.assertRaises(OSError):m.copy_atomic(new,old)
   self.assertEqual(old.read_bytes(),b'current');self.assertEqual(sorted(p.name for p in root.iterdir()),['Wakhan.apk','new.apk'])
   mode=old.stat().st_mode;m.copy_atomic(new,old);self.assertEqual(old.read_bytes(),b'new');self.assertEqual(old.stat().st_mode,mode)
 def test_modified_payload_stops_before_signing_or_service_read(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);(root/'x').write_bytes(b'tampered');(root/'PACKAGE.json').write_text(json.dumps({'version':m.VERSION,'build':m.BUILD,'sha256':{'x':'0'*64}}))
   with patch.object(m.os,'geteuid',return_value=0),patch.object(m.subprocess,'run') as process,patch.object(m,'read_existing_configuration') as key:
    with self.assertRaisesRegex(RuntimeError,'PACKAGE_FILE_CHANGED'):m.execute(root,{})
    process.assert_not_called();key.assert_not_called()
 def test_changed_current_source_stops_before_signing_or_service_read(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);source=root/'source';source.mkdir();(source/'main.mjs').write_bytes(b'new user changes');(root/'PACKAGE.json').write_text(json.dumps({'version':m.VERSION,'build':m.BUILD,'sha256':{}}));(root/'base0246.json').write_text(json.dumps({'main.mjs':'0'*64}))
   with patch.object(m.os,'geteuid',return_value=0),patch.object(m,'SOURCE',source),patch.object(m,'STATE',root/'state.json'),patch.object(m.subprocess,'run') as process,patch.object(m,'read_existing_configuration') as key:
    with self.assertRaisesRegex(RuntimeError,'CURRENT_SOURCE_CHANGED'):m.execute(root,{})
    process.assert_not_called();key.assert_not_called()
 def test_verified_repeat_performs_no_signing_or_service_change(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);package=root/'PACKAGE.json';package.write_text(json.dumps({'version':m.VERSION,'build':m.BUILD,'sha256':{}}));apk=root/'done.apk';apk.write_bytes(b'previously verified output');aab=root/'done.aab';aab.write_bytes(b'previously verified bundle');state=root/'state.json';saved={'ok':True,'version':m.VERSION,'build':m.BUILD,'package_sha256':m.sha(package),'signed_apk':str(apk),'apk_sha256':m.sha(apk),'published_path':str(apk),'signed_aab':str(aab),'aab_sha256':m.sha(aab)};state.write_text(json.dumps(saved));report={}
   with patch.object(m.os,'geteuid',return_value=0),patch.object(m,'STATE',state),patch.object(m.subprocess,'run') as process,patch.object(m,'read_existing_configuration') as key:
    m.execute(root,report);self.assertTrue(report['ok']);process.assert_not_called();key.assert_not_called()
 def test_future_apk_same_signer_is_not_overwritten(self):
  import hashlib,zipfile,types
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);source=root/'source';source.mkdir();(source/'main.mjs').write_text('current');(root/'base0246.json').write_text(json.dumps({'main.mjs':m.sha(source/'main.mjs')}));live=root/'live';(live/'releases').mkdir(parents=True);(live/'releases/Wakhan.apk').write_bytes(b'newer release signed by same owner')
   shell=(Path(__file__).resolve().parents[1]/'project/public/wakhan-shell.json').read_bytes()
   with zipfile.ZipFile(root/'app-release-unsigned.apk','w') as z:
    z.writestr('assets/public/wakhan-shell.json',shell);z.writestr('assets/public/wakhan-release.json',json.dumps({'version':m.VERSION,'build':m.BUILD}))
   (root/'PACKAGE.json').write_text(json.dumps({'version':m.VERSION,'build':m.BUILD,'sha256':{'app-release-unsigned.apk':m.sha(root/'app-release-unsigned.apk')}}))
   with patch.object(m.os,'geteuid',return_value=0),patch.object(m,'SOURCE',source),patch.object(m,'STATE',root/'state.json'),patch.object(m,'signer_hashes',return_value=[m.CERTIFICATE]),patch.object(m.subprocess,'run',return_value=types.SimpleNamespace(stdout=str(live))) as process,patch.object(m,'read_existing_configuration') as key:
    with self.assertRaisesRegex(RuntimeError,'CURRENT_PUBLIC_APK_CHANGED'):m.execute(root,{})
    key.assert_not_called();self.assertEqual((live/'releases/Wakhan.apk').read_bytes(),b'newer release signed by same owner')

if __name__=='__main__':unittest.main()
