import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,copyFileSync,writeFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
import {execFileSync} from 'node:child_process';
import {validateIosEntry} from '../scripts/validate-ios-entry.mjs';
function fixture(scene){
 const root=mkdtempSync(resolve(tmpdir(),'wakhan-ios-entry-'));mkdirSync(resolve(root,'ios/App/App'),{recursive:true});
 copyFileSync('ios-assets/native/MainViewController.swift',resolve(root,'ios/App/App/MainViewController.swift'));
 if(scene)writeFileSync(resolve(root,'ios/App/App/SceneDelegate.swift'),scene);else copyFileSync('ios-assets/native/SceneDelegate.swift',resolve(root,'ios/App/App/SceneDelegate.swift'));
 return root;
}
test('real Capacitor 8 scaffold bypasses app plugins even when their controller is compiled',()=>{
 const original=execFileSync('tar',['-xOf','node_modules/@capacitor/cli/assets/ios-spm-template.tar.gz','App/App/SceneDelegate.swift'],{encoding:'utf8'});
 const root=fixture(original);try{assert.throws(()=>validateIosEntry(root),/bypasses Wakhan native bridge/)}finally{rmSync(root,{recursive:true})}
});
test('shipped scene enters Wakhan bridge and preserves provider URL callbacks',()=>{
 const root=fixture();try{assert.equal(validateIosEntry(root),true)}finally{rmSync(root,{recursive:true})}
});
