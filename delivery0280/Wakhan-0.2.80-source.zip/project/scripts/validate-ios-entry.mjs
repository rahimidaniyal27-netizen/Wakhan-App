import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
export function validateIosEntry(root=process.cwd()){
 const scene=readFileSync(resolve(root,'ios/App/App/SceneDelegate.swift'),'utf8');
 const controller=readFileSync(resolve(root,'ios/App/App/MainViewController.swift'),'utf8');
 if(!/\.rootViewController\s*=\s*MainViewController\(\)/.test(scene)||/\.rootViewController\s*=\s*CAPBridgeViewController\(\)/.test(scene))throw Error('iOS scene bypasses Wakhan native bridge');
 if(!scene.includes('SceneDelegateProxy.shared.scene(scene, openURLContexts: URLContexts)'))throw Error('iOS sign-in URL callbacks missing');
 for(const name of ['WakhanVaultPlugin','WakhanSignInPlugin','WakhanLocalePlugin','WakhanDownloadsPlugin','WakhanMusicPlugin']){
  if(!controller.includes('registerPluginInstance('+name+'())'))throw Error('iOS plugin not registered: '+name);
 }
 if(!controller.includes('private let child = WakhanBridgeViewController()'))throw Error('iOS native bridge not attached');
 return true;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 validateIosEntry();console.log('iOS scene uses Wakhan bridge with vault/sign-in/media plugins and URL callbacks');
}
