async def exercise_sources(page,out,engine):
 await page.evaluate("go('p')")
 await page.locator('#wk-music [data-action=search]').click()
 await page.locator('#wk-music input[type=search]').fill('external review')
 await page.locator('#wk-music .search-form').evaluate('e=>e.requestSubmit()')
 await page.locator('#wk-music [data-track="yt.abcdefghijk"]').wait_for()
 assert await page.locator('#wk-music [data-track^="sc."]').count()==1
 await page.locator('#wk-music [data-track="yt.abcdefghijk"] [data-action=play]').click()
 await page.wait_for_function("WakhanMusicUI.queue.state().current?.playback==='audio'&&!WakhanMusicUI.queue.state().loading")
 assert not await page.evaluate('WakhanMusicUI.queue.state().error')
 assert await page.locator('#wk-music .player-cover').is_visible()
 assert await page.locator('#wk-music .embed-dock iframe').count()==0
 assert await page.locator('#wk-music [data-action=current-download]').count()==0
 # Ended only advances once into the second provider.
 await page.evaluate("document.querySelector('audio#aud')?.dispatchEvent(new Event('ended'))")
 # Use the actual queue's owner audio element, whose old shell ID varies.
 await page.evaluate("au.dispatchEvent(new Event('ended'));au.dispatchEvent(new Event('ended'))")
 await page.wait_for_function("WakhanMusicUI.queue.state().current?.provider==='soundcloud'&&!WakhanMusicUI.queue.state().loading")
 assert await page.locator('#wk-music .embed-dock iframe').count()==0
 await page.evaluate("go('h')")
 close=page.locator('#wk-music .mini [data-action=stop]');assert await close.is_visible();rect=await close.bounding_box();assert rect['width']<=40 and rect['height']<=44
 await close.click();assert not await page.locator('#wk-music .mini').is_visible();assert await page.evaluate('WakhanMusicUI.queue.state().current===null')
 # Replaying the SAME track must reconstruct the mini (old dataset.track bug).
 await page.evaluate("go('p')");await page.locator('#wk-music [data-action=search]').click();await page.locator('#wk-music input[type=search]').fill('external review');await page.locator('#wk-music .search-form').evaluate('e=>e.requestSubmit()');await page.locator('#wk-music [data-track^="sc."] [data-action=play]').click()
 await page.wait_for_function("WakhanMusicUI.queue.state().current?.provider==='soundcloud'&&!WakhanMusicUI.queue.state().loading")
 await page.evaluate("go('h')");assert await page.locator('#wk-music .mini').is_visible()
 await page.evaluate("go('p')")
 assert await page.locator('#wk-music .page').get_attribute('data-view')=='home'
 assert await page.locator('#wk-music .page').evaluate('e=>e.scrollTop')<2
 await page.screenshot(path=str(out/(engine+'-music-audio-and-close.png')))
 await page.evaluate('WakhanMusicUI.stop()')
 return dict(unified_youtube_soundcloud_search=True,legacy_authenticated_audio=True,no_video_iframe=True,duplicate_ended_advanced_once=True,mini_stop_and_close=True,replay_same_track=True,top_on_return=True,live_provider_network=False)
