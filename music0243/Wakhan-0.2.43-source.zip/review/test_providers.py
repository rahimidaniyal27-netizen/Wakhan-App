import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from wakhan_music.providers import *
class RightsTests(unittest.TestCase):
 def test_cc_permissions(self):
  for x in ['https://creativecommons.org/licenses/by/4.0/','http://creativecommons.org/licenses/by-sa/3.0/us/','https://creativecommons.org/publicdomain/zero/1.0/']:self.assertTrue(license_ok(x))
  for x in [None,'All rights reserved','https://creativecommons.org/licenses/by-nc/4.0/','https://creativecommons.org/licenses/by/4.0/evil','https://evil.test/licenses/by/4.0/']:self.assertFalse(license_ok(x))
 def base(self):return dict(id='abc',title='Track',duration=60,is_streamable=True,artwork={'1000x1000':'https://provider.test/cover.jpg'},permalink='/artist/track',user={'name':'Artist'})
 def test_audius_oml_is_online_only_even_if_download_flag_set(self):
  x=self.base();x['is_downloadable']=True;t=audius_track(x);self.assertFalse(t['downloadable']);self.assertFalse(t['persistent']);self.assertEqual(t['license'],OML)
 def test_audius_honours_gating_and_alternate_licence(self):
  for field,value in [('is_streamable',False),('is_available',False),('is_stream_gated',True),('is_delete',True),('is_unlisted',True),('allowed_api_keys',['private']),('license','All rights reserved'),('license','Attribution-NonCommercial CC BY-NC'),('artwork',{})]:
   x=self.base();x[field]=value;self.assertIsNone(audius_track(x),(field,value))
 def album(self):return {'metadata':{'identifier':'album','licenseurl':'https://creativecommons.org/licenses/by/4.0/','creator':'Artist'},'files':[{'name':'Front.jpg','source':'original','format':'JPEG','size':'2000'},{'name':'01.mp3','format':'VBR MP3','length':'03:01','size':'3000'}]}
 def test_archive_requires_original_cover_and_licence(self):
  x=self.album();t=archive_tracks(x)[0];self.assertTrue(t['downloadable']);self.assertEqual(decode_archive(t['id']),('album','01.mp3'));x['files'][0]['source']='derivative';self.assertEqual(archive_tracks(x),[]);x=self.album();x['metadata']['licenseurl']='https://creativecommons.org/licenses/by-nc/4.0/';self.assertEqual(archive_tracks(x),[])
 def test_archive_rejects_traversal_ids(self):
  for a,n in [('album','../a.mp3'),('../album','a.mp3'),('album','a\\b.mp3')]:
   with self.assertRaises(ValueError):decode_archive(archive_id(a,n))
 def test_fusion_preserves_source_order_and_deduplicates(self):
  a=[dict(id=str(i),artist='A',title=str(i))for i in range(3)];b=[dict(id='other',artist='A',title='0'),dict(id='four',artist='B',title='4')];r=merge_rankings([a,b]);self.assertEqual([x['id']for x in r],['0','1','four','2']);self.assertEqual([x['rank']for x in r],[1,2,3,4])
if __name__=='__main__':unittest.main()
