async def exercise_music_changes(page,out,engine,chart_calls):
 await page.evaluate("go('p')")
 await page.wait_for_function("document.querySelector('#wk-music').shadowRoot.querySelector('.section-line .subtle')?.textContent.includes('Archive')")
 entry=page.locator('#wk-music .search-entry')
 box=await entry.bounding_box();symbol=await entry.locator('svg').bounding_box()
 assert 10<=box['x']+box['width']-symbol['x']-symbol['width']<=18,(box,symbol)
 assert await page.locator('#wk-music .shortcuts [data-action=refresh]').count()==0
 status=await page.locator('#wk-music .section-line .subtle').inner_text();assert 'Archive'in status and'ccMixter'in status and'Audius'not in status,status
 before=chart_calls()
 # Exercise handlers on the actual overflow scroller, including preventDefault.
 await page.locator('#wk-music .page').evaluate('''e=>{e.scrollTop=0;function t(type,y,count=1){const v=new Event(type,{cancelable:true});v.touches=count?[{clientX:150,clientY:y}]:[];e.dispatchEvent(v);return v.defaultPrevented}t('touchstart',100);if(!t('touchmove',270))throw Error('pull was not claimed');t('touchend',270,0)}''')
 await page.wait_for_function("document.querySelector('#wk-music').shadowRoot.querySelector('.pull-refresh').hidden")
 assert chart_calls()==before+1,(before,chart_calls())
 await page.screenshot(path=str(out/(engine+'-search-and-sources.png')))
 return dict(search_icon_at_right_edge=True,actual_failed_names_shown=True,pull_requested_once=True,round_refresh_removed=True)
