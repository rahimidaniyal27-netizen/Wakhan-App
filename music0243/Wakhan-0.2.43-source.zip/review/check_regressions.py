async def exercise_regressions(page,out,engine):
 await page.evaluate("go('p')")
 await page.locator('#wk-music .feature img[src^=blob]').wait_for()
 await page.wait_for_function("document.querySelector('#wk-music').shadowRoot.querySelectorAll('[data-audius-cover][data-art-ready]').length>0")
 ready=await page.locator('#wk-music [data-audius-cover][data-art-ready]').count();assert 0<ready<20,ready
 await page.locator('#wk-music button[data-action=search]').click()
 field=page.locator('#wk-music input[type=search]')
 assert float(await field.evaluate('e=>parseFloat(getComputedStyle(e).fontSize)'))>=16
 await field.fill('آهنگ')
 await page.evaluate("window.dispatchEvent(new CustomEvent('wakhanKeyboardFrame',{detail:{overlap:320,duration:0,curve:0}}))")
 await page.wait_for_timeout(80)
 await page.evaluate("go('c')")
 await page.evaluate("window.dispatchEvent(new CustomEvent('wakhanKeyboardFrame',{detail:{overlap:0,duration:0,curve:0}}))")
 await page.wait_for_timeout(100)
 assert not await page.evaluate("document.body.classList.contains('wk-music-keyboard')")
 assert await page.locator('#wk-music').evaluate("e=>!e.shadowRoot.activeElement?.matches('input,textarea')")
 assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
 await page.evaluate("go('d')")
 # First unread is deliberately old; entry must display message60 at the bottom.
 await page.evaluate("WakhanChat.open('dm',2)")
 await page.locator('[data-mid="60"]').wait_for()
 async def bottom():
  return await page.locator('[data-messages]').evaluate('e=>e.scrollHeight-e.scrollTop-e.clientHeight')
 await page.wait_for_timeout(60);assert await bottom()<3,await bottom()
 await page.locator('[data-chat-media]').first.wait_for(state='visible')
 await page.wait_for_timeout(100);assert await bottom()<3,await bottom()
 # Users can still scroll up to read history without automatic snapping.
 await page.locator('[data-messages]').evaluate("e=>{e.dispatchEvent(new WheelEvent('wheel',{deltaY:-400}));e.scrollTop=0}")
 assert await bottom()>100
 await page.wait_for_timeout(80);assert await bottom()>100
 await page.evaluate("go('h');go('d')")
 await page.wait_for_timeout(200);assert await bottom()<3,await bottom()
 await page.screenshot(path=str(out/(engine+'-chat-latest.png')))
 await page.evaluate("go('h')")
 return {'lazy_artwork_requests':ready,'search_input_min_16':True,'search_blurred_on_tab_exit':True,'no_horizontal_overflow':True,'first_unread_does_not_override_latest':True,'latest_after_delayed_image':True,'manual_history_scroll_preserved':True,'latest_on_tab_return':True,'physical_ios_focus_zoom_tested':False}
