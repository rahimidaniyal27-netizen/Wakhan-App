import asyncio
async def exercise_room(page,out,engine):
 await page.evaluate("""()=>{go('c');CID='REVIEW';CV='hall';CG.token='review';CS={ok:true,_cid:'REVIEW',vid:'',playing:false,t:0,ver:1,timeline_revision:1,mine:0,owner:1,seats:[{id:1,name:'Test'},null,null,null,null,null,null,null],room:'REVIEW',sync_epoch:'test'};VC.on=true;VC.cid=CID;VC.mute=true;VC.members=[];rHall();clearInterval(cIv);clearTimeout(WMC.timer)}""")
 await page.wait_for_timeout(150)
 room=page.locator('#wm78-room');assert 'h4-royal' in await room.get_attribute('class')
 # Android physically resizes its WebView for IME. iOS reports an overlapping frame.
 samples=[]
 for platform in ['android','ios']:
  await page.set_viewport_size({'width':393,'height':852})
  await page.evaluate("""p=>{document.activeElement?.blur();document.documentElement.classList.remove('wk-ios','wk-android');document.documentElement.classList.add('wk-'+p);window.__h2vv={height:852,offsetTop:0,fullHeight:852};H2.state.royalFullHeight=0;H2.kb()}""",platform)
  await page.wait_for_timeout(50)
  resting=await page.locator('.h2-say').evaluate('e=>({r:e.getBoundingClientRect().toJSON(),color:getComputedStyle(e).color,bg:getComputedStyle(e).backgroundColor,opacity:getComputedStyle(e).opacity})')
  assert resting['r']['bottom']<=853 and resting['opacity']=='1',resting
  assert resting['bg']!='rgba(0, 0, 0, 0)',resting
  await page.locator('#wm70-room-text').focus()
  if platform=='android':await page.set_viewport_size({'width':393,'height':500})
  await page.evaluate("""()=>{window.__h2vv={height:500,offsetTop:0,fullHeight:852};H2.kb()}""")
  await page.wait_for_timeout(60)
  field=await page.locator('#wm70-room-text').evaluate('e=>({r:e.getBoundingClientRect().toJSON(),opacity:getComputedStyle(e.parentElement).opacity})')
  assert 460<=field['r']['bottom']<=500,(platform,field)
  assert field['opacity']=='1',field
  await page.screenshot(path=str(out/(engine+'-'+platform+'-room-keyboard.png')))
  samples.append({'platform':platform,'composer_bottom':field['r']['bottom'],'visible_bottom':500,'resting_composer_visible':True})
  await page.evaluate("""()=>{document.activeElement?.blur();window.__h2vv={height:852,offsetTop:0,fullHeight:852};H2.kb()}""")
  await page.set_viewport_size({'width':393,'height':852})
 await page.evaluate("""()=>{window.__h2vv={height:852,offsetTop:0,fullHeight:852};H2.kb();const n=document.createElement('div');n.id='flag-fixture';n.textContent='Yas🇦🇫';document.querySelector('.h2-chat').append(n)}""")
 await page.locator('#flag-fixture img.wk-country-flag').wait_for()
 flag=await page.locator('#flag-fixture img').evaluate('async e=>{await e.decode();return {src:e.src,w:e.naturalWidth,alt:e.alt}}');assert flag['w']>0 and '/flags/af.svg' in flag['src'],flag
 await page.evaluate("""()=>{WM70.people.set(2,{id:2,name:'Yas🇦🇫',relation:'accepted'});wp30More(2)}""")
 await page.wait_for_timeout(180)
 assert await page.locator('#sheet .wp30-menu').is_visible()
 assert await page.locator('#sheet>.wk-sheet-backbar').count()==0
 await page.locator('#sheet .wp30-menu .wk-person-backbar').wait_for(state='attached')
 assert await page.locator('#sheet .wp30-menu .wk-person-backbar').count()==1
 assert await page.locator('#sheet .wp30-menu .wk-back').is_visible()
 await page.screenshot(path=str(out/(engine+'-person-menu.png')))
 await page.evaluate('closeSheet()')
 # Use the actual client end dispatcher with a controlled authoritative protocol peer.
 media=await page.evaluate("""async()=>{
 const saved=wmcState,savedState=CS,savedApi=api;const calls=[],queue=['bbbbbbbbbbb','ccccccccccc'];
 CS={...CS,vid:'aaaaaaaaaaa',playing:true,mine:0,t:10,timeline_revision:1};WMC.ending=null;
 wmcState=async(code,body)=>{calls.push({...body});await Promise.resolve();if(body.vid!==CS.vid||body.timeline_revision!==CS.timeline_revision)return null;CS={...CS,vid:queue.shift()||CS.vid,t:0,playing:true,timeline_revision:CS.timeline_revision+1};return CS};
 const fake={duration:10,currentTime:10};
 try{await Promise.all([wmcFinishMedia(fake,'aaaaaaaaaaa'),wmcFinishMedia(fake,'aaaaaaaaaaa')]);if(CS.vid!=='bbbbbbbbbbb'||calls.length!==1)throw Error('double advance');await wmcFinishMedia(fake,'aaaaaaaaaaa');if(calls.length!==1)throw Error('stale end');await wmcFinishMedia(fake,'bbbbbbbbbbb');if(CS.vid!=='ccccccccccc')throw Error('FIFO');await wmcFinishMedia(fake,'ccccccccccc');if(CS.vid!=='ccccccccccc'||CS.t!==0||!CS.playing)throw Error('loop');
 // Real native video handler: initial seek once, then no seeks while buffering.
 CS={...CS,vid:'native:review',media:{kind:'native',formats:[{url:'https://example.invalid/review.mp4',height:720}]},t:5};CAT=performance.now();const v=nxVideo();let seeks=0,position=0,plays=0;Object.defineProperties(v,{readyState:{configurable:true,get:()=>1},duration:{configurable:true,get:()=>100},currentTime:{configurable:true,get:()=>position,set:n=>{position=n;seeks++}},paused:{configurable:true,get:()=>false},seeking:{configurable:true,get:()=>false}});v.load=()=>{};v.play=()=>{plays++;return Promise.resolve()};v.pause=()=>{};NX.key=null;nxApplyNative();nxApplyNative();nxApplyNative();if(seeks!==1)throw Error('buffering seek loop '+seeks);
 // The ended event goes through the same guarded dispatcher; no unguarded next call.
 CS={...CS,t:100};position=100;NX.key=CS.vid;v.dispatchEvent(new Event('ended'));await Promise.resolve();await Promise.resolve();if(calls.at(-1).a!=='end'||calls.at(-1).vid!=='native:review')throw Error('native queue');
 let manual;api=async(path,body)=>{manual={path,body};return {ok:false,err:'review'}};WMC.blocked=true;NX.blocked=true;await nxStep('next');if(manual.body.a!=='next'||!WMC.gesture||WMC.blocked||NX.blocked)throw Error('manual next');
 return {manual_next:true,fifo:true,duplicate_end_ignored:true,stale_end_ignored:true,empty_queue_repeats:true,native_end_guarded:true,buffering_seeks:seeks};
 }finally{wmcState=saved;api=savedApi;CS=savedState;NX.video?.remove();NX.video=null;NX.key=null;WMC.ending=null}
}""")
 await page.evaluate("""()=>{delete window.__h2vv;CID='';CV='list';go('h')}""")
 return {'geometry':samples,'flag_local':True,'person_header_compact':True,'media':media,'live_youtube_tested':False,'physical_keyboard_tested':False}
