import unittest,sqlite3,tempfile,sys
from pathlib import Path
from aiohttp import web
from aiohttp.test_utils import TestClient,TestServer
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from wakhan_music import install
class Lease:
 allowed=True
 def verify(self,token,purpose):
  if token!='valid' or purpose!='media':raise ValueError('token')
  return {'uid':1,'file':'song.m4a'}
 async def entitlement(self,uid):return {'allowed':self.allowed}
class Media(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.folder=tempfile.TemporaryDirectory();self.root=Path(self.folder.name);self.file=self.root/'song.m4a';self.file.write_bytes(b'0123456789'*1000);self.db=sqlite3.connect(':memory:');self.db.execute('CREATE TABLE wka_accounts(uid INTEGER,done INTEGER,blocked INTEGER)');self.db.execute('INSERT INTO wka_accounts VALUES(1,1,0)');self.db.commit();self.personal=Lease();self.app=web.Application();install(self.app,{'DB':self.db,'CACHE':str(self.root),'WM_PERSONAL':self.personal,'auth':lambda fn:fn,'J':lambda data,status=200:web.json_response(data,status=status)});self.client=TestClient(TestServer(self.app));await self.client.start_server()
 async def asyncTearDown(self):await self.client.close();self.db.close();self.folder.cleanup()
 async def test_requires_signed_file_scope_not_just_an_account_header(self):
  for target in ['song.m4a','song.m4a?lease=invalid','other.m4a?lease=valid']:
   r=await self.client.get('/api/app/music/media/'+target,headers={'X-Init':'anything'});self.assertEqual(r.status,403)
 async def test_native_range_without_x_init_preserves_entitlement(self):
  r=await self.client.get('/api/app/music/media/song.m4a?lease=valid',headers={'Range':'bytes=100-199'});self.assertEqual(r.status,206);self.assertEqual(await r.read(),self.file.read_bytes()[100:200]);self.assertEqual(r.headers['Content-Range'],'bytes 100-199/10000');self.assertIn('private',r.headers['Cache-Control'])
  self.personal.allowed=False;r=await self.client.get('/api/app/music/media/song.m4a?lease=valid');self.assertEqual(r.status,403)
 async def test_blocked_or_incomplete_account_cannot_reuse_a_lease(self):
  for done,blocked in [(1,1),(0,0)]:
   self.db.execute('UPDATE wka_accounts SET done=?,blocked=?',(done,blocked));self.db.commit();r=await self.client.get('/api/app/music/media/song.m4a?lease=valid');self.assertEqual(r.status,403)
 async def test_symlink_file_is_never_served(self):
  outside=self.root/'elsewhere';outside.mkdir();secret=outside/'private';secret.write_bytes(b'private');self.file.unlink();self.file.symlink_to(secret);r=await self.client.get('/api/app/music/media/song.m4a?lease=valid');self.assertEqual(r.status,404)
if __name__=='__main__':unittest.main()
