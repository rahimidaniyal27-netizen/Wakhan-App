async def exercise_offline(browser,base,init,engine):
 context=await browser.new_context(viewport={'width':393,'height':852},is_mobile=True,has_touch=True)
 await context.add_init_script(init+r'''
 Object.defineProperty(navigator,'onLine',{get:()=>false});window.__offlineApi=0;window.__offlineKeys=[];
 const nativeBase=window.Capacitor.nativePromise;window.Capacitor.nativePromise=async(plugin,method,args)=>{
  if(plugin==='WakhanDownloads'&&method==='source'){
   __offlineKeys.push(args.key);const samples=44100*5,buf=new ArrayBuffer(44+samples*2),d=new DataView(buf),text=(i,s)=>[...s].forEach((c,j)=>d.setUint8(i+j,c.charCodeAt()));text(0,'RIFF');d.setUint32(4,buf.byteLength-8,true);text(8,'WAVEfmt ');d.setUint32(16,16,true);d.setUint16(20,1,true);d.setUint16(22,1,true);d.setUint32(24,44100,true);d.setUint32(28,88200,true);d.setUint16(32,2,true);d.setUint16(34,16,true);text(36,'data');d.setUint32(40,samples*2,true);
   return {source:URL.createObjectURL(new Blob([buf],{type:'audio/wav'})),cover:'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"/>',bytes:buf.byteLength};
  }return nativeBase(plugin,method,args)
 };
 ''')
 page=await context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 async def offline(route):
  await page.evaluate('window.__offlineApi++');await route.abort()
 await page.route('https://music.kabulcafe.uk/api/**',offline)
 await page.goto(base);await page.wait_for_function('!!window.WakhanMusicUI')
 assert await page.locator('#wk-music .page').get_attribute('data-view')=='downloads'
 assert await page.evaluate('__offlineApi')==0
 # Seed durable per-account downloads with a valid local WAV; no online metadata.
 await page.evaluate(r'''async()=>{
  const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('wakhan-music-v1',1);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(Error(r.error?.name+':'+r.error?.message))});
  const samples=44100*5,buf=new ArrayBuffer(44+samples*2),d=new DataView(buf),text=(i,s)=>[...s].forEach((c,j)=>d.setUint8(i+j,c.charCodeAt()));text(0,'RIFF');d.setUint32(4,buf.byteLength-8,true);text(8,'WAVEfmt ');d.setUint32(16,16,true);d.setUint16(20,1,true);d.setUint16(22,1,true);d.setUint32(24,44100,true);d.setUint32(28,88200,true);d.setUint16(32,2,true);d.setUint16(34,16,true);text(36,'data');d.setUint32(40,samples*2,true);
  await new Promise((resolve,reject)=>{const tx=db.transaction('downloads','readwrite');for(const uid of ['1','2'])tx.objectStore('downloads').put({key:uid+':ia.offline',owner:uid,id:'ia.offline',title:uid==='1'?'Offline own':'OTHER PRIVATE ACCOUNT',artist:'Review',provider:'archive',duration:5,native:{bytes:441044},persistent:true,downloadable:true});tx.oncomplete=resolve;tx.onerror=()=>reject(Error(tx.error?.name+':'+tx.error?.message))});db.close();
 }''')
 await page.reload();await page.locator('#wk-music [data-track="ia.offline"]').wait_for();assert 'OTHER PRIVATE ACCOUNT'not in await page.locator('#wk-music .page').inner_text()
 await page.locator('#wk-music [data-action=play]').click()
 await page.wait_for_function('WakhanMusicUI.queue.state().current?.local===true')
 await page.wait_for_function('WakhanMusicUI.queue.state().loading===false')
 assert not await page.evaluate('WakhanMusicUI.queue.state().error')
 assert await page.evaluate('__offlineApi')==0
 assert await page.evaluate('__offlineKeys.length>0&&__offlineKeys.every(k=>k.startsWith("u1_"))')
 assert not errors,errors
 # Missing credentials may not expose either account's downloads.
 await page.evaluate("localStorage.removeItem('wkv_session')")
 # INIT seeds the sample session on each load; clear it AFTER that script on this last load.
 await page.add_init_script("localStorage.removeItem('wkv_session')")
 await page.reload();await page.wait_for_timeout(400);assert await page.locator('#wk-music').count()==0
 await context.close()
 return dict(cold_start_without_server=True,durable_download_after_restart=True,real_local_wav_prepared=True,other_account_excluded=True,missing_session_blocked=True,physical_device=False)
