import asyncio,sqlite3,tempfile,unittest,sys
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from wakhan_music.discovery import Discovery,external_id,decode_external,external_track
from wakhan_music.preferences import Preferences
from wakhan_music.providers import Providers
YT={'id':'abcdefghijk','title':'پرواز','ch':'هنرمند','thumb':'https://i.ytimg.com/vi/abcdefghijk/hqdefault.jpg','dur':180}
SC={'id':'42','url':'https://soundcloud.com/artist/song','title':'Test','ch':'Artist','thumb':'https://i1.sndcdn.com/artworks-test.jpg','dur':180}
class Identifiers(unittest.TestCase):
 def test_only_canonical_public_provider_links(self):
  for v in ('https://soundcloud.com@evil.org/a/b','https://soundcloud.com/a/b?url=bad','http://soundcloud.com/a/b','https://soundcloud.com/a','https://soundcloud.com/a/../b','https://soundcloud.com:8/a/b'):
   if '?'in v:continue
   with self.assertRaises(ValueError):external_id('soundcloud',v)
  i=external_id('soundcloud',SC['url']);self.assertEqual(decode_external(i),('soundcloud',SC['url']))
  for v in ('yt.abcdefghi','yt.abcdefghijkxx','sc.aHR0cHM6Ly9ldmlsLm9yZy9hL2I'):
   with self.assertRaises(ValueError):decode_external(v)
 def test_online_never_downloadable_and_original_cover(self):
  for provider,x in [('youtube',YT),('soundcloud',SC)]:
   t=external_track(provider,x);self.assertTrue(t['embed']);self.assertFalse(t['downloadable']);self.assertFalse(t['persistent']);self.assertEqual(t['cover'],x['thumb'])
class Account(unittest.TestCase):
 def test_restart_isolation_minimum_play_and_replay_throttle(self):
  with tempfile.TemporaryDirectory()as d:
   path=Path(d)/'prefs.sqlite';db=sqlite3.connect(path);p=Preferences(db);t=external_track('youtube',YT)
   with self.assertRaises(ValueError):p.listen(1,t,1,100)
   self.assertFalse(p.profile(1));self.assertTrue(p.listen(1,t,30,100));self.assertFalse(p.listen(1,t,30,120));self.assertFalse(p.profile(2));before=p.profile(1);db.close()
   db=sqlite3.connect(path);p=Preferences(db);self.assertEqual(p.profile(1),before);self.assertEqual(p.query(1),'هنرمند');self.assertTrue(p.listen(1,t,30,200));self.assertFalse(p.profile(2));db.close()
 def test_personal_does_not_forge_provider_ranking(self):
  p=Preferences(sqlite3.connect(':memory:'));a=external_track('youtube',YT);b=external_track('soundcloud',SC);p.listen(1,a,30,100);self.assertEqual(p.rank(1,[b,a])[0]['id'],a['id']);self.assertEqual(p.rank(2,[b,a])[0]['id'],b['id'])
class Catalog(unittest.IsolatedAsyncioTestCase):
 async def test_common_search_keeps_both_sources_even_when_licensed_down(self):
  calls=[]
  def flat(target,n):calls.append(target);return [YT]if target.startswith('ytsearch')else [SC]
  p=Discovery({'_flat':flat})
  async def fail(*a):raise TimeoutError()
  with patch.object(Providers,'catalog',fail):
   a,b=await asyncio.gather(p.catalog('persian'),p.catalog('persian'));self.assertEqual(a,b);self.assertEqual(len(calls),2);self.assertEqual({t['provider']for t in a['items']},{'youtube','soundcloud'});self.assertTrue(a['partial']);self.assertEqual((await p.resolve(a['items'][0]['id']))['id'],a['items'][0]['id'])
  await p.close()
 async def test_link_cannot_send_other_hosts_to_metadata(self):
  calls=[]
  p=Discovery({'_flat':lambda *a:calls.append(a)})
  with self.assertRaises(ValueError):await p.external('youtube','https://evil.org/?v=abcdefghijk')
  self.assertFalse(calls);await p.close()
 async def test_chart_is_provider_ranking_not_search(self):
  p=Discovery({'_flat':lambda *a:(_ for _ in ()).throw(AssertionError('search'))})
  async def chart(*a):return dict(ok=True,items=[],updated=1,ranking='providers')
  with patch.object(Providers,'catalog',chart):self.assertEqual((await p.catalog())['ranking'],'providers')
  await p.close()
if __name__=='__main__':unittest.main()
