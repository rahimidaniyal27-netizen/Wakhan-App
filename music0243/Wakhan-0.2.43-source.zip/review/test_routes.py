import sys,unittest,sqlite3
from pathlib import Path
from aiohttp import web
from aiohttp.test_utils import TestClient,TestServer
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from wakhan_music import install
class Routes(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.app=web.Application();self.ns={'DB':sqlite3.connect(':memory:'),'J':lambda value,status=200:web.json_response(value,status=status)}
  def auth(fn):
   async def guarded(req):
    if req.headers.get('X-Init')!='test-account':return web.json_response({'ok':False,'err':'auth'},status=401)
    req['u']={'id':1};return await fn(req)
   return guarded
  self.ns['auth']=auth;install(self.app,self.ns);self.client=TestClient(TestServer(self.app));await self.client.start_server()
 async def asyncTearDown(self):
  await self.client.close();self.ns['DB'].close()
 async def test_chart_search_resolve_are_authenticated(self):
  for path in ['/chart','/search?q=x','/resolve?id=au.abc','/recommendations']:
   r=await self.client.get('/api/app/music'+path);self.assertEqual(r.status,401)
 async def test_listen_is_also_authenticated(self):
  r=await self.client.post('/api/app/music/listen',json={'id':'yt.abcdefghijk','seconds':30});self.assertEqual(r.status,401)
 async def test_chart_is_never_a_persistent_http_cache(self):
  async def catalog():return dict(ok=True,items=[])
  self.ns['WKM_MUSIC'].catalog=catalog
  r=await self.client.get('/api/app/music/chart',headers={'X-Init':'test-account'});self.assertEqual(r.headers['Cache-Control'],'no-store');self.assertTrue((await r.json())['ok'])
 async def test_malformed_id_does_not_fetch_client_url(self):
  r=await self.client.get('/api/app/music/resolve?id=https://127.0.0.1/private',headers={'X-Init':'test-account'});self.assertEqual(r.status,400)
 async def test_search_length_is_bounded(self):
  r=await self.client.get('/api/app/music/search?q='+('x'*121),headers={'X-Init':'test-account'});self.assertEqual(r.status,400)
if __name__=='__main__':unittest.main()
