import UIKit
import Capacitor

/// Same plugin name as on Android: phone languages, and the colour behind the bars.
@objc(WakhanLocalePlugin)
public class WakhanLocalePlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "WakhanLocalePlugin"
    public let jsName = "WakhanLocale"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "preferred", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "bars", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "safeArea", returnType: CAPPluginReturnPromise)
    ]

    @objc func preferred(_ call: CAPPluginCall) {
        call.resolve(["languages": Locale.preferredLanguages])
    }

    /// Report only the unsafe edges still exposed inside this web view. A web
    /// view already below the status bar returns zero, avoiding a second inset.
    @objc func safeArea(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard let web = self.bridge?.webView, let window = web.window,
                  web.bounds.width > 0, web.bounds.height > 0 else {
                call.reject("web view is not visible")
                return
            }
            let frame = web.convert(web.bounds, to: window)
            let safe = window.safeAreaLayoutGuide.layoutFrame
            call.resolve([
                "width": Double(web.bounds.width),
                "top": Double(min(frame.height, max(0, safe.minY - frame.minY))),
                "right": Double(min(frame.width, max(0, frame.maxX - safe.maxX))),
                "bottom": Double(min(frame.height, max(0, frame.maxY - safe.maxY))),
                "left": Double(min(frame.width, max(0, safe.minX - frame.minX)))
            ])
        }
    }

    @objc func bars(_ call: CAPPluginCall) {
        var hex = (call.getString("color") ?? "#071019").trimmingCharacters(in: .whitespaces)
        if hex.hasPrefix("#") { hex.removeFirst() }
        guard hex.count == 6, let n = UInt32(hex, radix: 16) else { call.reject("bad colour"); return }
        let c = UIColor(red: CGFloat((n >> 16) & 255) / 255, green: CGFloat((n >> 8) & 255) / 255, blue: CGFloat(n & 255) / 255, alpha: 1)
        DispatchQueue.main.async {
            let vc = self.bridge?.viewController
            (vc?.parent?.view ?? vc?.view)?.backgroundColor = c
            call.resolve()
        }
    }
}
