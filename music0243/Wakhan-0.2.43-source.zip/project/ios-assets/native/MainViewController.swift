import UIKit
import WebKit
import Capacitor

/// The web canvas fills the screen, including the space behind the system bars.
/// Each page protects its controls with measured/CSS safe-area insets.
class WakhanBridgeViewController: CAPBridgeViewController {
    override func capacitorDidLoad() {
        bridge?.registerPluginInstance(WakhanLocalePlugin())
        bridge?.registerPluginInstance(WakhanDownloadsPlugin())
        bridge?.registerPluginInstance(WakhanMusicPlugin())
    }
}

class MainViewController: UIViewController {
    private let child = WakhanBridgeViewController()

    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(active), name: UIApplication.didBecomeActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(inactive), name: UIApplication.willResignActiveNotification, object: nil)
        view.backgroundColor = UIColor(red: 0, green: 71/255, blue: 1, alpha: 1)
        addChild(child)
        let web = child.view!
        web.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(web)
        NSLayoutConstraint.activate([
            web.topAnchor.constraint(equalTo: view.topAnchor),
            web.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            web.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        child.didMove(toParent: self)
    }

    @objc private func active() { UIApplication.shared.isIdleTimerDisabled = true }
    @objc private func inactive() { UIApplication.shared.isIdleTimerDisabled = false }
    deinit { NotificationCenter.default.removeObserver(self) }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIApplication.shared.isIdleTimerDisabled = UIApplication.shared.applicationState == .active
    }

    override var childForStatusBarStyle: UIViewController? { child }
    override var childForStatusBarHidden: UIViewController? { child }
}
