import {musicSource} from './music-source.mjs';
/* Reuse the app's existing authenticated audio preparation, including its
   entitlement and lease checks. Do not use or conceal an IFrame player. */
export async function externalAudio({track,fetchBinary,origin='https://music.kabulcafe.uk',valid=()=>true,delay=ms=>new Promise(r=>setTimeout(r,ms)),now=Date.now,timeout=245000}){
 if(!['youtube','soundcloud'].includes(track.provider))return track;
 const started=now(),owner=track.id;
 while(valid()){
  const response=await fetchBinary(origin+'/api/v60/audio?url='+encodeURIComponent(track.source_url),{cache:'no-store'});
  if(!valid())throw Error('cancelled');
  const data=await response.json();
  if(response.status===401)throw Error('auth');
  if(response.status===403)throw Error(data.err==='subscription_required'||data.err==='subscription'?'subscription_required':'audio_unavailable');
  if(data.pending){if(now()-started>timeout)throw Error('audio_timeout');await delay(2000);continue}
  if(!response.ok||!data.ok||typeof data.src!=='string'||!data.src.startsWith('/a/'))throw Error('audio_unavailable');
  const stream=musicSource(new URL(data.src,origin).href,origin);if(!stream)throw Error('audio_unavailable');
  return {...track,id:owner,embed:false,stream,duration:Number(data.dur)||track.duration,downloadable:false,persistent:false,playback:'audio'};
 }
 throw Error('cancelled');
}
