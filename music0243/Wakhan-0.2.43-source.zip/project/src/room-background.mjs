/* A native player preloads the already-authorized salon stream while visible.
   OS lifecycle owns the audio handoff and native room polling while WebView sleeps. */
export function installRoomBackground({player,enabled,getContext,getToken,beforeStart=()=>{},pauseVideo=()=>{},resumeVideo=()=>{},hooks,interval=1500}){
 if(!enabled)return {sync(){},appState(){},dispose(){}};
 let room=null,id='',serial=0,disposed=false,loading=null,blocked=false;
 const key=c=>c.code+'|'+c.vid+'|'+c.revision;
 async function stop(){++serial;loading=null;const old=id;id='';room=null;if(old)await player.control({id:old,action:'stop'}).catch(()=>{})}
 async function sync(authoritative=false){
  if(disposed||document.hidden)return;if(authoritative)blocked=false;if(blocked)return;
  const c=getContext();if(!c){if(room||id)void stop();return}
  if(room===key(c)){if(id&&!loading)void player.control({id,action:'room-sync',position:c.position,playing:c.playing,muted:!!c.muted}).catch(()=>{});return}
  const generation=++serial;const old=id;id='';room=key(c);if(old)await player.control({id:old,action:'stop'}).catch(()=>{});if(disposed||generation!==serial)return;
  beforeStart();const request='room_'+Date.now()+'_'+generation;id=request;
  loading=player.loadTrack({id:request,source:c.source,title:c.title||'Wakhan',artist:'',position:c.position,playing:c.playing,roomCode:c.code,roomToken:getToken(),roomVideo:c.vid,roomRevision:c.revision,roomCanEnd:!!c.can,muted:!!c.muted});
  try{await loading}catch{if(generation===serial){id='';room=null}}finally{if(generation===serial)loading=null}
 }
 function appState(active){if(disposed)return;if(!active){if(id)pauseVideo()}else{void sync();if(id)resumeVideo()}}
 const previousSet=hooks.getSet(),replacementSet=function(...args){const value=previousSet.apply(this,args);void sync(true);return value};hooks.setSet(replacementSet);
 const previousStop=hooks.getStop(),replacementStop=function(...args){const preserve=hooks.preserve?.();const value=previousStop.apply(this,args);if(!preserve){blocked=true;void stop()}return value};hooks.setStop(replacementStop);
 const visibility=()=>appState(!document.hidden);document.addEventListener('visibilitychange',visibility);const timer=setInterval(()=>void sync(),interval);
 return {sync,appState,dispose(){if(disposed)return;disposed=true;clearInterval(timer);document.removeEventListener('visibilitychange',visibility);if(hooks.getSet()===replacementSet)hooks.setSet(previousSet);if(hooks.getStop()===replacementStop)hooks.setStop(previousStop);void stop()}};
}
