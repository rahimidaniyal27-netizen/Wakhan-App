import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const read=p=>readFileSync(new URL(p,import.meta.url),'utf8'),sha=s=>createHash('sha256').update(s).digest('hex');
const patch=JSON.parse(read('./salon-patch-manifest.json'));
const shell=JSON.parse(read('../public/wakhan-shell.json')),baseline=JSON.parse(read('./cinema-027-baseline.json'));
test('96 non-chat programs and shell markup retain exact bytes; three salon programs match only the declared corrections',()=>{
 assert.equal(Object.keys(baseline.programs).length,99);assert.equal(sha(shell.head),baseline.head_sha256);assert.equal(sha(shell.body),baseline.body_sha256);
 const ids=new Set(shell.programs.map(p=>p.id));assert.equal(ids.size,shell.programs.length);
 for(const [id,digest] of Object.entries(baseline.programs)){const p=shell.programs.find(p=>p.id===id);assert(p,id);if(!patch.changes.some(c=>c.program===id))assert.equal(sha(p.code),digest,id+' changed outside the declared salon correction');else {let original=p.code;for(const c of [...patch.changes].reverse().filter(c=>c.program===id)){assert.equal(original.split(c.after).length-1,1);original=original.replace(c.after,c.before);}assert.equal(sha(original),digest,id+' exceeds the declared correction');}}
 for(const id of ['sln3.js','slr3.js','slr6.js','slr7.js','slr8.js','slr9.js','ytp3.js','me3.js','wkt.js'])assert(ids.has(id),id);
});
test('chat has one entry and no legacy renderer can install a second composer',()=>{
 assert(!shell.programs.some(p=>['chat2.js','social36.js'].includes(p.id)));
 const main=read('../src/main.mjs');assert.equal((main.match(/installChat\(\{/g)||[]).length,1);assert(main.includes('bindPageNavigation(window.WakhanPages)'));assert(main.includes('window.WakhanChat?.back()'));assert(main.includes('window.WakhanChat?.resume()'));
});
test('normal build validates current shell instead of replaying historical snapshots',()=>{
 const pkg=JSON.parse(read('../package.json')),build=read('../scripts/build.mjs');assert.equal(pkg.scripts['prepare:web'],'node scripts/validate-client.mjs');assert(!build.includes('prepare-web.py'));assert(!build.includes('apply-ui-hotfix'));const release=JSON.parse(read('../public/wakhan-release.json'));assert.equal(pkg.wakhanBuild,release.build);assert.equal(pkg.version,release.version);
});
