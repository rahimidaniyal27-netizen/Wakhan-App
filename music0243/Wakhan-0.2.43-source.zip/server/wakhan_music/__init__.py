import asyncio,collections,json,time
from .discovery import Discovery
from .preferences import Preferences

def install(app,namespace):
    from aiohttp import web
    p=Discovery(namespace);preferences=Preferences(namespace['DB']);rates=collections.OrderedDict()
    def limited(uid):
        now=time.monotonic();q=rates.setdefault(uid,collections.deque())
        while q and q[0]<now-60:q.popleft()
        if len(q)>=45:return True
        q.append(now);rates.move_to_end(uid)
        while len(rates)>5000:rates.popitem(last=False)
        return False
    def add(path,handler,method='GET'):
        async def route(req):
            if limited(int(req['u']['id'])):return namespace['J'](dict(ok=False,err='slow'),429)
            try:
                value=await handler(req);response=namespace['J'](value);response.headers['Cache-Control']='no-store';return response
            except (ValueError,TypeError,json.JSONDecodeError):return namespace['J'](dict(ok=False,err='track_unavailable'),400)
            except Exception as exc:
                if isinstance(exc,asyncio.CancelledError):raise
                return namespace['J'](dict(ok=False,err='music_unavailable'),503)
        app.router.add_route(method,'/api/app/music'+path,namespace['auth'](route))
    async def chart(req):return await p.catalog()
    async def search(req):
        q=str(req.query.get('q','')).strip()
        if not 1<=len(q)<=120:raise ValueError('query')
        return await p.catalog(q)
    async def resolve(req):
        ident=str(req.query.get('id',''))
        if len(ident)>1200:raise ValueError('track')
        return dict(ok=True,item=await p.resolve(ident))
    async def recommendations(req):
        uid=int(req['u']['id']);language=str(req['u'].get('language_code') or 'fa')[:2]
        value=await p.catalog(preferences.query(uid,language))
        return dict(ok=True,items=preferences.rank(uid,value['items']),personalized=bool(preferences.profile(uid)),updated=value['updated'],partial=value.get('partial',False))
    async def listen(req):
        body=await req.json();ident=str(body.get('id',''))
        if len(ident)>1200:raise ValueError('track')
        item=await p.resolve(ident);recorded=preferences.listen(int(req['u']['id']),item,body.get('seconds',0))
        return dict(ok=True,recorded=recorded)
    add('/recommendations',recommendations);add('/listen',listen,'POST')
    add('/chart',chart);add('/search',search);add('/resolve',resolve)
    async def start(app):await p.start()
    async def close(app):await p.close()
    app.on_startup.append(start);app.on_cleanup.append(close)
    namespace['WKM_MUSIC']=p
