/* WAKHAN Home design UI. Sample data is intentional; game engines and server binding are the next phase. */

(()=>{
 const root=document.getElementById('wakhan-home-final'),phone=root.querySelector('.hc-phone'),content=phone.querySelector('.hc-content'),header=phone.querySelector('.hc-header'),nav=phone.querySelector('.hc-nav'),overlay=phone.querySelector('.hc-overlay'),dialog=overlay.querySelector('.hc-dialog'),dialogBody=overlay.querySelector('.hc-dialog-content');
 const games=[{id:'fiskot',name:'فیس‌کوت',min:4,max:4,dimension:'دوبعدی'},{id:'ludo',name:'لدو',min:2,max:4,dimension:'دوبعدی'},{id:'chess',name:'شطرنج',min:2,max:2,dimension:'دوبعدی'},{id:'ono',name:'Ono',min:2,max:6,dimension:'دوبعدی'},{id:'patpal',name:'پت‌پال',min:4,max:16,dimension:'سه‌بعدی'},{id:'bazaar',name:'گم در بازار',min:4,max:10,dimension:'سه‌بعدی'}];
 const friends=[];
 const initial=window.openai?.widgetState?.privateContent?.homeFinal||{};
 const state={selected:games.some(g=>g.id===initial.selected)?initial.selected:'fiskot',view:'home',party:Array.isArray(initial.party)?initial.party.filter(id=>friends.some(f=>f.id===id)):[],glow:initial.glow!==false,showResume:false,invitation:false,mic:false,listen:true,public:false,host:true,origin:'home',players:1,lobbyGame:'ludo',hasLobby:false,lobbyPlayers:0,lobbyHost:true,inviteUntil:0,notifications:true};
 const gameStates=Object.fromEntries(games.map(g=>[g.id,{public:false,lobby:null}]));gameStates.ludo.lobby=null;
 const gameDetails={fiskot:{color:'#b09a6352',description:'چهار بازیکن در دو تیم دونفره روبه‌روی هم قرار می‌گیرند.'},ludo:{color:'#3d9b8052',description:'بازی لدو با دو تا چهار بازیکن.'},chess:{color:'#8aa4b24d',description:'رقابت دونفره روی صفحهٔ شطرنج.'},ono:{color:'#ad72ac49',description:'کارت‌های رنگی و رقابت با دو تا شش بازیکن.'},patpal:{color:'#3b9c9c4a',description:'پنهان‌شدن و جستجو در محیط سه‌بعدی.'},bazaar:{color:'#b17b4e4d',description:'ماجراجویی در گذرگاه‌های یک بازار افغانی.'}};
 let lastTrigger=null,inviteTimer=0,toastTimer=0,dialogKey='';
 const fa=n=>String(n).replace(/\d/g,d=>'0123456789'[d]);
 const game=id=>games.find(g=>g.id===id)||games[0];
 const capacity=g=>g.min===g.max?fa(g.max)+' نفر':fa(g.min)+' تا '+fa(g.max)+' نفر';
 function el(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;}
 function icon(name){const n=el('i');n.dataset.lucide=name;n.setAttribute('aria-hidden','true');return n;}
 function art(id,size){const n=el('span','hc-art');n.dataset.art=id;n.setAttribute('aria-hidden','true');if(size){n.style.width=size+'px';n.style.height=size+'px';}return n;}
 function button(label,action,cls='hc-secondary',symbol){const n=el('button',cls+' cursor-interaction');n.type='button';if(symbol)n.append(icon(symbol));if(label)n.append(document.createTextNode(label));if(action)n.dataset.action=action;return n;}
 function iconButton(label,action,symbol){const n=button('',action,'hc-icon',symbol);n.setAttribute('aria-label',label);return n;}
 function avatar(name,color){const n=el('span','hc-avatar',name.slice(0,1));if(color)n.style.background='radial-gradient(circle at 30% 20%,'+color+',#25283e)';return n;}
 function icons(){if(globalThis.lucide)lucide.createIcons({attrs:{width:18,height:18}});}
 function save(){rememberLobby();window.openai?.setWidgetState?.({modelContent:{design:'نمونهٔ ظاهری خانهٔ واخان، شیشه و فلز؛ کارکرد بازی‌ها نمایشی است',selectedGame:game(state.selected).name,selectedFriends:state.party.length,rankingCategory:rankState.category,rankingPeriod:rankState.period,language:'دری معیار',gameNames:games.map(g=>g.name)},privateContent:{homeFinal:{selected:state.selected,party:state.party,glow:state.glow,showResume:state.showResume,rankCategory:rankState.category,rankPeriod:rankState.period,rankGame:rankState.game}}})?.catch(()=>{});}
 function heading(title,label,action){const n=el('div','hc-section-head');n.append(el('h3',null,title));if(label)n.append(button(label,action,'hc-text-action','chevron-left'));return n;}
 function closeDialog(){overlay.hidden=true;dialogKey='';clearInterval(inviteTimer);[header,content,nav].forEach(n=>n.inert=false);if(lastTrigger?.isConnected)lastTrigger.focus({preventScroll:true});}
 function showDialog(title,key,body,trigger){clearInterval(inviteTimer);lastTrigger=trigger||lastTrigger;dialogKey=key;dialog.dataset.kind=key;dialog.querySelector('h3').textContent=title;dialogBody.replaceChildren(body);dialog.querySelector('.hc-message').textContent='';overlay.hidden=false;[header,content,nav].forEach(n=>n.inert=true);const r=phone.getBoundingClientRect(),h=dialog.getBoundingClientRect().height;const anchor=trigger?.isConnected?trigger.getBoundingClientRect().top-r.top:140;const y=Math.max(90,Math.min(anchor-70,phone.clientHeight-h-24));phone.style.setProperty('--sheet-top',y+'px');dialog.querySelector('[data-action=close]').focus({preventScroll:true});icons();}
 function message(text){dialog.querySelector('.hc-message').textContent=text;}
 function toast(text,trigger){phone.querySelector('.hc-toast')?.remove();clearTimeout(toastTimer);const n=el('div','hc-toast',text);n.setAttribute('role','status');const r=phone.getBoundingClientRect(),at=trigger?.isConnected?trigger.getBoundingClientRect().top-r.top:110;phone.style.setProperty('--toast-top',Math.max(90,Math.min(phone.clientHeight-80,at-55))+'px');phone.append(n);toastTimer=setTimeout(()=>n.remove(),2800);}
 function routeRow(title,sub,symbol,action){const row=button('',action,'hc-route-row'),copy=el('span');copy.append(el('b',null,title),el('small',null,sub));row.append(icon(symbol),copy,icon('chevron-left'));return row;}
 function voice(){const n=el('div','hc-voice'),label=el('span');label.append(icon('audio-lines'),document.createTextNode('گفت‌وگوی صوتی بازی'));const tools=el('div');const listen=iconButton(state.listen?'خاموش‌کردن صدا':'روشن‌کردن صدا','listen',state.listen?'volume-2':'volume-x'),mic=iconButton(state.mic?'خاموش‌کردن مایکروفون':'روشن‌کردن مایکروفون','mic',state.mic?'mic':'mic-off');listen.setAttribute('aria-pressed',String(state.listen));mic.setAttribute('aria-pressed',String(state.mic));tools.append(listen,mic);n.append(label,tools);return n;}
 function matchRow(g,name,count,action='join'){const row=el('div','hc-match-row'),copy=el('div','hc-match-copy');copy.append(el('b',null,name),el('small',null,g.name+' · '+fa(count)+' از '+fa(g.max)+' بازیکن'));const join=button('پیوستن',action,'hc-join');join.dataset.game=g.id;row.append(art(g.id),copy,join);return row;}
 function renderHeader(){
 header.replaceChildren();
 if(state.view==='home'){
  const wallet=button('', 'wallet','hc-wallet');wallet.setAttribute('aria-label','موجودی سکه: '+liveAmount());const coin=el('span','hc-coin-mark');coin.append(icon('coins'));const amount=el('span','hc-wallet-value');amount.append(el('b',null,liveAmount()));wallet.append(coin,amount,el('span','hc-wallet-add','+'));
  const tools=el('div','hc-tools'),bell=iconButton('دعوت‌ها','invitations','bell');if(state.invitation)bell.append(el('span','hc-dot'));tools.append(bell);header.append(wallet,tools);return;
 }
 header.append(iconButton('برگشت','back','chevron-right'));const brand=el('div','hc-brand');brand.append(el('h2',null,['game','arena'].includes(state.view)?game(state.selected).name:({ranking:'برترین‌ها',lobby:'میز انتظار',salon:'سالون',music:'موسیقی',cinema:'سینما',chats:'گفت‌وگوها',account:'حساب من'}[state.view]||'')));const tools=el('div','hc-tools');tools.append(iconButton('دعوت‌ها','invitations','bell'));header.append(brand,tools);
}

function friendStrip(){const list=el('div','hc-friends');friends.forEach(f=>{const n=button('',null,'hc-friend');n.dataset.friend=f.id;n.setAttribute('aria-label','انتخاب '+f.full+' برای دعوت');n.setAttribute('aria-pressed',String(state.party.includes(f.id)));const av=avatar(f.name,f.color);av.append(el('i','hc-online'));n.append(av,el('span',null,f.name));list.append(n);});const invite=button('','friends','hc-invite-friends','user-round-plus');invite.setAttribute('aria-label','دعوت از دوستان');list.append(invite);return list;}
 function rememberLobby(){if(state.view==='lobby'&&state.hasLobby){gameStates[state.lobbyGame].public=state.public;gameStates[state.lobbyGame].lobby={players:state.players,host:state.host,origin:state.origin};state.lobbyPlayers=state.players;state.lobbyHost=state.host;}}
 function resumeRow(id){const g=game(id),lobby=gameStates[id].lobby;if(!lobby)return null;const row=el('div','hc-resume'),copy=el('div','hc-resume-copy');copy.append(el('b',null,'میز '+g.name),el('small',null,fa(lobby.players)+' از '+fa(g.max)+' بازیکن'));const resume=button('ادامه','resume','hc-quiet','arrow-up-left');resume.dataset.resumeGame=id;row.append(art(id),copy,resume);return row;}
 function openGame(id,origin){rememberLobby();state.selected=id;if(origin)state.origin=origin;state.view='game';render();save();}
 function loadLobby(id){rememberLobby();const saved=gameStates[id].lobby;if(!saved){makeLobby(id,true,1,'home');return;}state.selected=id;state.lobbyGame=id;state.players=saved.players;state.host=saved.host;state.origin=saved.origin;state.public=gameStates[id].public;state.lobbyPlayers=saved.players;state.lobbyHost=saved.host;state.hasLobby=true;state.view='lobby';render();}
 function renderGame(){const g=game(state.selected),meta=gameDetails[g.id];content.replaceChildren();content.dataset.gamePage=g.id;const page=el('section','hc-game-page'),hero=el('div','hc-game-hero');hero.style.setProperty('--game-light',meta.color);hero.append(art(g.id),el('h3',null,g.name));const labels=el('div','hc-game-meta'),capacityLabel=el('span'),dimension=el('span');capacityLabel.append(icon('users-round'),document.createTextNode(capacity(g)));dimension.append(icon(g.dimension==='سه‌بعدی'?'box':'layout-grid'),document.createTextNode(g.dimension));labels.append(capacityLabel,dimension);hero.append(labels);page.append(hero,el('p','hc-game-description',meta.description));const actions=el('div','hc-actions');actions.append(button('ایجاد بازی','create','hc-primary','plus'),button('پیوستن','matches','hc-secondary','log-in'));page.append(actions,button('نمای بازی','arena','gm-arena-entry','eye'),gameRankShortcut(g));
  if(state.showResume){const resume=resumeRow(g.id);if(resume)page.append(resume);}page.append(heading('دعوت از دوستان','انتخاب','friends'),friendStrip(),button('دربارهٔ '+g.name,'game-info','hc-page-info','info'));content.append(page);
 }

 function homeGameCard(g,featured){
 const card=button('',null,'hm-game-card'+(featured?' is-featured':''));card.dataset.openGame=g.id;card.setAttribute('aria-label','ورود به '+g.name+'، '+capacity(g));
 const scene=art(g.id);scene.classList.add('hm-cover-art');const copy=el('span','hm-cover-copy');copy.append(el('b',null,g.name));
 const cap=el('span','hm-cover-capacity');cap.append(icon('users-round'),el('span',null,g.min===g.max?String(g.max):g.min+'–'+g.max));copy.append(cap);card.append(scene,copy);
 if(featured){const arrow=el('span','hm-cover-arrow');arrow.append(icon('chevron-left'));arrow.setAttribute('aria-hidden','true');card.append(arrow);}return card;
}
function renderNow(){}
function renderHome(){}
function rankAtmosphere(){
 const scene=el('div','gm-rank-sky gm-award-backdrop');scene.setAttribute('aria-hidden','true');
 ['gold','silver','bronze'].forEach(metal=>{const light=el('span','gm-stage-light');light.dataset.light=metal;scene.append(light);});
 scene.append(el('span','gm-stage-reflection'));return scene;
}

function walletDialog(trigger){const box=el('div'),balance=el('div','hc-wallet-balance'),mark=el('span','hc-coin-mark');mark.append(icon('coins'));balance.append(mark,el('strong',null,liveAmount()),el('span',null,'سکه'));box.append(balance,el('p',null,'افزایش سکه'));const offers=el('div','hc-wallet-offers');[1000,5000,10000].forEach(amount=>{const b=button(amount.toLocaleString('en-US'),null,'hc-wallet-offer','coins');b.dataset.coinOffer=String(amount);b.setAttribute('aria-label',amount.toLocaleString('en-US')+' سکه');offers.append(b);});box.append(offers);showDialog('سکه‌های شما','wallet',box,trigger);}
root.addEventListener('click',event=>{const b=event.target.closest('[data-coin-offer]');if(b)message('انتخاب: '+Number(b.dataset.coinOffer).toLocaleString('en-US')+' سکه · خریدی انجام نمی‌شود.');});

function historyDialog(trigger){
 const box=el('div');
 games.filter(g=>gameStates[g.id].lobby).forEach(g=>{const row=resumeRow(g.id);if(row)box.append(row);});
 if(!box.childElementCount)box.append(el('p','hc-blank','بازی ناتمام ندارید.'));
 showDialog('تاریخچهٔ بازی‌ها','history',box,trigger);
}

function codeDialog(trigger){
 const box=el('div'),label=el('label','hc-search'),input=el('input');input.placeholder='شناسهٔ بازی';input.setAttribute('aria-label','شناسهٔ بازی');input.inputMode='numeric';input.maxLength=8;input.dataset.joinCode='1';label.append(icon('key-round'),input);box.append(label,button('پیوستن','check-code','hc-primary','log-in'));showDialog('پیوستن با شناسه','code',box,trigger);input.focus({preventScroll:true});
}
 function switchRow(title,sub,key){const row=el('label','hc-setting'),copy=el('span',null,title);copy.append(el('small',null,sub));const toggle=el('input','hc-switch');toggle.type='checkbox';toggle.checked=!!state[key];toggle.dataset.switch=key;toggle.setAttribute('aria-label',title);row.append(copy,toggle);return row;}
 function renderLobby(){const g=game(state.lobbyGame);state.players=Math.max(1,Math.min(g.max,Math.round(state.players)));const box=el('section','hc-subpage'),top=el('div','hc-lobby-center');top.append(art(g.id),el('h3',null,g.name),el('p',null,fa(state.players)+' از '+fa(g.max)+' بازیکن'));const tag=el('span','hc-lobby-tag');tag.append(icon(state.players>=g.min?'circle-check':'clock-3'),document.createTextNode(state.players>=g.min?'آمادهٔ آغاز':'در انتظار بازیکنان'));top.append(tag);box.append(top);const roster=el('div','hc-roster'),names=['شما',...friends.map(f=>f.name)];for(let i=0;i<Math.min(g.max,Math.max(g.min,state.players));i++){const empty=i>=state.players,n=el('div','hc-seat'+(empty?' empty':''));n.append(avatar(empty?'＋':names[i%names.length]),el('span',null,empty?'جای خالی':i===0&&state.host?'شما · میزبان':i===1&&!state.host?'سهراب · میزبان':names[i%names.length]));roster.append(n);}box.append(roster);if(state.host){box.append(switchRow('عضوگیری','نمایش در فهرست میزها','public'));const a=el('div','hc-inline-actions'),invite=button('دعوت از دوستان','friends','hc-secondary','send'),start=button('آغاز بازی','begin','hc-primary','play');start.disabled=state.players<g.min;a.append(invite,start);box.append(a);}else{box.append(el('p','hc-blank','بازی با تصمیم میزبان آغاز می‌شود.'));}box.append(voice(),el('p','hc-blank',state.origin==='salon'?'بازی ایجادشده در سالون':'این بازی مستقل از عضویت سالون است.'));content.replaceChildren(box);}
 function renderSalon(){const box=el('section','hc-subpage'),hero=el('div','hc-salon-hero'),copy=el('div');copy.append(el('h3',null,'همراهان واخان'),el('p',null,'موسیقی و گفت‌وگو با دوستان'));const controls=el('div','hc-salon-controls');controls.append(iconButton('گفت‌وگوهای سالون','chats','message-circle'),iconButton('بازی در سالون','salon-games','gamepad-2'),iconButton('دعوت از دوستان','friends','user-round-plus'));hero.append(copy,controls);box.append(hero,heading('حاضران سالون'));const roster=el('div','hc-roster');['شما','سهراب','مریم','فرید'].forEach(name=>{const n=el('div','hc-seat');n.append(avatar(name),el('span',null,name));roster.append(n);});box.append(roster,routeRow('بازی‌های سالون','انتخاب بازی و دعوت از حاضران','gamepad-2','salon-games'),routeRow('گفت‌وگوهای سالون','پیام‌های همین جمع','messages-square','chats'),voice());content.replaceChildren(box);}
 function renderMedia(kind){const box=el('section','hc-subpage'),headingBox=el('div','hc-screen-heading');headingBox.append(el('h3',null,kind==='music'?'موسیقی شما':'سینمای واخان'),el('p',null,kind==='music'?'آهنگ‌های دل‌خواه خود را انتخاب کنید.':'تماشا در کنار دوستان'));box.append(headingBox);const now=el('div','hc-media-now');now.append(el('h3',null,kind==='music'?'آهنگ‌های دل‌خواه':'سفر به بدخشان'),el('p',null,kind==='music'?'از فهرست پسندشدهٔ خود انتخاب کنید.':'ادامهٔ تماشا از آخرین بخش'),button(kind==='music'?'شنیدن موسیقی':'ادامهٔ تماشا','play-media','hc-primary','play'));box.append(now);const rows=kind==='music'?[['آهنگ‌های پسندشده','انتخاب‌های شما','heart'],['تازه‌های موسیقی','پیشنهادهای تازه','audio-lines'],['شنیده‌های اخیر','موسیقی‌های پیشین شما','history']]:[['سالون‌های سینما','تماشای گروهی با دوستان','users-round'],['آرشیف فیلم‌ها','انتخاب فیلم و سریال','clapperboard'],['تاریخچهٔ تماشا','تماشاهای پیشین شما','history']];rows.forEach(([a,b,c])=>box.append(routeRow(a,b,c,'media-detail')));content.replaceChildren(box);}
 function renderChats(){const box=el('section','hc-subpage');box.append(heading('گفت‌وگوهای شما'));friends.slice(0,3).forEach((f,i)=>{const row=button('',null,'hc-route-row');row.dataset.chat=f.id;const copy=el('span');copy.append(el('b',null,f.full),el('small',null,['دعوت بازی را دیدید؟','برای بازی آماده‌ام.','در سالون هستم.'][i]));row.append(avatar(f.name,f.color),copy);box.append(row);});content.replaceChildren(box);}
 function renderAccount(){const box=el('section','hc-subpage'),profile=el('div','hc-profile'),copy=el('span');copy.append(el('h3',null,'حساب شما'),el('p',null,'واخان'));profile.append(avatar('شما'),copy);box.append(profile,routeRow('ویرایش حساب','نام و تصویر شما','user-round-pen','edit-profile'),routeRow('زبان برنامه','دری','languages','language'),switchRow('اعلان‌ها','دعوت‌ها و پیام‌های تازه','notifications'),routeRow('حریم خصوصی','مدیریت دسترسی و ارتباط‌ها','shield-check','privacy'));content.replaceChildren(box);}
 function renderNav(){nav.replaceChildren();[['خانه','house','home'],['موسیقی','music-2','music'],['سینما','clapperboard','cinema'],['گفت‌وگوها','message-circle','chats'],['من','user-round','account']].forEach(([name,symbol,action])=>{const n=button(name,action,'hc-nav-item',symbol);if(state.view===action||['game','lobby','ranking','arena'].includes(state.view)&&action==='home'||state.view==='salon'&&action==='cinema')n.setAttribute('aria-current','page');nav.append(n);});}
 function render(){const routeChanged=phone.dataset.screen!==state.view||phone.dataset.game!==state.selected;phone.dataset.screen=state.view;phone.dataset.game=state.selected;delete content.dataset.gamePage;phone.style.setProperty('--hc-glow',state.glow?'.6':'0');closeDialog();renderHeader();if(state.view==='home')renderHome();else if(state.view==='game')renderGame();else if(state.view==='arena')renderArena();else if(state.view==='ranking')renderRanks();else if(state.view==='lobby')renderLobby();else if(state.view==='salon')renderSalon();else if(state.view==='music'||state.view==='cinema')renderMedia(state.view);else if(state.view==='chats')renderChats();else renderAccount();renderNav();icons();syncHomeTabs();if(routeChanged)window.scrollTo(0,0);}
 function navigate(view){rememberLobby();state.view=view;render();}
 function searchDialog(trigger,mode='select'){const box=el('div'),label=el('label','hc-search'),input=el('input');input.type='search';input.placeholder='نام بازی';input.setAttribute('aria-label','جستجو در خانه');label.append(icon('search'),input);box.append(label);const rows=el('div');games.forEach(g=>{const row=button('',null,'hc-search-item');row.dataset.searchGame=g.id;row.dataset.searchText=g.name.toLowerCase();if(mode==='salon')row.dataset.fromSalon='1';const copy=el('span');copy.append(el('b',null,g.name),el('small',null,capacity(g)));row.append(art(g.id),copy,icon('chevron-left'));rows.append(row);});box.append(rows);input.oninput=()=>{const q=input.value.trim().toLowerCase();rows.querySelectorAll('[data-search-text]').forEach(n=>n.hidden=!n.dataset.searchText.includes(q));};showDialog(mode==='salon'?'بازی‌های سالون':'جستجو',mode,box,trigger);input.focus({preventScroll:true});}
 function matchesDialog(trigger,all=false){const box=el('div');(all?games:[game(state.selected)]).forEach((g,i)=>box.append(matchRow(g,'بازی '+friends[i%friends.length].name,g.min-1)));if(gameStates[state.selected].public&&gameStates[state.selected].lobby){const current=gameStates[state.selected].lobby,own=matchRow(game(state.selected),'بازی شما',current.players,'resume');own.querySelector('[data-action=resume]').dataset.resumeGame=state.selected;box.prepend(own);}showDialog(all?'میزها':'میزها '+game(state.selected).name,'matches',box,trigger);}
 function friendsDialog(trigger){const box=el('div');friends.forEach(f=>{const row=button('',null,'hc-search-item');row.dataset.inviteFriend=f.id;row.setAttribute('aria-pressed',String(state.party.includes(f.id)));const copy=el('span');copy.append(el('b',null,f.full),el('small',null,'آنلاین'));row.append(avatar(f.name,f.color),copy,icon(state.party.includes(f.id)?'circle-check':'circle'));box.append(row);});const actions=el('div','hc-inline-actions'),send=button('ارسال دعوت','send-invites','hc-primary','send');actions.append(send);box.append(actions);showDialog('دعوت از دوستان','friends',box,trigger);}
 function invitationDialog(trigger){const box=el('div');if(!state.invitation){box.append(el('p','hc-blank','دعوت تازه‌ای ندارید.'));showDialog('دعوت‌های بازی','invitations',box,trigger);return;}const row=el('div','hc-invite-game'),copy=el('span');copy.append(el('b',null,'پت‌پال'),el('small',null,'دعوت سهراب به بازی'));const timer=el('span','hc-invite-clock','20 ثانیه');timer.dataset.inviteClock='1';row.append(art('patpal'),copy,timer);const actions=el('div','hc-inline-actions');actions.append(button('پیوستن','accept-invite','hc-primary','log-in'),button('لغو','dismiss-invite','hc-secondary'));box.append(row,actions);state.inviteUntil=Date.now()+20000;showDialog('دعوت بازی','invitations',box,trigger);inviteTimer=setInterval(()=>{const seconds=Math.max(0,Math.ceil((state.inviteUntil-Date.now())/1000));const t=dialogBody.querySelector('[data-invite-clock]');if(t)t.textContent=fa(seconds)+' ثانیه';if(!seconds){clearInterval(inviteTimer);state.invitation=false;dialogBody.replaceChildren(el('p','hc-blank','زمان این دعوت پایان یافت.'));message('بازی همچنان در انتظار بازیکنان است.');renderHeader();}},200);}
 function makeLobby(id,host,count,origin){rememberLobby();state.selected=id;state.lobbyGame=id;state.host=host;state.lobbyHost=host;state.players=count;state.lobbyPlayers=count;state.hasLobby=true;state.origin=origin;state.public=gameStates[id].public;gameStates[id].lobby={players:count,host,origin};state.view='lobby';render();save();}
const rankNames={overall:'برترین‌ها',games:'برترین بازیکنان',purchase:'بیشترین خرید',activity:'بیشترین فعالیت'};
const rankPeople=[];
const rankState={category:rankNames[initial.rankCategory]?initial.rankCategory:'overall',period:['week','month'].includes(initial.rankPeriod)?initial.rankPeriod:'month',game:games.some(g=>g.id===initial.rankGame)?initial.rankGame:'fiskot'};
const rankWeights={purchase:30,games:40,activity:30};
const rankGameScores={fiskot:[96,84,77,78,55,64],ludo:[82,94,88,76,68,73],chess:[90,87,96,83,62,71],ono:[91,86,79,94,72,68],patpal:[87,91,84,79,95,72],bazaar:[88,85,92,81,77,96]};
const rankNum=n=>fa(Number(n).toLocaleString('en-US'));
function rankStats(p,period=rankState.period){return p[period]||p.month;}
function rankScore(p,category=rankState.category,period=rankState.period){const s=rankStats(p,period),i=rankPeople.indexOf(p);if(category==='purchase')return s.purchase;if(category==='activity')return s.hours;if(category==='games')return rankGameScores[rankState.game][i]*100+(period==='week'?0:25);const scale=period==='week'?300:1000,weight=rankWeights.purchase+rankWeights.games+rankWeights.activity||1;return Math.round((Math.min(100,s.purchase/scale*100)*rankWeights.purchase+s.games*rankWeights.games+s.activity*rankWeights.activity)/weight*100);}
function rankList(category=rankState.category,period=rankState.period){return [...rankPeople].sort((a,b)=>rankScore(b,category,period)-rankScore(a,category,period)||a.id.localeCompare(b.id));}
function rankPosition(p,category=rankState.category,period=rankState.period){return rankList(category,period).findIndex(n=>n.id===p.id)+1;}
function rankValue(p){return rankNum(rankScore(p))+(rankState.category==='purchase'?' دالر':rankState.category==='activity'?' ساعت':' امتیاز');}
function rankUserButton(p,cls){const b=button('',null,cls);b.dataset.rankUser=p.id;b.setAttribute('aria-label','جزئیات رتبهٔ '+p.name);return b;}
function rankPodium(category='overall',period='month'){
 const sorted=rankList(category,period),podium=el('div','gm-podium');podium.setAttribute('aria-label','سه نفر برتر');
 if(state.view==='ranking')podium.append(rankAtmosphere());
 [1,0,2].forEach(i=>{
  const p=sorted[i],b=rankUserButton(p,'gm-winner');b.dataset.place=String(i+1);
  const portrait=el('span','gm-winner-portrait');portrait.append(avatar(p.name,p.color));
  const frame=el('span','gm-portrait-frame');frame.setAttribute('aria-hidden','true');frame.append(el('span','gm-frame-orbit'),el('span','gm-frame-gem'));portrait.append(frame);
  const medal=el('span','gm-medal',String(i+1));portrait.append(medal);if(i===0)portrait.append(icon('crown'));
  const step=el('span','gm-step');step.append(el('b',null,p.name),el('small',null,rankNum(rankScore(p,category,period))+(category==='purchase'?' دالر':category==='activity'?' ساعت':'')));b.append(portrait,step);podium.append(b);
 });return podium;
}
function rankMini(){const section=el('section','gm-top-three');section.setAttribute('aria-label','برترین‌های این ماه');const head=heading('برترین‌ها','همه','rankings');head.append(el('small','gm-period','این ماه'));section.append(rankAtmosphere(),head,rankPodium());const me=rankPeople.find(p=>p.id==='me'),mine=button('','rankings','hc-rank-mine');mine.append(el('span',null,'رتبهٔ شما'),el('b',null,String(rankPosition(me,'overall','month'))),el('small',null,rankNum(rankScore(me,'overall','month'))+' امتیاز'),icon('chevron-left'));section.append(mine);return section;}

function rankMetric(title,value){const n=el('div','hc-rank-metric');n.append(el('small',null,title),el('b',null,value));return n;}
function showRankUser(id,trigger){const p=rankPeople.find(n=>n.id===id);if(!p)return;const period=state.view==='ranking'?rankState.period:'month',s=rankStats(p,period),box=el('div'),profile=el('div','hc-rank-profile');profile.append(avatar(p.name,p.color),el('h4',null,p.name),el('span',null,'رتبهٔ کلی '+fa(rankPosition(p,'overall',period))));box.append(profile);const metrics=el('div','hc-rank-metrics');metrics.append(rankMetric('مجموع خرید',rankNum(s.purchase)+' دالر'),rankMetric('پیروزی‌ها',fa(s.wins)+' بازی'),rankMetric('فعالیت',fa(s.hours)+' ساعت'));box.append(metrics,el('p',null,period==='month'?'آمار این ماه':'آمار این هفته'));const total=el('div','hc-rank-total');total.append(el('span',null,'امتیاز کلی واخان'),el('strong',null,rankNum(rankScore(p,'overall',period))));box.append(total);showDialog('جایگاه کاربر','rank-user',box,trigger);}
function renderRanks(){
 const box=el('section','hc-rank-page');box.setAttribute('aria-label','رتبه‌بندی واخان');
 const toolbar=el('div','hc-rank-toolbar'),periods=el('div','hc-rank-periods');periods.setAttribute('aria-label','دورهٔ رتبه‌بندی');[['این هفته','week'],['این ماه','month']].forEach(([name,value])=>{const b=button(name,null,'hc-rank-period');b.dataset.rankPeriod=value;b.setAttribute('aria-pressed',String(rankState.period===value));periods.append(b);});toolbar.append(periods,iconButton('شیوهٔ محاسبهٔ رتبه','rank-info','info'));box.append(toolbar);
 const tabs=el('div','hc-rank-categories');tabs.setAttribute('aria-label','نوع رتبه');[['کلی','overall'],['بازی‌ها','games'],['خرید','purchase'],['فعالیت','activity']].forEach(([label,key])=>{const b=button(label,null,'hc-rank-category');b.dataset.rankCategory=key;b.setAttribute('aria-pressed',String(rankState.category===key));tabs.append(b);});box.append(tabs);
 const context=el('div','hm-rank-context');context.append(el('h3','hc-rank-heading',rankNames[rankState.category]));
 if(rankState.category==='games'){const label=el('label','hc-rank-game-filter');label.append(el('span',null,'بازی'));const select=el('select');select.setAttribute('aria-label','انتخاب بازی برای رتبه‌بندی');select.dataset.rankGame='1';games.forEach(g=>{const option=el('option',null,g.name);option.value=g.id;option.selected=g.id===rankState.game;select.append(option);});label.append(select);context.append(label);}box.append(context);
 const sorted=rankList();box.append(rankPodium(rankState.category,rankState.period));
 const list=el('div','hc-rank-list');list.setAttribute('aria-live','polite');sorted.slice(3).forEach((p,index)=>{const i=index+3;const row=rankUserButton(p,'hc-rank-row');if(p.id==='me')row.classList.add('hc-rank-self');row.append(el('span','hc-rank-number',fa(i+1)),avatar(p.name,p.color),el('b',null,p.name),el('small',null,rankValue(p)));list.append(row);});box.append(list);const me=rankPeople.find(p=>p.id==='me'),foot=rankUserButton(me,'hc-rank-own-total');foot.append(el('span',null,'رتبهٔ شما'),el('b',null,fa(rankPosition(me))),el('small',null,rankValue(me)));box.append(foot);content.replaceChildren(box);
}

function gameRankShortcut(g){const me=rankPeople.find(p=>p.id==='me'),previous=rankState.game;rankState.game=g.id;const position=rankPosition(me,'games');rankState.game=previous;const b=button('رتبهٔ شما در '+g.name+' · '+fa(position),'game-rank','hc-page-info','trophy');return b;}
root.addEventListener('click',event=>{const category=event.target.closest('[data-rank-category]'),period=event.target.closest('[data-rank-period]'),user=event.target.closest('[data-rank-user]');if(category){rankState.category=category.dataset.rankCategory;renderRanks();icons();save();}else if(period){rankState.period=period.dataset.rankPeriod;renderRanks();icons();save();}else if(user){showRankUser(user.dataset.rankUser,user);}});
root.addEventListener('change',event=>{if(event.target.dataset.rankGame){rankState.game=event.target.value;renderRanks();icons();save();}});
window.addEventListener('openai:set_globals',event=>{const restored=event.detail?.globals?.widgetState?.privateContent?.homeFinal;if(!restored)return;if(rankNames[restored.rankCategory])rankState.category=restored.rankCategory;if(['week','month'].includes(restored.rankPeriod))rankState.period=restored.rankPeriod;if(games.some(g=>g.id===restored.rankGame))rankState.game=restored.rankGame;});

const arenaState={card:0,onoCard:1,color:'red',die:3,hints:true,skin:'teal',camera:0};
function arenaControl(label,kind,value,cls='gm-control'){
 const b=button(label,null,cls);b.dataset.arenaControl=kind;if(value!==undefined)b.dataset.value=String(value);return b;
}
function arenaPlayer(name,sub,color){const p=el('div','gm-player'),copy=el('span');copy.append(el('b',null,name),el('small',null,sub));p.append(avatar(name,color),copy);return p;}
function arenaCard(rank,suit,kind,index){const b=arenaControl('',kind,index,'gm-card');b.append(el('b',null,rank),el('span',null,suit));b.dataset.suit=suit;if(arenaState.card===index&&kind==='card')b.setAttribute('aria-pressed','true');b.setAttribute('aria-label',rank+' '+({'♠':'پیک','♥':'دل','♦':'خشت','♣':'گشنیز'}[suit]||''));return b;}
function renderFiskot(box){
 const score=el('div','gm-score');score.append(el('span',null,'تیم شما 42'),el('b',null,'حکم ♠'),el('span',null,'تیم روبه‌رو 36'));box.append(score);
 const table=el('div','gm-card-table');const top=arenaPlayer('سهراب','هم‌تیمی شما','#806347');top.classList.add('gm-opponent-top');table.append(top);
 const left=arenaPlayer('مریم','7 کارت','#795785');left.classList.add('gm-opponent-left');const right=arenaPlayer('فرید','7 کارت','#3c7667');right.classList.add('gm-opponent-right');table.append(left,right);
 const trick=el('div','gm-trick');[['10','♠'],['Q','♠']].forEach(([r,s])=>{const c=el('span','gm-played-card');c.append(el('b',null,r),el('span',null,s));trick.append(c);});table.append(trick,el('span','gm-turn','نوبت شما'));box.append(table);
 const hand=el('div','gm-hand');[['A','♠'],['K','♥'],['Q','♦'],['J','♣'],['9','♠']].forEach(([r,s],i)=>hand.append(arenaCard(r,s,'card',i)));box.append(hand,el('p','gm-hand-label','کارت‌های شما'));
}
function renderLudo(box){
 box.append(arenaPlayer('شما','نوبت شما','#327b6c'));const board=el('div','gm-ludo');board.setAttribute('role','img');board.setAttribute('aria-label','تختهٔ لدو با چهار خانه و مهره‌های رنگی');
 for(let y=0;y<15;y++)for(let x=0;x<15;x++){const c=el('span','gm-ludo-cell');if(x===7&&y<7)c.dataset.lane='red';if(x>7&&y===7)c.dataset.lane='blue';if(x===7&&y>7)c.dataset.lane='yellow';if(x<7&&y===7)c.dataset.lane='green';if(x>=6&&x<=8&&y>=6&&y<=8)c.classList.add('gm-ludo-center');board.append(c);}
 [['red','0','0'],['green','9','0'],['yellow','0','9'],['blue','9','9']].forEach(([color,x,y])=>{const home=el('div','gm-ludo-home');home.dataset.color=color;home.style.left=(Number(x)/15*100)+'%';home.style.top=(Number(y)/15*100)+'%';const inside=el('span');for(let i=0;i<4;i++)inside.append(el('i','gm-pawn'));home.append(inside);board.append(home);});box.append(board);
 const action=el('div','gm-dice-action'),dice=arenaControl(String(arenaState.die),'die',null,'gm-dice');dice.setAttribute('aria-label','نمایش تاس بعدی');const copy=el('span');copy.append(el('b',null,'تاس شما'),el('small',null,'فرید، مریم و سهراب در بازی‌اند'));action.append(dice,copy);box.append(action);
}
function renderChess(box){
 const players=el('div','gm-duel');players.append(arenaPlayer('سهراب','05:28','#806347'),arenaPlayer('شما','06:12','#695091'));box.append(players);
 const board=el('div','gm-chess');board.setAttribute('role','img');board.setAttribute('aria-label','صفحهٔ شطرنج با آخرین حرکت و خانه‌های مجاز اسب');const pieces=['♜♞♝♛♚♝♞♜','♟♟♟♟♟♟♟♟','        ','        ','    ♙   ','  ♘     ','♙♙♙♙ ♙♙♙','♖ ♗♕♔♗♘♖'];
 for(let y=0;y<8;y++)for(let x=0;x<8;x++){const cell=el('span','gm-chess-cell',pieces[y][x].trim());if((x+y)%2)cell.classList.add('is-dark');if(y>3)cell.classList.add('is-white');if(y===5&&x===2)cell.classList.add('is-selected');if(arenaState.hints&&[[1,3],[3,3],[0,4],[4,4]].some(([a,b])=>a===x&&b===y))cell.append(el('i','gm-legal-dot'));if(y===4&&x===4)cell.classList.add('is-last');board.append(cell);}box.append(board);
 const hints=arenaControl('حرکت‌های مجاز','hints',null,'hc-secondary');hints.setAttribute('aria-pressed',String(arenaState.hints));box.append(el('p','gm-turn-caption','نوبت شما · سفید'),hints);
}
function renderOno(box){
 const players=el('div','gm-ono-players');[['سهراب','5 کارت','#806347'],['مریم','4 کارت','#795785'],['فرید','6 کارت','#3c7667']].forEach(p=>players.append(arenaPlayer(...p)));box.append(players);
 const table=el('div','gm-ono-table'),deck=arenaControl('W','draw',null,'gm-ono-deck');deck.setAttribute('aria-label','دستهٔ کارت');const discard=el('span','gm-ono-discard','7');discard.dataset.color=arenaState.color;table.append(deck,discard,el('span','gm-turn','نوبت شما'));box.append(table);
 const colors=el('div','gm-ono-colors');[['red','سرخ'],['yellow','زرد'],['blue','آبی'],['green','سبز']].forEach(([v,n])=>{const b=arenaControl('', 'color',v,'gm-color');b.dataset.color=v;b.setAttribute('aria-label',n);b.setAttribute('aria-pressed',String(arenaState.color===v));colors.append(b);});box.append(colors);
 const hand=el('div','gm-ono-hand');[['7','red'],['2','blue'],['↺','green'],['+2','yellow'],['4','red']].forEach(([n,color],i)=>{const b=arenaControl(n,'ono-card',i,'gm-ono-card');b.dataset.color=color;b.setAttribute('aria-label',n+'، کارت '+({red:'سرخ',blue:'آبی',green:'سبز',yellow:'زرد'}[color]));b.setAttribute('aria-pressed',String(arenaState.onoCard===i));hand.append(b);});box.append(hand,el('p','gm-hand-label','دست شما'));
}
function renderAdventure(box,g){
 const scene=el('div','gm-scene');scene.dataset.scene=g.id;scene.dataset.camera=String(arenaState.camera);const art=el('div','gm-environment');art.setAttribute('role','img');art.setAttribute('aria-label',g.id==='patpal'?'حویلی و اتاق‌های خانهٔ پت‌پال':'گذرگاه فانوس‌دار بازار افغانی');scene.append(art);
 const hud=el('div','gm-scene-hud'),role=el('span','gm-scene-role'),timer=el('span','gm-scene-time');role.append(icon(g.id==='patpal'?'eye-off':'compass'),document.createTextNode(g.id==='patpal'?'پنهان‌شونده':'گشت‌وگذار'));timer.append(icon('timer'),document.createTextNode(g.id==='patpal'?'00:42':'03:18'));hud.append(role,timer);scene.append(hud);
 const caption=el('div','gm-scene-caption');caption.append(el('b',null,g.id==='patpal'?'حویلی مهتابی':'گذرگاه فانوس‌ها'),el('small',null,g.id==='patpal'?'مرحلهٔ پنهان‌شدن':'بازار کهنه'));scene.append(caption);
 const controls=el('div','gm-scene-controls');const left=arenaControl('','look',-1,'gm-look'),right=arenaControl('','look',1,'gm-look');left.setAttribute('aria-label','نگاه به چپ');right.setAttribute('aria-label','نگاه به راست');left.append(icon('chevron-left'));right.append(icon('chevron-right'));const action=arenaControl(g.id==='patpal'?'ظاهر شما':'سرنخ‌ها',g.id==='patpal'?'appearance':'clues',null,'gm-scene-action');action.append(icon(g.id==='patpal'?'palette':'scan-search'));controls.append(left,action,right);scene.append(controls);box.append(scene);
 if(g.id==='patpal'){const palette=el('div','gm-camouflage'),label=el('span');label.append(el('b',null,'هماهنگی رنگ'),el('small',null,'با پوشش‌های محیط'));palette.append(label);[['teal','پرده'],['sand','دیوار'],['rose','فرش']].forEach(([v,n])=>{const b=arenaControl(n,'skin',v,'gm-skin');b.dataset.skin=v;b.setAttribute('aria-pressed',String(arenaState.skin===v));palette.append(b);});box.append(palette);}else{const clue=arenaControl('', 'clues',null,'gm-clue-row');clue.append(icon('sparkles'),el('span',null,'سرنخ‌های پیدا‌شده'),el('b',null,'2'),icon('chevron-left'));box.append(clue);}
 const quality=arenaControl('گرافیک سبک','quality',null,'gm-quality');quality.append(icon('gauge'));box.append(quality);
}
function renderArena(){
 const g=game(state.selected),box=el('section','gm-arena');box.dataset.arena=g.id;const head=el('div','gm-arena-meta');head.append(el('span',null,'نمای طراحی'),el('span',null,g.id==='patpal'?'4 از 16 بازیکن':g.id==='bazaar'?'4 از 10 بازیکن':g.id==='chess'?'2 بازیکن':'4 بازیکن'));box.append(head);
 if(g.id==='fiskot')renderFiskot(box);else if(g.id==='ludo')renderLudo(box);else if(g.id==='chess')renderChess(box);else if(g.id==='ono')renderOno(box);else renderAdventure(box,g);
 box.append(voice());content.replaceChildren(box);
}
root.addEventListener('click',event=>{
 const b=event.target.closest('[data-arena-control]');if(!b)return;const action=b.dataset.arenaControl;
 if(action==='card')arenaState.card=Number(b.dataset.value);
 else if(action==='ono-card')arenaState.onoCard=Number(b.dataset.value);
 else if(action==='color')arenaState.color=b.dataset.value;
 else if(action==='die')arenaState.die=[1,6,3,4,2,5][(arenaState.die+1)%6];
 else if(action==='hints')arenaState.hints=!arenaState.hints;
 else if(action==='skin')arenaState.skin=b.dataset.value;
 else if(action==='look')arenaState.camera=Math.max(-1,Math.min(1,arenaState.camera+Number(b.dataset.value)));
 else if(action==='appearance'){content.querySelector('.gm-camouflage')?.scrollIntoView({block:'nearest',behavior:'smooth'});return;}
 else if(action==='quality'){b.setAttribute('aria-pressed',String(b.getAttribute('aria-pressed')!=='true'));return;}
 else if(action==='clues'){const body=el('div','gm-clues');[['پارچهٔ آبی','کنار دکان پارچه‌فروشی'],['فانوس مسی','در گذرگاه شرقی']].forEach(([name,sub])=>{const row=el('div');row.append(icon('map-pin'),el('b',null,name),el('small',null,sub));body.append(row);});showDialog('سرنخ‌ها','clues',body,b);return;}
 else if(action==='draw'){toast('نمای دستهٔ کارت‌های بازی',b);return;}
 renderArena();icons();
});

 root.addEventListener('click',event=>{const choose=event.target.closest('[data-open-game]');if(choose){openGame(choose.dataset.openGame,'home');return;}const friend=event.target.closest('[data-friend]');if(friend){const id=friend.dataset.friend;state.party=state.party.includes(id)?state.party.filter(x=>x!==id):[...state.party,id];if(state.view==='game')renderGame();else renderHome();icons();save();return;}const invitationFriend=event.target.closest('[data-invite-friend]');if(invitationFriend){const id=invitationFriend.dataset.inviteFriend;state.party=state.party.includes(id)?state.party.filter(x=>x!==id):[...state.party,id];invitationFriend.setAttribute('aria-pressed',String(state.party.includes(id)));const last=invitationFriend.lastElementChild;const replacement=icon(state.party.includes(id)?'circle-check':'circle');last.replaceWith(replacement);icons();save();return;}const found=event.target.closest('[data-search-game]');if(found){state.selected=found.dataset.searchGame;openGame(state.selected,found.dataset.fromSalon?'salon':'home');return;}const salon=event.target.closest('[data-salon]');if(salon){navigate('salon');return;}const chat=event.target.closest('[data-chat]');if(chat){const f=friends.find(x=>x.id===chat.dataset.chat);const box=el('div');box.append(el('p',null,'دعوت بازی را دیدید؟'),button('مشاهدهٔ دعوت','invitations','hc-primary','gamepad-2'));showDialog(f.full,'chat',box,chat);return;}if(event.target===overlay){closeDialog();return;}const b=event.target.closest('[data-action]');if(!b)return;const a=b.dataset.action;
  if(a==='wallet'){walletDialog(b);return;}if(a==='arena'){state.view='arena';render();return;}if(a==='game-rank'){rankState.category='games';rankState.game=state.selected;navigate('ranking');save();return;}if(a==='rankings'){navigate('ranking');return;}if(a==='rank-info'){const box=el('div');box.append(el('p',null,'امتیاز کلی: خرید '+fa(rankWeights.purchase)+'٪، بازی '+fa(rankWeights.games)+'٪ و فعالیت '+fa(rankWeights.activity)+'٪.'),el('p',null,'رتبهٔ هر بازی بر اساس نتیجهٔ همان بازی است.'),el('p',null,'اعداد و وزن‌ها برای نمایش طرح‌اند؛ معیار نهایی پیش از اجرا تعیین می‌شود.'));showDialog('شیوهٔ رتبه‌بندی','rank-info',box,b);return;}if(a==='home-history'){historyDialog(b);return;}if(a==='join-code'){codeDialog(b);return;}if(a==='check-code'){const value=dialogBody.querySelector('[data-join-code]').value.trim();message(value?'این شناسه در نمونهٔ طراحی ثبت نشده است.':'شناسهٔ بازی را وارد کنید.');return;}if(a==='close'){closeDialog();return;}if(a==='back'){if(state.view==='arena')openGame(state.selected,state.origin);else if(state.view==='lobby')openGame(state.lobbyGame,state.origin);else navigate('home');return;}if(a==='game-info'){const g=game(state.selected),box=el('div');box.append(art(g.id,100),el('p',null,gameDetails[g.id].description),el('p',null,'ظرفیت: '+capacity(g)),el('p',null,'بازی پس از حضور حداقل '+fa(g.min)+' بازیکن و با تصمیم میزبان آغاز می‌شود.'));showDialog('دربارهٔ '+g.name,'game-info',box,b);return;}if(['home','music','cinema','chats','account'].includes(a)){navigate(a);return;}if(a==='search'){searchDialog(b);return;}if(a==='matches'||a==='all-matches'){navigate('home');root.querySelector('.hm-now')?.scrollIntoView({block:'nearest',behavior:homeFinalPreference.matches?'auto':'smooth'});return;}if(a==='create'){makeLobby(state.selected,true,1,state.origin||'home');return;}if(a==='resume'){loadLobby(b.dataset.resumeGame||state.lobbyGame);return;}if(a==='join'){const g=game(b.dataset.game);makeLobby(g.id,false,Math.min(g.max,Number(b.dataset.matchPlayers??(g.min-1))+1),state.view==='game'?state.origin:'home');return;}if(a==='friends'){friendsDialog(b);return;}if(a==='send-invites'){if(!state.party.length){message('حداقل یک دوست را انتخاب کنید.');return;}message('دعوت برای '+fa(state.party.length)+' دوست فرستاده شد.');return;}if(a==='invitations'){invitationDialog(b);return;}if(a==='dismiss-invite'){state.invitation=false;closeDialog();renderHeader();icons();return;}if(a==='accept-invite'){state.invitation=false;makeLobby('patpal',false,4,'home');return;}if(a==='salons'){const box=el('div');box.append(routeRow('همراهان واخان','موسیقی و گفت‌وگو','users-round','open-salon'),routeRow('شب‌های کابل','تماشای گروهی','clapperboard','open-salon'));showDialog('سالون‌های فعال','salons',box,b);return;}if(a==='open-salon'){navigate('salon');return;}if(a==='salon-games'){searchDialog(b,'salon');return;}if(a==='mic'||a==='listen'){state[a]=!state[a];content.querySelector('.hc-voice')?.replaceWith(voice());icons();return;}if(a==='begin'){if(state.host&&state.players>=game(state.lobbyGame).min){state.selected=state.lobbyGame;rememberLobby();state.view='arena';render();}return;}if(a==='play-media'){const playing=b.getAttribute('aria-pressed')==='true';b.setAttribute('aria-pressed',String(!playing));b.replaceChildren(icon(playing?'play':'pause'),document.createTextNode(playing?(state.view==='music'?'شنیدن موسیقی':'ادامهٔ تماشا'):'توقف'));icons();return;}if(a==='media-detail'){const label=b.querySelector('b').textContent,box=el('div');box.append(routeRow(state.view==='music'?'انتخاب موسیقی':'فیلم‌های آرشیف',state.view==='music'?'فهرست موسیقی شما':'مشاهده و انتخاب','play','choose-media'));showDialog(label,'media-detail',box,b);return;}if(a==='choose-media'){message('انتخاب شما ثبت شد.');return;}if(a==='edit-profile'){const box=el('div'),label=el('label','hc-search'),input=el('input');input.value='شما';input.setAttribute('aria-label','نام شما');input.dataset.profileName='1';label.append(input);box.append(label,button('ذخیره','save-profile','hc-primary','check'));showDialog('ویرایش حساب','profile',box,b);return;}if(a==='save-profile'){message('نام ذخیره شد.');return;}if(a==='language'){const box=el('div');box.append(el('p',null,'دری'),el('p',null,'متن‌ها به دری معیار نمایش داده می‌شوند.'));showDialog('زبان برنامه','language',box,b);return;}if(a==='privacy'){const box=el('div');box.append(switchRow('نمایش وضعیت آنلاین','دوستان از حضور شما آگاه شوند.','presence'));showDialog('حریم خصوصی','privacy',box,b);return;}
 });
 root.addEventListener('change',event=>{const n=event.target;if(n.dataset.switch){state[n.dataset.switch]=n.checked;if(n.dataset.switch==='public'){toast(n.checked?'بازی در فهرست میزها قرار گرفت.':'عضوگیری متوقف شد.',n);}save();}});
 root.addEventListener('keydown',event=>{if(event.key==='Escape'&&!overlay.hidden)closeDialog();});
const homeTabMotion={memory:new Map(),captured:new Map(),contentAnimation:null,queued:false,beforeSignature:''};
const homeFinalEpoch=performance.now();
const homeFinalPreference=matchMedia('(prefers-reduced-motion: reduce)');
const homeTabGroups=[['navigation','.hc-nav'],['rank-category','.hc-rank-categories'],['rank-period','.hc-rank-periods']];
function homeFinalSignature(){return [state.view,state.selected,rankState.category,rankState.period,rankState.game].join(':');}
function homeTabKey(button){return button.dataset.action||button.dataset.rankCategory||button.dataset.rankPeriod||'';}
function homeTabGeometry(node,group){const a=node.getBoundingClientRect(),b=group.getBoundingClientRect();return {x:a.left-b.left-group.clientLeft,y:a.top-b.top-group.clientTop,width:a.width,height:a.height,groupWidth:group.clientWidth};}
function homeTabTransform(rect){return 'translate3d('+rect.x+'px,'+rect.y+'px,0)';}
function captureHomeTabs(){
 for(const [key,selector] of homeTabGroups){
  const group=root.querySelector(selector);if(!group||!group.getClientRects().length)continue;
  const active=group.querySelector(':scope > button[aria-current="page"],:scope > button[aria-pressed="true"]');if(!active)continue;
  const indicator=group.querySelector(':scope > .hm-selection');homeTabMotion.captured.set(key,{key:homeTabKey(active),rect:homeTabGeometry(indicator||active,group)});
 }
}
function syncHomeTabs(animate=true){
 for(const n of root.querySelectorAll('.gm-stage-light,.gm-stage-reflection,.gm-frame-orbit')){if(n.dataset.motionPhase)continue;const offset=parseFloat(getComputedStyle(n).animationDelay)||0;n.style.animationDelay=(offset-(performance.now()-homeFinalEpoch)/1000)+'s';n.dataset.motionPhase='1';}
 for(const [key,selector] of homeTabGroups){
  const group=root.querySelector(selector);if(!group||!group.getClientRects().length)continue;
  const active=group.querySelector(':scope > button[aria-current="page"],:scope > button[aria-pressed="true"]');if(!active)continue;
  group.dataset.smoothTabs=key;
  const target=homeTabGeometry(active,group),activeKey=homeTabKey(active),previous=homeTabMotion.memory.get(key),captured=homeTabMotion.captured.get(key);
  let indicator=group.querySelector(':scope > .hm-selection');
  const unchanged=indicator&&previous?.indicator===indicator&&previous.key===activeKey&&Math.abs(previous.rect.x-target.x)<.5&&Math.abs(previous.rect.width-target.width)<.5;
  if(unchanged)continue;
  if(!indicator){indicator=el('span','hm-selection');indicator.setAttribute('aria-hidden','true');group.prepend(indicator);}
  const origin=captured||(previous?{key:previous.key,rect:previous.rect}:null);
  indicator.getAnimations().forEach(a=>a.cancel());
  indicator.style.width=target.width+'px';indicator.style.height=target.height+'px';indicator.style.transform=homeTabTransform(target);
  if(animate&&!homeFinalPreference.matches&&origin&&origin.key!==activeKey&&Math.abs(origin.rect.groupWidth-target.groupWidth)<1){
   indicator.animate([{transform:homeTabTransform(origin.rect),width:origin.rect.width+'px',height:origin.rect.height+'px'},{transform:homeTabTransform(target),width:target.width+'px',height:target.height+'px'}],{duration:key==='rank-period'?280:320,easing:'cubic-bezier(.2,.8,.25,1)'});
  }
  homeTabMotion.memory.set(key,{indicator,key:activeKey,rect:target});
 }
 homeTabMotion.captured.clear();
}
function scheduleHomeMotion(event){
 if(!homeTabMotion.queued){homeTabMotion.beforeSignature=homeFinalSignature();captureHomeTabs();}
 if(homeTabMotion.queued)return;homeTabMotion.queued=true;
 requestAnimationFrame(()=>{
  homeTabMotion.queued=false;syncHomeTabs();
  if(homeTabMotion.beforeSignature!==homeFinalSignature()){
   homeTabMotion.contentAnimation?.cancel();
   if(!homeFinalPreference.matches)homeTabMotion.contentAnimation=content.animate([{opacity:.68,transform:'translateY(4px)'},{opacity:1,transform:'translateY(0)'}],{duration:200,easing:'cubic-bezier(.2,.8,.25,1)'});
  }
 });
}
root.addEventListener('click',scheduleHomeMotion,true);
root.addEventListener('change',scheduleHomeMotion,true);
let homeFinalWidth=phone.clientWidth;
const homeFinalResize=new ResizeObserver(()=>{const width=phone.clientWidth;if(Math.abs(width-homeFinalWidth)<.5)return;homeFinalWidth=width;syncHomeTabs(false);});homeFinalResize.observe(phone);
homeFinalPreference.addEventListener('change',()=>{if(homeFinalPreference.matches){homeTabMotion.contentAnimation?.cancel();for(const m of homeTabMotion.memory.values())m.indicator.getAnimations().forEach(a=>a.cancel());}syncHomeTabs(false);});
window.addEventListener('pagehide',()=>homeFinalResize.disconnect(),{once:true});

const liveHome={balance:null,salons:[],loading:true,error:false,origin:'home'};
const liveAmount=()=>liveHome.balance===null?'—':Number(liveHome.balance).toLocaleString('en-US',{maximumFractionDigits:2});
window.WakhanHomeNativeNotice=text=>toast(text);
friendStrip=function(){const list=el('div','hc-friends');friends.forEach(p=>{const b=button('',null,'hc-friend');b.dataset.friend=p.id;b.setAttribute('aria-label',p.full+'، آنلاین');b.setAttribute('aria-pressed',String(state.party.includes(p.id)));const av=avatar(p.name,p.color);if(p.photo){av.textContent='';const im=el('img');im.src=p.photo;im.alt='';im.onerror=()=>{im.remove();av.prepend(document.createTextNode(p.name.slice(0,1)));};av.append(im);}av.append(el('i','hc-online'));b.append(av,el('span',null,p.name));list.append(b);});const add=iconButton('دوستان','friends','user-round-plus');add.className='hc-invite-friends cursor-interaction';list.append(add);return list;};
renderNow=function(){const section=el('section','hm-now');section.append(heading('همین حالا'));const empty=el('div','hm-now-row hm-live-empty');empty.append(icon('gamepad-2'),el('span',null,'عضوگیری هم‌زمان با فعال‌شدن بازی‌ها آغاز می‌شود.'));section.append(empty);return section;};
function liveEmptyPodium(){const p=el('div','gm-podium');[2,1,3].forEach(place=>{const b=el('div','gm-winner');b.dataset.place=String(place);const portrait=el('span','gm-winner-portrait');portrait.append(avatar('—'));const frame=el('span','gm-portrait-frame');frame.append(el('span','gm-frame-orbit'),el('span','gm-frame-gem'));portrait.append(frame,el('span','gm-medal',String(place)));if(place===1)portrait.append(icon('crown'));const step=el('span','gm-step');step.append(el('b',null,'—'),el('small',null,'—'));b.append(portrait,step);p.append(b);});return p;}
rankMini=function(){const box=el('section','gm-top-three');const head=heading('برترین‌ها','همه','rankings');head.append(el('small','gm-period','این ماه'));box.append(rankAtmosphere(),head,liveEmptyPodium());return box;};
renderRanks=function(){const box=el('section','hc-rank-page'),toolbar=el('div','hc-rank-toolbar'),periods=el('div','hc-rank-periods');[['این هفته','week'],['این ماه','month']].forEach(([n,v])=>{const b=button(n,null,'hc-rank-period');b.dataset.rankPeriod=v;b.setAttribute('aria-pressed',String(rankState.period===v));periods.append(b);});toolbar.append(periods);box.append(toolbar);const tabs=el('div','hc-rank-categories');[['کلی','overall'],['بازی‌ها','games'],['خرید','purchase'],['فعالیت','activity']].forEach(([n,v])=>{const b=button(n,null,'hc-rank-category');b.dataset.rankCategory=v;b.setAttribute('aria-pressed',String(rankState.category===v));tabs.append(b);});box.append(tabs,el('h3','hc-rank-heading',rankNames[rankState.category]),liveEmptyPodium(),el('p','hm-live-ranking-note','رتبه‌بندی هنوز فعال نشده است.'));content.replaceChildren(box);};
gameRankShortcut=function(){return button('رتبه‌بندی','game-rank','hc-page-info','trophy');};
renderHome=function(){content.replaceChildren();const online=el('section','gm-online');online.classList.toggle('is-empty',friends.length===0);online.append(friendStrip());content.append(online);if(liveHome.error){const retry=button('دریافت اطلاعات تازه','native-refresh','hc-secondary','refresh-cw');content.append(retry);}
 const library=el('section','hm-game-library');library.append(heading('بازی‌ها'));const adventures=el('div','hm-adventures');['patpal','bazaar'].forEach(id=>adventures.append(homeGameCard(game(id),true)));const table=el('div','hm-table-games');['fiskot','ludo','chess','ono'].forEach(id=>table.append(homeGameCard(game(id),false)));library.append(adventures,table);content.append(library,renderNow(),rankMini());
 const salons=el('section','gm-salon-section');salons.append(heading('سالون‌ها','همه','salons'));const list=el('div','hc-salons');liveHome.salons.forEach(s=>{const b=button('',null,'hc-salon');b.dataset.salon=s.code;const mark=el('span','hc-salon-mark');mark.append(avatar(s.name),el('span','hc-live',s.live>0?'فعال':'سالون'));const copy=el('span');copy.append(el('b',null,s.name),el('small',null,s.live+' نفر حاضر'));b.append(mark,copy);list.append(b);});if(liveHome.salons.length)salons.append(list);else salons.append(el('p','hm-live-note',liveHome.loading?'در حال دریافت سالون‌ها…':'برای دیدن سالون‌ها، «همه» را باز کنید.'));content.append(salons);
};
root.addEventListener('click',event=>{const b=event.target.closest('button');if(!b)return;const a=b.dataset.action;let handled=true;
 if(a==='wallet')window.WakhanHomeNativeSend({type:'wallet'});
 else if(a==='invitations'||a==='friends'&&state.view==='home')window.WakhanHomeNativeSend({type:'people'});
 else if(a==='salons')window.WakhanHomeNativeSend({type:'salons'});
 else if(a==='native-refresh')window.WakhanHomeNativeSend({type:'refresh'});
 else if(a==='rank-info'||a==='arena'){toast('این بخش به‌زودی فعال می‌شود.',b);}
 else if(b.dataset.friend&&state.view==='home')window.WakhanHomeNativeSend({type:'dm',uid:b.dataset.friend});
 else if(b.dataset.openGame){openGame(b.dataset.openGame,liveHome.origin);}
 else handled=false;
 if(handled){event.preventDefault();event.stopImmediatePropagation();}
},true);
window.addEventListener('wakhan:home-live-data',event=>{const data=event.detail||{};liveHome.balance=Number.isFinite(data.balance)&&data.balance>=0?data.balance:null;liveHome.loading=data.loading===true;liveHome.error=data.error===true;liveHome.salons=Array.isArray(data.salons)?data.salons:[];friends.splice(0,friends.length,...(Array.isArray(data.friends)?data.friends.filter(p=>p.online===true):[]));if(state.view==='home')render();else{renderHeader();icons();}});
window.addEventListener('wakhan:home-live-route',event=>{const data=event.detail;liveHome.origin=data.origin==='salon'?'salon':'home';if(data.type==='open-game')openGame(data.game,liveHome.origin);else{state.view='home';state.origin=liveHome.origin;render();}});

// Optional application bridge. Without it, this file remains a local design preview.
// Actual match creation, payments, voice and ranking calculation belong to the next phase.
const homeHost=window.WakhanHomeHost;
function emitHomeIntent(type,detail){
 root.dispatchEvent(new CustomEvent('wakhan:home-intent',{bubbles:true,detail:{type,...detail}}));
 if(typeof homeHost?.onIntent==='function')homeHost.onIntent({type,...detail});
}
if(homeHost){
 root.addEventListener('click',event=>{
  const b=event.target.closest('button');if(!b)return;
  const action=b.dataset.action;
  if(['music','cinema','chats','account'].includes(action)){
   event.stopImmediatePropagation();event.preventDefault();
   if(typeof homeHost.navigate==='function')homeHost.navigate(action);else emitHomeIntent('navigate',{route:action});return;
  }
  if(b.dataset.salon!==undefined||action==='open-salon'){
   event.stopImmediatePropagation();event.preventDefault();emitHomeIntent('open-salon',{salonId:b.dataset.salon||null});return;
  }
  const intents={create:'create-match',join:'join-match',begin:'start-match','send-invites':'invite-friends','accept-invite':'accept-invite',mic:'toggle-microphone',listen:'toggle-listening'};
  if(intents[action]||b.dataset.coinOffer){
   event.stopImmediatePropagation();event.preventDefault();
   emitHomeIntent(b.dataset.coinOffer?'select-coin-package':intents[action],{gameId:b.dataset.game||state.selected,origin:state.origin,friendIds:[...state.party],coins:b.dataset.coinOffer?Number(b.dataset.coinOffer):undefined});
  }
 },true);
 root.addEventListener('change',event=>{if(event.target.dataset.switch==='public'){event.stopImmediatePropagation();emitHomeIntent('set-recruitment',{gameId:state.lobbyGame,enabled:event.target.checked,origin:state.origin});}},true);
}
window.WakhanHomeDesign=Object.freeze({
 mode:homeHost?'host-intents':'local-design-preview',
 openGame(gameId,origin='home'){
  if(!games.some(g=>g.id===gameId))throw new RangeError('Unknown game: '+gameId);
  if(!['home','salon'].includes(origin))throw new RangeError('Unknown game origin');
  openGame(gameId,origin);
 },
 openHome(){navigate('home');},
 openRecruiting(){navigate('home');root.querySelector('.hm-now')?.scrollIntoView({block:'nearest',behavior:homeMotionPreference.matches?'auto':'smooth'});},
 getView(){return {screen:state.view,gameId:state.selected,origin:state.origin};}
});

 render();
 window.dispatchEvent(new CustomEvent('wakhan:home-native-ready'));
 if(globalThis.Tweak){const tweaks=new Tweak({container:phone,onChange:()=>{render();save();}});tweaks.addToggle(state,'glow',{label:'نور ملایم پس‌زمینه'});tweaks.addToggle(state,'showResume',{label:'نمایش بازی قبلی'});tweaks.addToggle(state,'invitation',{label:'نمایش دعوت دریافتی'});tweaks.addSlider(state,'players',{label:'بازیکنان نمونهٔ میز انتظار',min:1,max:16,step:1,unit:'نفر'});}
 window.addEventListener('openai:set_globals',e=>{const restored=e.detail?.globals?.widgetState?.privateContent?.homeFinal;if(!restored)return;if(games.some(g=>g.id===restored.selected))state.selected=restored.selected;if(Array.isArray(restored.party))state.party=restored.party.filter(id=>friends.some(f=>f.id===id));if(typeof restored.glow==='boolean')state.glow=restored.glow;if(typeof restored.showResume==='boolean')state.showResume=restored.showResume;render();});
 window.addEventListener('pagehide',()=>{clearInterval(inviteTimer);clearTimeout(toastTimer);},{once:true});
})();
