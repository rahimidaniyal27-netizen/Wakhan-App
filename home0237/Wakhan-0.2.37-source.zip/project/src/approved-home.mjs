/* Approved Home only. Existing shell programs, media and chat renderers stay intact. */
export function installApprovedHome({getRoute,getView,getUid,request,fetchBinary,origin,assetOrigin,navigate,openWallet,openChat,openSalon,openPeople,notice,bars,hooks,closeTools=()=>{},getInsets=()=>null}){
 const nativeHomeURL=new URL('/home-ui/index.html',assetOrigin).href;
 const nonce=Array.from(crypto.getRandomValues(new Uint8Array(18)),v=>v.toString(16).padStart(2,'0')).join('');
 const state={frame:null,user:null,busy:false,last:0,command:null,insetSequence:0,disposed:false,snapshot:{balance:null,friends:[],salons:[],loading:true,error:false},photos:new Map()};
 const style=document.createElement('style');style.dataset.wakhanApprovedHome='';style.textContent=`
 body.wk-approved-home{overflow:hidden!important;background:#0f0a1d!important}
 body.wk-approved-home>header,body.wk-approved-home>nav#nav{display:none!important}
 body.wk-approved-home #view{position:fixed!important;inset:var(--wk-home-safe-top,var(--wk-safe-top,env(safe-area-inset-top,0px))) var(--wk-home-safe-right,env(safe-area-inset-right,0px)) var(--wk-home-safe-bottom,var(--wk-safe-bottom,env(safe-area-inset-bottom,0px))) var(--wk-home-safe-left,env(safe-area-inset-left,0px))!important;width:auto!important;max-width:none!important;min-height:0!important;max-height:none!important;height:auto!important;padding:0!important;margin:0!important;overflow:hidden!important;transform:none!important}
 body.wk-approved-home #view>[data-wk-page-active]{display:block;height:100%}
 body.wk-approved-home #view iframe.wk-approved-home-frame{display:block!important;width:100%!important;height:100%!important;min-height:0!important;max-height:none!important;max-width:none!important;position:static!important;transform:none!important;border:0!important;opacity:1!important;background:#0f0a1d;color-scheme:dark}
 `;document.head.append(style);
 function visible(){const on=getRoute()==='h';document.body.classList.toggle('wk-approved-home',on);bars?.(on);return on;}
 // A nested frame does not inherit its host's safe-area environment. Inset the
 // whole Home viewport once; all its headers, back buttons and bottom tabs follow.
 async function syncInsets(){
  if(state.disposed||getRoute()!=='h')return;const sequence=++state.insetSequence;
  try{
   const value=await getInsets();
   if(state.disposed||sequence!==state.insetSequence||getRoute()!=='h'||!value)return;
   const sides=['top','right','bottom','left'];
   if(!Number.isFinite(value.width)||value.width<=0||sides.some(side=>!Number.isFinite(value[side])||value[side]<0))return;
   const scale=innerWidth/value.width;if(scale<.25||scale>4)return;
   const insets=Object.fromEntries(sides.map(side=>[side,value[side]*scale]));
   if(insets.top+insets.bottom>=innerHeight||insets.left+insets.right>=innerWidth)return;
   for(const side of sides)document.documentElement.style.setProperty('--wk-home-safe-'+side,insets[side]+'px');
  }catch{} // CSS safe-area values remain the fallback for older native binaries.
 }
 function post(value){state.frame?.contentWindow?.postMessage({channel:'wakhan-home-r17',nonce,...value},'*');}
 function resetUser(uid){if(state.user===uid)return;state.user=uid;for(const p of state.photos.values())URL.revokeObjectURL(p.url);state.photos.clear();state.snapshot={balance:null,friends:[],salons:[],loading:true,error:false};state.last=0;post({type:'snapshot',data:state.snapshot});}
 async function photo(person,viewer){
  if(!person.avatar)return null;
  let address;try{address=new URL(person.avatar,origin);if(address.origin!==new URL(origin).origin)return null;}catch{return null;}
  const prior=state.photos.get(person.id);if(prior?.source===address.href)return prior.url;
  const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),8000);
  try{const response=await fetchBinary(address.href,{signal:abort.signal});if(!response.ok)return null;const blob=await response.blob();if(viewer!==state.user||viewer!==Number(getUid())||!blob.type.startsWith('image/')||blob.size>3*1024*1024)return null;const url=URL.createObjectURL(blob);if(prior)URL.revokeObjectURL(prior.url);state.photos.set(person.id,{source:address.href,url});return url;}catch{return null;}finally{clearTimeout(timer);}
 }
 async function refresh(force=false){
  if(!visible()||document.visibilityState==='hidden')return;
  const uid=Number(getUid());if(!Number.isSafeInteger(uid)||uid<=0)return;resetUser(uid);if(state.busy||!force&&Date.now()-state.last<8000)return;
  state.busy=true;state.last=Date.now();
  try{
   const values=await Promise.allSettled([request('/api/wallet'),request('/api/app/chat/people'),request('/api/app/salon/home')]);
   if(uid!==Number(getUid()))return;
   const [wallet,people,salons]=values.map(v=>v.status==='fulfilled'&&v.value?.ok?v.value:null);
   if(wallet&&Number.isFinite(Number(wallet.balance))&&Number(wallet.balance)>=0)state.snapshot.balance=Number(wallet.balance);
   if(people){
    const online=(people.items||[]).filter(p=>Number.isSafeInteger(Number(p.id))&&Number(p.id)>0&&p.online===true).slice(0,12);
    const photos=await Promise.all(online.map(p=>photo(p,uid)));
    if(uid!==Number(getUid()))return;
    state.snapshot.friends=online.map((p,i)=>({id:String(p.id),name:String(p.name||'کاربر').slice(0,80),full:String(p.name||'کاربر').slice(0,80),photo:photos[i],online:true}));
    const keep=new Set(online.map(p=>p.id));for(const [id,p]of state.photos)if(!keep.has(id)){URL.revokeObjectURL(p.url);state.photos.delete(id);}
   }
   if(salons){const seen=new Set();let rooms=[salons.mine,...salons.followed||[],...salons.joined||[],...salons.recent||[]].filter(Boolean);if(!rooms.length){try{const discover=await request('/api/app/salon/discover?f=all');if(discover?.ok)rooms=discover.items||[];}catch{}}
    state.snapshot.salons=rooms.filter(p=>p.code&&!seen.has(String(p.code))&&seen.add(String(p.code))).slice(0,6).map(p=>({code:String(p.code),name:String(p.name||'سالون').slice(0,80),live:Number.isFinite(Number(p.live))?Number(p.live):0,status:String(p.status||'idle')}));
   }
   state.snapshot.loading=false;state.snapshot.error=!wallet||!people||!salons;post({type:'snapshot',data:state.snapshot});
  }finally{state.busy=false;}
 }
 function mount(){
  if(!visible())return;void syncInsets();const pane=getView();
  if(!state.frame?.isConnected){const frame=document.createElement('iframe');frame.className='wk-approved-home-frame';frame.title='خانهٔ واخان';frame.src=nativeHomeURL+'#bridge='+nonce;frame.setAttribute('allow','');frame.onload=()=>{post({type:'snapshot',data:state.snapshot});if(state.command)post(state.command);};pane.replaceChildren(frame);state.frame=frame;}
  void refresh();
 }
 function routeHome(){mount();state.command={type:'route',view:'home',origin:'home'};post(state.command);}
 function openGamesFromSalon(){closeTools();navigate('h');mount();state.command={type:'open-games',origin:'salon'};post(state.command);}
 const receive=event=>{
  const msg=event.data;if(event.source!==state.frame?.contentWindow||msg?.channel!=='wakhan-home-r17'||msg.nonce!==nonce)return;
  if(msg.type==='ready'){post({type:'snapshot',data:state.snapshot});if(state.command)post(state.command);void refresh();return;}
  if(getRoute()!=='h')return;
  if(msg.type==='refresh'){void refresh(true);return;}
  if(msg.type==='navigate'){const routes={music:'p',cinema:'c',chats:'d',account:'m'};if(routes[msg.route])navigate(routes[msg.route]);return;}
  if(msg.type==='wallet'){void openWallet();return;}
  if(msg.type==='people'){openPeople();return;}
  if(msg.type==='dm'){const uid=Number(msg.uid);if(Number.isSafeInteger(uid)&&state.snapshot.friends.some(p=>Number(p.id)===uid))openChat(uid);return;}
  if(msg.type==='salon'){const code=String(msg.code||'');if(state.snapshot.salons.some(p=>p.code===code))void openSalon(code);return;}
  if(msg.type==='salons'){navigate('c');return;}
 };
 window.addEventListener('message',receive);
 const originalHome=hooks.getHome(),replacementHome=function(){mount();};hooks.setHome(replacementHome);
 const previousGo=hooks.getGo(),replacementGo=function(...args){visibleBefore(args[0]);const result=previousGo.apply(this,args);visible();if(getRoute()==='h')routeHome();return result;};hooks.setGo(replacementGo);
 function visibleBefore(tab){if(tab!=='h')document.body.classList.remove('wk-approved-home');}
 const salonGames=event=>{if(getRoute()!=='c')return;const b=event.target?.closest?.('.wkr-tabs button[data-tab="game"],[data-wakhan-games]');if(!b)return;event.preventDefault();event.stopImmediatePropagation();openGamesFromSalon();};
 document.addEventListener('click',salonGames,true);
 const resume=()=>{if(document.visibilityState==='visible'){void syncInsets();void refresh();}};document.addEventListener('visibilitychange',resume);
 window.addEventListener('resize',syncInsets);window.addEventListener('orientationchange',syncInsets);
 const timer=setInterval(()=>{if(getRoute()==='h')void refresh();},20000);
 if(getRoute()==='h')mount();
 return {mount,refresh,syncInsets,openGamesFromSalon,openGame(id,entry='home'){if(!['fiskot','ludo','chess','ono','patpal','bazaar'].includes(id))return;navigate('h');mount();state.command={type:'open-game',game:id,origin:entry==='salon'?'salon':'home'};post(state.command);},dispose(){state.disposed=true;++state.insetSequence;clearInterval(timer);window.removeEventListener('message',receive);window.removeEventListener('resize',syncInsets);window.removeEventListener('orientationchange',syncInsets);document.removeEventListener('click',salonGames,true);document.removeEventListener('visibilitychange',resume);style.remove();for(const side of ['top','right','bottom','left'])document.documentElement.style.removeProperty('--wk-home-safe-'+side);for(const p of state.photos.values())URL.revokeObjectURL(p.url);state.photos.clear();if(hooks.getHome()===replacementHome)hooks.setHome(originalHome);if(hooks.getGo()===replacementGo)hooks.setGo(previousGo);document.body.classList.remove('wk-approved-home');}};
}
