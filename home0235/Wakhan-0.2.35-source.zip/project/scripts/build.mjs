import {existsSync, readFileSync, writeFileSync} from 'node:fs';
import {build} from 'vite';
import './validate-client.mjs';
import {createHash} from 'node:crypto';
// The exported shell is the current release. Replaying the historical snapshot
// here used to replace current Me, social and theme programs during every build.
const path='public/wakhan-shell.json';
if(!existsSync(path))throw Error('Current public/wakhan-shell.json is required; do not regenerate from historical snapshots.');
const shell=JSON.parse(readFileSync(path,'utf8'));
if(!Array.isArray(shell.programs)||!shell.programs.length)throw Error('Invalid current WAKHAN shell');
const release=JSON.parse(readFileSync('public/wakhan-release.json','utf8'));const pkg=JSON.parse(readFileSync('package.json','utf8'));release.version=pkg.version;release.build=pkg.wakhanBuild;release.variant='approved-home-r18';release.device_verified=false;release.store_ready=false;release.shell_sha256=createHash('sha256').update(readFileSync(path)).digest('hex');writeFileSync('public/wakhan-release.json',JSON.stringify(release,null,2));
writeFileSync('public/build-flags.json',JSON.stringify({push:existsSync('android/app/google-services.json')}));
await build();
