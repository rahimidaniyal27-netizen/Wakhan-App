/* Only sanitized view data crosses this boundary; sign-in credentials stay in the parent. */
(()=>{
 const nonce=new URLSearchParams(location.hash.slice(1)).get('bridge');
 const send=value=>{if(parent!==window&&nonce)parent.postMessage({channel:'wakhan-home-r17',nonce,...value},'*');};
 window.WakhanHomeHost={navigate:route=>send({type:'navigate',route}),onIntent:intent=>{
  if(intent.type==='open-salon'){send({type:'salon',code:intent.salonId});return;}
  window.WakhanHomeNativeNotice?.('این بازی به‌زودی فعال می‌شود.');
 }};
 window.WakhanHomeNativeSend=send;
 let latest=null;
 window.addEventListener('message',event=>{const data=event.data;if(event.source!==parent||data?.channel!=='wakhan-home-r17'||data.nonce!==nonce)return;
  if(data.type==='snapshot'){latest=data.data;window.dispatchEvent(new CustomEvent('wakhan:home-live-data',{detail:latest}));}
  else if(['route','open-games','open-game'].includes(data.type))window.dispatchEvent(new CustomEvent('wakhan:home-live-route',{detail:data}));
 });
 window.addEventListener('wakhan:home-native-ready',()=>{if(latest)window.dispatchEvent(new CustomEvent('wakhan:home-live-data',{detail:latest}));send({type:'ready'});});
})();
