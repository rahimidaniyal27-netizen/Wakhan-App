const sourceNames={audius:'Audius',archive:'Archive',ccmixter:'ccMixter',youtube:'YouTube',soundcloud:'SoundCloud'};
export function sourceSummary({sources=[],loading=false,error=false,partial=false,updated=0}={}){
 if(loading)return 'تازه‌سازی…';if(error)return 'تازه‌سازی نشد';
 const unavailable=[...new Set(sources.filter(s=>s.available===false).map(s=>sourceNames[s.id]||'منبع ناشناخته'))];
 if(unavailable.length)return 'پاسخ نداد: '+unavailable.join('، ');
 if(partial)return 'وضعیت منابع نامشخص است';
 return updated?new Date(updated*1000).toLocaleTimeString('fa',{hour:'2-digit',minute:'2-digit'}):'';
}
/* Own only a downward, predominantly vertical pull that STARTED at scroll top. */
export function installPullRefresh({element,enabled=()=>true,busy=()=>false,refresh,onState=()=>{},threshold=64}){
 let start=null,distance=0,pending=false,dead=false,blockClickUntil=0;
 const paint=phase=>{if(!dead)onState({phase,distance,progress:Math.min(1,distance/threshold)})};
 function reset(){start=null;distance=0;paint('idle')}
 function begin(e){blockClickUntil=0;if(dead||pending||busy())return;reset();if(!enabled()||element.scrollTop>1||e.touches.length!==1)return;const t=e.touches[0];start={x:t.clientX,y:t.clientY,claimed:false}}
 function move(e){if(!start)return;if(!enabled()||busy()||e.touches.length!==1){reset();return}const t=e.touches[0],dx=t.clientX-start.x,dy=t.clientY-start.y;
  if(!start.claimed&&(dy<-5||Math.abs(dx)>10&&Math.abs(dx)>Math.abs(dy))){reset();return}
  if(dy<=0){distance=0;paint('idle');return}
  if(!start.claimed&&dy<10)return;
  if(!start.claimed&&element.scrollTop>1){reset();return}
  start.claimed=true;if(e.cancelable)e.preventDefault();distance=Math.min(96,dy*.5);paint(distance>=threshold?'ready':'pulling');
 }
 async function end(){if(!start)return;const claimed=start.claimed,fire=claimed&&distance>=threshold&&enabled()&&!busy()&&!pending;start=null;
  if(claimed)blockClickUntil=Date.now()+500;
  if(!fire){reset();return}pending=true;distance=36;paint('refreshing');
  try{await refresh()}catch{ /* Request owner displays the error and retains cached rows. */ }finally{pending=false;reset()}
 }
 const pointer=()=>{blockClickUntil=0},cancel=()=>reset(),click=e=>{if(Date.now()<blockClickUntil&&e.detail!==0){e.preventDefault();e.stopImmediatePropagation()}};
 element.addEventListener('pointerdown',pointer,{passive:true});element.addEventListener('touchstart',begin,{passive:true});element.addEventListener('touchmove',move,{passive:false});element.addEventListener('touchend',end,{passive:true});element.addEventListener('touchcancel',cancel,{passive:true});element.addEventListener('click',click,true);
 return {cancel,dispose(){reset();dead=true;element.removeEventListener('pointerdown',pointer);element.removeEventListener('touchstart',begin);element.removeEventListener('touchmove',move);element.removeEventListener('touchend',end);element.removeEventListener('touchcancel',cancel);element.removeEventListener('click',click,true)}};
}
