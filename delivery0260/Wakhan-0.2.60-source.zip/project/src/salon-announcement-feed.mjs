// A room entry owns one local announcement, ordered after the existing chat.
// Minimise/restore keeps that entry; leaving or changing account starts a new one.
export function createSalonAnnouncementFeed(){
 let entry=null;
 function ensure(uid,room){const key=String(uid||'')+'|'+String(room||'');if(!uid||!room){entry=null;return null}if(entry?.key!==key)entry={key,text:null,history:false,anchor:0};return entry}
 return {
  ensure,
  leave(){entry=null},
  meta(uid,room,hall){const e=ensure(uid,room);if(e&&e.text===null)e.text=String(hall?.notice||'').trim().slice(0,300)},
  messages(uid,room,messages){const e=ensure(uid,room);if(e&&!e.history){e.anchor=Math.max(0,...messages.map(m=>Number(m.id)||0));e.history=true}},
  saved(uid,room,text){const e=ensure(uid,room);if(e)e.text=String(text||'').trim().slice(0,300)},
  rows(uid,room,messages){const e=ensure(uid,room);if(!e?.history||!e.text)return messages;const notice={kind:'salon_notice',id:'entry-notice',text:e.text};const after=messages.findIndex(m=>(Number(m.id)||0)>e.anchor);return after<0?[...messages,notice]:[...messages.slice(0,after),notice,...messages.slice(after)]}
 };
}
