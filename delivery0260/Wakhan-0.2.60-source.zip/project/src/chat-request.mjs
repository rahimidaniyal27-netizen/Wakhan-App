/* Keep transport failures distinct from a server which has not installed Chat 2. */
export function createChatRequest({fetch:send,origin}){
 const base=new URL(origin).origin;
 return async function request(path,body){
  if(typeof path!=='string'||!path.startsWith('/api/app/')||new URL(path,base).origin!==base)throw Error('invalid_chat_route');
  try{
   const response=await send(base+path,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json'},redirect:'error',body:body===undefined?undefined:JSON.stringify(body)});
   let data;try{data=await response.json();}catch{}
   if(response.status===404&&/^\/api\/app\/chat\/(inbox|settings|people)(?:\?|$)/.test(path))return {ok:false,err:'chat_server_missing',message:'گفتگوها فعلاً در دسترس نیستند.'};
   if(response.status===401)return {ok:false,err:'auth',message:'نشست شما پایان یافته است. دوباره وارد حساب شوید.'};
   if(!response.ok||!data)return {ok:false,err:data?.err||'server_unavailable',message:data?.message||'دریافت اطلاعات ممکن نشد. دوباره تلاش کنید.'};
   return data;
  }catch{return {ok:false,err:'net',message:'ارتباط با سرور برقرار نشد. اتصال انترنت را بررسی کنید.'};}
 };
}
