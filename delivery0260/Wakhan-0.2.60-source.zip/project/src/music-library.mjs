/* Per-account, durable offline media. No Audius metadata/audio is written to disk. */
export function createMusicLibrary({uid,native=null,convertFileSrc=x=>x,fetchBinary=fetch,onProgress=()=>{}}){
 const jobs=new Map(),urls=new Map();let dbPromise;
 function db(){return dbPromise??=new Promise((resolve,reject)=>{const r=indexedDB.open('wakhan-music-v1',1);r.onupgradeneeded=()=>{r.result.createObjectStore('downloads',{keyPath:'key'});r.result.createObjectStore('lists',{keyPath:'key'})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
 const owner=()=>String(uid());
 async function tx(store,mode,fn){const database=await db();return new Promise((resolve,reject)=>{const t=database.transaction(store,mode),r=fn(t.objectStore(store));let result;r.onsuccess=()=>{result=r.result};r.onerror=()=>reject(r.error);t.oncomplete=()=>resolve(result);t.onabort=()=>reject(t.error||Error('storage'))})}
 const all=async store=>(await tx(store,'readonly',s=>s.getAll())).filter(x=>x.owner===owner());
 const key=id=>owner()+':'+id;
 async function blob(url,signal,max){const r=await fetchBinary(url,{signal});if(!r.ok)throw Error('download');const chunks=[];let size=0,total=Number(r.headers.get('Content-Length'))||0;if(total>max)throw Error('size');if(!r.body){const b=await r.blob();if(b.size>max)throw Error('size');return b}const reader=r.body.getReader();try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>max)throw Error('size');chunks.push(value);onProgress({url,loaded:size,total})}}finally{reader.releaseLock()}return new Blob(chunks,{type:r.headers.get('Content-Type')||'application/octet-stream'})}
 async function fileKey(id,user){const bytes=new TextEncoder().encode(id),sum=new Uint8Array(await crypto.subtle.digest('SHA-256',bytes));return 'u'+user+'_'+Array.from(sum,x=>x.toString(16).padStart(2,'0')).join('')}
 async function download(track){
  if(!track.persistent||!track.downloadable||track.provider==='audius')throw Error('license');const user=owner(),k=user+':'+track.id;if(jobs.has(k))return jobs.get(k).promise;
  const abort=new AbortController();const job={abort,key:null};
  const promise=(async()=>{let value;
   try{
    if(native){job.key=await fileKey(track.id,user);onProgress({id:track.id,key:job.key});if(abort.signal.aborted)throw Error('cancelled');const result=await native.download({key:job.key,source:track.stream,cover:track.cover});if(abort.signal.aborted){await native.remove({key:job.key});throw Error('cancelled')}value={...track,native:result,bytes:result.bytes}}
    else{const [audio,cover]=await Promise.all([blob(track.stream,abort.signal,120*1024*1024),blob(track.cover,abort.signal,8*1024*1024)]);value={...track,audio,coverBlob:cover,bytes:audio.size+cover.size}}
    if(user!==owner())throw Error('account');await tx('downloads','readwrite',s=>s.put({...value,key:k,owner:user,downloaded:Date.now()}));return value;
   }catch(e){abort.abort();if(native&&job.key)await native.remove({key:job.key}).catch(()=>{});throw e}finally{jobs.delete(k);onProgress({id:track.id,done:true})}
  })();job.promise=promise;jobs.set(k,job);return promise;
 }
 async function get(id){const value=await tx('downloads','readonly',s=>s.get(key(id)));if(!value)return null;
  if(value.native){const status=await native?.source({key:await fileKey(id,owner())}).catch(()=>null);if(!status)return null;return {...value,stream:convertFileSrc(status.source),nativeSource:status.source,cover:convertFileSrc(status.cover)}}
  let pair=urls.get(value.key);if(!pair){pair={stream:URL.createObjectURL(value.audio),cover:URL.createObjectURL(value.coverBlob)};urls.set(value.key,pair)}return {...value,...pair};
 }
 async function downloads(){const records=await all('downloads');return (await Promise.all(records.sort((a,b)=>b.downloaded-a.downloaded).map(x=>get(x.id)))).filter(Boolean)}
 async function remove(id){const k=key(id);const job=jobs.get(k);if(job){job.abort.abort();if(native&&job.key)await native.cancel({key:job.key})}const value=await tx('downloads','readonly',s=>s.get(k));if(value?.native)await native.remove({key:await fileKey(id,owner())});await tx('downloads','readwrite',s=>s.delete(k));const pair=urls.get(k);if(pair){URL.revokeObjectURL(pair.stream);URL.revokeObjectURL(pair.cover);urls.delete(k)}}
 async function lists(){return all('lists')}
 async function saveList(list){const x={id:list.id||crypto.randomUUID(),name:String(list.name||'').trim().slice(0,60),ids:[...new Set(list.ids||[])].slice(0,500)};if(!x.name)throw Error('name');await tx('lists','readwrite',s=>s.put({...x,key:key(x.id),owner:owner()}));return x}
 return {download,get,downloads,remove,lists,saveList,deleteList:id=>tx('lists','readwrite',s=>s.delete(key(id))),active:id=>jobs.has(key(id)),cancel:async id=>{const j=jobs.get(key(id));if(j){j.abort.abort();if(native&&j.key)await native.cancel({key:j.key})}},dispose(){for(const j of jobs.values()){j.abort.abort();if(native&&j.key)void native.cancel({key:j.key}).catch(()=>{})}for(const p of urls.values()){URL.revokeObjectURL(p.stream);URL.revokeObjectURL(p.cover)}urls.clear()}};
}
