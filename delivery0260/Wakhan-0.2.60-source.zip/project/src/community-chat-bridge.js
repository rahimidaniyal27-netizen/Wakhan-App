/* Shared friendship helpers and aliases into the sole current chat implementation.
   No legacy chat renderer, legacy message sender or legacy DM API requests. */
async function wm70Friend(action,uid){
 if(WM70.friendBusy)return;WM70.friendBusy=true;
 try{await wm70Request('friends',{action,uid:Number(uid)});await wm70RefreshFriends();if(WM70.modal==='profile'&&WM70.profileId===Number(uid))await wm70OpenProfile(uid);if(TAB==='d')window.WakhanChat?.resume();}
 catch(error){toast(wm70Error(error))}finally{WM70.friendBusy=false}
}
async function wm70RefreshFriends(){const seq=WM70.friendsSeq=(WM70.friendsSeq||0)+1,value=await wm70Request('friends');if(seq===WM70.friendsSeq){WM70.friends=value;for(const key of ['friends','incoming','outgoing','blocked'])for(const p of value[key]||[])wm70Remember(p);}return value;}
function wm70OpenFriends(){go('m');window.ME3?.open('friends');}
function wm70ChatDraw(){return window.WakhanChat?.draw();}
function wm70ThreadDraw(){return window.WakhanChat?.draw();}
function wm70OpenDM(uid){try{closeSheet()}catch{}if(window.WakhanChat)return window.WakhanChat.open('dm',Number(uid));window.__wkChatIntent={kind:'dm',id:Number(uid)};}
function wm70PollDM(){return window.WakhanChat?.resume();}
async function wm70RefreshSocial(){
 if(!ME?.me||WM70.socialBusy)return;WM70.socialBusy=true;
 try{const [inbox]=await Promise.all([api('/api/app/chat/inbox'),wm70RefreshFriends()]);if(!inbox?.ok)return;WM70.unread=inbox.unread||0;WM70.lastInbox=Date.now();renderNav();}
 catch{}finally{WM70.socialBusy=false;}
}
