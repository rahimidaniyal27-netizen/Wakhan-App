/* One scroll surface: the profile, portrait, light and navigation share one clip edge. */
export function installChatProfileLayout(root){
 const header=root.querySelector(':scope>.wc-profile-header'),body=root.querySelector(':scope>.wc-body');
 if(!header||!body)return;
 root.classList.add('wc-profile-page');
 body.prepend(header);
}
