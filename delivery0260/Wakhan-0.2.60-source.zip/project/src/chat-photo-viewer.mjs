/* Authenticated images only. Saving uses the device's own file/image UI. */
export function constrainPhoto({scale=1,x=0,y=0,width,height,naturalWidth,naturalHeight}){
 scale=Math.min(6,Math.max(1,Number(scale)||1));
 const fit=Math.min(width/naturalWidth,height/naturalHeight);
 const maxX=Math.max(0,(naturalWidth*fit*scale-width)/2),maxY=Math.max(0,(naturalHeight*fit*scale-height)/2);
 return {scale,x:Math.min(maxX,Math.max(-maxX,x)),y:Math.min(maxY,Math.max(-maxY,y))};
}
const glyph={back:'m15 18-6-6 6-6',download:'M12 3v12 M7 10l5 5 5-5 M4 16v5h16v-5',plus:'M12 5v14 M5 12h14',minus:'M5 12h14',reset:'M3 11a9 9 0 1 1 2 7 M3 3v8h8'};
const icon=name=>`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${glyph[name]}"/></svg>`;

export function createPhotoViewer({fetchPhoto,viewport,notice=()=>{},onClose=()=>{},platform='',doc=document,win=window}={}){
 let panel=null,image=null,stage=null,source='',blob=null,serial=0,previousFocus=null,pose={scale:1,x:0,y:0},gesture=null,lastTap=null,lastDouble=0,busy=false;
 const pointers=new Map();
 function render(){if(!image?.naturalWidth)return;const r=stage.getBoundingClientRect(),fit=Math.min(r.width/image.naturalWidth,r.height/image.naturalHeight);image.style.width=image.naturalWidth*fit+'px';image.style.height=image.naturalHeight*fit+'px';pose=constrainPhoto({...pose,width:r.width,height:r.height,naturalWidth:image.naturalWidth,naturalHeight:image.naturalHeight});image.style.transform=`translate(${pose.x}px,${pose.y}px) scale(${pose.scale})`;panel.querySelector('[data-photo-scale]').textContent=Math.round(pose.scale*100)+'٪';}
 function resize(){if(!panel)return;const v=viewport?.()||{height:win.innerHeight,offsetTop:0};panel.style.top=(v.offsetTop||0)+'px';panel.style.height=v.height+'px';render();}
 function close(){if(!panel)return;++serial;panel.remove();panel=null;image=null;stage=null;blob=null;gesture=null;pointers.clear();if(source)URL.revokeObjectURL(source);source='';if(previousFocus?.isConnected)previousFocus.focus({preventScroll:true});previousFocus=null;lastTap=null;onClose();}
 function zoom(scale){pose.scale=scale;render();}
 function contextMenu(event){if(panel&&event.target===image){event.stopImmediatePropagation();}}
 function key(event){if(!panel)return;if(event.key==='Escape'){event.preventDefault();close();}else if(event.key==='+'||event.key==='=')zoom(pose.scale+.5);else if(event.key==='-')zoom(pose.scale-.5);}
 function midpoint(){const p=[...pointers.values()];return {x:(p[0].x+p[1].x)/2,y:(p[0].y+p[1].y)/2,distance:Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y)};}
 function down(event){if(event.button!==0||event.target.closest('button'))return;pointers.set(event.pointerId,{x:event.clientX,y:event.clientY});if(pointers.size===1)gesture={mode:'pan',startX:event.clientX,startY:event.clientY,x:pose.x,y:pose.y,moved:false,time:Date.now()};else if(pointers.size===2){const mid=midpoint(),r=stage.getBoundingClientRect();gesture={mode:'pinch',distance:mid.distance,scale:pose.scale,anchorX:(mid.x-r.left-r.width/2-pose.x)/pose.scale,anchorY:(mid.y-r.top-r.height/2-pose.y)/pose.scale};}}
 function move(event){if(!panel||!pointers.has(event.pointerId)||!gesture)return;pointers.set(event.pointerId,{x:event.clientX,y:event.clientY});if(pointers.size===2){event.preventDefault();const mid=midpoint(),r=stage.getBoundingClientRect();if(gesture.mode!=='pinch')return;pose.scale=Math.min(6,Math.max(1,gesture.scale*mid.distance/Math.max(1,gesture.distance)));pose.x=mid.x-r.left-r.width/2-gesture.anchorX*pose.scale;pose.y=mid.y-r.top-r.height/2-gesture.anchorY*pose.scale;render();}else if(gesture.mode==='pan'&&pose.scale>1){const dx=event.clientX-gesture.startX,dy=event.clientY-gesture.startY;if(Math.abs(dx)+Math.abs(dy)>6){event.preventDefault();gesture.moved=true;pose.x=gesture.x+dx;pose.y=gesture.y+dy;render();}}}
 function up(event){if(!pointers.has(event.pointerId))return;const g=gesture;pointers.delete(event.pointerId);if(event.type==='pointerup'&&event.pointerType==='touch'&&g?.mode==='pan'&&!g.moved&&Date.now()-g.time<300){if(lastTap&&Date.now()-lastTap.time<300&&Math.hypot(event.clientX-lastTap.x,event.clientY-lastTap.y)<24){lastDouble=Date.now();zoom(pose.scale>1?1:2.5);lastTap=null;}else lastTap={time:Date.now(),x:event.clientX,y:event.clientY};}if(!pointers.size)gesture=null;else{const p=[...pointers.values()][0];gesture={mode:'pan',startX:p.x,startY:p.y,x:pose.x,y:pose.y,moved:true,time:Date.now()};}}
 async function save(){
  if(!panel||!blob||busy)return;busy=true;panel.querySelector('[data-photo-error]').hidden=true;const token=serial,button=panel.querySelector('[data-photo-action=save]');button.disabled=true;
  try{
   // Revalidate membership/deletion before exporting the bytes to the phone.
   const current=await fetchPhoto(panel.dataset.mediaId);if(token!==serial)return;
   const ext=current.type==='image/png'?'png':current.type==='image/webp'?'webp':'jpg';
   const file=new File([current],`Wakhan-photo-${new Date().toISOString().replace(/[:.]/g,'-')}.${ext}`,{type:current.type});
   if(typeof navigator.share==='function'&&navigator.canShare?.({files:[file]})){
    try{await navigator.share({files:[file]});return;}catch(error){if(error.name==='AbortError')return;if(!['NotAllowedError','TypeError'].includes(error.name))throw error;}
   }
   const ios=platform==='ios'||/iPad|iPhone|iPod/.test(navigator.userAgent)||navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1;
   if(ios){panel.querySelector('[data-photo-save-hint]').hidden=false;render();return;}
   const url=URL.createObjectURL(file),link=doc.createElement('a');link.href=url;link.download=file.name;doc.body.append(link);link.click();link.remove();win.setTimeout(()=>URL.revokeObjectURL(url),5000);
  }catch(error){if(token===serial){const errorBox=panel.querySelector('[data-photo-error]');errorBox.textContent=error?.message||'ذخیرهٔ عکس ممکن نشد. دوباره تلاش کنید.';errorBox.hidden=false;render();}}
  finally{if(token===serial){busy=false;button.disabled=false;}}
 }
 async function open(id){
  close();const token=++serial;previousFocus=doc.activeElement;pose={scale:1,x:0,y:0};busy=false;
  panel=doc.createElement('section');panel.className='wc-photo-viewer';panel.dataset.mediaId=id;panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.setAttribute('aria-label','نمای بزرگ عکس');
  panel.innerHTML=`<div class="wc-viewer-top"><button type="button" data-photo-action="close" aria-label="برگشت">${icon('back')}</button><button type="button" data-photo-action="save" disabled>${icon('download')}<span>ذخیره در گوشی</span></button></div><div class="wc-viewer-stage"><span data-photo-loading role="status">در حال بازکردن عکس…</span><img class="wc-viewer-image" alt="عکس گفتگو" hidden></div><div class="wc-viewer-error" data-photo-error hidden role="alert"></div><div class="wc-viewer-save-hint" data-photo-save-hint hidden role="status">برای ذخیره در آیفون، انگشت خود را روی عکس نگه دارید و «Save Image» یا «Save to Photos» را انتخاب کنید.</div><div class="wc-viewer-tools"><button type="button" data-photo-action="out" aria-label="کوچک‌کردن">${icon('minus')}</button><span data-photo-scale aria-live="polite">۱۰۰٪</span><button type="button" data-photo-action="in" aria-label="بزرگ‌کردن">${icon('plus')}</button><button type="button" data-photo-action="reset" aria-label="نمایش کامل عکس">${icon('reset')}</button></div>`;
  doc.body.append(panel);image=panel.querySelector('img');stage=panel.querySelector('.wc-viewer-stage');resize();panel.querySelector('[data-photo-action=close]').focus({preventScroll:true});
  panel.onclick=event=>{const action=event.target.closest('[data-photo-action]')?.dataset.photoAction;if(action==='close')close();if(action==='save')void save();if(action==='in')zoom(pose.scale+.5);if(action==='out')zoom(pose.scale-.5);if(action==='reset'){pose={scale:1,x:0,y:0};render();}};
  stage.addEventListener('pointerdown',down);stage.addEventListener('dblclick',()=>{if(Date.now()-lastDouble>400)zoom(pose.scale>1?1:2.5);});stage.addEventListener('touchmove',event=>{if(event.touches.length>1||pose.scale>1)event.preventDefault();},{passive:false});
  try{const data=await fetchPhoto(id);if(token!==serial)return;blob=data;source=URL.createObjectURL(data);image.loading='eager';image.src=source;await image.decode();if(token!==serial)return;image.hidden=false;panel.querySelector('[data-photo-loading]').hidden=true;panel.querySelector('[data-photo-action=save]').disabled=false;render();}
  catch(error){if(token===serial){close();notice(error?.message||'بازکردن عکس ممکن نشد. دوباره تلاش کنید.');}}
 }
 win.addEventListener('contextmenu',contextMenu,true);win.addEventListener('keydown',key,true);win.addEventListener('pointermove',move,{passive:false});win.addEventListener('pointerup',up);win.addEventListener('pointercancel',up);win.addEventListener('resize',resize);
 return {open,close,resize,get isOpen(){return !!panel;},dispose(){close();win.removeEventListener('contextmenu',contextMenu,true);win.removeEventListener('keydown',key,true);win.removeEventListener('pointermove',move);win.removeEventListener('pointerup',up);win.removeEventListener('pointercancel',up);win.removeEventListener('resize',resize);}};
}
