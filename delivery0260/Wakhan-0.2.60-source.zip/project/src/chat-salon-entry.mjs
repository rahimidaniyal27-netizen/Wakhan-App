// The existing salon renderer remains intact; only its explicit chat shortcut is routed here.
export function installSalonChatEntry({doc=globalThis.document,getRoute,openInbox}={}){
 const handle=event=>{
  if(getRoute?.()!=='c')return;
  const button=event.target?.closest?.('#wm78-room button[data-a="chats"],.slr button[data-a="chats"],#wm78-room button[onclick="H2.inbox()"]');
  if(!button||button.disabled)return;
  event.preventDefault();event.stopImmediatePropagation();void openInbox();
 };
 doc.addEventListener('click',handle,true);
 return ()=>doc.removeEventListener('click',handle,true);
}
