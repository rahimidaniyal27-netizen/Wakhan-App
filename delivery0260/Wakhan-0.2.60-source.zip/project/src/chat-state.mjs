// View-independent conversation state. Polls never replace drafts or editing state.
export const operationKey=()=>Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');
export const threadKey=(kind,id)=>`${kind}:${id}`;
export class Conversation {
 constructor(kind,id){this.kind=kind;this.id=id;this.messages=new Map();this.cursor=0;this.draft='';this.reply=null;this.edit=null;this.outbox=new Map();this.acked=new Set();this.read=new Set();this.firstUnread=null;this.more=true;this.loaded=false;this.mutation=null;}
 merge(result){
  for(const m of [...(result.messages||[]),...(result.changed||[])]){this.messages.set(m.id,m);if(m.client_key)this.outbox.delete(m.client_key);}
  for(const id of result.removed||[])this.messages.delete(id);
  this.cursor=result.cursor??this.cursor;
  if(!this.loaded)this.firstUnread=result.first_unread??null;
  this.loaded=true;
  // Deleted originals must disappear from quotes even when their reply is on an older page.
  for(const [id,m] of this.messages){if(m.reply&&(result.removed||[]).includes(m.reply.id))this.messages.set(id,{...m,reply:{id:m.reply.id,unavailable:true}});}
 }
 rows(){return [...this.messages.values()].sort((a,b)=>a.id-b.id);}
 startReply(m){if(this.edit)this.cancelEdit();this.reply={id:m.id,sender:m.sender,name:m.person?.name,text:m.text};}
 startEdit(m){if(this.edit)this.cancelEdit();this.edit={id:m.id,original:m.text,savedDraft:this.draft,savedReply:this.reply,key:null};this.draft=m.text;this.reply=null;}
 cancelEdit(){if(!this.edit)return;this.draft=this.edit.savedDraft;this.reply=this.edit.savedReply;this.edit=null;}
 finishEdit(){this.cancelEdit();}
 prepareSend(){if(this.edit){if(!this.draft.trim()||this.draft.trim()===this.edit.original)return null;return {action:'edit',id:this.edit.id,text:this.draft.trim(),client_key:this.edit.key??=operationKey()};}
  if(!this.draft.trim())return null;const p={text:this.draft.trim(),reply_to:this.reply?.id??null,client_key:operationKey()};this.outbox.set(p.client_key,{...p,reply:this.reply?{...this.reply}:null,ts:Date.now()/1000,status:'sending'});this.draft='';this.reply=null;return p;}
 failed(key){const item=this.outbox.get(key);if(item)item.status='failed';}
}
export function leftSwipe({dx,dy,duration=0}){return dx<=-48&&Math.abs(dy)<18&&Math.abs(dx)>Math.abs(dy)*2&&duration<1500;}
export function badge(tier,now=Date.now()/1000){if(!tier||!['vip','premium','royal'].includes(tier.tier))return null;return tier.until&&tier.until<=now?null:tier.tier;}
export const escapeHTML=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
