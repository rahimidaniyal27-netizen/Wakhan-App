/* Bundle flags with the client: a phone's emoji font must not change identity. */
export function installFlags({doc=document,origin=location.origin}={}){
 const asset=new URL('/flags/af.svg',origin).href;
 function replace(node){
  if(node.nodeType!==3||!node.data.includes('🇦🇫')||node.parentElement?.closest('script,style,textarea,input,[contenteditable],.wk-country-flag'))return;
  const parts=node.data.split('🇦🇫'),fragment=doc.createDocumentFragment();
  parts.forEach((text,i)=>{if(i){const flag=doc.createElement('img');flag.src=asset;flag.alt='🇦🇫';flag.setAttribute('aria-label','افغانستان');flag.className='wk-country-flag';flag.width=20;flag.height=14;fragment.append(flag)}if(text)fragment.append(doc.createTextNode(text))});node.replaceWith(fragment);
 }
 function scan(node){if(node.nodeType===3)return replace(node);if(node.nodeType!==1||node.matches('script,style,textarea,input,[contenteditable]'))return;const walker=doc.createTreeWalker(node,4),texts=[];while(walker.nextNode())if(walker.currentNode.data.includes('🇦🇫'))texts.push(walker.currentNode);texts.forEach(replace)}
 scan(doc.body);const observer=new MutationObserver(records=>{for(const record of records){if(record.type==='characterData')replace(record.target);else for(const node of record.addedNodes)scan(node)}});observer.observe(doc.body,{subtree:true,childList:true,characterData:true});return {dispose:()=>observer.disconnect()};
}
