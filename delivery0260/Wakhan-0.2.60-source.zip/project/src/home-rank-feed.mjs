/* One visible Home owns the one-second feed. Scores always come from the server. */
export function createRankFeed({request,isVisible,getIdentity,onData,onError=()=>{},now=Date.now,setTimer=setInterval,clearTimer=clearInterval}){
 let category='overall',period='month',busy=false,disposed=false,generation=0,failures=0,retryAt=0,lastIdentity=null,signature='';
 async function tick(force=false){
  if(disposed||busy||!isVisible()||!force&&now()<retryAt)return;
  const identity=getIdentity();if(!Number.isSafeInteger(identity)||identity<=0)return;
  if(identity!==lastIdentity){lastIdentity=identity;signature='';generation++;}
  const serial=generation,key=category+':'+period;busy=true;
  try{
   const result=await request('/api/app/home/rankings?category='+category+'&period='+period);
   if(disposed||serial!==generation||identity!==getIdentity()||!isVisible())return;
   if(!result?.ok||result.category!==category||result.period!==period||!Array.isArray(result.items))throw Error('rankings_unavailable');
   failures=0;retryAt=0;
   // The server's end timestamp changes every second; it is not a score change.
   const next=JSON.stringify([key,identity,result.start,result.available,result.rule,result.items,result.me,result.salons]);
   if(next!==signature){await onData(result);if(serial===generation&&identity===getIdentity())signature=next;}
  }catch(error){if(!disposed&&serial===generation&&identity===getIdentity()){failures++;retryAt=now()+Math.min(30000,1000*2**Math.min(failures,5));onError(error);}}
  finally{busy=false;if(!disposed&&serial!==generation)void tick(true);}
 }
 const timer=setTimer(()=>void tick(),1000);
 return {tick,select(nextCategory='overall',nextPeriod='month'){
  if(!['overall','activity','purchase','games'].includes(nextCategory)||!['week','month'].includes(nextPeriod))return;
  if(category!==nextCategory||period!==nextPeriod){category=nextCategory;period=nextPeriod;generation++;signature='';retryAt=0;}
  void tick(true);
 },invalidate(){generation++;signature='';retryAt=0;void tick(true);},dispose(){disposed=true;generation++;clearTimer(timer);}};
}
