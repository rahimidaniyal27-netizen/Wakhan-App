/* Stories: 24-hour photos and videos from you and your friends. Data comes from the chat server
   add-on (/api/app/chatx/stories…); media is fetched privately with the session (never a public URL). */
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ago=ts=>{const s=Math.max(0,Date.now()/1000-ts);if(s<3600)return Math.max(1,Math.round(s/60))+' دقیقه پیش';return Math.round(s/3600)+' ساعت پیش'};

export function createStories({request,fetchBinary,origin='https://music.kabulcafe.uk',avatar,toast=()=>{},pickMedia,hydrate=()=>{},onChange=()=>{}}){
 let groups=[],loaded=false,viewer=null,urls=new Map();
 const api=(part,body)=>request('/api/app/chatx/'+part,body||{});
 async function load(){try{const r=await api('stories');if(r?.ok){groups=r.groups||[];loaded=true}}catch{}return groups}
 function row(online=[]){
  const mine=groups.find(g=>g.mine);
  const me=`<button type="button" class="wc-story me${mine?' has':''}${mine&&mine.unseen?' unseen':''}" data-story="me"><span class="wc-story-ring">${mine?avatar(mine.person):'<span class="wc-avatar wc-story-add-face"></span>'}<i class="wc-story-plus" aria-hidden="true">+</i></span><span class="wc-online-name">استوری من</span></button>`;
  const others=groups.filter(g=>!g.mine).map(g=>`<button type="button" class="wc-story${g.unseen?' unseen':' seen'}" data-story="${g.person.id}"><span class="wc-story-ring">${avatar(g.person)}</span><span class="wc-online-name">${esc(String(g.person.name).split(' ')[0])}</span></button>`).join('');
  const seen=new Set(groups.map(g=>g.person.id));
  const live=online.filter(p=>!seen.has(p.id)).map(p=>`<button type="button" class="wc-story online" data-open="dm:${p.id}"><span class="wc-story-ring plain">${avatar({...p,online:true},false,true)}</span><span class="wc-online-name">${esc(String(p.name).split(' ')[0])}</span></button>`).join('');
  return `<div class="wc-online-people wc-stories" aria-label="استوری‌ها">${me}${others}${live}</div>`;
 }
 async function media(id){if(urls.has(id))return urls.get(id);const r=await fetchBinary(origin+'/api/app/chatx/story/'+id);if(!r.ok)throw Error('story');const u=URL.createObjectURL(await r.blob());urls.set(id,u);if(urls.size>40){const k=urls.keys().next().value;URL.revokeObjectURL(urls.get(k));urls.delete(k)}return u}
 function style(){if(document.getElementById('wkst-css'))return;const s=document.createElement('style');s.id='wkst-css';s.textContent=`
.wkst{position:fixed;inset:0;z-index:2147482000;background:#000;color:#fff;font-family:Vazirmatn,system-ui,sans-serif;direction:rtl;touch-action:none;animation:wkstin .2s ease-out}
@keyframes wkstin{from{opacity:0;transform:scale(.96)}to{opacity:1;transform:none}}
.wkst .bars{position:absolute;top:calc(env(safe-area-inset-top,0px) + 8px);left:10px;right:10px;display:flex;gap:4px;z-index:3;direction:ltr}
.wkst .bars i{flex:1;height:3px;border-radius:2px;background:rgba(255,255,255,.35);overflow:hidden}
.wkst .bars i b{display:block;height:100%;width:0;background:#fff}
.wkst .head{position:absolute;top:calc(env(safe-area-inset-top,0px) + 20px);left:12px;right:12px;display:flex;align-items:center;gap:10px;z-index:3}
.wkst .head .wc-avatar{width:38px!important;height:38px!important;font-size:15px!important;border-radius:50%;overflow:hidden;display:grid;place-items:center}
.wkst .head b{font-size:15px}.wkst .head small{font-size:12px;opacity:.75;margin-inline-start:6px}
.wkst .head .x{margin-inline-start:auto;width:40px;height:40px;border-radius:50%;border:0;background:rgba(255,255,255,.16);color:#fff;font-size:22px;line-height:1}
.wkst .stage{position:absolute;inset:0;display:grid;place-items:center}
.wkst .stage img,.wkst .stage video{max-width:100%;max-height:100%;width:100%;height:100%;object-fit:contain}
.wkst .cap{position:absolute;left:16px;right:16px;bottom:calc(env(safe-area-inset-bottom,0px) + 84px);text-align:center;font-size:17px;font-weight:700;text-shadow:0 2px 10px rgba(0,0,0,.7);z-index:3}
.wkst .foot{position:absolute;left:14px;right:14px;bottom:calc(env(safe-area-inset-bottom,0px) + 18px);display:flex;gap:10px;justify-content:center;z-index:3}
.wkst .foot button{height:46px;padding:0 18px;border-radius:23px;border:1px solid rgba(255,255,255,.35);background:linear-gradient(180deg,rgba(255,255,255,.2),rgba(255,255,255,.08));color:#fff;font:700 14px Vazirmatn,system-ui}
.wkst .tap{position:absolute;top:80px;bottom:90px;width:35%;z-index:2}.wkst .tap.prev{right:0}.wkst .tap.next{left:0}
.wkst .sheet{position:absolute;left:10px;right:10px;bottom:calc(env(safe-area-inset-bottom,0px) + 10px);max-height:55%;overflow:auto;border-radius:26px;padding:12px;background:rgba(20,16,44,.96);border:1px solid rgba(255,255,255,.2);z-index:5}
.wkst .sheet div{display:flex;align-items:center;gap:10px;padding:8px 4px}.wkst .sheet .wc-avatar{width:36px!important;height:36px!important;border-radius:50%;overflow:hidden;display:grid;place-items:center;font-size:14px}
.wkst .wc-avatar{--wc-hue:265;background:linear-gradient(145deg,hsl(var(--wc-hue) 92% 66%),hsl(calc(var(--wc-hue) + 38) 88% 52%));color:#fff;font-weight:800;border-radius:50%;overflow:hidden;display:grid;place-items:center;position:relative}\n.wkst .wc-avatar img{width:100%;height:100%;object-fit:cover}\n.wkst .wc-online-dot{display:none}\n`;document.head.append(s)}
 function close(){if(!viewer)return;clearInterval(viewer.timer);viewer.el.remove();viewer=null;onChange()}
 async function show(){const v=viewer;if(!v)return;const g=v.list[v.gi];const it=g?.items[v.ii];if(!it)return close();
  clearInterval(v.timer);v.el.querySelector('.head').innerHTML=`${avatar(g.person)}<b>${esc(g.mine?'استوری من':g.person.name)}</b><small>${ago(it.ts)}</small><button type="button" class="x" data-k="close" aria-label="بستن">×</button>`;
  try{hydrate(v.el.querySelector('.head'))}catch{}v.el.querySelector('.bars').innerHTML=g.items.map((_,i)=>`<i><b style="width:${i<v.ii?100:0}%"></b></i>`).join('');
  v.el.querySelector('.cap').textContent=it.caption||'';v.el.querySelector('.foot').innerHTML=g.mine?`<button type="button" data-k="viewers">👁 بیننده‌ها</button><button type="button" data-k="delete">حذف</button><button type="button" data-k="add">+ استوری تازه</button>`:'';
  const stage=v.el.querySelector('.stage');stage.innerHTML='';let url;try{url=await media(it.id)}catch{toast('این استوری دیگر در دسترس نیست.');return next()}
  if(viewer!==v)return;let dur=5000;
  if(it.kind==='video'){const el=document.createElement('video');el.src=url;el.playsInline=true;el.autoplay=true;el.setAttribute('playsinline','');stage.append(el);el.play?.().catch(()=>{});await new Promise(ok=>{el.onloadedmetadata=ok;setTimeout(ok,1500)});dur=Math.min(60000,(el.duration||10)*1000)}
  else{const el=new Image();el.src=url;stage.append(el)}
  if(!g.mine&&!it.seen){it.seen=true;api('story_view',{id:it.id}).catch(()=>{});g.unseen=g.items.some(x=>!x.seen)}
  const bar=v.el.querySelectorAll('.bars b')[v.ii];const t0=Date.now();v.timer=setInterval(()=>{if(v.paused)return;const p=Math.min(1,(Date.now()-t0)/dur);if(bar)bar.style.width=p*100+'%';if(p>=1)next()},60)}
 function next(){const v=viewer;if(!v)return;const g=v.list[v.gi];if(v.ii<g.items.length-1){v.ii++;return show()}if(v.gi<v.list.length-1){v.gi++;v.ii=0;return show()}close()}
 function prev(){const v=viewer;if(!v)return;if(v.ii>0){v.ii--;return show()}if(v.gi>0){v.gi--;v.ii=0;return show()}show()}
 async function open(key){if(!loaded)await load();
  if(key==='me'&&!groups.some(g=>g.mine))return add();
  const list=groups.filter(g=>g.items.length);const gi=list.findIndex(g=>key==='me'?g.mine:String(g.person.id)===String(key));if(gi<0)return;
  style();const el=document.createElement('div');el.className='wkst';el.innerHTML='<div class="stage"></div><div class="bars"></div><div class="head"></div><div class="tap prev" data-k="prev"></div><div class="tap next" data-k="next"></div><div class="cap"></div><div class="foot"></div>';document.body.append(el);
  const g=list[gi];viewer={el,list,gi,ii:Math.max(0,g.mine?0:g.items.findIndex(i=>!i.seen)),timer:0};
  el.addEventListener('click',async e=>{const b=e.target.closest('[data-k]');if(!b){return}const k=b.dataset.k;
   if(k==='close')return close();if(k==='next')return next();if(k==='prev')return prev();
   const it=viewer.list[viewer.gi].items[viewer.ii];
   if(k==='add'){close();return add()}
   if(k==='delete'){const r=await api('story_delete',{id:it.id});if(r?.ok){toast('استوری حذف شد.');close();await load();onChange()}return}
   if(k==='viewers'){viewer.paused=true;const r=await api('story_viewers',{id:it.id});const s=document.createElement('div');s.className='sheet';s.innerHTML=`<b>${(r?.viewers||[]).length} بیننده</b>`+(r?.viewers||[]).map(p=>`<div>${avatar(p)}<span>${esc(p.name)}</span></div>`).join('')+'<button type="button" data-k="unsheet" style="margin-top:8px;width:100%;height:42px;border-radius:21px;border:0;background:#fff;color:#15112b;font-weight:800">بستن</button>';el.append(s);try{hydrate(s)}catch{}return}
   if(k==='unsheet'){el.querySelector('.sheet')?.remove();viewer.paused=false;return}});
  let sy=0;el.addEventListener('touchstart',e=>{sy=e.touches[0].clientY;if(viewer)viewer.paused=true},{passive:true});el.addEventListener('touchend',e=>{if(viewer&&!el.querySelector('.sheet'))viewer.paused=false;if((e.changedTouches[0]?.clientY||0)-sy>90)close()},{passive:true});
  show()}
 async function add(){const pick=await pickMedia();if(!pick)return;toast('در حال فرستادن استوری…');try{const r=await api('story_post',{media:pick.id,caption:''});if(!r?.ok)throw Error(r?.message||'فرستادن استوری ممکن نشد.');toast('استوری فرستاده شد.');await load();onChange()}catch(e){toast(e.message)}}
 return {load,row,open,add,get groups(){return groups},get loaded(){return loaded}};
}
