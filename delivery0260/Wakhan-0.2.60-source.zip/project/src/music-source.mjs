export function musicSource(value,origin='https://music.kabulcafe.uk'){
 try{const u=new URL(value,origin);if(u.username||u.password||u.hash)return null;
  if(u.protocol==='file:'&&/^\/.*\/wakhan-music\/u\d{1,18}_[a-f0-9]{64}\.mp3$/.test(u.pathname)&&!u.search)return u.href;
  if(u.protocol!=='https:'||u.port&&u.port!=='443')return null;
  if(u.origin===origin&&/^\/(?:a|api\/app\/music\/media)\/[A-Za-z0-9_-][A-Za-z0-9_.-]*$/.test(u.pathname))return u.href;
  if(u.hostname==='api.audius.co'&&/^\/v1\/tracks\/[A-Za-z0-9]{1,30}\/stream$/.test(u.pathname)&&u.search==='?app_name=Wakhan')return u.href;
  if(u.hostname==='archive.org'&&/^\/download\/[A-Za-z0-9_.-]{1,180}\/.+\.mp3$/i.test(u.pathname)&&!u.search)return u.href;
  if(u.hostname==='ccmixter.org'&&/^\/content\/[^/]+\/[^/]+\.mp3$/i.test(u.pathname)&&!u.search)return u.href;
 }catch{}return null;
}
