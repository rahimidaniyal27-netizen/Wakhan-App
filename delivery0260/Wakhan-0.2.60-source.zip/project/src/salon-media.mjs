/* One media command owner; leaving a voice room is never a media operation. */
export function nativeRoomMedia(state,room,origin='https://music.kabulcafe.uk'){
 if(state?.media?.kind!=='native'||!state.media.formats?.length)return false;
 if(!/^[A-Za-z0-9_-]{11}$/.test(String(state.vid||'')))return true;
 if(state.media.provider!=='youtube')return false;
 try{const u=new URL(state.media.formats[0].url,origin);return u.origin===origin&&!u.username&&!u.password&&!u.hash&&u.pathname==='/api/app/rooms/'+room+'/video'&&u.searchParams.get('vid')===state.vid&&!!u.searchParams.get('lease')}catch{return false}
}
export function createSalonControls({context,request,apply,local=()=>{},notice=()=>{}}){
 let jobs=[],running=null,pending=null,generation=0,own=false;
 const commit=value=>{own=true;try{apply(value)}finally{own=false}};
 const key=c=>String(c?.uid)+'|'+c?.room+'|'+c?.state?.vid;
 const valid=c=>c?.room&&c.state?.vid&&c.state.mine>=0&&c.can===true;
 function filter(state){if(own)return state;const c=context();if(!pending||!c||key(c)!==pending.key||state?.vid!==c.state.vid||state.mine<0||Number(state.timeline_revision)>pending.revision)return state;return {...state,playing:c.state.playing,t:c.state.t};}
 async function drain(){
  while(jobs.length){const job=jobs.shift(),c=context();if(!valid(c)||key(c)!==job.key)continue;const owner=generation;
   pending={key:job.key,revision:Number(c.state.timeline_revision)||0};
   try{
    let value;
    if(job.kind==='stop'){
     value=await request('/api/app/salon/screen',{code:c.room,action:'close'});if(!value?.ok)throw Error(value?.err||'failed');
     value=await request('/api/c/'+encodeURIComponent(c.room)+'?v=-1');
    }else value=await request('/api/c/'+encodeURIComponent(c.room),{a:job.kind==='seek'?'seek':job.playing?'play':'pause',vid:c.state.vid,t:job.time});
    if(owner!==generation||key(context())!==job.key)continue;
    if(!value?.ok)throw Error(value?.err||'failed');
    pending=null;const next=jobs.at(-1);commit(next&&next.key===job.key&&next.kind!=='stop'?{...value,t:next.time,playing:next.playing}:value);local(context()?.state);
   }catch{
    if(owner!==generation||key(context())!==job.key)continue;jobs=[];pending=null;notice('کنترل پخش انجام نشد؛ دوباره بزن');
    try{const fresh=await request('/api/c/'+encodeURIComponent(c.room)+'?v=-1');if(owner===generation&&key(context())===job.key&&fresh?.ok){commit(fresh);local(context()?.state)}}catch{}
   }finally{pending=null}
  }
 }
 function enqueue(kind,playing,time){const c=context();if(!valid(c))return Promise.resolve(false);const job={kind,playing,time:Math.max(0,Number(time)||0),key:key(c)};
  if(jobs.at(-1)?.kind===kind&&kind!=='stop')jobs[jobs.length-1]=job;else if(jobs.length<8)jobs.push(job);else return running||Promise.resolve(false);
  commit({...c.state,playing:kind==='stop'?false:playing,t:job.time});local(context()?.state);
  if(!running)running=drain().finally(()=>{running=null});return running;
 }
 return {native:nativeRoomMedia,filter,toggle(){const c=context();return enqueue('toggle',!c?.state?.playing,c?.position)},seekTo(t){return enqueue('seek',!!context()?.state?.playing,t)},seekBy(t){return this.seekTo((context()?.position||0)+t)},stop(){return enqueue('stop',false,context()?.position)},dispose(){generation++;jobs=[];pending=null}};
}
