// A stopped recording stays local until the user presses the normal send button.
import {operationKey} from './chat-state.mjs';
export function voiceDraft(conversation,context){
 return {t:conversation,c:{...context},reply_to:conversation.reply?.id||null,key:operationKey(),stage:'requesting',seconds:0,blob:null,mediaId:'',sendAfterStop:false,cancelled:false,busy:false,error:'',voice:null,url:'',player:null};
}
export function releaseVoiceDraft(job){
 if(!job)return;job.cancelled=true;
 try{job.player?.pause();}catch{}
 if(job.url)URL.revokeObjectURL(job.url);
 job.url='';job.blob=null;job.voice?.stop(false);
}
