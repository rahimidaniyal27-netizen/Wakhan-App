/* Keep the existing views and commands; navigation never waits for a refresh. */
export function installRetainedNavigation({pages,getTab,setTab,getSub,setSub,getGo,setGo,renderNav,home,music,chat,me,isSalon,hasRoom,openLobby,afterChange=()=>{}}){
 const previous=getGo(),measurements=[];let serial=0;
 function navigate(tab,sub){
  const from=getTab(),started=performance.now(),epoch=++serial,primary=['h','p','c','d','m'].includes(tab),salon=isSalon();
  if(tab==='c'&&window.WakhanCinema?.opening&&!salon)openLobby();
  const key=tab==='c'?'c:lobby':tab,cached=pages.peek(key),canRetain=primary&&!sub&&!getSub()&&!salon&&(tab!=='c'||!hasRoom()||window.WakhanCinema?.opening)&&(tab==='p'||tab==='m'||!!cached?.querySelector('iframe,.sl,.wkchat,.wk3'));
  if(canRetain){if(tab==='p')pages.stats.externalRenders++;
   setTab(tab);setSub(null);pages.view();
   document.body.classList.toggle('cinema',tab==='c');document.body.classList.toggle('sl-on',tab==='c');document.body.classList.toggle('wk3-on',tab==='m');document.body.classList.remove('wk-typing');
   if(tab==='m')me()?.activate?.();
   renderNav();
  }else previous(tab,sub);
  if(from==='h'||tab==='h')home()?.onRoute?.(from);
  if(from==='p'||tab==='p')music()?.onRoute?.(from);
  if(from==='d'||tab==='d')chat()?.resume?.();
  afterChange(tab);
  const handler=performance.now()-started;
  requestAnimationFrame(()=>{if(epoch!==serial)return;window.scrollTo({top:0,behavior:'instant'});measurements.push({from,to:tab,retained:canRetain,handler,frame:performance.now()-started});if(measurements.length>80)measurements.shift()});
 }
 navigate.__s9=1;setGo(navigate);return {navigate,measurements};
}
