// Combine independent keyboard observations; never subtract a keyboard twice.
export function chatViewport({height,baseline=height,visual=null,overlap=0,keyboardHeight=0,nativeObserved=false}){
 const top=Math.max(0,Number(visual?.offsetTop)||0);
 const bottoms=[height];
 if(!nativeObserved&&Number(visual?.height)>0)bottoms.push(top+Number(visual.height));
 if(nativeObserved)bottoms.push(baseline-Math.max(0,overlap));
 else if(overlap>0)bottoms.push(baseline-overlap);
 if(!nativeObserved&&keyboardHeight>0)bottoms.push(baseline-keyboardHeight);
 return {offsetTop:top,height:Math.max(1,Math.min(...bottoms)-top),fullHeight:baseline};
}

export function installChatViewport({keyboard,onChange=()=>{},win=window,doc=document}={}){
 let baseline=win.innerHeight,width=win.innerWidth,overlap=0,keyboardHeight=0,open=false,disposed=false,nativeObserved=false;
 const listeners=[],handles=[];
 const listen=(target,name,fn)=>{target?.addEventListener(name,fn);listeners.push(()=>target?.removeEventListener(name,fn));};
 const current=()=>chatViewport({height:win.innerHeight,baseline,visual:win.visualViewport,overlap,keyboardHeight,nativeObserved});
 function changed(){
  if(disposed)return;
  if(width!==win.innerWidth){width=win.innerWidth;baseline=win.innerHeight;}
  else if(!open&&!doc.activeElement?.matches('textarea,input:not([type=checkbox]):not([type=range])'))baseline=win.innerHeight;
  onChange(current());
 }
 function nativeFrame(event){const value=event.detail||event;if(!Number.isFinite(value.overlap))return;if(value.overlap>0&&!open)baseline=Math.max(baseline,win.innerHeight);nativeObserved=true;overlap=Math.max(0,value.overlap);open=overlap>0;changed();}
 async function bridge(name,handler){try{const handle=await keyboard?.addListener(name,handler);if(handle){if(disposed)await handle.remove();else handles.push(handle);}}catch{}}
 const show=event=>{if(!open)baseline=Math.max(baseline,win.innerHeight);keyboardHeight=Math.max(0,Number(event.keyboardHeight)||0);open=nativeObserved?overlap>0:keyboardHeight>0;changed();};
 const hide=()=>{keyboardHeight=0;if(!nativeObserved)overlap=0;open=nativeObserved&&overlap>0;changed();};
 listen(win,'wakhanKeyboardFrame',nativeFrame);listen(win,'resize',changed);listen(win.visualViewport,'resize',changed);listen(win.visualViewport,'scroll',changed);
 listen(doc,'focusin',changed);listen(doc,'focusout',()=>win.requestAnimationFrame?.(changed));
 if(keyboard){void bridge('keyboardWillShow',show);void bridge('keyboardDidShow',show);void bridge('keyboardWillHide',hide);void bridge('keyboardDidHide',hide);}
 return {current,dispose(){disposed=true;listeners.forEach(remove=>remove());handles.forEach(handle=>void handle.remove());}};
}
