// Wallpaper pixels belong to the resting chat canvas, not the keyboard-sized scrollport.
export function wallpaperHeight({fullHeight,headerHeight=0,formHeight=0,footerChrome=0,rootChrome=0}){
 return Math.max(1,fullHeight-headerHeight-formHeight-footerChrome-rootChrome);
}
