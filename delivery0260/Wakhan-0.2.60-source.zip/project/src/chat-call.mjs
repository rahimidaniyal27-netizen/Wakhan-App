/* One-to-one voice and video calls (WebRTC). Signalling goes through the chat server add-on
   (/api/app/chatx/call_*); media flows peer to peer, relayed by the same TURN service the salons use. */
const ICON={
 mic:'<path d="M12 3a3 3 0 0 1 3 3v5a3 3 0 0 1-6 0V6a3 3 0 0 1 3-3z"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"/>',
 micx:'<path d="M15 10V6a3 3 0 0 0-5.7-1.3M9 9v2a3 3 0 0 0 4.6 2.5"/><path d="M5.5 11a6.5 6.5 0 0 0 10.3 5.3M18.5 11c0 .8-.1 1.5-.4 2.2M12 17.5V21M4 4l16 16"/>',
 cam:'<rect x="2.5" y="6" width="13" height="12" rx="3"/><path d="m15.5 10.5 6-3.5v10l-6-3.5"/>',
 camx:'<rect x="2.5" y="6" width="13" height="12" rx="3"/><path d="m15.5 10.5 6-3.5v10l-6-3.5M3 3l18 18"/>',
 flip:'<path d="M4 8h11l-3-3M20 16H9l3 3"/>',
 end:'<path d="M3.5 14.5c4.7-4.7 12.3-4.7 17 0l-2.3 2.3-3.4-1.5v-2.4a10 10 0 0 0-5.6 0v2.4l-3.4 1.5z" fill="currentColor" stroke="none"/>',
 ok:'<path d="M6.6 3.5 9 5.9l-1.4 3a12 12 0 0 0 7.5 7.5l3-1.4 2.4 2.4-1.7 3.1C11.6 21 3 12.4 3.5 5.2z" fill="currentColor" stroke="none"/>',
 spk:'<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z"/><path d="M15.5 9a4.2 4.2 0 0 1 0 6M18 6.5a7.8 7.8 0 0 1 0 11"/>'
};
const svg=k=>`<svg viewBox="0 0 24 24" aria-hidden="true">${ICON[k]}</svg>`;
const clock=s=>String(Math.floor(s/60)).padStart(2,'0')+':'+String(Math.floor(s%60)).padStart(2,'0');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

export function installCalls({request,fetchBinary,origin='https://music.kabulcafe.uk',getUid,toast=()=>{},avatar=()=>'',hydrate=()=>{},onEnded=()=>{}}){
 let current=null,incomingTimer=0,ringing=null,disposed=false,enabled=false,lastIncoming='';
 const style=()=>{if(document.getElementById('wkcall-css'))return;const s=document.createElement('style');s.id='wkcall-css';s.textContent=`
.wkcall{position:fixed;inset:0;z-index:2147483000;display:flex;flex-direction:column;align-items:center;justify-content:space-between;padding:calc(env(safe-area-inset-top,0px) + 54px) 20px calc(env(safe-area-inset-bottom,0px) + 34px);color:#fff;font-family:Vazirmatn,system-ui,sans-serif;background:radial-gradient(120% 70% at 50% 0%,#3a2a8a,#0d0a24 62%,#060512);direction:rtl;animation:wkcin .22s ease-out}
@keyframes wkcin{from{opacity:0;transform:scale(1.03)}to{opacity:1;transform:none}}
.wkcall .who{display:flex;flex-direction:column;align-items:center;gap:12px;z-index:2;text-align:center}
.wkcall .who .ring{position:relative;width:132px;height:132px;border-radius:50%;display:grid;place-items:center}
.wkcall .who .ring::before,.wkcall .who .ring::after{content:'';position:absolute;inset:-10px;border-radius:50%;border:2px solid rgba(255,255,255,.25);animation:wkpulse 1.8s ease-out infinite}
.wkcall .who .ring::after{animation-delay:.9s}
.wkcall.live .who .ring::before,.wkcall.live .who .ring::after{animation:none;opacity:0}
@keyframes wkpulse{from{transform:scale(.92);opacity:1}to{transform:scale(1.35);opacity:0}}
.wkcall .who .wc-avatar{width:120px!important;height:120px!important;font-size:46px!important;border-radius:50%;overflow:hidden;display:grid;place-items:center}
.wkcall .who b{font-size:26px;font-weight:900}
.wkcall .who small{font-size:15px;color:rgba(255,255,255,.75);direction:ltr}
.wkcall .bar{display:flex;gap:22px;z-index:2;align-items:center}
.wkcall .bar button{width:66px;height:66px;border-radius:50%;display:grid;place-items:center;border:1px solid rgba(255,255,255,.3);background:linear-gradient(180deg,rgba(255,255,255,.22),rgba(255,255,255,.08));color:#fff;backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);padding:0}
.wkcall .bar button.on{background:#fff;color:#15112b}
.wkcall .bar button svg{width:28px;height:28px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
.wkcall .bar .end{background:#ff3b5c!important;border-color:#ff3b5c!important;color:#fff!important}
.wkcall .bar .end svg{transform:rotate(135deg)}
.wkcall .bar .ok{background:#2fd06d!important;border-color:#2fd06d!important}
.wkcall .bar label{display:flex;flex-direction:column;align-items:center;gap:7px;font-size:12px;color:rgba(255,255,255,.8)}
.wkcall video.remote{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#000;z-index:0}
.wkcall video.local{position:absolute;top:calc(env(safe-area-inset-top,0px) + 54px);left:16px;width:108px;height:156px;border-radius:18px;object-fit:cover;z-index:3;border:1px solid rgba(255,255,255,.4);background:#111;transform:scaleX(-1)}
.wkcall.video.live .who{opacity:0;pointer-events:none}
.wkcall.video.live{background:#000}
.wkcall .shade{position:absolute;left:0;right:0;bottom:0;height:220px;background:linear-gradient(0deg,rgba(0,0,0,.6),transparent);z-index:1;pointer-events:none}
.wkcall .wc-avatar{--wc-hue:265;background:linear-gradient(145deg,hsl(var(--wc-hue) 92% 66%),hsl(calc(var(--wc-hue) + 38) 88% 52%));color:#fff;font-weight:800;border-radius:50%;overflow:hidden;display:grid;place-items:center;position:relative}\n.wkcall .wc-avatar img{width:100%;height:100%;object-fit:cover}\n.wkcall .wc-online-dot{display:none}\n`;document.head.append(s)};
 const api=async(part,body)=>{const r=await request('/api/app/chatx/'+part,body||{});return r};
 const turn=async()=>{try{const r=await fetchBinary(origin+'/api/turn');const j=await r.json();if(Array.isArray(j?.ice)&&j.ice.length)return j.ice}catch{}return [{urls:'stun:stun.l.google.com:19302'}]};
 function haptic(){try{window.WakhanNative?.HapticFeedback?.impact?.({style:'medium'})}catch{}}
 function tone(kind){stopTone();try{const AC=window.AudioContext||window.webkitAudioContext;const ctx=new AC();const g=ctx.createGain();g.gain.value=0;g.connect(ctx.destination);const o=ctx.createOscillator();o.frequency.value=kind==='in'?620:440;o.connect(g);o.start();let on=false;const t=setInterval(()=>{on=!on;g.gain.setTargetAtTime(on?.08:0,ctx.currentTime,.02);if(kind==='in'&&on)haptic()},kind==='in'?600:1000);ringing={ctx,t}}catch{}}
 function stopTone(){if(!ringing)return;clearInterval(ringing.t);try{ringing.ctx.close()}catch{}ringing=null}
 function overlay(c){style();const el=document.createElement('div');el.className='wkcall'+(c.video?' video':'');el.innerHTML=`<video class="remote" playsinline autoplay ${c.video?'':'hidden'}></video><video class="local" playsinline autoplay muted hidden></video><div class="shade"></div><div class="who"><span class="ring">${avatar(c.person||{})}</span><b>${esc(c.person?.name||'')}</b><small data-status></small></div><div class="bar" data-bar></div><audio class="ra" autoplay playsinline></audio>`;document.body.append(el);try{hydrate(el)}catch{}return el}
 function status(t){const n=current?.el?.querySelector('[data-status]');if(n)n.textContent=t}
 function bar(mode){const c=current;if(!c)return;const b=c.el.querySelector('[data-bar]');
  if(mode==='incoming')b.innerHTML=`<label><button type="button" class="end" data-k="decline" aria-label="رد تماس">${svg('end')}</button>رد</label><label><button type="button" class="ok" data-k="accept" aria-label="پاسخ">${svg(c.video?'cam':'ok')}</button>پاسخ</label>`;
  else b.innerHTML=`<label><button type="button" data-k="mute" class="${c.muted?'on':''}" aria-label="میکروفون">${svg(c.muted?'micx':'mic')}</button>${c.muted?'بی‌صدا':'میکروفون'}</label>${c.video?`<label><button type="button" data-k="cam" class="${c.camOff?'on':''}" aria-label="دوربین">${svg(c.camOff?'camx':'cam')}</button>دوربین</label><label><button type="button" data-k="flip" aria-label="چرخش دوربین">${svg('flip')}</button>چرخش</label>`:''}<label><button type="button" class="end" data-k="end" aria-label="قطع تماس">${svg('end')}</button>قطع</label>`;}
 async function media(video,facing='user'){return navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:video?{facingMode:facing,width:{ideal:720},height:{ideal:1280}}:false})}
 async function peer(c){const pc=new RTCPeerConnection({iceServers:await turn()});c.pc=pc;c.out=[];
  pc.onicecandidate=e=>{if(e.candidate)c.out.push(e.candidate.toJSON())};
  pc.ontrack=e=>{const s=e.streams[0];if(!s)return;const a=c.el.querySelector('.ra');a.srcObject=s;a.play?.().catch(()=>{});if(c.video){const v=c.el.querySelector('video.remote');v.srcObject=s;v.hidden=false;v.muted=true;v.play?.().catch(()=>{})}};
  pc.onconnectionstatechange=()=>{const s=pc.connectionState;if(s==='connected')live();if(s==='failed')finish('failed',true)};
  for(const t of c.stream.getTracks())pc.addTrack(t,c.stream);
  return pc}
 function gathered(pc,ms=1500){return new Promise(ok=>{if(pc.iceGatheringState==='complete')return ok();const t=setTimeout(ok,ms);pc.addEventListener('icegatheringstatechange',()=>{if(pc.iceGatheringState==='complete'){clearTimeout(t);ok()}})})}
 function showLocal(c){if(!c.video)return;const v=c.el.querySelector('video.local');v.srcObject=c.stream;v.hidden=false;v.play?.().catch(()=>{})}
 function live(){const c=current;if(!c||c.live)return;c.live=true;c.t0=Date.now();stopTone();c.el.classList.add('live');bar('active');clearInterval(c.clock);c.clock=setInterval(()=>status(clock((Date.now()-c.t0)/1000)),500);status('00:00')}
 async function loop(){const c=current;if(!c||c.done)return;try{if(c.out.length){const batch=c.out.splice(0,30);await api('call_ice',{id:c.id,candidates:batch})}
   const r=await api('call_poll',{id:c.id,since:c.since||0});const v=r?.call;if(current!==c||c.done)return;
   if(v){if(v.state==='ended'){finish(v.reason==='declined'?'declined':'ended',false);return}
    if(c.role==='caller'&&v.answer&&!c.answered){c.answered=true;status('در حال اتصال…');await c.pc.setRemoteDescription({type:'answer',sdp:v.answer})}
    if(Array.isArray(v.ice)){for(const cand of v.ice){try{await c.pc.addIceCandidate(cand)}catch{}}c.since=v.ice_next}}
  }catch{}
  if(current===c&&!c.done)c.timer=setTimeout(loop,c.live?2000:700)}
 async function start(person,video=false){
  if(!enabled){toast('تماس پس از به‌روزرسانی سرور فعال می‌شود.');return}
  if(current){toast('یک تماس دیگر در جریان است.');return}
  const c={person,video,role:'caller',muted:false,camOff:false,facing:'user'};current=c;c.el=overlay(c);bind(c);bar('active');status(video?'تماس تصویری…':'در حال زنگ…');
  try{c.stream=await media(video);showLocal(c);const pc=await peer(c);await pc.setLocalDescription(await pc.createOffer());await gathered(pc);
   if(current!==c)return;const r=await api('call_start',{target:person.id,video,sdp:pc.localDescription.sdp});
   if(!r?.ok){finish('error',false,r?.message||'برقراری تماس ممکن نشد.');return}
   c.id=r.call.id;c.out=[];tone('out');loop()}
  catch(e){finish('error',false,e?.name==='NotAllowedError'?'اجازهٔ میکروفون یا دوربین داده نشده است.':'برقراری تماس ممکن نشد.')}}
 async function accept(c){stopTone();bar('active');status('در حال اتصال…');
  try{c.stream=await media(c.video);showLocal(c);const pc=await peer(c);await pc.setRemoteDescription({type:'offer',sdp:c.offer});await pc.setLocalDescription(await pc.createAnswer());await gathered(pc,1200);
   const r=await api('call_answer',{id:c.id,sdp:pc.localDescription.sdp});if(!r?.ok){finish('error',false,r?.message);return}c.out=[];loop()}
  catch(e){finish('error',true,e?.name==='NotAllowedError'?'اجازهٔ میکروفون یا دوربین داده نشده است.':'پاسخ به تماس ممکن نشد.')}}
 function finish(reason,tell=true,message=''){const c=current;if(!c||c.done)return;c.done=true;stopTone();clearTimeout(c.timer);clearInterval(c.clock);
  if(tell&&c.id)api('call_end',{id:c.id}).catch(()=>{});
  try{c.pc?.close()}catch{}for(const t of c.stream?.getTracks()||[])try{t.stop()}catch{}
  status(message||(reason==='declined'?'تماس رد شد':reason==='failed'?'اتصال قطع شد':'تماس پایان یافت'));c.el.classList.add('ending');
  setTimeout(()=>{c.el.remove();if(current===c)current=null;onEnded()},message?1600:900)}
 function bind(c){c.el.addEventListener('click',e=>{const b=e.target.closest('[data-k]');if(!b)return;const k=b.dataset.k;haptic();
  if(k==='end'||k==='decline')return finish(k,true);
  if(k==='accept')return void accept(c);
  if(k==='mute'){c.muted=!c.muted;for(const t of c.stream?.getAudioTracks()||[])t.enabled=!c.muted;bar('active');return}
  if(k==='cam'){c.camOff=!c.camOff;for(const t of c.stream?.getVideoTracks()||[])t.enabled=!c.camOff;bar('active');return}
  if(k==='flip')return void flip(c)})}
 async function flip(c){try{c.facing=c.facing==='user'?'environment':'user';const s=await navigator.mediaDevices.getUserMedia({video:{facingMode:c.facing}});const track=s.getVideoTracks()[0];const sender=c.pc.getSenders().find(x=>x.track?.kind==='video');await sender?.replaceTrack(track);for(const t of c.stream.getVideoTracks()){c.stream.removeTrack(t);t.stop()}c.stream.addTrack(track);showLocal(c)}catch{toast('چرخش دوربین ممکن نشد.')}}
 async function watch(){if(disposed)return;clearTimeout(incomingTimer);
  if(enabled&&!document.hidden&&getUid()&&!current){try{const r=await api('call_poll',{});const v=r?.incoming;if(v&&!current&&v.id!==lastIncoming){lastIncoming=v.id;const c={id:v.id,person:v.person,video:v.video,role:'callee',offer:v.offer,muted:false,camOff:false,facing:'user'};current=c;c.el=overlay(c);bind(c);bar('incoming');status(v.video?'تماس تصویری ورودی':'تماس صوتی ورودی');tone('in');c.out=[];
    c.watch=setInterval(async()=>{if(current!==c||c.pc){clearInterval(c.watch);return}try{const p=await api('call_poll',{id:c.id});if(p?.call?.state==='ended'){clearInterval(c.watch);finish('missed',false,'تماس از دست رفت')}}catch{}},1500)}}catch{}}
  incomingTimer=setTimeout(watch,current?6000:3500)}
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)watch()});
 return {start,enable(on=true){const was=enabled;enabled=on;if(on&&!was)watch()},get active(){return !!current},dispose(){disposed=true;clearTimeout(incomingTimer);if(current)finish('ended',true)}};
}
