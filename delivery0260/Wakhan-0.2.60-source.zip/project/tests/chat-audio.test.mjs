import test from 'node:test';
import assert from 'node:assert/strict';
import {createVoiceRecording,microphoneError} from '../src/chat-audio.mjs';

function fixture({permission,empty=false,rejectMp4=false,rejectBitrateAtStart=false,defaultMime='audio/mp4',chunkType='audio/mp4',onState,audioSession,hasExternalCapture}={}){
 let stopped=0,clock=0,next=0;const timers=new Map(),states=[],results=[],errors=[];
 const stream={getTracks:()=>[{stop(){stopped++;}}]};
 class Recorder{
  static current;static isTypeSupported(type){return ['audio/mp4','audio/webm;codecs=opus'].includes(type);}
  constructor(input,options){if(rejectMp4&&options.mimeType==='audio/mp4')throw Error('codec rejected');assert.equal(input,stream);this.options=options;this.mimeType=options.mimeType||defaultMime;this.state='inactive';Recorder.current=this;}
  start(timeslice){assert.equal(timeslice,250);if(rejectBitrateAtStart&&this.options.audioBitsPerSecond)throw Object.assign(Error('encoder configuration rejected'),{name:'UnknownError'});this.state='recording';}
  stop(){this.state='inactive';queueMicrotask(()=>{if(!empty)this.ondataavailable?.({data:new Blob(['captured audio'],{type:chunkType})});this.onstop?.();});}
 }
 const voice=createVoiceRecording({audioSession,hasExternalCapture,mediaDevices:{getUserMedia:permission||(()=>Promise.resolve(stream))},Recorder,onState:(...args)=>{states.push(args);onState?.(...args);},onResult:result=>results.push(result),onError:e=>errors.push(e),now:()=>clock,setTimer:fn=>{timers.set(++next,fn);return next;},clearTimer:id=>timers.delete(id),setTicker:fn=>{timers.set(++next,fn);return next;},clearTicker:id=>timers.delete(id)});
 return {voice,stream,Recorder,states,results,errors,timers,get stopped(){return stopped;},advance:ms=>clock+=ms};
}
const settled=()=>new Promise(resolve=>setImmediate(resolve));

test('one start captures MP4, sends the actual blob and releases the microphone',async()=>{
 const f=fixture();assert(await f.voice.start());assert.equal(await f.voice.start(),false);
 assert.equal(f.Recorder.current.options.mimeType,'audio/mp4');assert.equal(f.Recorder.current.options.audioBitsPerSecond,64_000);
 f.advance(5300);f.voice.stop(true);await settled();
 assert.equal(f.results.length,1);assert.equal(f.results[0].blob.type,'audio/mp4');assert.equal(await f.results[0].blob.text(),'captured audio');assert.equal(f.results[0].seconds,5);
 assert.equal(f.stopped,1);assert.equal(f.timers.size,0);assert.equal(f.voice.recording,false);assert.equal(f.states.at(-1)[0],'idle');
});
test('denied microphone permission produces a specific Dari error',async()=>{
 const f=fixture({permission:()=>Promise.reject({name:'NotAllowedError'})});assert.equal(await f.voice.start(),false);
 assert.equal(f.errors.length,1);assert.match(f.errors[0].message,/اجازه.*مایک/);assert.doesNotMatch(f.errors[0].message,/سرور/);assert.equal(f.voice.starting,false);
});
test('closing during permission request releases a late stream and never starts recording',async()=>{
 let grant;const f=fixture({permission:()=>new Promise(resolve=>grant=resolve)});const starting=f.voice.start();assert(f.voice.starting);
 f.voice.stop(false);grant(f.stream);assert.equal(await starting,false);await settled();
 assert.equal(f.stopped,1);assert.equal(f.Recorder.current,undefined);assert.equal(f.results.length,0);assert.equal(f.errors.length,0);assert.equal(f.timers.size,0);
});
test('cancel is idempotent and never uploads discarded audio',async()=>{
 const f=fixture();await f.voice.start();f.voice.stop(false);f.voice.stop(true);await settled();f.voice.stop(true);
 assert.equal(f.results.length,0);assert.equal(f.stopped,1);assert.equal(f.timers.size,0);
});
test('a rejected MP4 constructor falls back to another supported recorder',async()=>{
 const f=fixture({rejectMp4:true,chunkType:'audio/webm;codecs=opus'});assert(await f.voice.start());
 assert.equal(f.Recorder.current.options.mimeType,'audio/webm;codecs=opus');f.voice.stop(true);await settled();assert.equal(f.results[0].blob.type,'audio/webm');
});
test('recorder hardware failure releases tracks and cannot send a partial message',async()=>{
 const f=fixture();await f.voice.start();f.Recorder.current.onerror({error:{name:'NotReadableError'}});await settled();
 assert.equal(f.results.length,0);assert.equal(f.errors.length,1);assert.match(f.errors[0].message,/مایک مصروف/);assert.equal(f.stopped,1);assert.equal(f.timers.size,0);
});
test('an empty capture reports that no sound was recorded',async()=>{
 const f=fixture({empty:true});await f.voice.start();f.voice.stop(true);await settled();assert.equal(f.results.length,0);assert.match(f.errors[0].message,/صدایی ثبت نشد/);
});
test('a browser chunk without a type retains the actual recorder format',async()=>{
 const f=fixture({chunkType:''});await f.voice.start();f.voice.stop(true);await settled();assert.equal(f.results[0].blob.type,'audio/mp4');
});
test('the size threshold stops recording before the existing server limit',async()=>{
 const f=fixture();await f.voice.start();f.Recorder.current.ondataavailable({data:new Blob([new Uint8Array(1_350_000)],{type:'audio/mp4'})});await settled();
 assert.equal(f.results.length,1);assert(f.results[0].blob.size<1_500_000);assert.equal(f.stopped,1);
});
test('upload errors reach the UI instead of becoming unhandled promises',async()=>{
 const errors=[];const f=fixture();await f.voice.start();f.voice.stop(false);await settled();
 const voice=createVoiceRecording({mediaDevices:{getUserMedia:async()=>f.stream},Recorder:f.Recorder,onResult:async()=>{throw Error('فرستادن پیام صوتی ناکام شد.');},onError:error=>errors.push(error)});
 await voice.start();voice.stop(true);await settled();assert.equal(errors.length,1);assert.match(errors[0].message,/فرستادن پیام صوتی/);
});
test('unknown device exceptions also receive a microphone-specific Dari explanation',()=>{
 assert.match(microphoneError(Error('opaque device error')).message,/مایک/);
});
test('an unavailable device returns to idle so the interface cannot remain stuck',async()=>{
 const states=[],errors=[];const voice=createVoiceRecording({mediaDevices:{},Recorder:null,onState:s=>states.push(s),onError:e=>errors.push(e)});
 assert.equal(await voice.start(),false);assert.deepEqual(states,['idle']);assert.equal(errors.length,1);assert.equal(voice.starting,false);assert.equal(voice.recording,false);
});
test('an encoder rejected at start retries MP4 without the optional bitrate',async()=>{
 const f=fixture({rejectBitrateAtStart:true});assert(await f.voice.start());assert.equal(f.Recorder.current.options.mimeType,'audio/mp4');assert.equal(f.Recorder.current.options.audioBitsPerSecond,undefined);assert.equal(f.errors.length,0);assert.equal(f.stopped,0);f.voice.stop(true);await settled();assert.equal(f.results.length,1);assert.equal(f.results[0].blob.type,'audio/mp4');assert.equal(f.stopped,1);
});
test('a rendering failure is not mislabeled as missing microphone permission',async()=>{
 const f=fixture({onState:stage=>{if(stage==='recording')throw TypeError('UI rendering failure');}});assert.equal(await f.voice.start(),false);assert.equal(f.errors[0].captureStage,'ui');assert.match(f.errors[0].message,/نمایش نوار ضبط/);assert.doesNotMatch(f.errors[0].message,/اجازه/);assert.equal(f.stopped,1);assert.equal(f.timers.size,0);
});

test('Safari playback-only AudioSession is changed before microphone access and restored after stop',async()=>{
 const audioSession={type:'playback'};let f;f=fixture({audioSession,permission:async()=>{assert.equal(audioSession.type,'play-and-record');return f.stream;}});
 assert(await f.voice.start());assert.equal(audioSession.type,'play-and-record');f.advance(1900);f.voice.stop(true);await settled();assert.equal(f.results.length,1);assert.equal(audioSession.type,'playback');assert.equal(f.errors.length,0);
});
test('permission failure restores the previous audio role and records the actual capture stage',async()=>{
 const audioSession={type:'playback'},f=fixture({audioSession,permission:async()=>{throw Object.assign(Error('denied by device'),{name:'NotAllowedError'});}});assert.equal(await f.voice.start(),false);assert.equal(audioSession.type,'playback');assert.equal(f.errors[0].captureStage,'permission');assert.equal(f.errors[0].captureDetails.audioSessionBefore,'playback');assert.equal(f.errors[0].captureDetails.audioSessionCurrent,'play-and-record');assert.equal(f.errors[0].originalMessage,'denied by device');
});
test('cancelling permission releases the role; its late response cannot undo a newer capture',async()=>{
 const audioSession={type:'playback'};let resolve;const old=fixture({audioSession,permission:()=>new Promise(r=>resolve=r)});const waiting=old.voice.start();old.voice.stop(false);assert.equal(audioSession.type,'playback');const next=fixture({audioSession});assert(await next.voice.start());resolve(old.stream);assert.equal(await waiting,false);assert.equal(audioSession.type,'play-and-record');next.voice.stop(false);await settled();assert.equal(audioSession.type,'playback');
});
test('stopping a chat recording does not switch an active hall microphone to playback',async()=>{
 const audioSession={type:'playback'};let external=false;const f=fixture({audioSession,hasExternalCapture:()=>external});assert(await f.voice.start());external=true;f.voice.stop(false);await settled();assert.equal(audioSession.type,'play-and-record');assert.equal(f.stopped,1);
});
test('a newer playback policy is left alone when the recording releases its role',async()=>{
 const audioSession={type:'auto'},f=fixture({audioSession});assert(await f.voice.start());audioSession.type='ambient';f.voice.stop(false);await settled();assert.equal(audioSession.type,'ambient');
});
