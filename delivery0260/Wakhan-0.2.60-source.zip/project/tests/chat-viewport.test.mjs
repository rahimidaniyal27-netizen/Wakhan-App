import test from 'node:test';
import assert from 'node:assert/strict';
import {chatViewport,installChatViewport} from '../src/chat-viewport.mjs';
test('the visual viewport wins over a stale zero native keyboard overlap',()=>{
 assert.deepEqual(chatViewport({height:844,visual:{height:460,offsetTop:0}}),{height:460,offsetTop:0,fullHeight:844});
});
test('a native keyboard event lifts the composer before visual viewport resizing',()=>{
 assert.equal(chatViewport({height:844,keyboardHeight:370}).height,474);
 assert.equal(chatViewport({height:844,overlap:370,visual:{height:844,offsetTop:0}}).height,474);
});
test('already resized content does not subtract the keyboard twice',()=>{
 assert.equal(chatViewport({height:474,baseline:844,keyboardHeight:370,visual:{height:474,offsetTop:0}}).height,474);
});
test('a panned viewport keeps its bottom above the keyboard',()=>{
 const v=chatViewport({height:844,baseline:844,overlap:370,visual:{height:400,offsetTop:72}});
 assert.equal(v.offsetTop,72);assert.equal(v.height,400);assert(v.offsetTop+v.height<=474);
});
test('bridge show/hide events recover full height and release their subscriptions',async()=>{
 const native={},listeners=new Map();let removed=0,focused=false;
 const target={addEventListener:(name,fn)=>listeners.set(name,fn),removeEventListener:(name)=>listeners.delete(name)};
 const win={...target,innerHeight:844,innerWidth:390,visualViewport:{...target,height:844,offsetTop:0},requestAnimationFrame:fn=>fn()};
 const doc={...target,activeElement:{matches:()=>focused}},provider=installChatViewport({win,doc,keyboard:{addListener:async(name,fn)=>{native[name]=fn;return {remove:async()=>{removed++;}};}}});
 await new Promise(resolve=>setImmediate(resolve));focused=true;native.keyboardWillShow({keyboardHeight:370});assert.equal(provider.current().height,474);
 win.innerHeight=474;win.visualViewport.height=474;native.keyboardDidShow({keyboardHeight:370});assert.equal(provider.current().height,474);
 native.keyboardWillHide();win.innerHeight=844;win.visualViewport.height=844;focused=false;native.keyboardDidHide();assert.equal(provider.current().height,844);provider.dispose();assert.equal(removed,4);
});
test('native overlap measured inside a safe-area webview wins over the screen-wide keyboard height',()=>{
 const v=chatViewport({height:759,baseline:759,overlap:257,keyboardHeight:291,nativeObserved:true,visual:{height:759,offsetTop:0}});
 assert.equal(v.height,502); // 34px of the keyboard is outside this webview's safe bottom.
 assert.equal(chatViewport({height:759,baseline:759,overlap:0,keyboardHeight:291,nativeObserved:true,visual:{height:502,offsetTop:0}}).height,759);
});
test('a late Capacitor hide/show cannot overwrite a newer native keyboard frame',async()=>{
 const callbacks={},listeners=new Map(),target={addEventListener:(n,f)=>listeners.set(n,f),removeEventListener:()=>{}};
 const win={...target,innerHeight:759,innerWidth:393,visualViewport:{...target,height:759,offsetTop:0},requestAnimationFrame:f=>f()},doc={...target,activeElement:{matches:()=>true}};
 const p=installChatViewport({win,doc,keyboard:{addListener:async(n,f)=>{callbacks[n]=f;return {remove(){}};}}});await new Promise(r=>setImmediate(r));
 callbacks.keyboardWillShow({keyboardHeight:291});listeners.get('wakhanKeyboardFrame')({detail:{overlap:257}});callbacks.keyboardDidShow({keyboardHeight:291});assert.equal(p.current().height,502);
 listeners.get('wakhanKeyboardFrame')({detail:{overlap:0}});callbacks.keyboardDidShow({keyboardHeight:291});assert.equal(p.current().height,759);p.dispose();
});
