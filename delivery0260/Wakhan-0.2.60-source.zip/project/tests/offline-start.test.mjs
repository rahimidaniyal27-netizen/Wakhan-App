import test from 'node:test';import assert from 'node:assert/strict';import {offlineEligible} from '../src/offline-music.mjs';import {SessionBroker,AuthError} from '../src/session.mjs';
const broker=()=>new SessionBroker({origin:'https://example.test',store:{},fetch:()=>{}});
const session={origin:'https://example.test',key:'wka1.'+'A'.repeat(24)+'.'+'a'.repeat(32),user:{id:1}};
test('cold offline music requires a valid saved account session',()=>{const b=broker();assert.equal(offlineEligible(b),false);b.session=session;assert.equal(offlineEligible(b),true);assert.equal(offlineEligible(b,new AuthError('net')),true)});
test('server auth, policy and malformed response errors cannot open offline music',()=>{const b=broker();b.session=session;for(const e of ['auth','too_young','banned','server_response','server'])assert.equal(offlineEligible(b,new AuthError(e)),false)});
test('a session from another server never exposes this server offline library',()=>{const b=broker();b.session={...session,origin:'https://other.test'};assert.equal(offlineEligible(b),false)});
