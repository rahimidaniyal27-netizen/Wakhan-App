import {test} from 'node:test';import assert from 'node:assert/strict';import {wallpaperHeight} from '../src/chat-layout.mjs';
test('wallpaper uses resting canvas dimensions, independent of keyboard and reply-bar height',()=>{
 const frame={fullHeight:759,headerHeight:60,formHeight:47,footerChrome:13,rootChrome:0};
 assert.equal(wallpaperHeight(frame),639);
 assert.equal(wallpaperHeight({...frame,keyboardHeight:291,replyBarHeight:44}),639);
});
