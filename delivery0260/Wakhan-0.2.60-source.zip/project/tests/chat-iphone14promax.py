"""Linux WebKit simulation of iPhone 14 Pro Max. This is not a physical iOS test."""
import asyncio,base64,hashlib,json,os,uuid
from pathlib import Path
from playwright.async_api import async_playwright
BASE='http://127.0.0.1:8765';OUT=Path('/workspace/wakhan-chat-r16/review')
results=[]
def passed(name):results.append(name);print('PASS',name,flush=True)
async def run():
 source=Path(__file__).resolve().parents[1]/'src';critical=['chat-audio.mjs','chat-profile-layout.mjs','cinema-layout-fix.css','chat2.mjs','chat-approved.css','chat-salon-entry.mjs','chat2.css','chat-glass.css','chat-viewport.mjs','chat-state.mjs','chat-layout.mjs','chat-photo-viewer.mjs'];fingerprints={name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in critical}
 async with async_playwright() as pw:
  browser=await pw.webkit.launch(headless=True)
  options=dict(pw.devices['iPhone 14 Pro Max']);options.pop('default_browser_type',None)
  options.update(viewport={'width':430,'height':839},screen={'width':430,'height':932},locale='fa-AF')
  context=await browser.new_context(**options);page=await context.new_page();page.set_default_timeout(15000)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await context.add_init_script("window.testInputs=[];document.addEventListener('pointerdown',e=>window.testInputs.push({pointerType:e.pointerType,trusted:e.isTrusted}),true);window.WakhanNative={platform:'ios'};document.addEventListener('contextmenu',event=>{if(!event.target.closest?.('input,textarea,[contenteditable=true]'))event.preventDefault();},true);")
  async def post(part,data,uid=1):
   r=await context.request.post(BASE+'/api/app/chat/'+part,headers={'X-Test-Uid':str(uid)},data=data);body=await r.json();assert r.ok and body.get('ok'),body;return body
  async def send(text,uid=1,kind='dm',target=2):return await post('send',dict(kind=kind,target=target,text=text,client_key=uuid.uuid4().hex),uid)
  async def tap(action):await page.locator('[data-action="'+action+'"]').first.tap()
  async def box(selector):return await page.locator(selector).bounding_box()
  async def hold(selector):
   r=await page.locator(selector).bounding_box();await page.mouse.move(r['x']+r['width']/2,r['y']+r['height']/2);await page.mouse.down();await page.wait_for_timeout(420);await page.mouse.up();await page.locator('.wc-message-menu').wait_for()
  async def keyboard(overlap):
   await page.evaluate('''overlap=>{if(overlap){window.keyboardCallbacks.keyboardWillShow({keyboardHeight:overlap+34});window.dispatchEvent(new CustomEvent('wakhanKeyboardFrame',{detail:{overlap,duration:.2}}));window.keyboardCallbacks.keyboardDidShow({keyboardHeight:overlap+34});}else{window.dispatchEvent(new CustomEvent('wakhanKeyboardFrame',{detail:{overlap:0,duration:.2}}));window.keyboardCallbacks.keyboardDidHide();}}''',overlap)
  async def wall():return await page.locator('[data-wallpaper]').evaluate("el=>{const r=el.getBoundingClientRect();return {width:r.width,height:r.height,image:getComputedStyle(el.querySelector('.wc-wallpaper-detail')).backgroundImage};}")
  try:
   await page.goto(BASE+'/?u=1&layout=ios');await page.locator('.wc-inbox-actions').wait_for()
   metrics=await page.evaluate('({width:innerWidth,height:innerHeight,screenWidth:screen.width,screenHeight:screen.height,dpr:devicePixelRatio,touch:navigator.maxTouchPoints,userAgent:navigator.userAgent})')
   assert metrics['width']==430 and metrics['height']==839 and metrics['screenWidth']==430 and metrics['screenHeight']==932 and metrics['dpr']==3 and 'iPhone' in metrics['userAgent'],metrics
   for width in [430,320]:
    await page.set_viewport_size({'width':width,'height':839});bounds=await page.locator('.wc-new').bounding_box();assert bounds['width']>=44 and bounds['height']>=44,bounds
   await page.set_viewport_size({'width':430,'height':839})
   assert (await box('.wc-inbox-actions'))['y']<=12;assert (await box('.wkchat'))['width']==430
   assert await page.locator('[data-search-box]').is_hidden();await tap('toggle-search');assert await page.locator('[data-search-box]').is_visible();tap_audit=await page.evaluate('window.testInputs');assert any(event['trusted'] for event in tap_audit),tap_audit;await tap('toggle-search')
   await page.locator('[data-filter=requests]').tap();assert await page.locator('.wkchat>.wc-header').count()==0
   await page.locator('[data-request^="accept:"]').first.tap();assert await page.locator('.wc-inbox-actions').is_visible()
   await page.locator('[data-filter=all]').tap();await page.screenshot(path=str(OUT/'iphone14promax-inbox.png'))
   passed('WebKit: native 430x839 canvas, compact top toolbar, icon-only search and inline request acceptance')
   original=await send('پیام اصلی آزمون آیفون',uid=2,target=1)
   png=await page.evaluate("""()=>{const c=document.createElement('canvas');c.width=430;c.height=720;const x=c.getContext('2d'),g=x.createLinearGradient(0,0,430,720);g.addColorStop(0,'#684386');g.addColorStop(.5,'#c0a5cf');g.addColorStop(1,'#314e6a');x.fillStyle=g;x.fillRect(0,0,430,720);for(let i=10;i<720;i+=40){x.fillStyle='#fff5';x.fillRect(8,i,414,2);}return c.toDataURL('image/png');}""")
   image=await post('image',{'data':png});await post('wallpaper',dict(target=2,mode='personal',image=image['id'],darkness=10,x=50,y=50,client_key=uuid.uuid4().hex))
   await page.evaluate("()=>window.chat.open('dm',2)");await page.locator('[data-wallpaper].wc-wall-active').wait_for();before=await wall()
   selector=f'article[data-mid="{original["id"]}"] .wc-bubble'
   r=await page.locator(selector).bounding_box();x=r['x']+r['width']*.7;y=r['y']+r['height']/2
   await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x-70,y,steps=6);await page.mouse.up()
   await page.locator('.wc-context').wait_for();assert 'پیام اصلی آزمون آیفون' in await page.locator('.wc-context').inner_text()
   assert await page.locator('textarea').evaluate('el=>document.activeElement===el')
   for overlap in [285,337,0,285]:
    await keyboard(overlap);await page.wait_for_timeout(60)
    root=await box('.wkchat');footer=await box('.wc-compose');field=await box('textarea');reply=await box('.wc-context')
    assert abs(root['height']-(839-overlap))<1,(overlap,root)
    assert abs(footer['y']+footer['height']-(839-overlap))<1
    assert field['y']+field['height']<=839-overlap+1;assert reply['y']+reply['height']<=field['y']+1
    assert await wall()==before
   await page.locator('textarea').fill('پاسخ آیفون\nبا چند سطر\nسطر سوم');assert (await wall())==before
   await page.evaluate('window.savedReplyElement=document.querySelector(".wc-context")');await page.wait_for_timeout(2700)
   assert await page.evaluate('window.savedReplyElement===document.querySelector(".wc-context")')
   await page.screenshot(path=str(OUT/'iphone14promax-reply-keyboard.png'))
   passed('WebKit: swipe reply, 285/337px native keyboard transitions, multiline draft and stable wallpaper/quote through polling')
   await tap('send');await page.wait_for_function('!document.querySelector("article[data-pending]")')
   history=await (await context.request.get(BASE+'/api/app/chat/history?kind=dm&target=2',headers={'X-Test-Uid':'1'})).json()
   saved=next(m for m in history['messages'] if m['text'].startswith('پاسخ آیفون'));assert saved['reply']['id']==original['id']
   await keyboard(0);await hold(selector);await page.locator('.wc-message-menu [data-action=reply]').tap();await page.locator('.wc-context').wait_for();await tap('cancel-context');assert await page.locator('.wc-context').count()==0
   passed('WebKit: actual send/history quote ID, long-press menu reply and cancellation')
   own=await send('پیام قابل ویرایش');await page.wait_for_selector(f'article[data-mid="{own["id"]}"]')
   await hold(f'article[data-mid="{own["id"]}"] .wc-bubble');await tap('edit');await page.locator('textarea').fill('پیام ویرایش‌شده');await tap('send')
   await page.wait_for_function('(id)=>document.querySelector(`article[data-mid="${id}"]`)?.textContent.includes("پیام ویرایش‌شده")',arg=own['id'])
   await hold(f'article[data-mid="{own["id"]}"] .wc-bubble');await tap('delete');await tap('all');await page.wait_for_selector(f'article[data-mid="{own["id"]}"]',state='detached')
   passed('WebKit: edit and two-sided deletion use actual API routes and keep message identity')
   # The native file chooser opens directly; the application adds no extra media dialog.
   async with page.expect_file_chooser() as chooser:await tap('attach')
   picker=await chooser.value;await picker.set_files({'name':'test-photo.png','mimeType':'image/png','buffer':base64.b64decode(png.split(',')[1])})
   photo=page.locator('article.mine .wc-photo').last;await photo.wait_for(state='visible')
   host=photo.locator('xpath=ancestor::div[contains(@class,"wc-bubble")]');style=await host.evaluate("el=>({padding:getComputedStyle(el).padding,border:getComputedStyle(el).borderWidth,caption:el.querySelector('.wc-caption')?.textContent})")
   assert style=={'padding':'0px','border':'0px','caption':None} or style=={'padding':'0px','border':'0px'}
   await photo.tap();await page.locator('.wc-viewer-image').wait_for(state='visible');await page.locator('[data-photo-action=in]').tap();assert '150' in await page.locator('[data-photo-scale]').inner_text()
   await page.locator('[data-photo-action=reset]').tap();assert '100' in await page.locator('[data-photo-scale]').inner_text()
   allowed=await page.locator('.wc-viewer-image').evaluate("el=>{const e=new MouseEvent('contextmenu',{bubbles:true,cancelable:true});el.dispatchEvent(e);return !e.defaultPrevented;}");assert allowed
   await page.locator('[data-photo-action=save]').tap();await page.locator('[data-photo-save-hint]').wait_for(state='visible');await page.locator('[data-photo-action=close]').tap()
   passed('WebKit: direct photo chooser, frameless image, fullscreen zoom and iPhone save-menu fallback')
   # The viewer itself must show a revoked-file error above its own overlay.
   other=await (await context.request.post(BASE+'/api/app/dm/media',headers={'X-Test-Uid':'2'},data={'kind':'image','data':png,'dur':0})).json();assert other['ok']
   media_message=await send('عکس ⟦m:'+other['id']+'⟧',uid=2,target=1)
   received=page.locator('[data-media-open="'+other['id']+'"]');await received.wait_for(state='visible');await received.tap();await page.locator('.wc-viewer-image').wait_for(state='visible')
   await post('message',dict(kind='dm',target=1,id=media_message['id'],action='delete_all',client_key=uuid.uuid4().hex),uid=2)
   await page.locator('[data-photo-action=save]').tap();await page.locator('[data-photo-error]').wait_for(state='visible');assert await page.locator('.wc-photo-viewer').is_visible();await page.locator('[data-photo-action=close]').tap()
   passed('WebKit: deleted media cannot be exported from cache and the error is visible inside the photo viewer')
   gid=(await post('create_group',dict(name='گروپ آزمون آیفون',members=[2,3],client_key=uuid.uuid4().hex)))['id']
   await send('پیام عضو دوم',uid=2,kind='group',target=gid);await send('پیام خودم',kind='group',target=gid)
   await page.evaluate('id=>window.chat.open("group",id)',gid);await page.locator('.wc-message-author').first.wait_for();assert await page.locator('.wc-message-author').count()==2;assert await page.locator('article.mine .wc-sender').count()==1
   await page.locator('.wc-message-author[data-person="2"]').tap();await page.locator('.wc-profile').wait_for();await tap('back');await page.locator('.wc-message-author').first.wait_for()
   await tap('back');await page.locator('.wc-inbox-actions').wait_for();await tap('settings');await page.locator('.wc-settings-row').first.wait_for();assert (await box('.wkchat'))['width']==430
   await page.set_viewport_size({'width':320,'height':560});assert await page.locator('.wkchat').evaluate('el=>el.scrollWidth<=el.clientWidth+1');await page.set_viewport_size({'width':839,'height':430});assert await page.locator('.wkchat').evaluate('el=>el.scrollWidth<=el.clientWidth+1')
   passed('WebKit: real group member names/avatars/profile navigation, settings and narrow/landscape layout')
   await page.set_viewport_size({'width':430,'height':839});await page.goto(BASE+'/?u=1&layout=ios&navigation=1');await page.locator('.wc-inbox-actions').wait_for()
   await page.evaluate('window.go("c")');await page.locator('[data-cinema] video').wait_for();await page.evaluate('window.keptCinemaVideo=document.querySelector("[data-cinema] video");window.keptCinemaVideo.wakhanTestMarker=43;window.go("d")');await page.locator('.wc-inbox-actions').wait_for();assert await page.locator('[data-cinema] video').is_hidden()
   await page.evaluate('window.chat.open("dm",2)');await page.locator('textarea').wait_for();await keyboard(285);await page.evaluate('window.go("m")');await page.locator('[data-me]').wait_for();assert await page.locator('.wkchat').is_hidden();assert await page.locator('body.wkchat-inbox,body.wkchat-thread').count()==0
   await keyboard(0);await page.evaluate('window.go("c")');assert await page.evaluate('document.querySelector("[data-cinema] video")===window.keptCinemaVideo&&window.keptCinemaVideo.wakhanTestMarker===43');await page.evaluate('window.go("d")');await page.locator('textarea').wait_for();assert (await box('.wkchat'))['height']==839
   passed('WebKit: actual page cache retains the same cinema video node; Me is unobstructed; chat recovers height after keyboard closes in another tab')
   assert errors==[],errors
   assert fingerprints=={name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in critical},'Source changed during browser checks'
   report={'source_sha256':fingerprints,'device':'iPhone 14 Pro Max profile','engine':'Linux WebKit/WPE via Python Playwright','screen':[430,932],'native_viewport':[430,839],'device_scale_factor':3,'physical_ios_device':False,'measured_profile':metrics,'trusted_tap_audit':tap_audit,'touch_capability_note':'Linux WebKit reports maxTouchPoints=0; driver tap events are verified separately, not physical iOS touch hardware','keyboard_events':'simulated native overlap and Capacitor callbacks','passed':results,'unverified':['physical iPhone keyboard','hardware microphone permission/recording','actual Photos save menu','real cinema playback on iPhone']}
   (OUT/'IPHONE14PROMAX_TEST_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('WEBKIT_IPHONE14PROMAX_SIMULATION_PASS',flush=True)
  except BaseException:
   await page.screenshot(path=str(OUT/'iphone14promax-failure.png'));raise
  finally:await browser.close()
asyncio.run(run())
