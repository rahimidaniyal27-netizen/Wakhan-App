"""Real chat UI and original salon CSS: unified canvas and stable tab bounds."""
from pathlib import Path
import asyncio,hashlib,json,re
from playwright.async_api import async_playwright
B=Path('/workspace/wakhan-chat-r16');SRC=B/'source/android-project/src';OUT=B/'review'
async def main():
 names=['chat2.mjs','chat-approved.css','chat-profile-layout.mjs','cinema-layout-fix.css'];hashes={n:hashlib.sha256((SRC/n).read_bytes()).hexdigest() for n in names};passed=[]
 async with async_playwright() as pw:
  browser=await pw.webkit.launch(headless=True);opts=dict(pw.devices['iPhone 14 Pro Max']);opts.pop('default_browser_type',None);opts.update(viewport={'width':430,'height':932},locale='fa-AF');context=await browser.new_context(**opts);page=await context.new_page();page.set_default_timeout(12000)
  await page.goto('http://127.0.0.1:8765/?u=1&layout=ios-full');await page.locator('.wc-inbox-actions').wait_for();await page.evaluate("window.chat.open('dm',2)");await page.locator('textarea').wait_for();assert await page.locator('[data-action=emoji]').count()==0
  async def unified():
   m=await page.locator('.wkchat').evaluate('''n=>{const h=n.querySelector('.wc-header');return {image:getComputedStyle(n).backgroundImage,header:getComputedStyle(h).backgroundColor,filter:getComputedStyle(h).backdropFilter,top:h.getBoundingClientRect().top,width:n.scrollWidth,client:n.clientWidth}}''');assert m['image']=='none' and m['header']=='rgba(0, 0, 0, 0)' and m['filter']=='none' and m['width']<=m['client'] and m['top']>=59,m
  await unified();await page.locator('.wc-header [data-action=profile]').tap();await page.locator('.wc-salon-face').wait_for()
  # A visible image must pass through the former header/body boundary, not just its aura.
  await page.locator('.wc-salon-face>.wc-avatar').evaluate("n=>{const i=new Image();i.src='data:image/svg+xml,'+encodeURIComponent('<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"100\" height=\"100\"><rect width=\"100\" height=\"100\" fill=\"rgb(35,211,159)\"/></svg>');n.replaceChildren(i)}")
  await page.wait_for_function("document.querySelector('.wc-salon-face img').complete")
  assert await page.locator('.wc-ambient-layer,.wc-ambient-copy').count()==0
  root_height=(await page.locator('.wkchat').bounding_box())['height'];scroller=page.locator('.wc-body');initial=await scroller.bounding_box();samples=[]
  from PIL import Image
  import io
  for amount in [30,60,90,140,0]:
   await scroller.evaluate('(n,y)=>n.scrollTop=y',amount)
   await page.wait_for_function('(y)=>Math.abs(document.querySelector(".wc-body").scrollTop-y)<1',arg=amount)
   face=await page.locator('.wc-salon-face>.wc-avatar').bounding_box();header=await page.locator('.wc-profile-header').bounding_box();assert header['y']>=59 and abs(header['y']-64)<1,header
   assert (await page.locator('.wkchat').bounding_box())['height']==root_height
   # Sample a point inside the real portrait, including above the sticky navigation's bottom.
   x=face['x']+face['width']/2;y=max(initial['y']+7,face['y']+12)
   shot=Image.open(io.BytesIO(await page.screenshot()));ratio=shot.width/430;color=shot.getpixel((round(x*ratio),round(y*ratio)))[:3]
   assert max(abs(a-b) for a,b in zip(color,(35,211,159)))<4,(amount,face,header,color)
   if amount==60:
    assert y<header['y']+header['height'],(y,header)
    await page.screenshot(path=str(OUT/'r16-profile-scrolled.png'))
   samples.append(dict(scroll=amount,face=face,header=header,pixel=color))
  profile_samples=samples;await page.screenshot(path=str(OUT/'r16-unified-profile.png'));passed.append('The actual portrait remains visible while scrolling through the former header seam, with one original aura and no duplicated ambient layer')
  await page.locator('[data-action=back]').tap();await page.locator('textarea').wait_for();await unified();await page.evaluate('window.chat.inbox()');await page.locator('[data-action=settings]').tap();await page.locator('.wc-header').wait_for();await unified();passed.append('Back remains reachable during profile scrolling; thread/settings retain their safe areas and transparent canvas; emoji stays removed')
  # Use the exact historical cinema stylesheet rather than a replacement approximation.
  shell=json.loads((SRC.parent/'public/wakhan-shell.json').read_text());program=next(p['code'] for p in shell['programs'] if p['id']=='sln3.js');css=re.search(r'const css=`([\s\S]*?)`;',program).group(1);assert '${' not in css
  await page.close();page=await context.new_page();await page.set_content('<!doctype html><html dir="rtl"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0}#view{padding:0 16px}*{box-sizing:border-box}</style><body class="sl-on"><div id="view"><section data-wk-page-active><main class="sl"><div class="sl-body"><div style="height:400px;background:#38224f">اصل صفحهٔ سالون</div></div></main></section></div>');await page.add_style_tag(content=css)
  async def bounds():return await page.locator('.sl-body').evaluate('n=>({x:n.getBoundingClientRect().x,w:n.getBoundingClientRect().width,transform:getComputedStyle(n).transform,animation:getComputedStyle(n).animationName,overflow:document.documentElement.scrollWidth,viewport:innerWidth})')
  rest=await bounds();await page.locator('.sl-body').evaluate("n=>{n.classList.add('in-f');const a=n.getAnimations()[0];a.pause();a.currentTime=0}");broken=await bounds();assert abs(broken['x']-rest['x'])>10,(broken,rest)
  await page.add_style_tag(content=(SRC/'cinema-layout-fix.css').read_text());samples=[]
  for direction in ['rtl','ltr']:
   await page.locator('html').evaluate('(n,d)=>n.dir=d',direction)
   for cls in ['in-f','in-b']:
    await page.locator('.sl-body').evaluate('(n,c)=>{n.className="sl-body "+c}',cls)
    for ms in [0,50,150,300,380]:
     await page.locator('.sl-body').evaluate('(n,t)=>{const a=n.getAnimations()[0];a.pause();a.currentTime=t}',ms);m=await bounds();assert abs(m['x']-rest['x'])<1 and abs(m['w']-rest['w'])<1 and m['overflow']<=m['viewport'],(direction,cls,ms,m,rest);assert m['animation'] in ['slinF','slinB'];samples.append(dict(direction=direction,css_class=cls,ms=ms,**m))
  await page.screenshot(path=str(OUT/'r15-cinema-stable-tabs.png'));passed.append('Original cinema tab animation reproduces the gap; scoped override keeps body bounds fixed at 20 samples in RTL/LTR while retaining fade/blur')
  await page.locator('body').evaluate("n=>n.classList.remove('sl-on')");await page.locator('.sl-body').evaluate("n=>{n.className='sl-body in-f';const a=n.getAnimations()[0];a.pause();a.currentTime=0}");outside=await bounds();assert abs(outside['x']-rest['x'])>10;passed.append('Cinema correction is inactive outside the active salon lobby; the tab-gap override does not leak to other pages')
  for n,d in hashes.items():assert hashlib.sha256((SRC/n).read_bytes()).hexdigest()==d
  (OUT/'CANVAS_CINEMA_TEST_REPORT.json').write_text(json.dumps(dict(source_sha256=hashes,passed=passed,original_cinema_css_sha256=hashlib.sha256(css.encode()).hexdigest(),before=broken,rest=rest,samples=samples,profile_samples=profile_samples,physical_device_tested=False),ensure_ascii=False,indent=2));await browser.close()
 for value in passed:print('PASS',value,flush=True)
asyncio.run(main())
