"""Regression of the reported r12 screenshots; browser simulation, not physical iOS."""
import asyncio,base64,hashlib,json,uuid
from pathlib import Path
from playwright.async_api import async_playwright
BASE='http://127.0.0.1:8765';OUT=Path('/workspace/wakhan-chat-r16/review');results=[]
async def run():
 src=Path(__file__).resolve().parents[1]/'src';names=['chat2.mjs','chat-glass.css','chat-viewport.mjs','chat-layout.mjs'];hashes={n:hashlib.sha256((src/n).read_bytes()).hexdigest() for n in names}
 async with async_playwright() as pw:
  browser=await pw.webkit.launch(headless=True);opts=dict(pw.devices['iPhone 14 Pro Max']);opts.pop('default_browser_type',None);opts.update(viewport={'width':430,'height':932},screen={'width':430,'height':932},locale='fa-AF');context=await browser.new_context(**opts);page=await context.new_page();page.set_default_timeout(12000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  async def post(part,data,uid=1):
   r=await context.request.post(BASE+'/api/app/chat/'+part,headers={'X-Test-Uid':str(uid)},data=data);v=await r.json();assert v.get('ok'),v;return v
  async def send(text,uid=1):return await post('send',dict(kind='dm',target=2 if uid==1 else 1,text=text,client_key=uuid.uuid4().hex),uid)
  async def metrics():return await page.evaluate('''()=>{const r=document.querySelector('.wkchat'),a=document.querySelector('.wc-scroll');return {width:r.getBoundingClientRect().width,height:r.getBoundingClientRect().height,docWidth:document.documentElement.scrollWidth,scrollY:scrollY,scale:visualViewport.scale,scroll:a?.scrollTop}}''')
  async def kb(n):await page.evaluate('(overlap)=>window.dispatchEvent(new CustomEvent("wakhanKeyboardFrame",{detail:{overlap}}))',n);await page.wait_for_timeout(80)
  def passed(s):results.append(s);print('PASS',s,flush=True)
  await page.goto(BASE+'/?u=1&layout=ios-full&navigation=1');await page.locator('.wc-inbox-actions').wait_for();r=await page.locator('.wc-inbox-actions').bounding_box();assert 59<=r['y']<=71,r
  for a in ['new','settings','toggle-search']:
   n=page.locator(f'.wc-inbox-actions [data-action="{a}"]');assert (await n.inner_text()).strip()=='';assert await n.get_attribute('aria-label');box=await n.bounding_box();assert box['width']>=44 and box['height']>=44
  assert await page.locator('.wc-list-heading').count()==0
  await page.screenshot(path=str(OUT/'r13-fullscreen-inbox.png'));passed('Fullscreen iPhone safe area survives native marker; compact labelled-accessible icon controls stay below the status bar')
  original=await send('پیام خودم برای پاسخ\n'+('این پیام طولانی است. '*30));await send('پیام دریافتی',2)
  image=await page.evaluate('''()=>{const c=document.createElement('canvas');c.width=960;c.height=540;const x=c.getContext('2d');let g=x.createLinearGradient(0,0,960,540);g.addColorStop(0,'#1c1533');g.addColorStop(.5,'#7e5ba8');g.addColorStop(1,'#35234f');x.fillStyle=g;x.fillRect(0,0,960,540);x.fillStyle='#cbb4ec';x.beginPath();x.arc(680,160,90,0,Math.PI*2);x.fill();return c.toDataURL('image/png')}''');w=await post('image',{'data':image});await post('wallpaper',dict(target=2,mode='personal',image=w['id'],darkness=10,x=50,y=50,client_key=uuid.uuid4().hex))
  await page.evaluate("window.chat.open('dm',2)");await page.locator('[data-wallpaper].wc-wall-active').wait_for();head=await page.locator('.wc-header').bounding_box();assert abs(head['y']-59)<1,head
  assert float(await page.locator('textarea').evaluate('n=>parseFloat(getComputedStyle(n).fontSize)'))>=16
  wall=await page.locator('.wc-wallpaper-detail').evaluate('n=>({h:n.getBoundingClientRect().height,w:n.getBoundingClientRect().width,size:getComputedStyle(n).backgroundSize,image:getComputedStyle(n).backgroundImage})');assert wall['size']=='cover';assert await page.locator('.wc-wallpaper-fill').count()==0
  s=f'article[data-mid="{original["id"]}"] .wc-bubble';await page.locator(s).scroll_into_view_if_needed();r=await page.locator(s).bounding_box();x=r['x']+min(90,r['width']*.8);y=max(head['y']+head['height']+20,min(r['y']+r['height']/2,700));await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x-65,y,steps=7);await page.mouse.up();await page.locator('.wc-context').wait_for()
  assert 'شما' in await page.locator('.wc-context').inner_text()
  for n in [337,285,0,337,0]:
   await kb(n);m=await metrics();assert m['width']==430 and abs(m['height']-(932-n))<1 and m['docWidth']<=430 and m['scrollY']==0 and m['scale']==1,m
   reply=await page.locator('.wc-context').bounding_box();assert reply['height']<=49
   now=await page.locator('.wc-wallpaper-detail').evaluate('n=>({h:n.getBoundingClientRect().height,w:n.getBoundingClientRect().width,size:getComputedStyle(n).backgroundSize,image:getComputedStyle(n).backgroundImage})');assert now==wall,(now,wall)
   stage=await page.locator('.wc-thread-stage').bounding_box();assert now['h']>=stage['height']-1
  passed('Own-message left swipe keeps page width/scale fixed; long quote stays 49px; repeated keyboard frames keep the same wallpaper without a bottom band')
  await page.locator('textarea').fill('پاسخ به پیام خودم');await page.locator('[data-action=send]').tap();await page.wait_for_function('!document.querySelector("article[data-pending]")');history=await (await context.request.get(BASE+'/api/app/chat/history?kind=dm&target=2',headers={'X-Test-Uid':'1'})).json();saved=next(m for m in history['messages'] if m['text']=='پاسخ به پیام خودم');assert saved['reply']['id']==original['id'];passed('Own-message reply persists the correct original ID on the real history API')
  upload=await (await context.request.post(BASE+'/api/app/dm/media',headers={'X-Test-Uid':'2'},data={'kind':'image','data':image,'dur':0})).json();assert upload['ok'];msg=await send('عکس ⟦m:'+upload['id']+'⟧',2);photo=page.locator(f'article[data-mid="{msg["id"]}"] .wc-photo');await photo.wait_for(state='visible');assert await photo.evaluate('n=>n.complete&&n.naturalWidth>0');assert await photo.get_attribute('data-force') is None;assert await page.locator(f'[data-media-load="{upload["id"]}"]').is_hidden();assert await photo.locator('xpath=ancestor::div[contains(@class,"wc-bubble")]').evaluate('n=>getComputedStyle(n).padding==="0px"');passed('Received photo displays automatically without Network Information or a download tap; thumbnail is frameless')
  # Leave a focused reply while its keyboard is open: only cached chat is hidden.
  await page.evaluate("window.chat.open('dm',2)");await page.locator('textarea').wait_for();await page.locator('textarea').fill('پیش‌نویس');await page.locator('textarea').focus();await kb(337);await page.evaluate("window.go('c')");await page.locator('[data-cinema]').wait_for();assert not await page.evaluate("document.activeElement?.closest('.wkchat')!==null");assert not await page.locator('body').evaluate("n=>n.classList.contains('wkchat-thread')||n.classList.contains('wkchat-inbox')");assert await page.locator('body').evaluate('n=>getComputedStyle(n).overflow')!='hidden'
  await page.evaluate('window.cinemaVideo=document.querySelector("[data-cinema] video")');await kb(0)
  for _ in range(3):
   await page.evaluate("window.go('d')");await page.locator('textarea').wait_for();assert (await metrics())['height']==932;await page.evaluate("window.go('c')");assert await page.evaluate('window.cinemaVideo===document.querySelector("[data-cinema] video")');assert await page.locator('.wkchat:visible').count()==0;assert await page.evaluate('visualViewport.scale')==1
  await page.screenshot(path=str(OUT/'r13-cinema-after-tabs.png'));passed('Repeated tab switches release chat focus/scroll isolation and retain the cinema video node without zoom or a visible chat surface')
  # Rotation and a genuinely safe native host must not receive another 59px inset.
  await page.set_viewport_size({'width':932,'height':430});await page.goto(BASE+'/?u=1&layout=ios');await page.locator('.wc-inbox-actions').wait_for();assert (await page.locator('.wc-inbox-actions').bounding_box())['y']<=12
  await page.set_viewport_size({'width':320,'height':640});assert await page.evaluate('document.documentElement.scrollWidth')<=320
  passed('Already-inset native host, narrow width and landscape keep one safe-area owner and no horizontal page overflow')
  assert not errors,errors
  for n,d in hashes.items():assert hashlib.sha256((src/n).read_bytes()).hexdigest()==d
  (OUT/'R13_SCREENSHOT_REGRESSION.json').write_text(json.dumps({'source_sha256':hashes,'engine':'Linux WebKit via Python Playwright','physical_ios_device':False,'viewport':[430,932],'simulated_safe_area':[59,34],'passed':results},ensure_ascii=False,indent=2));await browser.close()
asyncio.run(run())
