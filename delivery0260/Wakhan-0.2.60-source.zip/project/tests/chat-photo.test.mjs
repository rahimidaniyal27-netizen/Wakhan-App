import {test} from 'node:test';
import assert from 'node:assert/strict';
import {constrainPhoto} from '../src/chat-photo-viewer.mjs';
test('whole portrait fits without crop and cannot drift when unzoomed',()=>{
 assert.deepEqual(constrainPhoto({scale:1,x:70,y:-90,width:390,height:600,naturalWidth:400,naturalHeight:800}),{scale:1,x:0,y:-0});
});
test('zoomed portrait pan is clamped to actual image edges',()=>{
 assert.deepEqual(constrainPhoto({scale:2,x:999,y:-999,width:390,height:600,naturalWidth:400,naturalHeight:800}),{scale:2,x:105,y:-300});
});
test('landscape, invalid zoom and upper zoom limit keep usable bounds',()=>{
 const frame={width:390,height:600,naturalWidth:800,naturalHeight:400};
 assert.equal(constrainPhoto({...frame,scale:50}).scale,6);
 assert.equal(constrainPhoto({...frame,scale:NaN}).scale,1);
 assert.equal(constrainPhoto({...frame,scale:2,y:200}).y,0);
});
