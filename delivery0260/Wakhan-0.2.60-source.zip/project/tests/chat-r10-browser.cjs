const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const assert=require('node:assert/strict');
const base='http://127.0.0.1:8765',review='/workspace/wakhan-chat-r16/review';let browser,page;
(async()=>{
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-crashpad-for-testing','--no-zygote','--single-process','--disable-background-timer-throttling']});
 const context=await browser.newContext({viewport:{width:390,height:844},hasTouch:true});
 await context.addInitScript(()=>{
  window.WakhanNative={platform:'ios'};
  // Match the production shell's image callout blocker without loading unrelated programs.
  document.addEventListener('contextmenu',event=>{if(!event.target.closest?.('input,textarea,[contenteditable=true]'))event.preventDefault();},true);
 });
 page=await context.newPage();page.setDefaultTimeout(12000);const errors=[];let mediaGets=0;page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(r.method()==='GET'&&r.url().includes('/api/app/dm/media/'))mediaGets++;});
 await page.goto(base+'/?u=1');const click=a=>page.locator(`[data-action="${a}"]`).first().click();await page.locator('[data-action=new]').waitFor();
 for(const width of [390,320]){
  await page.setViewportSize({width,height:844});const rect=await page.locator('.wkchat').boundingBox();assert.equal(rect.x,0);assert.equal(rect.y,0);assert.equal(rect.width,width);
  const button=page.locator('.wc-new');assert.equal((await button.innerText()).trim(),'');assert(await button.getAttribute('aria-label'));assert((await button.boundingBox()).width>=44);assert(await page.locator('#nav').isVisible());assert(await page.locator('body>header').isHidden());assert(await page.locator('#view').evaluate(el=>el.scrollWidth<=innerWidth));
 }
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:review+'/r10-inbox.png'});console.log('PASS inbox fills shell width without header gap at 320/390; one-line compose label; five-tab navigation retained');
 await page.evaluate(()=>window.chat.open('dm',2));await page.locator('textarea').waitFor();
 const rect=await page.locator('.wkchat').boundingBox();assert.equal(rect.x,0);assert.equal(rect.width,390);assert.equal(rect.y,0);
 await page.locator('textarea').fill('پیش‌نویس محفوظ');
 const png=await page.evaluate(()=>{const c=document.createElement('canvas');c.width=300;c.height=600;const x=c.getContext('2d');x.fillStyle='#168ab0';x.fillRect(0,0,300,600);x.fillStyle='#ffd886';x.fillRect(10,10,280,100);x.fillStyle='#ed7293';x.fillRect(10,490,280,100);return c.toDataURL('image/png');});
 const headers={'X-Test-Uid':'2'},upload=await (await context.request.post(base+'/api/app/dm/media',{headers,data:{kind:'image',data:png,dur:0}})).json();assert(upload.ok);
 const post=async text=>{const response=await context.request.post(base+'/api/app/chat/send',{headers,data:{kind:'dm',target:1,text,client_key:crypto.randomUUID().replaceAll('-','')}});const result=await response.json();assert(result.ok);return result;};
 await post('عکس ⟦m:'+upload.id+'⟧');const thumb=page.locator(`img[data-chat-media="${upload.id}"]`);await thumb.waitFor({state:'visible'});
 const bubble=thumb.locator('xpath=ancestor::div[contains(@class,"wc-bubble")]');const geometry=await bubble.evaluate(el=>{const s=getComputedStyle(el),image=el.querySelector('img');return {background:s.backgroundColor,border:s.borderWidth,padding:s.padding,width:el.getBoundingClientRect().width,imageWidth:image.getBoundingClientRect().width,ratio:image.getBoundingClientRect().height/image.getBoundingClientRect().width,caption:el.querySelector('.wc-caption')?.textContent};});
 assert.equal(geometry.background,'rgba(0, 0, 0, 0)');assert.equal(geometry.border,'0px');assert.equal(geometry.padding,'0px');assert(Math.abs(geometry.width-geometry.imageWidth)<1);assert.equal(geometry.ratio,2);assert.equal(geometry.caption,undefined);
 await page.screenshot({path:review+'/r10-photo-message.png'});console.log('PASS portrait is frameless, keeps its full aspect ratio and has no automatic photo caption or side padding');
 const before=mediaGets;await thumb.click();await page.locator('.wc-viewer-image').waitFor({state:'visible'});assert(mediaGets>before,'viewer must revalidate authorization instead of reusing cached thumbnail');assert.equal(await page.locator('.wc-photo-viewer').count(),1);
 const photo=page.locator('.wc-viewer-image');let bounds=await photo.boundingBox();assert.equal(bounds.height/bounds.width,2);
 await page.locator('[data-photo-action=in]').click();assert.equal(await page.locator('[data-photo-scale]').innerText(),'150٪');await photo.dblclick();assert.equal(await page.locator('[data-photo-scale]').innerText(),'100٪');await photo.dblclick();assert.equal(await page.locator('[data-photo-scale]').innerText(),'250٪');
 await page.evaluate(()=>{const stage=document.querySelector('.wc-viewer-stage'),r=stage.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;const down=(id,px)=>stage.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,pointerId:id,pointerType:'touch',button:0,clientX:px,clientY:y}));down(10,x-30);down(11,x+30);window.dispatchEvent(new PointerEvent('pointermove',{cancelable:true,pointerId:11,clientX:x+90,clientY:y}));for(const id of [10,11])window.dispatchEvent(new PointerEvent('pointerup',{pointerId:id,pointerType:'touch'}));});
 assert.equal(await page.locator('[data-photo-scale]').innerText(),'500٪');await page.locator('[data-photo-action=reset]').click();assert.equal(await page.locator('[data-photo-scale]').innerText(),'100٪');
 const allowed=await photo.evaluate(el=>{const event=new MouseEvent('contextmenu',{bubbles:true,cancelable:true});el.dispatchEvent(event);return !event.defaultPrevented;});assert(allowed,'viewer image must preserve iOS Save Image menu');const blocked=await page.locator('.wc-viewer-top').evaluate(el=>{const e=new MouseEvent('contextmenu',{bubbles:true,cancelable:true});el.dispatchEvent(e);return e.defaultPrevented;});assert(blocked,'callout exception must be scoped to the opened image');
 const saveBefore=mediaGets;await page.locator('[data-photo-action=save]').click();await page.locator('[data-photo-save-hint]').waitFor({state:'visible'});assert(mediaGets>saveBefore);await page.screenshot({path:review+'/r10-photo-viewer.png'});
 console.log('PASS authenticated fullscreen viewer, zoom buttons/double-tap/pinch; fresh authorization before save; iOS native image-menu fallback unblocked');
 const sent=await post('پیام پشت نمای عکس');await page.waitForFunction(id=>!!document.querySelector(`article[data-mid="${id}"]`),sent.id);await page.waitForTimeout(600);assert(!await page.evaluate(id=>requests.some(r=>r.path==='/api/app/chat/ack'&&r.body.state==='read'&&r.body.ids.includes(id)),sent.id));
 await page.evaluate(()=>window.chat.back());assert.equal(await page.locator('.wc-photo-viewer').count(),0);assert.equal(await page.locator('textarea').inputValue(),'پیش‌نویس محفوظ');console.log('PASS viewer prevents read acknowledgements behind overlay, back closes only photo and retains draft');
 // Real captions must remain; only the autogenerated label is removed.
 await post('یادگاری سفر ⟦m:'+upload.id+'⟧');await page.locator('.wc-caption',{hasText:'یادگاری سفر'}).waitFor();
 const openPhoto=page.locator(`[data-media-open="${upload.id}"]`).first();await openPhoto.click();await photo.waitFor({state:'visible'});
 await page.evaluate(()=>{Object.defineProperty(navigator,'canShare',{configurable:true,value:()=>true});Object.defineProperty(navigator,'share',{configurable:true,value:async payload=>{window.sharedFile={name:payload.files[0].name,type:payload.files[0].type,size:payload.files[0].size};}});});
 await page.locator('[data-photo-action=save]').click();await page.waitForFunction(()=>!!window.sharedFile);const shared=await page.evaluate(()=>window.sharedFile);assert.equal(shared.type,'image/jpeg');assert(shared.size>1000);assert(shared.name.startsWith('Wakhan-photo-'));await page.keyboard.press('Escape');
 // Expired access must prevent exporting a previously cached photo.
 await page.route('**/api/app/dm/media/'+upload.id,route=>route.fulfill({status:404,body:'unavailable'}));await openPhoto.click();await page.locator('.wc-toast').waitFor();assert.equal(await page.locator('.wc-photo-viewer').count(),0);await page.unroute('**/api/app/dm/media/'+upload.id);
 console.log('PASS authored captions retained; native share gets a real photo File; revoked media cannot be reopened from cached thumbnails');
 await page.evaluate(()=>window.chat.back());await page.locator('.wc-inbox-actions').waitFor();await page.evaluate(()=>window.chat.back());assert.equal(await page.locator('body.wkchat-inbox,body.wkchat-thread').count(),0);assert(await page.locator('body>header').isVisible());assert.deepEqual(errors,[]);console.log('PASS leaving chat removes scoped shell overrides; no JavaScript errors');
})().catch(async error=>{console.error(error);try{await page?.screenshot({path:review+'/r10-browser-failure.png'});}catch{}process.exitCode=1;}).finally(async()=>{await browser?.close();});
