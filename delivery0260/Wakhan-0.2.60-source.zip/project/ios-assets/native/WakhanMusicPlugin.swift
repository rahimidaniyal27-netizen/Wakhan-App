import Foundation
import AVFoundation
import MediaPlayer
import UIKit
import Capacitor

private final class MusicHTTP: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}

/// AVPlayer owns audio while WKWebView is suspended. No hidden video/keepalive.
@objc(WakhanMusicPlugin)
public class WakhanMusicPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "WakhanMusicPlugin"
    public let jsName = "WakhanMusic"
    public let pluginMethods: [CAPPluginMethod] = ["loadTrack", "control", "state", "stopAll"].map { CAPPluginMethod(name: $0, returnType: CAPPluginReturnPromise) }
    private let player = AVPlayer()
    private var itemObserver: NSKeyValueObservation?
    private var playbackObserver: NSKeyValueObservation?
    private var timeObserver: Any?
    private var requestID = "", source = "", wanted = false, ended = false, ready = false
    private var foreground = true, room = "", roomKey = "", roomVideo = "", roomRevision = 0
    private var roomEpoch = "", roomCanEnd = false, roomMuted = false, roomPosition = 0.0, roomAt = Date(), roomPlaying = false
    private var lastEnd = "", lastEndAt = Date.distantPast, pendingHTTP = false, interrupted = false
    private var roomTimer: Timer?
    private let httpDelegate = MusicHTTP()
    private lazy var http: URLSession = { let c = URLSessionConfiguration.ephemeral; c.timeoutIntervalForRequest = 12; c.urlCache = nil; return URLSession(configuration: c, delegate: httpDelegate, delegateQueue: nil) }()
    private func matches(_ value: String, _ pattern: String) -> Bool { value.range(of: pattern, options: .regularExpression) != nil }
    private func allowed(_ raw: String) -> URL? {
        guard let u = URL(string: raw), u.user == nil, u.password == nil, u.fragment == nil else { return nil }
        if u.isFileURL {
            let folder = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("wakhan-music").resolvingSymlinksInPath()
            let file = u.resolvingSymlinksInPath()
            return file.deletingLastPathComponent() == folder && matches(file.lastPathComponent,"^u[0-9]{1,18}_[a-f0-9]{64}\\.mp3$") && FileManager.default.fileExists(atPath:file.path) ? file : nil
        }
        guard u.scheme == "https", u.port == nil || u.port == 443, let host = u.host else { return nil }
        if host == "music.kabulcafe.uk" && (matches(u.path,"^/(a|api/app/music/media)/[A-Za-z0-9_-][A-Za-z0-9_.-]*$") || matches(u.path,"^/api/app/rooms/[A-Za-z0-9_-]{1,64}/video$")) { return u }
        if host == "api.audius.co" && matches(u.path,"^/v1/tracks/[A-Za-z0-9]{1,30}/stream$") && u.query == "app_name=Wakhan" { return u }
        if host == "archive.org" && matches(u.path,"^/download/[A-Za-z0-9_.-]{1,180}/.+\\.mp3$") && u.query == nil { return u }
        if host == "ccmixter.org" && matches(u.path,"^/content/[^/]+/[^/]+\\.mp3$") && u.query == nil { return u }
        return nil
    }
    public override func load() {
        foreground = UIApplication.shared.applicationState == .active
        NotificationCenter.default.addObserver(self, selector:#selector(background), name:UIApplication.willResignActiveNotification, object:nil)
        NotificationCenter.default.addObserver(self, selector:#selector(active), name:UIApplication.didBecomeActiveNotification, object:nil)
        NotificationCenter.default.addObserver(self, selector:#selector(interruption(_:)), name:AVAudioSession.interruptionNotification, object:nil)
        NotificationCenter.default.addObserver(self, selector:#selector(routeChanged(_:)), name:AVAudioSession.routeChangeNotification, object:nil)
        NotificationCenter.default.addObserver(self, selector:#selector(finished(_:)), name:AVPlayerItem.didPlayToEndTimeNotification, object:nil)
        playbackObserver = player.observe(\.timeControlStatus, options:[.new]) { [weak self] _,_ in DispatchQueue.main.async { self?.publish() } }
        timeObserver = player.addPeriodicTimeObserver(forInterval:CMTime(seconds:1,preferredTimescale:600),queue:.main) { [weak self] _ in if self?.foreground == true { self?.publish() } }
        MPRemoteCommandCenter.shared().playCommand.addTarget { [weak self] _ in DispatchQueue.main.async { self?.roomMuted=false;self?.wanted=true;self?.applyIntent() };return .success }
        MPRemoteCommandCenter.shared().pauseCommand.addTarget { [weak self] _ in DispatchQueue.main.async { self?.roomMuted=true;self?.wanted=false;self?.player.pause();self?.publish() };return .success }
        MPRemoteCommandCenter.shared().changePlaybackPositionCommand.addTarget { [weak self] event in guard let e=event as? MPChangePlaybackPositionCommandEvent else{return .commandFailed};DispatchQueue.main.async { self?.player.seek(to:CMTime(seconds:max(0,e.positionTime),preferredTimescale:600)) };return .success }
    }
    private func session() {
        do { let s=AVAudioSession.sharedInstance();if s.category != .playAndRecord { try s.setCategory(.playback,mode:.default) };try s.setActive(true) } catch { fail() }
    }
    private func snapshot() -> JSObject {
        let p=player.currentTime().seconds,d=player.currentItem?.duration.seconds ?? 0
        return ["id":requestID,"active":!requestID.isEmpty && !ended,"ready":ready,"buffering":player.timeControlStatus == .waitingToPlayAtSpecifiedRate,"ended":ended,"playing":player.rate>0,"wanted":wanted,"position":p.isFinite ? max(0,p):0,"duration":d.isFinite ? max(0,d):0,"backgroundOnly":!room.isEmpty]
    }
    private func publish() {
        guard !requestID.isEmpty else{return};var info=MPNowPlayingInfoCenter.default().nowPlayingInfo ?? [:];let p=player.currentTime().seconds,d=player.currentItem?.duration.seconds ?? 0
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime]=p.isFinite ? max(0,p):0;info[MPNowPlayingInfoPropertyPlaybackRate]=player.rate;info[MPMediaItemPropertyPlaybackDuration]=d.isFinite ? max(0,d):0;MPNowPlayingInfoCenter.default().nowPlayingInfo=info
        notifyListeners("state",data:snapshot())
    }
    private func fail() { player.pause();wanted=false;var value=snapshot();value["error"]="PLAYBACK_FAILED";notifyListeners("state",data:value) }
    private func applyIntent() { if wanted && !interrupted && (room.isEmpty || !foreground) { session();player.play() } else { player.pause() };publish() }
    private func loadSource(_ u: URL, position:Double, title:String, artist:String) {
        player.pause();source=u.absoluteString;ready=false;ended=false;itemObserver=nil
        let item=AVPlayerItem(url:u),id=requestID;player.replaceCurrentItem(with:item)
        MPNowPlayingInfoCenter.default().nowPlayingInfo=[MPMediaItemPropertyTitle:title,MPMediaItemPropertyArtist:artist]
        itemObserver=item.observe(\.status,options:[.initial,.new]) { [weak self,weak item] _,_ in DispatchQueue.main.async {
            guard let self=self,let item=item,self.player.currentItem === item,self.requestID==id else{return}
            if item.status == .failed { self.fail();return }
            if item.status == .readyToPlay && !self.ready {
                self.ready=true;let start=self.room.isEmpty ? position:self.expectedRoomPosition()
                self.player.seek(to:CMTime(seconds:max(0,start),preferredTimescale:600),toleranceBefore:.zero,toleranceAfter:.zero) { [weak self] _ in DispatchQueue.main.async { guard self?.requestID==id else{return};self?.applyIntent() } }
            };self.publish()
        } }
    }
    @objc public func loadTrack(_ call: CAPPluginCall) {
        guard let id=call.getString("id"),matches(id,"^[A-Za-z0-9_-]{1,64}$"),let raw=call.getString("source"),let u=allowed(raw) else {call.reject("INVALID_AUDIO_SOURCE");return}
        let code=call.getString("roomCode") ?? "",token=call.getString("roomToken") ?? ""
        if !code.isEmpty && (!matches(code,"^[A-Za-z0-9_-]{1,64}$") || !matches(token,"^wka1\\.[A-Za-z0-9_-]{24}\\.[a-f0-9]{32}$") || u.host != "music.kabulcafe.uk" || u.path != "/api/app/rooms/"+code+"/video") {call.reject("INVALID_ROOM_CONTEXT");return}
        DispatchQueue.main.async { self.clearRoom();self.requestID=id;self.room=code;self.roomKey=token;self.wanted=call.getBool("playing") ?? true;self.roomPlaying=self.wanted;self.roomPosition=max(0,call.getDouble("position") ?? 0);self.roomAt=Date();self.roomMuted=call.getBool("muted") ?? false;self.roomVideo=call.getString("roomVideo") ?? "";self.roomRevision=call.getInt("roomRevision") ?? 0;self.roomCanEnd=call.getBool("roomCanEnd") ?? false
            self.loadSource(u,position:self.roomPosition,title:call.getString("title") ?? "Wakhan",artist:call.getString("artist") ?? "")
            if !code.isEmpty { self.roomTimer=Timer.scheduledTimer(withTimeInterval:3,repeats:true) { [weak self] _ in self?.pollRoom() };self.pollRoom() };call.resolve(self.snapshot())
        }
    }
    @objc public func control(_ call: CAPPluginCall) {
        DispatchQueue.main.async { guard call.getString("id")==self.requestID else {call.resolve();return}
            switch call.getString("action") ?? "" {
            case "play":self.roomMuted=false;self.wanted=true;self.applyIntent()
            case "pause":self.roomMuted=true;self.wanted=false;self.player.pause()
            case "room-sync":self.roomMuted=call.getBool("muted") ?? self.roomMuted;self.roomPosition=max(0,call.getDouble("position") ?? 0);self.roomAt=Date();self.roomPlaying=call.getBool("playing") ?? false;if !self.foreground {self.wanted=self.roomPlaying && !self.roomMuted;self.applyIntent()}
            case "seek":self.player.seek(to:CMTime(seconds:max(0,call.getDouble("position") ?? 0),preferredTimescale:600))
            case "stop":self.stop()
            default:call.reject("INVALID_PLAYER_ACTION");return
            };call.resolve(self.snapshot())
        }
    }
    @objc public func state(_ call: CAPPluginCall) { DispatchQueue.main.async { call.resolve(self.snapshot()) } }
    @objc public func stopAll(_ call: CAPPluginCall) { DispatchQueue.main.async { self.stop();call.resolve() } }
    private func clearRoom() { roomTimer?.invalidate();roomTimer=nil;room="";roomKey="";roomVideo="";lastEnd="";pendingHTTP=false }
    private func stop() { clearRoom();wanted=false;player.pause();player.replaceCurrentItem(with:nil);itemObserver=nil;requestID="";source="";ready=false;ended=false;MPNowPlayingInfoCenter.default().nowPlayingInfo=nil }
    @objc private func background() { foreground=false;if !room.isEmpty { if ready { player.seek(to:CMTime(seconds:expectedRoomPosition(),preferredTimescale:600)) };wanted=roomPlaying && !roomMuted;applyIntent();pollRoom() } }
    @objc private func active() { foreground=true;if !room.isEmpty { player.pause();pollRoom() };publish() }
    private func expectedRoomPosition() -> Double { max(0,roomPosition+(roomPlaying ? Date().timeIntervalSince(roomAt):0)) }
    private func roomRequest(_ action:[String:Any]?=nil) {
        guard !room.isEmpty,!pendingHTTP else{return};let id=requestID,code=room,key=roomKey
        guard let url=URL(string:"https://music.kabulcafe.uk/api/c/"+code+"?v=-1") else{return}
        var request=URLRequest(url:url);request.setValue(key,forHTTPHeaderField:"X-Init");request.cachePolicy = .reloadIgnoringLocalCacheData
        if let body=action { request.httpMethod="POST";request.setValue("application/json",forHTTPHeaderField:"Content-Type");request.httpBody=try? JSONSerialization.data(withJSONObject:body) }
        pendingHTTP=true
        http.dataTask(with:request) { [weak self] data,response,error in DispatchQueue.main.async {
            guard let self=self,self.requestID==id,self.room==code else{return};self.pendingHTTP=false
            if let status=(response as? HTTPURLResponse)?.statusCode,[401,403,404].contains(status) {self.stop();return}
            guard error==nil,let data=data,data.count<7000000,let value=(try? JSONSerialization.jsonObject(with:data))as? [String:Any],value["ok"]as? Bool==true else{return}
            self.applyRoom(value)
        } }.resume()
    }
    private func pollRoom() {
        guard !foreground,!pendingHTTP else{return}
        let key=roomVideo+"|"+String(roomRevision)+"|"+roomEpoch
        if ended && roomCanEnd && roomPlaying && !roomVideo.isEmpty && (key != lastEnd || Date().timeIntervalSince(lastEndAt)>5) {lastEnd=key;lastEndAt=Date();roomRequest(["a":"end","vid":roomVideo,"timeline_revision":roomRevision])}else{roomRequest()}
    }
    private func applyRoom(_ v:[String:Any]) {
        guard (v["mine"]as? Int ?? -1)>=0 else{stop();return}
        guard let vid=v["vid"]as? String,matches(vid,"^[A-Za-z0-9_-]{11}$"),let media=v["media"]as? [String:Any],media["kind"]as? String=="native",let formats=media["formats"]as? [[String:Any]],let raw=formats.first?["url"]as? String,let url=URL(string:raw,relativeTo:URL(string:"https://music.kabulcafe.uk"))?.absoluteURL,allowed(url.absoluteString) != nil,URLComponents(url:url,resolvingAgainstBaseURL:true)?.queryItems?.first(where:{$0.name=="vid"})?.value==vid,url.path=="/api/app/rooms/"+room+"/video",let position=v["t"]as? Double,position.isFinite else {player.pause();roomPlaying=false;wanted=false;publish();return}
        let revision=v["timeline_revision"]as? Int ?? 0,changed=roomVideo != vid || roomRevision != revision
        roomVideo=vid;roomRevision=revision;roomEpoch=v["sync_epoch"]as? String ?? "";roomCanEnd=v["can"]as? Bool ?? false;roomPosition=max(0,position);roomAt=Date();roomPlaying=v["playing"]as? Bool ?? false;wanted=roomPlaying && !roomMuted
        if changed || source.isEmpty {loadSource(url,position:position,title:v["title"]as? String ?? "Wakhan",artist:"")}
        else if ready {let current=player.currentTime().seconds;if current.isFinite && abs(current-position)>3 {player.seek(to:CMTime(seconds:position,preferredTimescale:600))};applyIntent()}
    }
    @objc private func finished(_ n:Notification) {
        guard let item=n.object as? AVPlayerItem,item === player.currentItem else{return};ended=true;wanted=false;publish()
        if !room.isEmpty {pollRoom()}
    }
    @objc private func interruption(_ n:Notification) {
        guard let raw=n.userInfo?[AVAudioSessionInterruptionTypeKey]as? UInt,let type=AVAudioSession.InterruptionType(rawValue:raw) else{return}
        if type == .began {interrupted=true;player.pause()}else if let raw=n.userInfo?[AVAudioSessionInterruptionOptionKey]as? UInt,AVAudioSession.InterruptionOptions(rawValue:raw).contains(.shouldResume) {interrupted=false;applyIntent()}else{interrupted=false;wanted=false;roomMuted=true};publish()
    }
    @objc private func routeChanged(_ n:Notification) { if let raw=n.userInfo?[AVAudioSessionRouteChangeReasonKey]as? UInt,AVAudioSession.RouteChangeReason(rawValue:raw) == .oldDeviceUnavailable {wanted=false;roomMuted=true;player.pause();publish()} }
    deinit { roomTimer?.invalidate();NotificationCenter.default.removeObserver(self);if let token=timeObserver {player.removeTimeObserver(token)};http.invalidateAndCancel() }
}
