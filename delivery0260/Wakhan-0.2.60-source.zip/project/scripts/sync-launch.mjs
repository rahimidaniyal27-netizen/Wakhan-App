import {copyFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
export function syncLaunch(root=process.cwd(),platform=process.env.CAPACITOR_PLATFORM_NAME){
 if(platform!=='ios')return false;
 const target=resolve(root,'ios/App/App/Base.lproj/LaunchScreen.storyboard');
 if(!existsSync(target))throw Error('iOS launch storyboard missing after sync');
 copyFileSync(resolve(root,'ios-assets/native/LaunchScreen.storyboard'),target);return true;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))syncLaunch();
