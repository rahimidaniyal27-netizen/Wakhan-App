"""Validate the current approved shell without replaying old snapshots."""
from pathlib import Path
import subprocess
raise SystemExit(subprocess.call(["node", "scripts/validate-client.mjs"], cwd=Path(__file__).resolve().parents[1]))
