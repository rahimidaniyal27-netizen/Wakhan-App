import {el,button,asset,counter,modal,waitText} from '../ui.js';
const suits={H:'♥',D:'♦',C:'♣',S:'♠'},colorNames={r:'سرخ',y:'زرد',g:'سبز',b:'آبی'},colors={r:'#d9434f',y:'#dfb73b',g:'#39a276',b:'#377acb'};
export const cardFile=(game,c)=>game==='fiskot'?'card-'+c+'.svg':'ono-'+(c.color?c.color+'-':'')+c.value+'.svg';
export function createCards(root,ctx){let latest=null,selected=null,preOno=false,lastKey='',scroll=0,collectTimer=0,collectKey='';const panel=el('section',{class:'hand-panel'}),table=el('section',{class:'felt'});root.replaceChildren(table,panel);
 function play(c){if(ctx.busy())return;const a={type:'play',card:ctx.snapshot().game==='ono'?c.id:c};if(ctx.snapshot().game==='ono'){a.ono=preOno;if(!c.color){modal('رنگ تازه را انتخاب کن',el('div',{class:'actions'},Object.entries(colors).map(([color,value])=>button(colorNames[color],()=>{document.querySelector('#overlay').replaceChildren();void ctx.act({...a,color});},{style:{background:value,color:'white'}}))));return;}}void ctx.act(a);}
 function update(v){latest=v;const s=v.state,game=v.game,n=v.members.length,me=v.seat;const key=JSON.stringify([s.phase,s.turn,s.trick,s.last_trick,s.hand_cards,s.legal,s.top,s.counts,s.color,s.direction,s.scores,s.tricks,s.deadline,s.ono_window,s.challenge,v.version]);if(key===lastKey)return;lastKey=key;
  const chosenId=selected;selected=(s.hand_cards||[]).some(c=>(game==='ono'?c.id:c)===chosenId)?chosenId:null;
  table.replaceChildren();
  for(let seat=0;seat<n;seat++){if(seat===me)continue;const relative=(seat-me+n)%n;let x,y;if(game==='fiskot'){[x,y]=relative===1?[0,48]:relative===2?[50,0]:[100,48];}else{const angle=Math.PI+(relative/(n))*Math.PI*2;x=50+Math.sin(angle)*54;y=50+Math.cos(angle)*56;}
   const person=v.members.find(m=>m.seat===seat);const p=el('div',{class:'seat '+(s.turn===seat?'active ':'')+(person?.left?'left':''),style:{left:x+'%',top:y+'%',transform:'translate(-50%,-50%)'}},ctx.avatar(person),el('span',{class:'seat-name'},person?.name||'بازیکن'),el('span',{},`${s.counts?.[seat]??0} کارت${game==='fiskot'&&seat%2===me%2?' · هم‌تیمی':''}`),el('div',{class:'backs'},Array.from({length:Math.min(5,s.counts?.[seat]||0)},()=>el('i',{class:'tiny-card',style:{backgroundImage:`url('${asset(game==='ono'?'ono-back.svg':'card-back.svg')}')`}}))));table.append(p);
  }
  if(game==='fiskot'){
   const score=el('div',{class:'table-score'},`امتیاز مچ ${s.scores[me%2]} : ${s.scores[1-me%2]} · باری ${s.tricks[me%2]} : ${s.tricks[1-me%2]}`,el('br'),s.trump?'حکم '+suits[s.trump]:'حکم هنوز انتخاب نشده');table.append(score);
   const cards=s.trick?.length?s.trick:s.last_trick?.cards&&ctx.now()<s.collect_until?s.last_trick.cards:[];const collecting=!s.trick?.length&&cards.length===4;const winner=((s.last_trick?.winner||0)-me+4)%4,directions=[[0,85],[-90,0],[0,-85],[90,0]],id=JSON.stringify([s.hand,s.last_trick]);if(collecting&&id!==collectKey){collectKey=id;clearTimeout(collectTimer);collectTimer=setTimeout(()=>{lastKey='';update(latest);},Math.max(0,(s.collect_until-ctx.now())*1000)+20);}table.append(el('div',{class:'trick-space','data-collecting':collecting,style:{'--collect-x':directions[winner][0]+'px','--collect-y':directions[winner][1]+'px','--collect-duration':Math.max(.05,s.collect_until-ctx.now())+'s'}},cards.map(c=>el('div',{class:'trick-card','data-position':(c.seat-me+4)%4},el('img',{src:asset(cardFile(game,c.card)),alt:c.card})))));
  }else{
   table.append(el('div',{class:'table-center'},button(el('img',{src:asset('ono-back.svg'),alt:'کشیدن یک کارت'}),()=>ctx.act({type:'draw'}),{class:'pile-card',disabled:s.turn!==me||s.phase!=='turn','aria-label':'کشیدن یک کارت'}),el('div',{class:'pile-card'},el('img',{src:asset(cardFile(game,s.top)),alt:'کارت روی زمین'}))),el('div',{class:'table-score',style:{top:'80%'}},el('span',{class:'color-dot',style:{background:colors[s.color]}}),' '+colorNames[s.color]+' · '+(s.direction===1?'↻':'↺')));
  }
  const old=panel.querySelector('.hand-strip');if(old)scroll=old.scrollLeft;panel.replaceChildren();
  const own=s.hand_cards||[],legal=new Set(s.legal||[]);const hint=game==='fiskot'&&s.phase==='trump'?(s.turn===me?'از پنج کارتت یک خال را حکم کن.':'منتظر انتخاب حکم'):s.turn===me?(waitText[s.phase]||'نوبت تو'):'نوبت '+(v.members.find(m=>m.seat===s.turn)?.name||'بازیکن');panel.append(el('p',{class:'hand-hint'},hint,' · ',counter(s.deadline,ctx.now())));
  const strip=el('div',{class:'hand-strip','aria-label':'کارت‌های دست تو'});for(const c of own){const id=game==='ono'?c.id:c;const b=button(el('img',{src:asset(cardFile(game,c)),alt:game==='fiskot'?c:(colorNames[c.color]||'تغییر رنگ')+' '+c.value}),()=>{selected=id;lastKey='';update(latest);},{class:'playing-card '+(selected===id?'selected':''),'data-card':id,'aria-pressed':selected===id,disabled:s.phase!=='trump'&&!legal.has(id)});strip.append(b);}panel.append(strip);strip.scrollLeft=scroll;
  const controls=el('div',{class:'hand-controls'});if(game==='fiskot'&&s.phase==='trump'&&s.turn===me)controls.append(el('div',{class:'suits'},Object.entries(suits).map(([suit,symbol])=>button(symbol,()=>ctx.act({type:'trump',suit}),{class:['H','D'].includes(suit)?'red':'','aria-label':{H:'دل',D:'خشت',C:'گشنیز',S:'پیک'}[suit]}))));
  else if(selected!=null&&legal.has(selected)){const c=own.find(c=>(game==='ono'?c.id:c)===selected);controls.append(button('انداختن کارت',()=>play(c),{class:'primary','data-play':''}));}
  if(game==='ono'){
   if(s.phase==='drawn'&&s.turn===me)controls.append(button('رد نوبت',()=>ctx.act({type:'pass'})));
   if(s.phase==='ono'){const mine=s.ono_window?.seat===me;controls.append(button(mine?'Ono!':'Ono نگفت!',()=>ctx.act({type:mine?'declare_ono':'catch_ono'}),{class:'primary'}));}
   else if(s.phase==='challenge4'&&s.turn===me)controls.append(button('قبول +4',()=>ctx.act({type:'accept4'})),button('اعتراض',()=>ctx.act({type:'challenge4'}),{class:'primary'}));
   else controls.append(button(preOno?'✓ Ono همراه کارت':'اعلام Ono با کارت',()=>{preOno=!preOno;lastKey='';update(latest);},{'aria-pressed':preOno}));
   if(s.last_effect&&s.last_effect.type!=='play')controls.append(el('span',{class:'small'},({wild4:s.last_effect.challenged?(s.last_effect.challenge_correct?'اعتراض درست':'اعتراض نادرست'):'قبول +4',missed_ono:'اعلام Ono فراموش شد',draw2:'دو کارت جریمه',ono:'Ono!',timeout_draw:'مهلت تمام شد'}[s.last_effect.type]||'')+(s.last_effect.count?' · '+s.last_effect.count+' کارت':'')));
  }
  panel.append(controls);
 }
 return{update,dispose(){clearTimeout(collectTimer);root.replaceChildren();}};
}
