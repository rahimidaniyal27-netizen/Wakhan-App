const fragment=new URLSearchParams(location.hash.slice(1)),nonce=fragment.get('bridge'),listeners=new Map(),pending=new Map();let serial=0;
export function send(value){if(parent!==window&&nonce)parent.postMessage({channel:'wakhan-games-v1',nonce,...value},'*');}
export function on(type,fn){if(!listeners.has(type))listeners.set(type,new Set());listeners.get(type).add(fn);return()=>listeners.get(type)?.delete(fn);}
export function rpc(op,payload={}){const id=String(++serial);return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(id);reject(Object.assign(Error('network'),{code:'network'}));},15000);pending.set(id,{resolve,reject,timer});send({type:'rpc',id,op,payload});});}
function insets(data){if(!data||['top','right','bottom','left'].some(k=>!Number.isFinite(data[k])||data[k]<0||data[k]>Math.max(innerHeight,innerWidth)/2))return;for(const [k,v] of Object.entries(data))document.documentElement.style.setProperty('--safe-'+k,v+'px');}
insets(Object.fromEntries(['top','right','bottom','left'].map(k=>[k,Number(fragment.get('safe-'+k)||0)])));
window.addEventListener('message',e=>{const m=e.data;if(e.source!==parent||!nonce||m?.channel!=='wakhan-games-v1'||m.nonce!==nonce)return;if(m.type==='insets')insets(m.data);if(m.type==='rpc-result'){const p=pending.get(m.id);if(!p)return;pending.delete(m.id);clearTimeout(p.timer);m.ok?p.resolve(m.data):p.reject(Object.assign(Error(m.err),{code:m.err}));return;}for(const fn of listeners.get(m.type)||[])fn(m);});
export const ready=()=>send({type:'ready'});
export const uid=()=>Number(document.body.dataset.uid||0);
