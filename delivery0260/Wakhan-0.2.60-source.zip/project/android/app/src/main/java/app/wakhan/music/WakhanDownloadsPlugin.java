package app.wakhan.music;

import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

@CapacitorPlugin(name="WakhanDownloads")
public class WakhanDownloadsPlugin extends Plugin {
    private final ExecutorService workers=Executors.newFixedThreadPool(2);
    private final ConcurrentHashMap<String,Boolean> active=new ConcurrentHashMap<>();
    private File folder(){File f=new File(getContext().getFilesDir(),"wakhan-music");f.mkdirs();return f;}
    private boolean key(String k){return k!=null&&k.matches("u[0-9]{1,18}_[a-f0-9]{64}");}
    private File file(String k,String ext){return new File(folder(),k+ext);}
    private boolean allowed(URL u){String host=u.getHost();return "https".equals(u.getProtocol())&&(u.getPort()==-1||u.getPort()==443)&&u.getUserInfo()==null&&(host.equals("archive.org")||host.matches("ia[0-9]+\\.(?:us|eu)\\.archive\\.org")||host.equals("ccmixter.org"));}
    private long fetch(String address,File output,long limit,String k) throws Exception {
        URL u=new URL(address);HttpURLConnection c=null;
        for(int i=0;i<6;i++){
            if(!allowed(u))throw new IOException("SOURCE_INVALID");
            c=(HttpURLConnection)u.openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("User-Agent","Wakhan/0.2.40");int status=c.getResponseCode();
            if(status>=300&&status<400){String next=c.getHeaderField("Location");c.disconnect();if(next==null)throw new IOException("DOWNLOAD_FAILED");u=new URL(u,next);continue;}
            if(status!=200){c.disconnect();throw new IOException("DOWNLOAD_FAILED");}break;
        }
        if(c==null||c.getResponseCode()!=200)throw new IOException("DOWNLOAD_FAILED");
        long total=c.getContentLengthLong(),size=0,last=0;if(total>limit){c.disconnect();throw new IOException("FILE_TOO_LARGE");}
        try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(output)){
            byte[] buffer=new byte[65536];int n;
            while((n=in.read(buffer))!=-1){if(!Boolean.TRUE.equals(active.get(k)))throw new IOException("CANCELLED");size+=n;if(size>limit)throw new IOException("FILE_TOO_LARGE");out.write(buffer,0,n);long now=System.currentTimeMillis();if(now-last>250){last=now;JSObject progress=new JSObject();progress.put("key",k);progress.put("loaded",size);progress.put("total",total);notifyListeners("progress",progress);}}
        }finally{c.disconnect();}
        if(size<20)throw new IOException("EMPTY_FILE");return size;
    }
    private JSObject source(String k){JSObject j=new JSObject();j.put("source",android.net.Uri.fromFile(file(k,".mp3")).toString());j.put("cover",android.net.Uri.fromFile(file(k,".image")).toString());j.put("bytes",file(k,".mp3").length()+file(k,".image").length());return j;}
    @PluginMethod public void download(PluginCall call){
        String k=call.getString("key");if(!key(k)){call.reject("INVALID_KEY");return;}
        if(active.putIfAbsent(k,true)!=null){call.reject("DOWNLOAD_ACTIVE");return;}
        workers.execute(()->{File a=file(k,".audio.part"),b=file(k,".cover.part");try{
            fetch(call.getString("source",""),a,120L*1024*1024,k);fetch(call.getString("cover",""),b,8L*1024*1024,k);
            if(!Boolean.TRUE.equals(active.get(k))||!a.renameTo(file(k,".mp3"))||!b.renameTo(file(k,".image")))throw new IOException("SAVE_FAILED");call.resolve(source(k));
        }catch(Exception e){file(k,".mp3").delete();file(k,".image").delete();call.reject("DOWNLOAD_FAILED");}finally{a.delete();b.delete();active.remove(k);}});
    }
    @PluginMethod public void source(PluginCall call){String k=call.getString("key");if(!key(k)||!file(k,".mp3").isFile()||!file(k,".image").isFile()){call.reject("FILE_MISSING");return;}call.resolve(source(k));}
    @PluginMethod public void cancel(PluginCall call){String k=call.getString("key");if(key(k))active.replace(k,false);call.resolve();}
    @PluginMethod public void remove(PluginCall call){String k=call.getString("key");if(!key(k)){call.reject("INVALID_KEY");return;}active.replace(k,false);file(k,".mp3").delete();file(k,".image").delete();call.resolve();}
    @Override protected void handleOnDestroy(){active.clear();workers.shutdownNow();super.handleOnDestroy();}
}
