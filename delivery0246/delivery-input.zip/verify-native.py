"""Verify the restored interface and both native payloads against exact source."""
import hashlib,json,plistlib,sys,zipfile
from pathlib import Path
root=Path(sys.argv[1])if len(sys.argv)>1 else Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
source=root/'Wakhan-0.2.46-source.zip'
with zipfile.ZipFile(source)as src:
 assert src.testzip()is None;m=json.loads(src.read('source-verification.json'));assert m['version']=='0.2.46-beta'and m['build']==61 and m['ui_reference']=='0.2.44-beta'and m['seat_lock_hold_ms']==1000
 for n,h in m['source_sha256'].items():assert sha(src.read('project/'+n))==h,n
 shell=json.loads(src.read('project/public/wakhan-shell.json'));programs={p['id']:p['code']for p in shell['programs']}
 for name in ['slr3.js','sln3.js','slr6.js','slr7.js','slr8.js','slr9.js']:assert name in programs,name
 assert 'holdSeat(i)},1000)'in programs['slr3.js']and'transform 1s cubic-bezier(.3,0,.2,1),filter 1s'in programs['slr3.js']
 evidence=json.loads(src.read('review/ui-preservation.json'));assert evidence['head_exact']and evidence['body_exact']and evidence['external_stylesheets_exact']
 result=dict(version='0.2.46-beta',build=61,source_sha256=sha(source.read_bytes()),ui_reference='0.2.44-beta',seat_lock_hold_ms=1000,server_update_required=True,physical_device_verified=False)
 for platform,filename in [('android','app-release-unsigned.apk'),('ios','Wakhan-0.2.46-beta.ipa')]:
  with zipfile.ZipFile(root/filename)as z:
   assert z.testzip()is None
   if platform=='ios':
    info=next(n for n in z.namelist()if n.count('/')==2 and n.endswith('.app/Info.plist'));v=plistlib.loads(z.read(info));base=info.rsplit('/',1)[0];prefix=base+'/'
    assert v['CFBundleIdentifier']=='app.wakhan.music'and v['CFBundleShortVersionString']=='0.2.46'and str(v['CFBundleVersion'])=='61'
    binary=z.read(base+'/'+v['CFBundleExecutable']);assert b'wakhanKeyboardFrame'in binary and b'WakhanDownloadsPlugin'in binary
   else:
    prefix='assets/';binary=b''.join(z.read(n)for n in z.namelist()if n.endswith('.dex'));assert b'WakhanDownloads'in binary
   if platform=='android':assert b'room-sync'in binary
   else:assert b'WakhanMusicPlugin'in binary
   for n,h in m['source_sha256'].items():
    if n.startswith('public/')and n not in('public/build-flags.json','public/wakhan-release.json'):assert sha(z.read(prefix+n))==h,(platform,n)
   release=json.loads(z.read(prefix+'public/wakhan-release.json'));assert release['version']=='0.2.46-beta'and release['build']==61
   js=b''.join(z.read(n)for n in z.namelist()if n.startswith(prefix+'public/assets/index-')and n.endswith('.js'));assert b'wk-cinema-floating'not in js and b'wk-shared-nav'in js
   result[platform+'_assets_match_source']=True
 result['sha256']={n:sha((root/n).read_bytes())for n in ['app-release-unsigned.apk','app-release.aab','Wakhan-0.2.46-beta.ipa']}
(root/'native-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
