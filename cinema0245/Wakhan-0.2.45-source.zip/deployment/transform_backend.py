"""Surgical AST migration of the verified standalone server, never a review-copy deployment."""
import ast,json
from pathlib import Path
RETIRE=('native_room_core.py','native_room_video.py','wakhan_cinema_v12.py','wakhan_experience_v9.py','wakhan_hall51.py','wakhan_salon.py','wakhan_archive.py','wakhan_room_tools.py','room_tools.py')
FILES=('app_core.py','native_runtime.py','native_wakhan2.py','wakhan_community_v70.py','native_profiles.py','native_admin.py')
OLD_KEYS={'CIN','CV','WM_CINEMA','WM_EXPERIENCE','WM_HALL51','WM_ROOM_VIDEO','cview','cbump','cin_sweep','api_cin','api_cinctl','api_cv','api_cv_poll','wmr_code_revoked','room_ok'}
def parsed(text):return ast.parse(text).body
class Transform(ast.NodeTransformer):
 def __init__(self,name):self.name=name
 def visit_Module(self,node):
  if self.name=='app_core.py':
   node.body=[s for s in node.body if not(isinstance(s,(ast.FunctionDef,ast.AsyncFunctionDef))and(s.name in {'cin','cbump','cpos','wmr_code_init','wmr_code_revoked','wmr_personal_rotate','wmr_base_rkey','rkey','wm_personal_cinema_init','wm_personal_cinema_get','wm_personal_cinema_reply','wmr_base_room_ok','room_ok','api_room_new','api_room_check','cvr','cvbump','cvlist','cview','_cview0','api_cin','room_owner','room_hosts','room_can','room_admin','api_cinctl','api_cv_poll','api_cv','cin_sweep'}))and not(isinstance(s,ast.Assign)and any(isinstance(t,ast.Name)and t.id in {'CIN','CV','SEATS','ROOMCH','ROOM_CONTROL'}for t in s.targets))]
  return self.generic_visit(node)
 def visit_ImportFrom(self,node):
  if self.name=='native_runtime.py'and node.module in {'native_room_core','native_room_video','wakhan_cinema_v12','wakhan_experience_v9','wakhan_hall51'}:return None
  if self.name=='wakhan_community_v70.py'and node.module=='wakhan_room_tools':return None
  return node
 def visit_ClassDef(self,node):
  if self.name=='native_profiles.py'and node.name=='Profiles':node.body=[s for s in node.body if getattr(s,'name',None)not in {'view','mark_action','select_provider'}]
  return self.generic_visit(node)
 def visit_FunctionDef(self,node):return self.function(node)
 def visit_AsyncFunctionDef(self,node):return self.function(node)
 def function(self,node):
  if self.name=='native_runtime.py'and node.name=='cinema_lock':return None
  if self.name=='native_wakhan2.py'and node.name in {'ytp','ytlog','ytp_logged','ytlog_in'}:return None
  if self.name=='wakhan_community_v70.py':
   if node.name=='gift':node.body=parsed("return await self.n['WKC_CINEMA'].gifts.commit(uid,body)");return node
   if node.name in {'room','send_room','gift_quote','api_room','api_gifts'}:return None
   if node.name=='changed':node.body=parsed("rooms=self.n.get('WKC_ROOMS')\nif rooms:\n for code in {s.code for s in rooms.sessions.values()if s.uid==uid}:rooms.store.bump(code)")
   if node.name=='install':
    start=next(i for i,s in enumerate(node.body)if isinstance(s,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='quote'for t in s.targets));node.body=node.body[start:]
  if self.name=='native_admin.py'and node.name=='__init__':node.body=[s for s in node.body if not(isinstance(s,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='room_ok'for t in s.targets))and not(isinstance(s,ast.Assign)and any(isinstance(t,ast.Subscript)and isinstance(t.slice,ast.Constant)and t.slice.value=='room_ok'for t in s.targets))]
  return self.generic_visit(node)
 def visit_Assign(self,node):
  if self.name=='native_runtime.py':
   targets=[ast.unparse(t)for t in node.targets]
   if any(t in {"ns['WM_EXPERIENCE']","ns['WM_CINEMA']","ns['WM_HALL51']"}for t in targets):return None
  if self.name=='native_wakhan2.py'and any(isinstance(t,ast.Name)and t.id=='salon'for t in node.targets)and isinstance(node.value,ast.Constant)and node.value.value is None:return parsed("from wakhan_cinema import install as install_cinema\ninstall_cinema(app,ns)\nsalon=ns['WKC_ROOMS']")
  if self.name=='native_admin.py':
   targets=[ast.unparse(t)for t in node.targets]
   if targets==['rows']and isinstance(node.value,ast.Call)and 'SELECT r.code' in ast.unparse(node):return parsed("rows=[(r['code'],r['owner'],r['name'])for r in self.n['WKC_ROOMS'].all()]")[0]
   if targets==['metadata']and 'WM_HALL51'in ast.unparse(node):return parsed("metadata=self.n['WKC_ROOMS'].info(code,actor)")[0]
   if targets==['state']and "self.n['CIN']"in ast.unparse(node):return parsed("state={'seats':self.n['WKC_ROOMS'].present(code)}")[0]
  return self.generic_visit(node)
 def visit_Expr(self,node):
  source=ast.unparse(node)
  if self.name=='native_runtime.py':
   if "ns['WM_HALL51']"in source or 'install_room_video(app, ns)'in source or "await ns['WM_ROOM_VIDEO'].close()"in source:return None
   if source=="ns['WM_COMMUNITY70'].install()":return[node,*parsed('from wakhan_cinema import install_model\ninstall_model(ns)')]
  if self.name=='native_wakhan2.py':
   if any(s in source for s in ["'/wk/yt'","'/wk/yt/log'","WAKHAN2 salon %s, archive %s"]):return None
  if self.name=='wakhan_community_v70.py'and source=='self.room_tools.routes(app)':return None
  return self.generic_visit(node)
 def visit_If(self,node):
  source=ast.unparse(node.test)
  if self.name=='wakhan_community_v70.py'and 'room_tools'in source:return None
  if self.name=='native_admin.py':
   if "self.n['wmr_code_revoked']"in source:return None
   if source=='not enabled':return parsed("if not enabled:\n rooms=self.n['WKC_ROOMS']\n for session in list(rooms.sessions.values()):\n  if session.code==code:rooms.leave(session)\n rooms.store.set_playback(code,None)")[0]
  return self.generic_visit(node)
 def visit_Try(self,node):
  if self.name=='native_wakhan2.py'and any(isinstance(s,ast.ImportFrom)and s.module=='wakhan_salon'for s in node.body):return None
  return self.generic_visit(node)
 def visit_Call(self,node):
  if self.name=='native_runtime.py'and isinstance(node.func,ast.Name)and node.func.id=='upgrade_room_core':return self.visit(node.args[0])
  return self.generic_visit(node)
 def visit_Tuple(self,node):
  if self.name=='native_runtime.py'and any(isinstance(e,ast.Constant)and e.value=='cin_sweep'for e in node.elts):node.elts=[e for e in node.elts if not(isinstance(e,ast.Constant)and e.value=='cin_sweep')]
  return self.generic_visit(node)
 def visit_List(self,node):
  if self.name in {'native_runtime.py','wakhan_community_v70.py'}:
   def keep(s):
    if not isinstance(s,ast.Tuple):return True
    values=[e.value for e in s.elts if isinstance(e,ast.Constant)]
    if self.name=='native_runtime.py':return not any(isinstance(v,str)and v.startswith(('/api/cinema','/api/room','/api/c/','/api/cv/'))for v in values)
    return not any(v in {'hall','gifts'}for v in values)
   node.elts=[s for s in node.elts if keep(s)]
  return self.generic_visit(node)
def transform(name,text):
 tree=Transform(name).visit(ast.parse(text));ast.fix_missing_locations(tree);out=ast.unparse(tree)+'\n';compile(out,name,'exec')
 # No remaining active references to retired room keys in modified modules.
 remaining={n.slice.value for n in ast.walk(ast.parse(out))if isinstance(n,ast.Subscript)and isinstance(n.slice,ast.Constant)and n.slice.value in OLD_KEYS}
 if remaining:raise RuntimeError(name+': unconverted Cinema keys '+str(sorted(remaining)))
 return out
if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('source',type=Path);parser.add_argument('destination',type=Path);args=parser.parse_args();args.destination.mkdir(parents=True,exist_ok=True)
 for name in FILES:(args.destination/name).write_text(transform(name,(args.source/name).read_text()))
