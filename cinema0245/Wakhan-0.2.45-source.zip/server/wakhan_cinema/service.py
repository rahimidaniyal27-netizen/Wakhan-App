"""A single authenticated room protocol for HTTP commands, events and WebRTC."""
import asyncio
import json
import re
import secrets
import time
from pathlib import Path
from urllib.parse import urlencode
from aiohttp import web
from .store import CinemaStore,CinemaError
from .rooms import Rooms
from .catalog import CinemaCatalog,YT_ID
from .commands import Commands,require
from .media import CinemaMedia
from .assets import Assets
from .gifts import Gifts
PREFIX='/api/app/cinema/v2'
KEY=re.compile(r'^[A-Za-z0-9_-]{8,80}$')
CODE=re.compile(r'^[A-Z0-9]{4,8}$')

class CinemaService:
    def __init__(self,namespace,*,store=None,rooms=None,catalog=None,origin='https://music.kabulcafe.uk',workers=True):
        self.n=namespace;self.me=namespace['WME'];self.origin=origin.rstrip('/');self.workers=workers
        self.store=store or CinemaStore(namespace['DB']);self.store.initialize()
        self.rooms=rooms or Rooms(self.store,namespace['WM_COMMUNITY70']);self.catalog=catalog or CinemaCatalog(self.store,origin=self.origin);self.files=CinemaMedia(self.store,self.rooms,origin=self.origin);self.catalog.streaming=self.files;self.commands=Commands(self.store,self.rooms,self.catalog)
        self.assets=Assets(self);self.gifts=Gifts(self);self.locks={};self.tickets={};self.task=None;self.stopped=False
    async def body(self,request):
        value=await request.json()
        if not isinstance(value,dict):raise CinemaError('bad_body')
        return value
    def session(self,uid,value):
        code=str(value.get('code')or'').upper();sid=str(value.get('session')or'')
        if not CODE.fullmatch(code):raise CinemaError('bad_code')
        return self.rooms.get(uid,code,sid)
    def snapshot(self,session):return self.rooms.snapshot(session,self.catalog)
    async def broadcast(self,code):
        sessions=[s for s in self.rooms.sessions.values()if s.code==code and s.socket and not s.socket.closed]
        async def send(s):
            try:await s.socket.send_json({'type':'snapshot','snapshot':self.snapshot(s)})
            except(ConnectionError,RuntimeError):pass
        if sessions:await asyncio.gather(*(send(s)for s in sessions))
    async def salons(self,request,uid):
        self.rooms.account(uid);section=request.query.get('section','mine');q=str(request.query.get('q')or'')[:100]
        return{'ok':True,'items':self.rooms.list(uid,section,q),'mine':next((r for r in self.rooms.list(uid,'mine')if r['mine']),None)}
    async def create(self,request,uid):
        body=await self.body(request);name=' '.join(str(body.get('name')or'').split())[:60];require(name,'name_required',400);self.rooms.account(uid)
        room=self.store.create(uid,name);return{'ok':True,'room':self.rooms.summary(room,uid)}
    async def profile(self,request,uid):
        code=str(request.query.get('code')or'').upper();room=self.store.room(code);require(room and self.rooms.visible(code,uid),'room_forbidden')
        return{'ok':True,'room':{**self.rooms.summary(room,uid),'settings':room['settings'],'role':self.rooms.role(room,uid),'ownerProfile':self.rooms.community.public(room['owner'],uid),'event':self.store.one('SELECT *FROM wkc_events WHERE code=?',(code,))}}
    async def contacts(self,request,uid):
        self.rooms.account(uid);return{'ok':True,'items':self.rooms.community.friends(uid).get('friends',[])[:100]}
    async def invite(self,request,uid):
        body=await self.body(request);session=self.session(uid,body);room=self.store.room(session.code);permissions=self.rooms.permissions(room,uid,session.seat);target=int(body.get('uid')or 0);require(permissions['share'],'sharing_disabled');require(target!=uid and self.rooms.friend(uid,target),'friend_required');self.rooms.account(target);self.me.slow(uid,'cinema_invite',12,60)
        key=str(body.get('key')or'');require(re.fullmatch(r'[a-f0-9]{32}',key),'bad_key',400);people=self.rooms.community;people.send_dm(uid,{'uid':target,'client_key':key,'text':'دعوت به '+room['name']+' · '+session.code})
        with self.store.db:self.store.db.execute("INSERT OR IGNORE INTO wkc_members VALUES(?,?,'member','invite',?)",(session.code,target,time.time()))
        self.store.bump(session.code);await self.broadcast(session.code);return{'ok':True}
    async def follow(self,request,uid):
        b=await self.body(request);code=str(b.get('code')or'').upper();require(self.rooms.visible(code,uid),'room_forbidden');require(type(b.get('on'))is bool,'bad_input',400);self.store.follow(uid,code,b['on']);return{'ok':True,'favorite':b['on']}
    async def join(self,request,uid):
        self.me.slow(uid,'cinema_join',30,60);b=await self.body(request);code=str(b.get('code')or'').upper();require(CODE.fullmatch(code),'bad_code',400)
        try:s=self.rooms.join(uid,code,auto_seat=b.get('seat')is True)
        except CinemaError as error:
            if error.code=='knock_required':self.store.bump(code);await self.broadcast(code)
            raise
        await self.broadcast(code)
        return{'ok':True,'snapshot':self.snapshot(s)}
    async def events(self,request,uid):
        s=self.session(uid,request.query);self.rooms.touch(s);s.acknowledged=max(s.acknowledged,min(int(request.query.get('message',s.floor)),(self.store.one('SELECT max(id)AS n FROM wkc_messages WHERE code=?',(s.code,))or{}).get('n')or 0))
        return{'ok':True,'snapshot':self.snapshot(s)}
    async def command(self,request,uid):
        b=await self.body(request);s=self.session(uid,b);key=str(b.get('key')or'');kind=str(b.get('kind')or'');payload=b.get('payload')or{}
        require(KEY.fullmatch(key)and isinstance(payload,dict),'bad_command',400);self.me.slow(uid,'cinema_command',120,60)
        lock=self.locks.setdefault(s.code,asyncio.Lock())
        async with lock:
            cached=self.store.cached(uid,key,s.code)
            if cached:return{**cached,'snapshot':self.snapshot(s)}
            self.rooms.touch(s);result=await self.commands.execute(s,kind,payload,key);self.store.remember(uid,key,s.code,result)
            if not result.get('left'):result={**result,'snapshot':self.snapshot(s)}
        await self.broadcast(s.code);return result
    async def connect(self,request,uid):
        self.me.slow(uid,'cinema_connect',30,60);s=self.session(uid,await self.body(request));ticket=secrets.token_urlsafe(32);self.tickets[ticket]=(s.id,uid,time.monotonic()+30)
        if len(self.tickets)>2000:self.tickets={k:v for k,v in self.tickets.items()if v[2]>time.monotonic()}
        return{'ok':True,'url':self.origin.replace('https://','wss://',1).replace('http://','ws://',1)+PREFIX+'/room/live?'+urlencode({'ticket':ticket})}
    async def relay(self,session,to,data):
        require(isinstance(data,dict)and len(json.dumps(data))<40000,'bad_signal',400)
        target=next((s for s in self.rooms.peers(session)if s.uid==int(to)and s.uid!=session.uid),None);require(target,'peer_gone',409)
        require(session.seat>=0 or target.seat>=0,'voice_forbidden')
        event={'type':'signal','from':session.uid,'data':data}
        if target.socket and not target.socket.closed:await target.socket.send_json(event)
        else:target.signals=(target.signals+[event])[-64:]
        return{'ok':True}
    async def signal(self,request,uid):
        b=await self.body(request);s=self.session(uid,b);return await self.relay(s,b.get('to'),b.get('data'))
    async def live(self,request):
        ticket=self.tickets.pop(str(request.query.get('ticket')or''),None)
        if not ticket or ticket[2]<time.monotonic():raise web.HTTPUnauthorized()
        sid,uid,_=ticket;s=self.rooms.sessions.get(sid)
        if not s:raise web.HTTPUnauthorized()
        self.rooms.get(uid,s.code,sid);ws=web.WebSocketResponse(heartbeat=25,max_msg_size=50000);await ws.prepare(request)
        if s.socket and not s.socket.closed:await s.socket.close(code=4000,message=b'replaced')
        s.socket=ws;self.rooms.touch(s);await ws.send_json({'type':'snapshot','snapshot':self.snapshot(s)})
        queued,s.signals=s.signals,[]
        for event in queued:await ws.send_json(event)
        try:
            async for message in ws:
                if message.type!=web.WSMsgType.TEXT:continue
                try:
                    self.rooms.get(uid,s.code,s.id);data=json.loads(message.data);require(isinstance(data,dict),'bad_frame',400);self.rooms.touch(s)
                    if data.get('type')in {'ack','heartbeat'}:
                        last=int(data.get('message')or s.floor);maximum=(self.store.one('SELECT max(id)AS n FROM wkc_messages WHERE code=?',(s.code,))or{}).get('n')or 0;s.acknowledged=max(s.acknowledged,min(last,maximum))
                        if maximum>s.acknowledged:await ws.send_json({'type':'snapshot','snapshot':self.snapshot(s)})
                    elif data.get('type')=='signal':await self.relay(s,data.get('to'),data.get('data'))
                except(CinemaError,ValueError,TypeError,KeyError)as error:
                    if getattr(error,'code','')in {'session_expired','room_forbidden','account_unavailable'}:await ws.close(code=4003);break
                    await ws.send_json({'type':'error','code':getattr(error,'code','bad_frame')})
        finally:
            if s.socket is ws:s.socket=None
        return ws
    async def library(self,request,uid):
        source=request.query.get('source','archive');query=str(request.query.get('q')or'')[:100];self.me.slow(uid,'cinema_search',40,60)
        if source=='youtube':items=await self.catalog.youtube(query or'موسیقی افغانستان فارسی دری')
        elif source=='archive':items=self.catalog.archive(query,request.query.get('page',0))
        else:raise CinemaError('bad_source')
        return{'ok':True,'items':items,'source':source}
    async def link(self,request,uid):
        body=await self.body(request);raw=str(body.get('url')or'')[:500];self.me.slow(uid,'cinema_link',20,60);media=await self.catalog.resolve({'url':raw})
        item={'id':media.get('provider_id')or media['id'],'provider':media['provider'],'provider_id':media.get('provider_id'),'title':media['title'],'cover':media.get('cover'),'duration':media.get('duration')}
        return{'ok':True,'items':[item]}
    async def detail(self,request,uid):return{'ok':True,'item':self.catalog.details(uid,str(request.query.get('id')or''))}
    async def play(self,request,uid):
        b=await self.body(request);media=await self.catalog.resolve(b.get('item')or{});history=self.store.one('SELECT position FROM wkc_history WHERE uid=?AND item=?',(uid,media['id']));position=float(history['position'])if history else 0;position=position if not media.get('duration')or position<media['duration']-3 else 0;return{'ok':True,'media':self.catalog.present({**media,'playing':True,'position':position,'version':1},uid,None)}
    async def history(self,request,uid):
        rows=self.store.rows('SELECT *FROM wkc_history WHERE uid=?ORDER BY ts DESC LIMIT 100',(uid,))
        items=[]
        for row in rows:
            media=json.loads(row['media']);items.append({**media,'id':media.get('provider_id')or media['id'],'episode':media.get('episode',''),'version':media.get('version_id',''),'position':row['position']})
        return{'ok':True,'items':items}
    async def progress(self,request,uid):
        b=await self.body(request);reference=b.get('item')or{};media=await self.catalog.resolve(reference);position=max(0,min(21600,float(b.get('position')or 0)))
        with self.store.db:self.store.db.execute('INSERT INTO wkc_history VALUES(?,?,?,?,?)ON CONFLICT(uid,item)DO UPDATE SET media=excluded.media,position=excluded.position,ts=excluded.ts',(uid,media['id'],json.dumps(media),position,time.time()))
        return{'ok':True}
    async def report(self,request,uid):
        b=await self.body(request);code=str(b.get('code')or'');room=self.store.room(code);require(room,'not_found',404);reason=str(b.get('reason')or'');require(reason in {'content','harassment','spam','other'},'bad_reason',400);self.me.slow(uid,'cinema_report',5,3600)
        with self.store.db:self.store.db.execute('INSERT INTO wka_reports(reporter,target,hall,reason,note,ts)VALUES(?,?,?,?,?,?)',(uid,room['owner'],code,reason,str(b.get('note')or'')[:300],int(time.time())))
        return{'ok':True}
    async def youtube_player(self,request):
        video=str(request.query.get('id')or'');channel=str(request.query.get('channel')or'')
        if not(YT_ID.fullmatch(video)and re.fullmatch(r'[A-Za-z0-9_-]{1,80}',channel)):raise web.HTTPBadRequest()
        nonce=secrets.token_urlsafe(20);html=Path(__file__).with_name('youtube.html').read_text().replace('__NONCE__',nonce)
        return web.Response(text=html,content_type='text/html',headers={'Cache-Control':'no-store','Referrer-Policy':'strict-origin-when-cross-origin','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; script-src 'nonce-"+nonce+"' https://www.youtube.com https://s.ytimg.com; style-src 'nonce-"+nonce+"'; frame-src https://www.youtube.com https://www.youtube-nocookie.com; connect-src https://www.youtube.com; img-src https: data:; frame-ancestors * capacitor://localhost https://localhost"})
    async def soundcloud_player(self,request):
        from urllib.parse import urlsplit
        raw=str(request.query.get('url')or'');u=urlsplit(raw);channel=str(request.query.get('channel')or'')
        if u.scheme!='https'or u.hostname!='soundcloud.com'or u.username or u.password or u.port or not re.fullmatch(r'/[A-Za-z0-9_-]{1,160}/[A-Za-z0-9_-]{1,160}',u.path)or u.query or u.fragment or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',channel):raise web.HTTPBadRequest()
        nonce=secrets.token_urlsafe(20);html=Path(__file__).with_name('soundcloud.html').read_text().replace('__NONCE__',nonce)
        return web.Response(text=html,content_type='text/html',headers={'Cache-Control':'no-store','Referrer-Policy':'strict-origin-when-cross-origin','Content-Security-Policy':"default-src 'none'; script-src 'nonce-"+nonce+"' https://w.soundcloud.com; style-src 'nonce-"+nonce+"'; frame-src https://w.soundcloud.com; frame-ancestors * capacitor://localhost https://localhost"})
    def routes(self,app):
        handlers=[('GET','salons/contacts',self.contacts),('POST','salons/invite',self.invite),('POST','room/upload',self.assets.upload),('GET','room/gifts',self.gifts.catalog),('POST','room/gifts/quote',self.gifts.quote),('POST','room/gifts/send',self.gifts.send),('GET','salons',self.salons),('POST','salons/create',self.create),('GET','salons/profile',self.profile),('POST','salons/follow',self.follow),('POST','salons/report',self.report),('POST','room/join',self.join),('GET','room/events',self.events),('POST','room/command',self.command),('POST','room/connect',self.connect),('POST','room/signal',self.signal),('GET','library',self.library),('POST','library/link',self.link),('GET','library/title',self.detail),('POST','library/play',self.play),('GET','library/history',self.history),('POST','library/progress',self.progress)]
        for method,path,handler in handlers:app.router.add_route(method,PREFIX+'/'+path,self.me.handler(handler))
        app.router.add_get(PREFIX+'/photo/{key}',self.assets.photo);app.router.add_get(PREFIX+'/room/live',self.live);app.router.add_get(PREFIX+'/player/youtube',self.youtube_player);app.router.add_get(PREFIX+'/player/soundcloud',self.soundcloud_player)
        async def media_file(request):
            try:return await self.files.file(request)
            except CinemaError as error:return web.json_response({'ok':False,'err':error.code},status=error.status)
        app.router.add_get(PREFIX+'/media/file',media_file)
        async def lifecycle(application):
            if self.workers:self.task=asyncio.create_task(self.sweep())
            yield
            await self.close()
        app.cleanup_ctx.append(lifecycle)
    async def sweep(self):
        while not self.stopped:
            await asyncio.sleep(5)
            changed=set()
            for session in list(self.rooms.sessions.values()):
                if time.time()-session.seen>=120:self.rooms.leave(session);changed.add(session.code)
            for row in self.store.rows('SELECT code FROM wkc_playback WHERE playing=1'):
                code=row['code'];media=self.store.playback(code)
                if media and media.get('duration')and media['position']>=media['duration']:
                    room=self.store.room(code)
                    if room:
                        from .rooms import Session
                        lock=self.locks.setdefault(code,asyncio.Lock())
                        async with lock:
                            latest=self.store.playback(code)
                            if latest and latest['id']==media['id']and latest.get('cycle')==media.get('cycle'):
                                try:await self.commands.execute(Session('clock',room['owner'],code,time.time()),'ended',{'id':media['id'],'cycle':media.get('cycle',0)},'clock');changed.add(code)
                                except CinemaError:pass
            for code in changed:await self.broadcast(code)
    async def close(self):
        self.stopped=True
        if self.task:self.task.cancel();await asyncio.gather(self.task,return_exceptions=True)
        for s in list(self.rooms.sessions.values()):
            if s.socket:await s.socket.close(code=1001)
        await self.catalog.close();await self.files.close()
