"""Room gifts use the existing account ledger, catalogue, quotes and XP deduplication."""
import json,re,time
from .commands import require
class Gifts:
 def __init__(self,service):self.s=service
 def target(self,uid,b):
  session=self.s.session(uid,b);target=int(b.get('uid')or 0);room=session.code;people=self.s.rooms.community
  from wakhan_community_catalog_v70 import GIFTS
  item=GIFTS.get(b.get('gift'));require(item and target!=uid,'bad_gift',400);require(any(s.uid==target and s.seat>=0 for s in self.s.rooms.peers(session)),'recipient_left',409);require(not people.blocked(uid,target),'blocked')
  return session,target,item
 async def catalog(self,request,uid):
  from wakhan_community_catalog_v70 import GIFTS
  return{'ok':True,'items':list(GIFTS.values())}
 async def quote(self,request,uid):
  b=await self.s.body(request);session,target,item=self.target(uid,b);value={'purpose':'cinema_v2_gift','uid':uid,'target':target,'room':session.code,'gift':item['code'],'units':item['units'],'expires':int(time.time())+180};people=self.s.rooms.community
  return{'ok':True,'token':people.personal.sign(value),'gift':item,'recipient':people.public(target,uid)}
 async def send(self,request,uid):
  return await self.s.rooms.community.gift(uid,await self.s.body(request))
 async def commit(self,uid,b):
  key=str(b.get('key')or'');require(re.fullmatch(r'[A-Za-z0-9_-]{8,80}',key),'bad_key',400);session,target,item=self.target(uid,b);people=self.s.rooms.community;request_key='cinema-v2:'+key
  old=self.s.store.one('SELECT id,target,meta FROM wm_coin_ops WHERE uid=?AND request_key=?',(uid,request_key))
  if old:
   meta=json.loads(old['meta']);require(old['target']==target and meta.get('room')==session.code and meta.get('gift')==item['code'],'intent_mismatch',409);return{'ok':True,'id':old['id'],'duplicate':True}
  try:value=people.personal.verify(b.get('token'),'cinema_v2_gift')
  except(ValueError,TypeError,KeyError):require(False,'quote_invalid',409)
  require((value.get('uid'),value.get('target'),value.get('room'),value.get('gift'),value.get('units'))==(uid,target,session.code,item['code'],item['units']),'quote_invalid',409);self.s.me.slow(uid,'cinema_gift',6,10)
  with self.s.store.db:
   oid,created=people.wallet.move('gift',uid,target,item['units'],request_key,{'gift':item['code'],'room':session.code,'source':'cinema-v2'})
   if created:
    self.s.store.db.execute('INSERT INTO wm70_cinema_gifts VALUES(?,?,?,?,?,?)',(oid,session.code,uid,target,item['code'],int(time.time())))
    self.s.store.db.execute("INSERT INTO wkc_messages(code,uid,kind,body,key,ts)VALUES(?,?,'gift',?,?,?)",(session.code,uid,json.dumps({'text':str(item.get('name')or item['code']),'gift':item['code'],'target':target}),'gift:'+str(oid),time.time()))
  if created:
   self.s.store.bump(session.code);await self.s.broadcast(session.code)
  return{'ok':True,'id':oid,'duplicate':not created}
