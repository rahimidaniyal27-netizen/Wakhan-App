"""Provider discovery and a typed media contract; no retired Cinema resolver."""
import asyncio
import json
import re
import sys
import time
from urllib.parse import parse_qs,urlsplit,urlencode
from .store import CinemaError
YT_ID=re.compile(r'^[A-Za-z0-9_-]{11}$')

def youtube_id(value):
    value=str(value or'').strip()
    if YT_ID.fullmatch(value):return value
    try:
        u=urlsplit(value)
        if u.scheme!='https'or u.username or u.password:return None
        host=(u.hostname or'').lower()
        if host=='youtu.be':candidate=u.path.strip('/').split('/')[0]
        elif host in {'youtube.com','www.youtube.com','m.youtube.com','music.youtube.com'}:
            candidate=(parse_qs(u.query).get('v')or[''])[0]if u.path=='/watch'else u.path.strip('/').split('/')[-1]
        else:return None
        return candidate if YT_ID.fullmatch(candidate)else None
    except ValueError:return None

class CinemaCatalog:
    def __init__(self,store,*,origin='https://music.kabulcafe.uk',extract=None):
        self.store,self.origin=store,origin.rstrip('/');self.extract=extract or self._youtube;self.jobs=asyncio.Semaphore(2);self.cache={};self.pending={};self.streaming=None
    async def _youtube(self,query):
        async with self.jobs:
            process=await asyncio.create_subprocess_exec(sys.executable,'-m','yt_dlp','--dump-single-json','--flat-playlist','--skip-download','--no-warnings','--quiet','--socket-timeout','10','--retries','1','--playlist-end','24','ytsearch24:'+query,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
            try:out,err=await asyncio.wait_for(process.communicate(),25)
            except (asyncio.TimeoutError,asyncio.CancelledError) as error:
                process.kill();await process.communicate()
                if isinstance(error,asyncio.CancelledError):raise
                raise CinemaError('youtube_timeout',504)
            if process.returncode or len(out)>2_000_000:raise CinemaError('youtube_unavailable',502)
            value=json.loads(out);items=[]
            for item in value.get('entries')or[]:
                video=str(item.get('id')or'')
                if YT_ID.fullmatch(video):items.append({'id':'yt:'+video,'provider':'youtube','provider_id':video,'title':str(item.get('title')or'YouTube')[:200],'artist':str(item.get('channel')or item.get('uploader')or'')[:100],'cover':'https://i.ytimg.com/vi/'+video+'/hqdefault.jpg','duration':max(0,float(item.get('duration')or 0))})
            return items
    async def youtube(self,query):
        query=' '.join(str(query).split())[:100]
        if not query:return[]
        now=time.monotonic();cached=self.cache.get(query)
        if cached and now-cached[0]<300:return cached[1]
        if query not in self.pending:
            async def fetch():
                try:
                    items=await self.extract(query);self.cache[query]=(time.monotonic(),items)
                    while len(self.cache)>100:self.cache.pop(next(iter(self.cache)))
                    return items
                finally:self.pending.pop(query,None)
            self.pending[query]=asyncio.create_task(fetch())
        return await asyncio.shield(self.pending[query])
    def archive(self,q='',page=0):
        if not self.store.exists('wks_titles'):return[]
        page=max(0,min(100,int(page)));query='%'+str(q).replace('\\','\\\\').replace('%','\\%').replace('_','\\_')[:100]+'%'
        rows=self.store.rows("SELECT id,kind,title,poster,backdrop,year,descr,genres,cat,score FROM wks_titles WHERE title LIKE ? ESCAPE '\\' ORDER BY score DESC,id LIMIT 24 OFFSET ?",(query,page*24))
        for row in rows:row.update(provider='archive',cover=row.get('poster')or row.get('backdrop')or'',description=row.pop('descr',''))
        return rows
    def details(self,uid,tid):
        title=self.store.one('SELECT *FROM wks_titles WHERE id=?',(tid,))if self.store.exists('wks_titles')else None
        if not title:raise CinemaError('not_found',404)
        title.update(provider='archive',cover=title.get('poster')or title.get('backdrop')or'')
        title['episodes']=self.store.rows('SELECT ep,max(s)AS season,max(e)AS episode,max(title)AS title,max(dur)AS duration FROM wks_sources WHERE tid=?GROUP BY ep ORDER BY season,episode,ep',(tid,))
        title['versions']=self.versions(tid,'')
        return title
    def versions(self,tid,episode):
        if not self.store.exists('wks_sources'):return[]
        return self.store.rows('SELECT sid AS id,provider,lang,sub,q AS quality,rights FROM wks_sources WHERE tid=?AND ep=?ORDER BY ts DESC',(tid,str(episode or'')))
    async def resolve(self,reference,*,room=None):
        provider=str(reference.get('provider')or'');raw=str(reference.get('provider_id')or reference.get('id')or reference.get('url')or'');video=youtube_id(raw.removeprefix('yt:'))if provider=='youtube'or'youtu'in raw else None
        if video:
            known=next((item for _,items in self.cache.values()for item in items if item.get('provider_id')==video),None)
            return {**(known or{}),'id':'yt:'+video,'provider':'youtube','provider_id':video,'title':(known or{}).get('title')or str(reference.get('title')or'YouTube')[:200],'cover':'https://i.ytimg.com/vi/'+video+'/hqdefault.jpg','duration':float((known or{}).get('duration')or 0),'cycle':0,'source':{'kind':'youtube','embed':self.origin+'/api/app/cinema/v2/player/youtube?'+urlencode({'id':video})}}
        if provider=='soundcloud'or raw.startswith('https://soundcloud.com/')or raw.startswith('https://www.soundcloud.com/'):
            parsed=urlsplit(raw);parts=parsed.path.strip('/').split('/')
            if parsed.scheme!='https'or parsed.hostname not in {'soundcloud.com','www.soundcloud.com'}or parsed.username or parsed.password or parsed.port or len(parts)!=2 or not all(re.fullmatch(r'[A-Za-z0-9_-]{1,160}',v)for v in parts):raise CinemaError('bad_soundcloud')
            link='https://soundcloud.com/'+ '/'.join(parts)
            return{'id':'sc:'+link,'provider':'soundcloud','provider_id':link,'title':str(reference.get('title')or parts[-1].replace('-',' '))[:200],'duration':0,'cover':'','cycle':0,'source':{'kind':'soundcloud','embed':self.origin+'/api/app/cinema/v2/player/soundcloud?'+urlencode({'url':link})}}
        tid=str(reference.get('id')or'');ep=str(reference.get('episode')or'');sid=str(reference.get('version')or'')
        if provider=='archive':
            rows=self.store.rows('SELECT *FROM wks_sources WHERE tid=?AND ep=?'+('AND sid=?'if sid else'')+"ORDER BY rights='room'DESC,ts DESC",(tid,ep,sid)if sid else(tid,ep))
            allowed=[r for r in rows if r['rights']=='room'or not room and r['rights']in {'room','personal'}]
            if not allowed:raise CinemaError('no_licensed_source',403)
            row=allowed[0];title=self.details(0,tid)
            return {'id':'archive:'+tid+':'+ep+':'+row['sid'],'provider':'archive','provider_id':tid,'episode':ep,'version_id':row['sid'],'title':row.get('title')or title['title'],'cover':row.get('thumb')or title['cover'],'duration':float(row.get('dur')or 0),'cycle':0,'source':{'kind':'file','catalog_source':row['sid'],'catalog_title':tid,'catalog_episode':ep}}
        aparat=None
        if provider=='aparat':aparat=raw.removeprefix('aparat:')
        elif raw.startswith('https://'):
            parsed=urlsplit(raw)
            if parsed.hostname in {'aparat.com','www.aparat.com'}and not parsed.username and parsed.path.startswith('/v/'):aparat=parsed.path.strip('/').split('/')[-1]
        if aparat and re.fullmatch(r'[A-Za-z0-9]{3,40}',aparat):
            return {'id':'aparat:'+aparat,'provider':'aparat','provider_id':aparat,'title':str(reference.get('title')or'Aparat')[:200],'cover':'','duration':0,'cycle':0,'source':{'kind':'file','provider_id':aparat}}
        raise CinemaError('unsupported_source')
    def present(self,media,uid,room):
        return self.streaming.present(media,uid,room)if self.streaming else dict(media)
    async def close(self):
        for task in list(self.pending.values()):task.cancel()
        if self.pending:await asyncio.gather(*self.pending.values(),return_exceptions=True)
