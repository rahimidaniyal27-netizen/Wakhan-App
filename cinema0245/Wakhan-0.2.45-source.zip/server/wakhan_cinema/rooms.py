import asyncio
import secrets
import time
from dataclasses import dataclass,field
from .store import CinemaError

@dataclass
class Session:
    id:str
    uid:int
    code:str
    seen:float
    floor:int=0
    acknowledged:int=0
    seat:int=-1
    socket:object=None
    muted:bool=True
    signals:list=field(default_factory=list)

class Rooms:
    def __init__(self,store,community,*,now=time.time):
        self.store,self.community,self.now=store,community,now
        self.sessions={};self.hall=self
    def account(self,uid):
        row=self.store.one('SELECT done,blocked FROM wka_accounts WHERE uid=?',(uid,))
        if not row or not row['done']or row['blocked']:raise CinemaError('account_unavailable',403)
    def friend(self,a,b):
        return a==b or self.community.relation(a,b)=='accepted'
    def member(self,code,uid):
        r=self.store.room(code)
        return bool(r and(r['owner']==uid or self.store.one('SELECT uid FROM wkc_members WHERE code=?AND uid=?',(code,uid))))
    def role(self,room,uid):
        if uid==room['owner']:return'owner'
        row=self.store.one('SELECT role FROM wkc_members WHERE code=?AND uid=?',(room['code'],uid))
        return row['role']if row else'guest'
    def forbidden(self,code,uid,kind):
        return bool(self.store.one('SELECT uid FROM wkc_rules WHERE code=?AND uid=?AND kind=?',(code,uid,kind)))
    def visible(self,code,uid,info=None):
        r=self.store.room(code)
        if not r:return False
        owner=self.store.one('SELECT done,blocked FROM wka_accounts WHERE uid=?',(r['owner'],))
        if not owner or not owner['done']or owner['blocked']:return False
        if self.store.exists('wka_disabled_halls')and self.store.one('SELECT code FROM wka_disabled_halls WHERE code=?',(code,)):return False
        if r['owner']==uid:return True
        if self.forbidden(code,uid,'ban'):return False
        return r['settings']['privacy']=='public'or self.member(code,uid)or r['settings']['privacy']=='friends'and self.friend(r['owner'],uid)
    def present(self,code):
        return list({s.uid for s in self.sessions.values()if s.code==code and self.now()-s.seen<120})
    def owner_of(self,code):
        row=self.store.room(code);return row['owner']if row else None
    def permissions(self,room,uid,seat=-1):
        role=self.role(room,uid);owner=role=='owner';assistant=role=='assistant';code=room['code'];settings=room['settings']
        return {'owner':owner,'control':owner or assistant,'moderate':owner,'mic':seat>=0 and not self.forbidden(code,uid,'mic')and(owner or settings['mic']=='free'or self.forbidden(code,uid,'mic_grant')),'chat':not self.forbidden(code,uid,'chat')and(owner or settings['chat']),'share':owner or settings['share'],'assistant':assistant}
    def join(self,uid,code,*,auto_seat=False):
        self.account(uid);room=self.store.room(code)
        if not room:raise CinemaError('not_found',404)
        if not self.visible(code,uid):raise CinemaError('private_room',403)
        for session in self.sessions.values():
            if session.uid==uid and session.code==code and self.now()-session.seen<120:
                session.seen=self.now();return session
        settings=room['settings'];owner=uid==room['owner'];admitted=self.store.one("SELECT uid FROM wkc_knocks WHERE code=?AND uid=?AND status='admitted'",(code,uid))
        if settings['approval']and not owner and not self.member(code,uid)and not admitted:
            with self.store.db:self.store.db.execute("INSERT INTO wkc_knocks VALUES(?,?,'waiting',?)ON CONFLICT(code,uid)DO UPDATE SET status='waiting',ts=excluded.ts",(code,uid,self.now()))
            raise CinemaError('knock_required',409)
        if settings['capacity']and len(self.present(code))>=settings['capacity']and not owner:raise CinemaError('room_full',409)
        floor=(self.store.one('SELECT max(id)AS id FROM wkc_messages WHERE code=?',(code,))or{}).get('id')or 0
        session=Session(secrets.token_urlsafe(24),uid,code,self.now(),floor,floor)
        occupied={s.seat for s in self.sessions.values()if s.code==code and s.seat>=0 and self.now()-s.seen<120}
        if auto_seat or owner:
            session.seat=next((i for i in range(settings['seats'])if i not in occupied and(i not in settings['locks']or owner)),-1)
        self.sessions[session.id]=session
        with self.store.db:self.store.db.execute("INSERT OR IGNORE INTO wkc_members VALUES(?,?,'member','join',?)",(code,uid,self.now()))
        with self.store.db:self.store.db.execute('INSERT INTO wkc_visits VALUES(?,?,?)ON CONFLICT(uid,code)DO UPDATE SET ts=excluded.ts',(uid,code,self.now()))
        self.store.bump(code);return session
    def get(self,uid,code,sid):
        session=self.sessions.get(str(sid));self.account(uid)
        if not session or session.uid!=uid or session.code!=code or self.now()-session.seen>=120:raise CinemaError('session_expired',409)
        if not self.visible(code,uid):raise CinemaError('room_forbidden',403)
        return session
    def touch(self,session):session.seen=self.now()
    def leave(self,session):
        self.sessions.pop(session.id,None);self.store.bump(session.code)
        if session.socket and not session.socket.closed:
            try:asyncio.get_running_loop().create_task(session.socket.close(code=4003,message=b'left'))
            except RuntimeError:pass
    def peers(self,session):
        return [s for s in self.sessions.values()if s.code==session.code and self.now()-s.seen<120]
    def summary(self,room,viewer):
        code=room['code'];people=self.present(code);media=self.store.playback(code);settings=room['settings']
        return {'code':code,'owner':room['owner'],'name':room['name'],'notice':room['notice'],'photo':settings.get('photo')or None,'seats':settings['seats'],'live':len(people),'present':len(people),'status':'watching'if media and media['playing']else'talking'if people else'idle','mine':room['owner']==viewer,'favorite':bool(self.store.one('SELECT uid FROM wkc_follows WHERE uid=?AND code=?',(viewer,code))),'privacy':settings['privacy'],'approval':settings['approval']}
    def directory(self,uid,query=''):
        return [self.summary(r,uid)for r in self.all()if self.visible(r['code'],uid)and(query.casefold()in r['name'].casefold()or query.upper()in r['code'])]
    def all(self):
        return [self.store.room(r['code'])for r in self.store.rows('SELECT code FROM wkc_rooms ORDER BY ts DESC')]
    def info(self,code,uid):
        room=self.store.room(code);return self.summary(room,uid)if room and self.visible(code,uid)else None
    def row(self,code,uid,info=None):return self.info(code,uid)
    def list(self,uid,section='mine',q=''):
        rooms=self.directory(uid,q);followed={r['code']for r in self.store.rows('SELECT code FROM wkc_follows WHERE uid=?',(uid,))};joined={r['code']for r in self.store.rows('SELECT code FROM wkc_members WHERE uid=?',(uid,))};visits={r['code']:r['ts']for r in self.store.rows('SELECT code,ts FROM wkc_visits WHERE uid=?',(uid,))}
        if section=='mine':rooms=[r for r in rooms if r['mine']or r['code']in followed]
        elif section=='followed':rooms=[r for r in rooms if r['code']in followed]
        elif section=='joined':rooms=[r for r in rooms if r['code']in joined]
        elif section=='recent':rooms=[r for r in rooms if r['code']in visits];rooms.sort(key=lambda r:-visits[r['code']])
        elif section!='discover':raise CinemaError('bad_section')
        if section!='recent':rooms.sort(key=lambda r:(not r['mine'],-r['live'],r['name']))
        return rooms[:100]
    def wipe(self,uid):
        for session in list(self.sessions.values()):
            if session.uid==uid or self.owner_of(session.code)==uid:self.leave(session)
        with self.store.db:
            for table in ['wkc_follows','wkc_members','wkc_visits','wkc_rules','wkc_knocks','wkc_commands','wkc_history']:self.store.db.execute('DELETE FROM '+table+' WHERE uid=?',(uid,))
            self.store.db.execute('DELETE FROM wkc_rooms WHERE owner=?',(uid,))
    def snapshot(self,session,catalog):
        room=self.store.room(session.code);members=[]
        for s in self.peers(session):
            profile=self.community.public(s.uid,session.uid)
            members.append({'id':s.uid,'name':profile.get('name')or'کاربر','avatar':profile.get('avatar'),'appearance':profile.get('halo'),'seat':s.seat,'muted':s.muted,'role':self.role(room,s.uid)})
        media=self.store.playback(session.code)
        if media:media=catalog.present(media,session.uid,session.code)
        messages=self.store.messages(session.code,max(session.floor,session.acknowledged))
        recent=self.store.rows('SELECT *FROM wkc_messages WHERE code=?AND id>?AND id<=?ORDER BY id DESC LIMIT 100',(session.code,session.floor,session.acknowledged))
        for item in recent:item['body']=__import__('json').loads(item['body'])
        messages=sorted(recent+messages,key=lambda item:item['id'])
        for message in messages:
            profile=self.community.public(message['uid'],session.uid)if message['uid']else{}
            message['sender']={'id':message['uid'],'name':profile.get('name')or'واخان','avatar':profile.get('avatar')}
        return {'account':session.uid,'room':{**self.summary(room,session.uid),'settings':room['settings']},'session':session.id,'revision':room['revision'],'serverTime':self.now(),'permissions':self.permissions(room,session.uid,session.seat),'members':members,'messages':messages,'queue':self.store.queue(session.code),'media':media,'notice':room['notice'],'knocks':self.store.rows("SELECT uid,ts FROM wkc_knocks WHERE code=?AND status='waiting'",(session.code,))if session.uid==room['owner']else[]}
