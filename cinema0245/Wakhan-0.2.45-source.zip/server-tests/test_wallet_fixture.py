"""Test only: unchanged shared wallet ledger primitives; never part of the deployed Cinema package."""
import json,time
from decimal import Decimal as D
LEDGER_SCHEMA="\n        CREATE TABLE IF NOT EXISTS wm_coin_accounts(uid INTEGER PRIMARY KEY,balance INTEGER NOT NULL DEFAULT 0,\n          CHECK(typeof(balance)='integer'),CHECK(uid=0 OR balance>=0));\n        CREATE TABLE IF NOT EXISTS wm_coin_ops(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,\n          uid INTEGER NOT NULL,target INTEGER NOT NULL,units INTEGER NOT NULL CHECK(units>0),\n          request_key TEXT NOT NULL,meta TEXT NOT NULL,ts INTEGER NOT NULL,UNIQUE(uid,request_key));\n        CREATE TABLE IF NOT EXISTS wm_coin_entries(op INTEGER NOT NULL,uid INTEGER NOT NULL,\n          delta INTEGER NOT NULL CHECK(delta!=0),PRIMARY KEY(op,uid));\n        CREATE INDEX IF NOT EXISTS wm_coin_user ON wm_coin_entries(uid,op);\n        CREATE TABLE IF NOT EXISTS wm_coin_topups(id INTEGER PRIMARY KEY AUTOINCREMENT,uid INTEGER NOT NULL,\n          months INTEGER NOT NULL DEFAULT 0,units INTEGER NOT NULL CHECK(units>0),cur TEXT NOT NULL,\n          amount TEXT NOT NULL,proof TEXT NOT NULL DEFAULT '',status TEXT NOT NULL,ts INTEGER NOT NULL);\n        CREATE TABLE IF NOT EXISTS wm_coin_charges(charge TEXT PRIMARY KEY,oid INTEGER,uid INTEGER NOT NULL,\n          stars INTEGER NOT NULL,state TEXT NOT NULL,ts INTEGER NOT NULL);\n        CREATE TABLE IF NOT EXISTS wm_coin_purchases(id INTEGER PRIMARY KEY,uid INTEGER NOT NULL,product TEXT NOT NULL,\n          cid INTEGER NOT NULL,months INTEGER NOT NULL,cur TEXT NOT NULL DEFAULT 'coins',amount TEXT NOT NULL,\n          status TEXT NOT NULL DEFAULT 'ok',ts INTEGER NOT NULL);\n        CREATE TRIGGER IF NOT EXISTS wm_coin_entry_update BEFORE UPDATE ON wm_coin_entries\n          BEGIN SELECT RAISE(ABORT,'immutable_coin_ledger');END;\n        CREATE TRIGGER IF NOT EXISTS wm_coin_entry_delete BEFORE DELETE ON wm_coin_entries\n          BEGIN SELECT RAISE(ABORT,'immutable_coin_ledger');END;\n        CREATE TRIGGER IF NOT EXISTS wm_coin_op_update BEFORE UPDATE ON wm_coin_ops\n          BEGIN SELECT RAISE(ABORT,'immutable_coin_operation');END;\n        CREATE TRIGGER IF NOT EXISTS wm_coin_op_delete BEFORE DELETE ON wm_coin_ops\n          BEGIN SELECT RAISE(ABORT,'immutable_coin_operation');END;\n        "
class WalletFixture:

    @staticmethod
    def amount(units):
        return format(D(units) / 100, '.2f')

    def balance(self, uid):
        row = self.db.execute('SELECT balance FROM wm_coin_accounts WHERE uid=?', (uid,)).fetchone()
        return row[0] if row else 0

    def move(self, kind, uid, target, units, key, meta):
        old = self.db.execute('SELECT id,kind,target,units,meta FROM wm_coin_ops WHERE uid=? AND request_key=?', (uid, key)).fetchone()
        encoded = json.dumps(meta, sort_keys=True, separators=(',', ':'))
        if old:
            if old[1:] != (kind, target, units, encoded):
                raise ValueError('intent_mismatch')
            return (old[0], False)
        if type(units) is not int or units <= 0 or uid == target:
            raise ValueError('bad')
        for account in (uid, target):
            self.db.execute('INSERT OR IGNORE INTO wm_coin_accounts(uid) VALUES(?)', (account,))
        result = self.db.execute('UPDATE wm_coin_accounts SET balance=balance-? WHERE uid=? AND (uid=0 OR balance>=?)', (units, uid, units))
        if result.rowcount != 1:
            raise ValueError('insufficient_coins')
        self.db.execute('UPDATE wm_coin_accounts SET balance=balance+? WHERE uid=?', (units, target))
        c = self.db.execute('INSERT INTO wm_coin_ops(kind,uid,target,units,request_key,meta,ts) VALUES(?,?,?,?,?,?,?)', (kind, uid, target, units, key, encoded, int(time.time())))
        self.db.executemany('INSERT INTO wm_coin_entries VALUES(?,?,?)', [(c.lastrowid, uid, -units), (c.lastrowid, target, units)])
        return (c.lastrowid, True)
