import asyncio,json,sqlite3,sys,unittest
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from unittest.mock import patch
from aiohttp import web,ClientSession
from aiohttp.test_utils import TestServer
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from wakhan_cinema.store import CinemaStore
from wakhan_cinema.rooms import Rooms
from wakhan_cinema.media import CinemaMedia,public_url,PublicResolver
class People:
 def relation(self,a,b):return'none'
 def public(self,uid,viewer):return{'id':uid,'name':'User'}
class Content:
 def __init__(self,body):self.body=body
 async def read(self,n):return self.body[:n]
 async def iter_chunked(self,n):yield self.body
class Upstream:
 def __init__(self,status=206,mime='video/mp4'):
  self.status=status;self.headers={'Content-Type':mime,'Content-Length':'5','Content-Range':'bytes 0-4/10'};self.content=Content(b'video')
 async def __aenter__(self):return self
 async def __aexit__(self,*args):pass
 def release(self):pass
class HTTP:
 def __init__(self):self.calls=[];self.mime='video/mp4'
 async def request(self,method,url,**kwargs):self.calls.append((method,url,kwargs));return Upstream(mime=self.mime)
class MediaTests(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.db=sqlite3.connect(':memory:');self.db.executescript("CREATE TABLE wka_accounts(uid INTEGER,done INTEGER,blocked INTEGER);INSERT INTO wka_accounts VALUES(1,1,0),(2,1,0);CREATE TABLE wks_sources(tid TEXT,ep TEXT,sid TEXT,provider TEXT,url TEXT,rights TEXT);INSERT INTO wks_sources VALUES('film','','one','commons','https://cdn-review.example/video.mp4','room');")
  self.store=CinemaStore(self.db);self.store.initialize();self.room=self.store.create(1,'room');self.rooms=Rooms(self.store,People());self.member=self.rooms.join(1,self.room['code']);self.http=HTTP();self.files=CinemaMedia(self.store,self.rooms,session=self.http,key=b'k'*32)
  self.media={'id':'archive:film::one','provider':'archive','cycle':0,'source':{'kind':'file','catalog_title':'film','catalog_episode':'','catalog_source':'one'}};self.store.set_playback(self.room['code'],self.media,playing=True)
  app=web.Application()
  async def handle(req):return await self.files.file(req)
  app.router.add_get('/file',handle);self.server=TestServer(app);await self.server.start_server();self.client=ClientSession()
 async def asyncTearDown(self):await self.client.close();await self.server.close();self.db.close()
 def url(self,uid=1):
  value=self.files.present(self.media,uid,self.room['code']);lease=parse_qs(urlsplit(value['source']['url']).query)['lease'][0];return self.server.make_url('/file?lease='+lease)
 async def test_real_range_http_preserved_and_lease_stable_across_snapshots(self):
  a=self.files.present(self.media,1,self.room['code']);b=self.files.present(self.media,1,self.room['code']);self.assertEqual(a,b)
  async with self.client.get(self.url(),headers={'Range':'bytes=0-4'})as response:self.assertEqual(response.status,206);self.assertEqual(response.headers['Content-Range'],'bytes 0-4/10');self.assertEqual(await response.read(),b'video')
  self.assertEqual(self.http.calls[0][2]['headers']['Range'],'bytes=0-4')
 async def test_wrong_viewer_or_stopped_media_cannot_stream(self):
  async with self.client.get(self.url(2))as response:self.assertEqual(response.status,403)
  old=self.url();self.store.set_playback(self.room['code'],None)
  async with self.client.get(old)as response:self.assertEqual(response.status,403)
  self.assertEqual(self.http.calls,[])
 async def test_invalid_range_rejected_before_upstream(self):
  async with self.client.get(self.url(),headers={'Range':'bytes=0-1,4-9'})as response:self.assertEqual(response.status,416)
  self.assertEqual(self.http.calls,[])
 async def test_html_response_is_not_presented_as_video(self):
  self.http.mime='text/html'
  async with self.client.get(self.url())as response:self.assertEqual(response.status,502)
 async def test_private_addresses_and_dns_rebinding_rejected(self):
  for raw in ['http://cdn-review.example/video','https://user:pass@cdn-review.example/video','https://127.0.0.1/a','https://[::1]/a','https://169.254.169.254/a','https://metadata.google.internal/a']:
   self.assertFalse(public_url(raw),raw)
  loop=asyncio.get_running_loop()
  with patch.object(loop,'getaddrinfo',return_value=[(2,1,6,'',('10.0.0.5',443))]):
   with self.assertRaises(OSError):await PublicResolver().resolve('rebind.example',443)
if __name__=='__main__':unittest.main()
