import unittest
import test_cinema_service as base
class RegressionTests(unittest.IsolatedAsyncioTestCase):
 asyncSetUp=base.ServiceTests.asyncSetUp
 asyncTearDown=base.ServiceTests.asyncTearDown
 call=base.ServiceTests.call
 command=base.ServiceTests.command
 async def test_changed_and_deleted_messages_reach_an_acknowledged_viewer(self):
  _,r=await self.command(1,self.owner,'message',{'text':'before'});message=r['snapshot']['messages'][-1]['id'];session=self.service.rooms.sessions[self.guest['snapshot']['session']];session.acknowledged=message
  await self.command(1,self.owner,'message.edit',{'id':message,'text':'after'});snap=self.service.snapshot(session);self.assertEqual(next(m for m in snap['messages']if m['id']==message)['body']['text'],'after')
  await self.command(1,self.owner,'message.delete',{'id':message});snap=self.service.snapshot(session);self.assertEqual(next(m for m in snap['messages']if m['id']==message)['deleted'],1)
 async def test_guest_cannot_forge_duration_or_chat_asset(self):
  await self.command(1,self.owner,'load',{'item':{'provider':'youtube','id':'abcdefghijk'}});status,r=await self.command(2,self.guest,'metadata',{'id':'yt:abcdefghijk','duration':1});self.assertEqual(status,403)
  status,r=await self.command(2,self.guest,'message',{'image':'/api/app/cinema/v2/photo/forged.jpg'});self.assertEqual(status,400)
 async def test_joined_list_and_message_history_boundary(self):
  _,r=await self.call(2,'salons',query={'section':'joined'});self.assertEqual(r['items'][0]['code'],self.code)
  await self.command(1,self.owner,'message',{'text':'before-entry'});_,late=await self.call(3,'room/join',{'code':self.code});self.assertEqual(late['snapshot']['messages'],[])
 async def test_early_voice_offer_is_delivered_when_peer_socket_connects(self):
  owner=self.service.rooms.sessions[self.owner['snapshot']['session']];await self.service.relay(owner,2,{'description':{'type':'offer','sdp':'pending'}});guest=self.service.rooms.sessions[self.guest['snapshot']['session']];self.assertEqual(len(guest.signals),1)
  _,ticket=await self.call(2,'room/connect',{'code':self.code,'session':guest.id});ws=await self.client.ws_connect(ticket['url']);await ws.receive_json();event=await ws.receive_json(timeout=2);self.assertEqual(event['data']['description']['sdp'],'pending');self.assertEqual(guest.signals,[]);await ws.close()
 async def test_slow_viewer_does_not_hold_an_owner_command(self):
  import asyncio
  release=asyncio.Event();started=asyncio.Event()
  class Socket:
   closed=False
   async def send_json(self,value):started.set();await release.wait()
   async def close(self,**kwargs):self.closed=True;release.set()
  session=self.service.rooms.sessions[self.guest['snapshot']['session']];session.socket=Socket()
  try:
   status,result=await asyncio.wait_for(self.command(1,self.owner,'message',{'text':'fast'}),1);self.assertEqual(status,200);await asyncio.wait_for(started.wait(),1);self.assertFalse(release.is_set())
  finally:release.set()
