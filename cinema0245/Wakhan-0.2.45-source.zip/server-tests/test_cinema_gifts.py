import unittest,sys,types
from unittest.mock import patch
import test_cinema_service as base
from test_wallet_fixture import WalletFixture,LEDGER_SCHEMA
from wakhan_cinema.store import CinemaError
class GiftTests(unittest.IsolatedAsyncioTestCase):
 asyncSetUp=base.ServiceTests.asyncSetUp
 asyncTearDown=base.ServiceTests.asyncTearDown
 call=base.ServiceTests.call
 command=base.ServiceTests.command
 def ledger(self):
  self.db.executescript(LEDGER_SCHEMA+"CREATE TABLE wm70_cinema_gifts(op INTEGER PRIMARY KEY,room TEXT,sender INTEGER,recipient INTEGER,code TEXT,ts INTEGER);INSERT INTO wm_coin_accounts VALUES(1,500),(2,0);")
  wallet=object.__new__(WalletFixture);wallet.db=self.db;people=self.service.rooms.community;people.wallet=wallet;people.blocked=lambda a,b:False;people.personal=types.SimpleNamespace(verify=lambda token,purpose:token)
  self.service.me.more=types.SimpleNamespace(can_see=lambda *args:True);self.catalog=types.SimpleNamespace(GIFTS={'rose':{'code':'rose','units':100,'coins':1}});return wallet
 def body(self):
  return{'code':self.code,'session':self.owner['snapshot']['session'],'uid':2,'gift':'rose','key':'gift-command-once','token':{'uid':1,'target':2,'room':self.code,'gift':'rose','units':100}}
 async def test_retry_after_recipient_leaves_is_a_receipt_not_a_second_debit(self):
  wallet=self.ledger();body=self.body()
  with patch.dict(sys.modules,{'wakhan_community_catalog_v70':self.catalog}):
   first=await self.service.gifts.commit(1,body);self.service.rooms.leave(self.service.rooms.sessions[self.guest['snapshot']['session']]);retry=await self.service.gifts.commit(1,body)
  self.assertEqual(first['id'],retry['id']);self.assertTrue(retry['duplicate']);self.assertEqual((wallet.balance(1),wallet.balance(2)),(400,100));self.assertEqual(self.db.execute('SELECT sum(delta)FROM wm_coin_entries').fetchone()[0],0);self.assertEqual(self.db.execute('SELECT count(*)FROM wm_coin_ops').fetchone()[0],1)
 async def test_quote_target_and_privacy_are_checked_before_ledger_mutation(self):
  wallet=self.ledger();body=self.body();body['token']['units']=200
  with patch.dict(sys.modules,{'wakhan_community_catalog_v70':self.catalog}):
   with self.assertRaisesRegex(CinemaError,'quote_invalid'):await self.service.gifts.commit(1,body)
   body['token']['units']=100;self.service.me.more.can_see=lambda *args:False
   with self.assertRaisesRegex(CinemaError,'gift_private'):await self.service.gifts.commit(1,body)
  self.assertEqual((wallet.balance(1),wallet.balance(2)),(500,0));self.assertEqual(self.db.execute('SELECT count(*)FROM wm_coin_ops').fetchone()[0],0)
