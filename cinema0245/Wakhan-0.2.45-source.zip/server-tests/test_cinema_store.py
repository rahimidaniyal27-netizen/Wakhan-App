import unittest,sqlite3,sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from wakhan_cinema.store import CinemaStore,CinemaError
class StoreTests(unittest.TestCase):
 def setUp(self):
  self.db=sqlite3.connect(':memory:');self.now=100.;self.store=CinemaStore(self.db,lambda:self.now)
 def tearDown(self):self.db.close()
 def test_existing_room_codes_notice_and_follows_migrate_once(self):
  self.db.executescript("CREATE TABLE rooms(code TEXT,owner INTEGER,ts INTEGER);INSERT INTO rooms VALUES('ABC123',1,7);CREATE TABLE wm_personal_cinemas(uid INTEGER,code TEXT,name TEXT,created_at INTEGER);INSERT INTO wm_personal_cinemas VALUES(1,'ABC123','من',7);CREATE TABLE wm51_halls(uid INTEGER,name TEXT,notice TEXT);INSERT INTO wm51_halls VALUES(1,'اسم','اعلان');CREATE TABLE wka_room_favorites(uid INTEGER,code TEXT,ts INTEGER);INSERT INTO wka_room_favorites VALUES(2,'ABC123',8);")
  self.store.initialize();r=self.store.room('ABC123');self.assertEqual((r['owner'],r['name'],r['notice']),(1,'من','اعلان'));self.assertEqual(self.store.create(1,'دیگر')['code'],'ABC123');self.store.update('ABC123',notice='new');self.store.initialize();self.assertEqual(self.store.room('ABC123')['notice'],'new');self.assertEqual(self.db.execute('SELECT notice FROM wm51_halls').fetchone()[0],'اعلان');self.assertEqual(self.db.execute('SELECT count(*)FROM wkc_follows').fetchone()[0],1)
 def test_follow_is_idempotent_and_missing_room_rejected(self):
  self.store.initialize();r=self.store.create(1,'room');self.store.follow(2,r['code'],True);self.store.follow(2,r['code'],True);self.assertEqual(len(self.store.rows('SELECT *FROM wkc_follows')),1);self.store.follow(2,r['code'],False);self.assertEqual(len(self.store.rows('SELECT *FROM wkc_follows')),0)
  with self.assertRaises(CinemaError):self.store.follow(2,'ABSENT',True)
 def test_playback_is_persisted_and_pause_does_not_touch_members(self):
  self.store.initialize();r=self.store.create(1,'room');self.db.execute("INSERT INTO wkc_members VALUES(?,1,'member','join',0)",(r['code'],));self.db.commit();self.store.set_playback(r['code'],{'id':'video','cycle':1},playing=True,position=3);self.now+=2.;self.assertEqual(self.store.playback(r['code'])['position'],5);self.store.set_playback(r['code'],None);self.assertIsNone(self.store.playback(r['code']));self.assertEqual(self.db.execute('SELECT count(*)FROM wkc_members').fetchone()[0],1)
 def test_command_receipt_bound_to_user_and_room(self):
  self.store.initialize();self.store.remember(1,'one','ABC123',{'ok':True});self.assertEqual(self.store.cached(1,'one','ABC123'),{'ok':True});self.assertIsNone(self.store.cached(2,'one','ABC123'))
  with self.assertRaises(CinemaError):self.store.cached(1,'one','OTHER')
if __name__=='__main__':unittest.main()

class RetainedDataTests(unittest.TestCase):
 def test_old_entry_rules_revoked_codes_and_personal_progress_are_preserved(self):
  db=sqlite3.connect(':memory:');db.executescript("""CREATE TABLE rooms(code TEXT,owner INTEGER,ts INTEGER);INSERT INTO rooms VALUES('OLD123',1,1),('NEW123',1,2);CREATE TABLE wm_personal_cinemas(uid INTEGER,code TEXT,name TEXT,created_at INTEGER);INSERT INTO wm_personal_cinemas VALUES(1,'NEW123','Current',2);CREATE TABLE wm_cinema_code_history(code TEXT,uid INTEGER);INSERT INTO wm_cinema_code_history VALUES('OLD123',1),('NEW123',1);CREATE TABLE wm51_halls(uid INTEGER,name TEXT,notice TEXT,mic TEXT,chat TEXT);INSERT INTO wm51_halls VALUES(1,'Current','notice','friends','friends');CREATE TABLE wks_chatban(code TEXT,uid INTEGER,ts INTEGER);INSERT INTO wks_chatban VALUES('NEW123',2,1);CREATE TABLE wks_titles(id TEXT,title TEXT,poster TEXT,backdrop TEXT);INSERT INTO wks_titles VALUES('film','Movie','','');CREATE TABLE wks_sources(tid TEXT,ep TEXT,sid TEXT,rights TEXT,ts INTEGER,title TEXT,thumb TEXT);INSERT INTO wks_sources VALUES('film','','version','solo',1,'Movie','');CREATE TABLE wks_progress(uid INTEGER,tid TEXT,ep TEXT,pos INTEGER,dur INTEGER,ts INTEGER);INSERT INTO wks_progress VALUES(2,'film','',42,100,10);""")
  store=CinemaStore(db);store.initialize();self.assertIsNone(store.room('OLD123'));self.assertEqual(store.room('NEW123')['settings']['mic'],'friends');self.assertEqual(store.room('NEW123')['settings']['chatAccess'],'friends');self.assertEqual(store.room('NEW123')['settings']['capacity'],8);self.assertTrue(store.one("SELECT uid FROM wkc_rules WHERE code='NEW123'AND uid=2 AND kind='chat'"));self.assertEqual(store.one('SELECT position FROM wkc_history WHERE uid=2')['position'],42);self.assertEqual(db.execute('SELECT pos FROM wks_progress').fetchone()[0],42);self.assertTrue(store.one("SELECT code FROM wkc_reserved_codes WHERE code='OLD123'"));db.close()
