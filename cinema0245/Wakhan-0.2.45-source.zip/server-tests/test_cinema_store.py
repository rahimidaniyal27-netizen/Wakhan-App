import unittest,sqlite3,sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from wakhan_cinema.store import CinemaStore,CinemaError
class StoreTests(unittest.TestCase):
 def setUp(self):
  self.db=sqlite3.connect(':memory:');self.now=100.;self.store=CinemaStore(self.db,lambda:self.now)
 def tearDown(self):self.db.close()
 def test_existing_room_codes_notice_and_follows_migrate_once(self):
  self.db.executescript("CREATE TABLE rooms(code TEXT,owner INTEGER,ts INTEGER);INSERT INTO rooms VALUES('ABC123',1,7);CREATE TABLE wm_personal_cinemas(uid INTEGER,code TEXT,name TEXT,created_at INTEGER);INSERT INTO wm_personal_cinemas VALUES(1,'ABC123','من',7);CREATE TABLE wm51_halls(uid INTEGER,name TEXT,notice TEXT);INSERT INTO wm51_halls VALUES(1,'اسم','اعلان');CREATE TABLE wka_room_favorites(uid INTEGER,code TEXT,ts INTEGER);INSERT INTO wka_room_favorites VALUES(2,'ABC123',8);")
  self.store.initialize();r=self.store.room('ABC123');self.assertEqual((r['owner'],r['name'],r['notice']),(1,'من','اعلان'));self.assertEqual(self.store.create(1,'دیگر')['code'],'ABC123');self.store.update('ABC123',notice='new');self.store.initialize();self.assertEqual(self.store.room('ABC123')['notice'],'new');self.assertEqual(self.db.execute('SELECT notice FROM wm51_halls').fetchone()[0],'اعلان');self.assertEqual(self.db.execute('SELECT count(*)FROM wkc_follows').fetchone()[0],1)
 def test_follow_is_idempotent_and_missing_room_rejected(self):
  self.store.initialize();r=self.store.create(1,'room');self.store.follow(2,r['code'],True);self.store.follow(2,r['code'],True);self.assertEqual(len(self.store.rows('SELECT *FROM wkc_follows')),1);self.store.follow(2,r['code'],False);self.assertEqual(len(self.store.rows('SELECT *FROM wkc_follows')),0)
  with self.assertRaises(CinemaError):self.store.follow(2,'ABSENT',True)
 def test_playback_is_persisted_and_pause_does_not_touch_members(self):
  self.store.initialize();r=self.store.create(1,'room');self.db.execute("INSERT INTO wkc_members VALUES(?,1,'member','join',0)",(r['code'],));self.db.commit();self.store.set_playback(r['code'],{'id':'video','cycle':1},playing=True,position=3);self.now+=2.;self.assertEqual(self.store.playback(r['code'])['position'],5);self.store.set_playback(r['code'],None);self.assertIsNone(self.store.playback(r['code']));self.assertEqual(self.db.execute('SELECT count(*)FROM wkc_members').fetchone()[0],1)
 def test_command_receipt_bound_to_user_and_room(self):
  self.store.initialize();self.store.remember(1,'one','ABC123',{'ok':True});self.assertEqual(self.store.cached(1,'one','ABC123'),{'ok':True});self.assertIsNone(self.store.cached(2,'one','ABC123'))
  with self.assertRaises(CinemaError):self.store.cached(1,'one','OTHER')
if __name__=='__main__':unittest.main()
