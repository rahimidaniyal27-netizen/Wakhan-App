import unittest,sqlite3,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from wakhan_cinema.store import CinemaStore,CinemaError
from wakhan_cinema.catalog import CinemaCatalog
from wakhan_cinema.discovery import free_license
class Metadata:
 def __init__(self):self.calls=[]
 async def metadata(self,url):
  self.calls.append(url)
  if'archive.org/advancedsearch'in url:return{'response':{'docs':[{'identifier':'afghan-doc','title':'A documentary','licenseurl':'https://creativecommons.org/licenses/by/4.0/'}]}}
  if'commons'in url:return{'query':{'pages':{}}}
  return{'data':[]}
class DiscoveryTests(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.db=sqlite3.connect(':memory:');self.store=CinemaStore(self.db);self.store.initialize();self.catalog=CinemaCatalog(self.store);self.catalog.streaming=Metadata()
 async def asyncTearDown(self):await self.catalog.close();self.db.close()
 async def test_provider_matches_survive_a_different_title_language_and_are_cached(self):
  items=await self.catalog.find_archive('افغانستان');self.assertEqual(items[0]['title'],'A documentary');self.assertEqual(len(self.catalog.streaming.calls),3);again=await self.catalog.find_archive('افغانستان');self.assertEqual(again,items);self.assertEqual(len(self.catalog.streaming.calls),3);row=self.store.one('SELECT rights FROM wks_sources');self.assertEqual(row['rights'],'room')
 async def test_solo_catalogue_grant_cannot_be_used_for_shared_room_playback(self):
  await self.catalog.find_archive('افغانستان');row=self.store.one('SELECT tid FROM wks_sources');self.db.execute("UPDATE wks_sources SET rights='solo'");self.db.commit();reference={'id':row['tid'],'provider':'archive'};personal=await self.catalog.resolve(reference);self.assertEqual(personal['source']['kind'],'file')
  with self.assertRaisesRegex(CinemaError,'no_licensed_source'):await self.catalog.resolve(reference,room='ROOM01')
 async def test_provider_outage_is_not_reported_as_an_empty_success(self):
  async def fail(url):raise OSError('offline')
  self.catalog.streaming.metadata=fail
  with self.assertRaisesRegex(CinemaError,'archive_unavailable'):await self.catalog.find_archive('unknown')
 def test_only_explicit_redistribution_licences_enable_room_grants(self):
  self.assertTrue(free_license('https://creativecommons.org/licenses/by-sa/4.0/'));self.assertFalse(free_license('https://example.test/creativecommons.org/licenses/by/4.0/'));self.assertFalse(free_license('https://creativecommons.org/licenses/by-nc/4.0/'))
