import json,sqlite3,sys,tempfile,unittest,shutil
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'deployment'))
import backend_update as deployment
from transform_backend import FILES,RETIRE
class DeploymentTests(unittest.TestCase):
 def test_drift_is_rejected_before_mutation(self):
  with tempfile.TemporaryDirectory()as tmp:
   root=Path(tmp);file=root/'native_runtime.py';file.write_text('current');expected={'native_runtime.py':deployment.sha(file)};deployment.verify(root,expected);file.write_text('locally changed')
   with self.assertRaisesRegex(RuntimeError,'CINEMA_BASE_CHANGED'):deployment.verify(root,expected)
   self.assertEqual(file.read_text(),'locally changed')
 def test_rollback_restores_code_without_rewinding_user_database(self):
  with tempfile.TemporaryDirectory()as tmp:
   root=Path(tmp);live=root/'live';work=root/'backup';original=work/'original';live.mkdir();original.mkdir(parents=True)
   for name in[*FILES,*RETIRE]:(original/name).write_text('original:'+name)
   for name in FILES:(live/name).write_text('candidate:'+name)
   (live/'wakhan_cinema').mkdir();(live/'wakhan_cinema/__init__.py').write_text('fresh')
   database=live/'accounts.sqlite'
   with sqlite3.connect(database)as db:db.execute('CREATE TABLE ledger(value INTEGER)');db.execute('INSERT INTO ledger VALUES(123)')
   report={};state={'live':live,'work':work,'backup':original,'changed':True,'latest_attempted':False,'copy_atomic':lambda a,b:shutil.copyfile(a,b)}
   with patch.object(deployment.subprocess,'run'),patch.object(deployment,'start_and_check')as start:deployment.rollback(state,report);start.assert_called_once_with(False)
   for name in[*FILES,*RETIRE]:self.assertEqual((live/name).read_text(),'original:'+name)
   with sqlite3.connect(database)as db:self.assertEqual(db.execute('SELECT value FROM ledger').fetchone()[0],123)
   self.assertFalse((live/'wakhan_cinema').exists());self.assertTrue((work/'failed-new-package').is_dir());self.assertTrue(report['backend_rolled_back'])
 def test_configuration_is_read_from_systemd_without_exposing_environment(self):
  with tempfile.TemporaryDirectory()as tmp:
   config=Path(tmp)/'settings.json';config.write_text(json.dumps({'database':'/private/db','owner':1,'env':{'PRIVATE':'hidden'}}));out=type('Result',(),{'stdout':'{ path='+sys.executable+' ; argv[]='+sys.executable+' /app/native_runtime.py --config '+str(config)+' ; ignore_errors=no ; }'})()
   with patch.object(deployment.subprocess,'run',return_value=out):python,value=deployment.configuration()
   self.assertEqual(python,Path(sys.executable));self.assertEqual(value['owner'],1)
