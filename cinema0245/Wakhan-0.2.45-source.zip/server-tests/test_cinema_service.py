import asyncio,json,sqlite3,sys,unittest
from pathlib import Path
from aiohttp import web,ClientSession
from aiohttp.test_utils import TestServer
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from wakhan_cinema.service import CinemaService,PREFIX
from wakhan_cinema.store import CinemaError
class People:
 def relation(self,a,b):return'accepted'if{a,b}=={1,2}else'none'
 def public(self,uid,viewer):return{'id':uid,'name':'user'+str(uid),'avatar':None}
class Me:
 def slow(self,*args):pass
 def handler(self,fn):
  async def call(req):
   if not req.headers.get('X-Review-Uid'):return web.json_response({'ok':False},status=401)
   try:return web.json_response(await fn(req,int(req.headers['X-Review-Uid'])))
   except CinemaError as e:return web.json_response({'ok':False,'err':e.code},status=e.status)
   except(ValueError,KeyError,TypeError):return web.json_response({'ok':False,'err':'bad_input'},status=400)
  return call
class ServiceTests(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.db=sqlite3.connect(':memory:');self.db.executescript('CREATE TABLE wka_accounts(uid INTEGER PRIMARY KEY,done INTEGER,blocked INTEGER);INSERT INTO wka_accounts VALUES(1,1,0),(2,1,0),(3,1,0);')
  self.service=CinemaService({'DB':self.db,'WME':Me(),'WM_COMMUNITY70':People()},workers=False);app=web.Application();self.service.routes(app);self.server=TestServer(app);await self.server.start_server();self.service.origin=str(self.server.make_url('')).rstrip('/');self.client=ClientSession();self.n=0
  _,created=await self.call(1,'salons/create',{'name':'room'});self.code=created['room']['code'];_,self.owner=await self.call(1,'room/join',{'code':self.code});_,self.guest=await self.call(2,'room/join',{'code':self.code,'seat':True})
 async def asyncTearDown(self):
  await self.client.close();await self.server.close();self.db.close()
 async def call(self,uid,path,body=None,query=None):
  async with self.client.request('POST'if body is not None else'GET',self.server.make_url(PREFIX+'/'+path),headers={'X-Review-Uid':str(uid)}if uid else{},json=body,params=query)as response:return response.status,await response.json()
 async def command(self,uid,joined,kind,payload=None,key=None):
  self.n+=1;return await self.call(uid,'room/command',{'code':self.code,'session':joined['snapshot']['session'],'key':key or'command-'+str(self.n),'kind':kind,'payload':payload or{}})
 async def test_auth_and_session_scope(self):
  status,_=await self.call(None,'salons');self.assertEqual(status,401)
  status,_=await self.call(2,'room/events',query={'code':self.code,'session':self.owner['snapshot']['session']});self.assertEqual(status,409)
  status,result=await self.command(2,self.guest,'stop');self.assertEqual((status,result['err']),(403,'control_forbidden'))
 async def test_media_stop_keeps_membership_and_seat(self):
  status,r=await self.command(1,self.owner,'load',{'item':{'provider':'youtube','id':'abcdefghijk'}});self.assertEqual(status,200);self.assertEqual(r['snapshot']['media']['source']['kind'],'youtube');self.assertTrue(r['snapshot']['media']['source']['embed'].startswith('https://music.kabulcafe.uk/api/app/cinema/v2/player/youtube?'))
  status,r=await self.command(1,self.owner,'stop');self.assertEqual(status,200);self.assertIsNone(r['snapshot']['media']);self.assertEqual(next(m['seat']for m in r['snapshot']['members']if m['id']==1),0);self.assertIn(self.owner['snapshot']['session'],self.service.rooms.sessions)
 async def test_fifo_approval_repeat_and_duplicate_commands(self):
  _,r=await self.command(1,self.owner,'load',{'item':{'provider':'youtube','id':'abcdefghijk'}})
  _,r=await self.command(2,self.guest,'queue.add',{'item':{'provider':'youtube','id':'bbbbbbbbbbb'}},key='add-one-once');self.assertEqual(r['snapshot']['queue'][0]['status'],'pending');qid=r['snapshot']['queue'][0]['id']
  _,r=await self.command(2,self.guest,'queue.add',{'item':{'provider':'youtube','id':'bbbbbbbbbbb'}},key='add-one-once');self.assertEqual(len(r['snapshot']['queue']),1)
  _,r=await self.command(1,self.owner,'queue.approve',{'id':qid});_,r=await self.command(1,self.owner,'next');self.assertEqual(r['snapshot']['media']['provider_id'],'bbbbbbbbbbb');self.assertEqual(r['snapshot']['queue'],[])
  _,r=await self.command(1,self.owner,'next');self.assertEqual(r['snapshot']['media']['provider_id'],'bbbbbbbbbbb');self.assertEqual(r['snapshot']['media']['cycle'],1)
 async def test_announcement_durable_and_guest_cannot_edit(self):
  status,_=await self.command(2,self.guest,'notice',{'notice':'forged'});self.assertEqual(status,403)
  _,r=await self.command(1,self.owner,'notice',{'notice':'سلام <img src=x>'});self.assertEqual(r['snapshot']['notice'],'سلام <img src=x>')
  _,r=await self.call(2,'salons',query={'section':'discover'});self.assertEqual(r['items'][0]['notice'],'سلام <img src=x>')
 async def test_websocket_snapshot_chat_and_scoped_signaling(self):
  _,a=await self.call(1,'room/connect',{'code':self.code,'session':self.owner['snapshot']['session']});_,b=await self.call(2,'room/connect',{'code':self.code,'session':self.guest['snapshot']['session']})
  ws1=await self.client.ws_connect(a['url']);ws2=await self.client.ws_connect(b['url']);self.assertEqual((await ws1.receive_json())['type'],'snapshot');await ws2.receive_json()
  await ws1.send_json({'type':'signal','to':2,'data':{'description':{'type':'offer','sdp':'review'}}});message=await ws2.receive_json(timeout=2);self.assertEqual((message['type'],message['from']),('signal',1))
  _,result=await self.command(1,self.owner,'message',{'text':'hello'});self.assertEqual(result['snapshot']['messages'][0]['body']['text'],'hello');message=await ws2.receive_json(timeout=2);self.assertEqual(message['type'],'snapshot');self.assertEqual(message['snapshot']['messages'][0]['body']['text'],'hello')
  await ws1.close();await ws2.close()
if __name__=='__main__':unittest.main()
