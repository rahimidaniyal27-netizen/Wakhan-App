/* A fixed pane per route. No renderer swapping, DOM copying or media teardown. */
export function installPageCache({root,route}){
 if(!root)throw Error('view_host_missing');root.replaceChildren();root.dataset.wkViewHost='1';const entries=new Map();let current=null;const stats={created:0,hits:0};
 const style=document.createElement('style');style.textContent='[data-wk-page]{display:contents}[data-wk-page][hidden]{display:none!important}.wk-instant-tabs [data-wk-page]>.fade,.wk-instant-tabs [data-wk-page]>.wn-page{animation:none!important;transition:none!important;filter:none!important}body.wk-cinema-active>header{display:none!important}';document.head.append(style);document.body.classList.add('wk-instant-tabs');
 function pane(tab){tab=String(tab);let node=entries.get(tab);if(!node){node=document.createElement('section');node.dataset.wkPage=tab;node.hidden=true;node.inert=true;root.append(node);entries.set(tab,node);stats.created++}return node}
 function activate(tab){const node=pane(tab);if(current===node){stats.hits++;return node}if(current){current.hidden=true;current.inert=true;delete current.dataset.wkPageActive}node.hidden=false;node.inert=false;node.dataset.wkPageActive='1';current=node;return node}
 function view(){return activate(route().tab)}
 function clear(){for(const node of entries.values())node.remove();entries.clear();current=null}
 return {view,pane,activate,clear,stats,has:tab=>entries.has(String(tab)),active:()=>current?.dataset.wkPage,dispose(){clear();style.remove();document.body.classList.remove('wk-instant-tabs')}};
}
