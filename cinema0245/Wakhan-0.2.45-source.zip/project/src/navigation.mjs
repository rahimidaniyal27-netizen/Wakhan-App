/* One synchronous navigation owner. Network refresh happens inside each page. */
export function installNavigation({pages,getRoute,setRoute,getSub,setSub,renderNav,services,renderOther,setGo,beforeChange=()=>{}}){
 let serial=0;const measurements=[];
 function navigate(tab,sub=null,options={}){
  tab=String(tab);if(tab==='c'&&!options.preserveCinema){services.cinema()?.open();return}
  const started=performance.now(),from=getRoute(),invocation=++serial;beforeChange(from,tab);try{getSub()?.stop?.()}catch{}setSub(sub);setRoute(tab);pages.activate(tab);
  document.body.classList.toggle('wk-cinema-active',tab==='c');document.body.classList.remove('wk-typing');
  services.home()?.onRoute(from);services.music()?.onRoute(from);services.chat()?.resume();services.games()?.routeChanged();services.cinema()?.onRoute();
  renderNav();
  if(tab==='m'||!['h','p','c','d'].includes(tab))renderOther();else if(tab==='h')services.home()?.mount();
  const handler=performance.now()-started;
  requestAnimationFrame(()=>{if(invocation!==serial)return;const pane=pages.pane(tab);pane.scrollTop=0;window.scrollTo({top:0,behavior:'instant'});measurements.push({from,to:tab,handler,frame:performance.now()-started,visible:!pane.hidden});if(measurements.length>60)measurements.shift()});
 }
 setGo(navigate);return {navigate,measurements,dispose(){serial++}};
}
