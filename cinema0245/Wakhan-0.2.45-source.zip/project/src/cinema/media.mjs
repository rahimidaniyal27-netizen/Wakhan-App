/* One visible player is moved between room, fullscreen and mini-card. */
export function createCinemaMedia({origin,makeID=()=>crypto.randomUUID(),onEnded=()=>{},onState=()=>{},onError=()=>{},onInteraction=()=>{}}){
 const host=document.createElement('div');host.className='cinema-media';const video=document.createElement('video');video.playsInline=true;video.setAttribute('webkit-playsinline','');video.preload='metadata';video.controls=false;video.style.cssText='width:100%;height:100%;object-fit:contain;background:#000';
 let iframe=null,current=null,source=null,channel='',ready=false,disposed=false,generation=0,pending=null,endedKey='',duration=0,position=0,playing=false,localMuted=false,buffering=false,lastSeek=0,loadTimer=0,ducked=false,backgrounded=false,lastError=null;
 const reportError=value=>{lastError=value.code;onError(value);notify()};const interaction=()=>{lastError='gesture';onInteraction();notify()};
 const notify=()=>onState({error:lastError,ready,buffering,playing,position,duration,provider:current?.provider,muted:localMuted});
 const trusted=(raw,path)=>{const u=new URL(raw,origin);if(u.origin!==origin||u.username||u.password||u.hash||path&&!u.pathname.startsWith(path))throw Error('untrusted_media');return u.href};
 const key=()=>current?current.id+'|'+current.cycle:'';
 function end(){if(!current||!current.playing||endedKey===key())return;endedKey=key();onEnded({id:current.id,cycle:current.cycle})}
 function post(message){if(!iframe||!ready)return;iframe.contentWindow?.postMessage({channel,...message},origin)}
 function sync(){if(!current||!ready)return;const target=Math.max(0,Number(pending?.position??current.position)||0);const wants=!backgrounded&&(pending?.playing??current.playing);
  if(source==='file'){
   if(video.readyState>=1&&Math.abs(video.currentTime-target)>1.5&&performance.now()-lastSeek>1000){try{video.currentTime=target;lastSeek=performance.now()}catch{}}
   video.muted=localMuted;video.volume=ducked?.3:1;
   if(wants&&video.paused)void video.play().then(()=>{lastError=null;playing=true;notify()}).catch(()=>{interaction();playing=false;notify()});else if(!wants&&!video.paused)video.pause();
  }else post({type:'state',playing:!!wants,position:target,muted:localMuted,revision:current.revision});notify();
 }
 function clear(){lastError=null;generation++;clearTimeout(loadTimer);ready=false;buffering=false;video.pause();video.removeAttribute('src');video.load();iframe?.remove();iframe=null;host.replaceChildren();source=null;channel='';pending=null;duration=0;position=0;playing=false}
 function embed(){if(!current?.source?.embed){reportError({code:'source_failed',provider:current?.provider});return}clear();source=current.provider==='soundcloud'?'soundcloud':'youtube';channel=makeID();const u=new URL(trusted(current.source.embed,'/api/app/cinema/v2/player/'));u.searchParams.set('channel',channel);iframe=document.createElement('iframe');iframe.title=current.title||'YouTube';iframe.allow='autoplay; fullscreen; picture-in-picture; encrypted-media';iframe.referrerPolicy='strict-origin-when-cross-origin';iframe.src=u.href;iframe.style.cssText='width:100%;height:100%;border:0;background:#000';host.replaceChildren(iframe);buffering=true;const g=generation;loadTimer=setTimeout(()=>{if(g===generation&&!ready)reportError({code:'player_timeout',provider:current?.provider})},15000);notify()}
 function failed(){if(!current)return;const canEmbed=current.provider==='youtube'&&current.source?.embed;if(source==='file'&&canEmbed){embed();return}reportError({code:video.error?.code===4?'format_unsupported':'source_failed',provider:current.provider})}
 function update(media){if(disposed)return;if(!media){clear();current=null;notify();return}const changed=!current||current.id!==media.id||current.source?.url!==media.source?.url||current.source?.embed!==media.source?.embed;
  const newer=!current||Number(media.version)>Number(current.version)||media.id!==current.id;current={...media};if(newer)pending=null;if(changed){clear();endedKey='';if(media.source?.kind==='file'&&media.source.url){source='file';host.replaceChildren(video);video.src=trusted(media.source.url,'/api/app/cinema/v2/media/');buffering=true;video.load();const g=generation;loadTimer=setTimeout(()=>{if(g===generation&&!ready)failed()},12000)}else embed()}else sync();notify();
 }
 function receive(event){if(!iframe||event.source!==iframe.contentWindow||event.origin!==origin||event.data?.channel!==channel)return;const data=event.data;
  if(data.type==='ready'){lastError=null;ready=true;clearTimeout(loadTimer);buffering=false;sync()}
  else if(data.type==='progress'){position=Math.max(0,Number(data.position)||0);duration=Math.max(0,Number(data.duration)||0);playing=!!data.playing;if(playing)lastError=null;buffering=!!data.buffering;notify()}
  else if(data.type==='ended'){playing=!!current?.playing;end()}
  else if(data.type==='error')reportError({code:(current?.provider||'player')+'_'+data.code,provider:current?.provider});
  else if(data.type==='gesture')interaction();
 }
 video.addEventListener('loadedmetadata',()=>{if(source!=='file')return;lastError=null;ready=true;duration=video.duration||0;clearTimeout(loadTimer);buffering=false;sync()});
 video.addEventListener('error',()=>{if(source==='file'&&video.error?.code!==1)failed()});video.addEventListener('ended',()=>{if(source==='file'&&ready&&video.ended)end()});
 video.addEventListener('timeupdate',()=>{if(source==='file'){position=video.currentTime;duration=Number.isFinite(video.duration)?video.duration:0;notify()}});
 for(const event of ['playing','pause','waiting'])video.addEventListener(event,()=>{if(source!=='file')return;playing=!video.paused;buffering=event==='waiting';notify()});
 window.addEventListener('message',receive);
 return {host,update,rollback(){pending=null;sync()},background(on){backgrounded=!!on;sync()},duck(on){ducked=!!on;sync()},retry(){if(!current)return;const item={...current};current=null;update(item)},mount(target){if(host.parentElement!==target)target.replaceChildren(host)},intent({position:time,playing:wants}){pending={position:time??position,playing:wants??playing};sync()},mute(){localMuted=!localMuted;sync();return localMuted},unlock(){if(source==='file'&&current?.playing)void video.play().then(()=>{lastError=null;notify()}).catch(interaction);else post({type:'unlock'})},state:()=>({error:lastError,current,source,ready,playing,position,duration,muted:localMuted}),pause(){video.pause();post({type:'state',playing:false,position,muted:localMuted})},dispose(){disposed=true;clear();host.remove();window.removeEventListener('message',receive)}};
}
