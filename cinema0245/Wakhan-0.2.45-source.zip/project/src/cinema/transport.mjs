const PREFIX='/api/app/cinema/v2';
const failure=value=>Object.assign(new Error(value?.error||value?.err||'network'),{code:value?.error||value?.err||'network'});
/* One transport per signed-in account. Commands carry an idempotency key. */
export function createCinemaTransport({request,store,origin,Socket=globalThis.WebSocket,clock={setTimeout:(...args)=>setTimeout(...args),clearTimeout:id=>clearTimeout(id)},randomID=()=>crypto.randomUUID(),onEvent=()=>{},onSignal=()=>{}}){
 let socket=null,timer=null,generation=0,closed=false,attempt=0,polling=false,tail=Promise.resolve();
 const path=(name,query)=>PREFIX+'/'+name+(query?'?'+new URLSearchParams(query):'');
 async function call(name,body,query){const value=await request(path(name,query),body);if(value?.ok===false)throw failure(value);return value}
 const cursor=()=>store.get().messages.reduce((n,m)=>Math.max(n,Number(m.id)||0),0);
 const current=()=>{store.account();const s=store.get();return s.room&&s.session?{code:s.room.code,session:s.session,uid:s.account,epoch:store.epoch()}:null};
 const matches=c=>{const now=current();return !!now&&now.code===c.code&&now.session===c.session&&now.uid===c.uid&&now.epoch===c.epoch};
 function accept(event,c){if(!matches(c))return;if(event.type==='signal'){onSignal(event);return}if(event.type==='snapshot')store.apply(event.snapshot,{generation:c.epoch});else if(event.type==='messages')store.append(event.messages);else onEvent(event)}
 function schedule(fn,ms){clock.clearTimeout(timer);timer=clock.setTimeout(fn,ms)}
 async function poll(c,g){if(closed||g!==generation||!matches(c))return;if(polling){schedule(()=>poll(c,g),500);return}polling=true;
  try{const result=await call('room/events',undefined,{code:c.code,session:c.session,after:store.get().revision,message:cursor()});if(matches(c)&&g===generation){if(result.snapshot)accept({type:'snapshot',snapshot:result.snapshot},c);for(const event of result.events||[])accept(event,c);store.patch({connection:'online'})}}
  catch(error){if(matches(c)){store.patch({connection:'reconnecting'});onEvent({type:'error',code:error.code})}}
  finally{polling=false;if(g===generation&&!closed&&matches(c)&&socket?.readyState!==1)schedule(()=>connect(c,g),1500)}
 }
 async function connect(c,g){if(closed||g!==generation||!matches(c))return;
  try{const result=await call('room/connect',{code:c.code,session:c.session});if(closed||g!==generation||!matches(c))return;
   const url=new URL(result.url,origin);if(url.protocol!==(new URL(origin).protocol==='https:'?'wss:':'ws:')||url.host!==new URL(origin).host||url.username||url.password||url.hash||url.pathname!==PREFIX+'/room/live')throw failure({error:'bad_socket'});
   const ws=new Socket(url.href);socket=ws;
   ws.onopen=()=>{if(g!==generation||!matches(c)){ws.close();return}attempt=0;store.patch({connection:'online'});clock.clearTimeout(timer);const heartbeat=()=>{if(ws!==socket||ws.readyState!==1||g!==generation)return;if(!matches(c)){ws.close();return;}ws.send(JSON.stringify({type:'heartbeat',revision:store.get().revision,message:cursor()}));schedule(heartbeat,20000)};schedule(heartbeat,20000)};
   ws.onmessage=event=>{if(g!==generation)return;try{const data=JSON.parse(event.data);accept(data,c);if(data.type==='snapshot'&&ws.readyState===1)ws.send(JSON.stringify({type:'ack',revision:store.get().revision,message:cursor()}))}catch{}};
   ws.onclose=()=>{if(socket!==ws)return;socket=null;if(g!==generation||closed||!matches(c))return;store.patch({connection:'reconnecting'});schedule(()=>poll(c,g),Math.min(500*2**attempt++,5000))};
   ws.onerror=()=>ws.close();
  }catch(error){if(g===generation&&!closed){onEvent({type:'error',code:error.code});void poll(c,g)}}
 }
 function stop(){generation++;closed=true;clock.clearTimeout(timer);const ws=socket;socket=null;ws?.close()}
 async function start(){stop();closed=false;attempt=0;const c=current(),g=generation;if(c)void connect(c,g)}
 function command(kind,payload={}){const c=current();if(!c)return Promise.reject(failure({error:'not_in_room'}));const key=randomID();
  const task=tail.catch(()=>{}).then(async()=>{if(!matches(c))throw failure({error:'room_changed'});let value;for(let retry=0;retry<2;retry++){try{value=await call('room/command',{code:c.code,session:c.session,key,kind,payload});break}catch(error){if(retry||!['network','timeout','fetch_failed'].includes(error.code||'network')){onEvent({type:'error',code:error.code});throw error}}}if(!matches(c))throw failure({error:'room_changed'});if(value.snapshot)store.apply(value.snapshot,{generation:c.epoch});return value});tail=task;return task;
 }
 function signal(to,data){const c=current();if(!c)return Promise.resolve(false);if(socket?.readyState===1){socket.send(JSON.stringify({type:'signal',to,data}));return Promise.resolve(true)}return call('room/signal',{code:c.code,session:c.session,to,data})}
 return {call,command,signal,start,stop,dispose:stop};
}
