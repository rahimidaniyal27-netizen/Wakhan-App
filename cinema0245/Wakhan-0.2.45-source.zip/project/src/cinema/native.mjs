/* Native audio owns licensed file sources only while the web player is suspended. */
export function installCinemaNative({cinema,player,enabled,getKey,origin,getRoute}){
 if(!enabled)return {appState(){},suspend(){},dispose(){}};
 let id='',signature='',generation=0,hidden=document.hidden,disposed=false,suspended=false;
 const valid=raw=>{try{const u=new URL(raw);return u.origin===origin&&u.pathname==='/api/app/cinema/v2/media/file'&&u.searchParams.has('lease')&&!u.username&&!u.password&&!u.hash}catch{return false}};
 async function stop(){generation++;const previous=id;id='';signature='';if(previous)await player.control({id:previous,action:'stop'}).catch(()=>{})}
 async function sync(state){if(disposed)return;const media=state.media,source=media?.source,personalMusic=window.WakhanNativeMusic?.ownsPlayback;
  if(!state.session||!media||source?.kind!=='file'||!valid(source.url)||state.personal||personalMusic){if(id)void stop();return}
  if(suspended)return;
  const next=[state.account,state.room.code,state.session,media.id,media.cycle,source.url].join('|');if(next===signature)return;
  const token=++generation,previous=id;id='cinema_'+crypto.randomUUID().replaceAll('-','');const requestID=id;signature=next;
  if(previous)await player.control({id:previous,action:'stop'}).catch(()=>{});if(disposed||token!==generation)return;
  try{await player.loadTrack({id:requestID,source:source.url,title:media.title||'Wakhan',artist:state.room.name,position:cinema.store.position(media),playing:!!media.playing,cinema:{code:state.room.code,session:state.session,token:getKey()}});if(disposed||token!==generation)await player.control({id:requestID,action:'stop'}).catch(()=>{})}catch{if(token===generation){signature='';id=''}}
 }
 const unsubscribe=cinema.store.subscribe(state=>void sync(state));
 async function appState(active){hidden=!active;cinema.media.background(hidden&&!!id);if(active){if(id)await player.control({id,action:'pause'}).catch(()=>{});cinema.media.background(false);cinema.refreshPeople();}else if(!suspended)await sync(cinema.context())}
 const visibility=()=>void appState(!document.hidden);document.addEventListener('visibilitychange',visibility);
 return{appState,suspend(){suspended=true;cinema.media.background(false);void stop()},resume(){suspended=false;void sync(cinema.context())},dispose(){disposed=true;unsubscribe();document.removeEventListener('visibilitychange',visibility);cinema.media.background(false);return stop()}};
}
