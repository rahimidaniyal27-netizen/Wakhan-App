const empty=account=>({account,view:'salons',section:'mine',personal:null,room:null,session:null,revision:0,serverTime:0,received:0,media:null,messages:[],queue:[],members:[],notice:'',minimized:false,fullscreen:false,connection:'offline',error:null});
/* The room session outlives its views; navigation never releases voice/media. */
export function createCinemaState({uid=()=>0,now=()=>performance.now()}={}){
 let value=empty(Number(uid())||0),epoch=0;const listeners=new Set();
 function emit(){for(const fn of listeners)fn(value)}
 function account(){const id=Number(uid())||0;if(id!==value.account){epoch++;value=empty(id);emit()}return id}
 function patch(next){value={...value,...next};emit();return value}
 function append(messages=[]){const rows=new Map(value.messages.map(m=>[String(m.id),m]));for(const message of messages)if(message?.id)rows.set(String(message.id),message);if(messages.length)patch({messages:[...rows.values()].slice(-400)});return messages}
 function apply(snapshot,{generation=epoch}={}){
  account();if(generation!==epoch||!snapshot||snapshot.account&&snapshot.account!==value.account)return false;
  if(snapshot.room&&value.room&&snapshot.room.code!==value.room.code)return false;
  const revision=Number(snapshot.revision)||0;if(revision<value.revision)return false;
  const {messages,...next}=snapshot;patch({...next,revision,received:now(),error:null});if(messages)append(messages);return true;
 }
 function enter(room,session,notice=''){
  account();epoch++;value={...empty(value.account),room,session,notice,view:'room',connection:'connecting',messages:notice?[{id:'notice:'+session,kind:'notice',text:notice,local:true}]:[]};emit();return epoch;
 }
 function reconnect(snapshot){const {view,minimized,fullscreen}=value;epoch++;value={...value,session:snapshot.session,revision:0};apply(snapshot);patch({view,minimized,fullscreen});return epoch}
 function leave(){epoch++;value=empty(value.account);emit()}
 function position(media=value.media){if(!media)return 0;return Math.max(0,Number(media.position||0)+(media.playing?Math.max(0,now()-value.received)/1000:0))}
 return {get:()=>value,patch,apply,append,enter,reconnect,leave,account,position,epoch:()=>epoch,subscribe(fn){listeners.add(fn);fn(value);return()=>listeners.delete(fn)},dispose(){epoch++;listeners.clear()}};
}
