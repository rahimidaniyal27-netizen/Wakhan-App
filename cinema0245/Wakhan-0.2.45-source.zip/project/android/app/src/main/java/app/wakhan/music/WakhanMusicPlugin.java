package app.wakhan.music;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import org.json.JSONArray;
import androidx.core.content.ContextCompat;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.common.util.concurrent.ListenableFuture;

@CapacitorPlugin(name = "WakhanMusic")
public class WakhanMusicPlugin extends Plugin {
    private MediaController controller;
    private ListenableFuture<MediaController> connecting;
    private String requestId = "";
    private volatile String desiredId = "";
    private boolean visible = true;
    private boolean destroyed = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (destroyed || !visible || controller == null) return;
            publish();
            handler.postDelayed(this, 1000);
        }
    };

    private boolean cinemaBound=false,cinemaMuted=false,cinemaApplying=false;
    private String cinemaMedia="",cinemaSource="";
    private CinemaSession cinemaSession;
    private CinemaSession cinemaSession(){if(cinemaSession==null)cinemaSession=new CinemaSession(new CinemaSession.Sink(){public void apply(JSONObject snapshot){applyCinema(snapshot);}public void unavailable(){if(controller!=null)controller.pause();}});return cinemaSession;}
    private void clearCinema(){cinemaBound=false;cinemaMedia="";cinemaSource="";if(cinemaSession!=null)cinemaSession.stop();}
    private boolean allowedRemote(Uri uri){
        if(!"https".equals(uri.getScheme())||uri.getPort()!=-1||uri.getUserInfo()!=null||uri.getFragment()!=null||uri.getPath()==null)return false;
        String host=uri.getHost(),path=uri.getPath();
        return ("music.kabulcafe.uk".equals(host)&&(path.matches("/(a|api/app/music/media)/[A-Za-z0-9_-][A-Za-z0-9_.-]*")||(path.equals("/api/app/cinema/v2/media/file")&&uri.getQueryParameter("lease")!=null)))
            ||("api.audius.co".equals(host)&&path.matches("/v1/tracks/[A-Za-z0-9]{1,30}/stream")&&"app_name=Wakhan".equals(uri.getQuery()))
            ||("archive.org".equals(host)&&path.matches("/download/[A-Za-z0-9_.-]{1,180}/.+\\.mp3")&&uri.getQuery()==null)
            ||("ccmixter.org".equals(host)&&path.matches("/content/[^/]+/[^/]+\\.mp3")&&uri.getQuery()==null);
    }

    private interface Ready { void run(MediaController player); }
    private void ready(PluginCall call, Ready action) {
        getActivity().runOnUiThread(() -> {
            if (destroyed) { call.reject("PLAYER_UNAVAILABLE"); return; }
            if (controller != null) { action.run(controller); return; }
            if (connecting == null) {
                SessionToken token = new SessionToken(getContext(),
                    new ComponentName(getContext(), WakhanMusicService.class));
                connecting = new MediaController.Builder(getContext(), token).buildAsync();
            }
            ListenableFuture<MediaController> pending = connecting;
            pending.addListener(() -> {
                if (destroyed) { call.reject("PLAYER_UNAVAILABLE"); return; }
                if (pending != connecting) { call.reject("PLAYER_CANCELLED"); return; }
                try {
                    if (controller == null) {
                        controller = pending.get();
                        controller.addListener(new Player.Listener() {
                            @Override public void onEvents(Player player, Player.Events events) { publish(); }
                            @Override public void onPlayWhenReadyChanged(boolean playing,int reason){if(cinemaBound&&!cinemaApplying){if(reason==Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_BECOMING_NOISY)cinemaMuted=true;else if(!visible&&reason==Player.PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST)cinemaMuted=!playing;}}
                            @Override public void onPlayerError(PlaybackException error) {
                                JSObject value = snapshot();
                                value.put("error", "PLAYBACK_FAILED");
                                value.put("errorCode", error.errorCode);
                                notifyListeners("state", value);
                            }
                        });
                        handler.removeCallbacks(tick); tick.run();
                    }
                    action.run(controller);
                } catch (Exception error) {
                    connecting = null; call.reject("PLAYER_UNAVAILABLE");
                }
            }, ContextCompat.getMainExecutor(getContext()));
        });
    }

    private JSObject snapshot() {
        JSObject value = new JSObject();
        value.put("backgroundOnly",cinemaBound);
        value.put("id", controller != null && controller.getCurrentMediaItem() != null
            ? controller.getCurrentMediaItem().mediaId : requestId);
        if (controller == null) { value.put("active", false); return value; }
        long duration = controller.getDuration();
        int state = controller.getPlaybackState();
        value.put("active", controller.getMediaItemCount() > 0 && state != Player.STATE_IDLE && state != Player.STATE_ENDED);
        value.put("ready", state == Player.STATE_READY);
        value.put("buffering", state == Player.STATE_BUFFERING);
        value.put("ended", state == Player.STATE_ENDED);
        value.put("playing", controller.isPlaying());
        value.put("wanted", controller.getPlayWhenReady());
        value.put("position", Math.max(0, controller.getCurrentPosition()) / 1000.0);
        value.put("duration", duration == C.TIME_UNSET ? 0 : Math.max(0, duration) / 1000.0);
        return value;
    }

    private void publish() {
        if (!destroyed && controller != null) notifyListeners("state", snapshot());
    }

    @PluginMethod public void loadTrack(PluginCall call) {
        String source = call.getString("source", "");
        String id = call.getString("id", "");
        Uri uri = Uri.parse(source);
        boolean allowed=allowedRemote(uri);
        String path=uri.getPath();
        if ("file".equals(uri.getScheme()) && uri.getQuery() == null && uri.getFragment() == null && path != null) {
            try {
                java.io.File file = new java.io.File(path);
                java.io.File folder = new java.io.File(getContext().getFilesDir(), "wakhan-music");
                allowed = file.isFile() && file.getCanonicalFile().getParentFile().equals(folder.getCanonicalFile()) && file.getName().matches("u[0-9]{1,18}_[a-f0-9]{64}\\.mp3");
            } catch (java.io.IOException error) { allowed = false; }
        }
        if (!allowed || !id.matches("[A-Za-z0-9_-]{1,64}")) { call.reject("INVALID_AUDIO_SOURCE"); return; }
        final JSONObject cinema=call.getObject("cinema");
        if(cinema!=null&&(!CinemaSession.valid(cinema)||!"music.kabulcafe.uk".equals(uri.getHost())||!"/api/app/cinema/v2/media/file".equals(uri.getPath()))){call.reject("INVALID_CINEMA_SESSION");return;}
        desiredId = id;
        ready(call, player -> {
            if (!id.equals(desiredId)) { call.resolve(); return; }
            clearCinema();if(cinema!=null){cinemaBound=true;cinemaSession().bind(cinema);cinemaSession().foreground(visible);}
            requestId = id;
            MediaMetadata metadata = new MediaMetadata.Builder()
                .setTitle(call.getString("title", "Wakhan"))
                .setArtist(call.getString("artist", "")).build();
            player.setMediaItem(new MediaItem.Builder().setMediaId(id).setUri(uri).setMediaMetadata(metadata).build());
            player.seekTo((long)(Math.max(0, call.getDouble("position", 0.0)) * 1000));
            player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO,true).build());
            cinemaApplying=true;player.setPlayWhenReady(Boolean.TRUE.equals(call.getBoolean("playing",true))&&(!cinemaBound||!visible));cinemaApplying=false;
            player.prepare();
            publish(); call.resolve(snapshot());
        });
    }

    @PluginMethod public void control(PluginCall call) {
        String id = call.getString("id", "");
        String action = call.getString("action", "");
        if (action.equals("stop") && id.equals(desiredId)) desiredId = "";
        ready(call, player -> {
            if (!id.equals(requestId)) { call.resolve(); return; }
            switch (action) {
                case "play":cinemaMuted=false; if (player.getPlaybackState() == Player.STATE_IDLE) player.prepare(); player.play(); break;
                case "pause":cinemaMuted=true; player.pause(); break;
                case "seek": player.seekTo((long)(Math.max(0, call.getDouble("position", 0.0)) * 1000)); break;
                case "stop":clearCinema(); player.stop(); player.clearMediaItems(); requestId = ""; break;
                default: call.reject("INVALID_PLAYER_ACTION"); return;
            }
            publish(); call.resolve(snapshot());
        });
    }

    @PluginMethod public void state(PluginCall call) {
        getActivity().runOnUiThread(() -> call.resolve(snapshot()));
    }

    @PluginMethod public void stopAll(PluginCall call) {
        desiredId = "";clearCinema();
        getActivity().runOnUiThread(() -> {
            if (controller != null) { controller.stop(); controller.clearMediaItems(); }
            requestId = "";
            getContext().stopService(new Intent(getContext(), WakhanMusicService.class));
            handler.removeCallbacks(tick);
            if (connecting != null) MediaController.releaseFuture(connecting);
            connecting = null; controller = null;
            call.resolve();
        });
    }

    private void applyCinema(JSONObject snapshot){
        if(controller==null||!cinemaBound||visible)return;
        JSONObject media=snapshot.optJSONObject("media"),source=media==null?null:media.optJSONObject("source");
        if(media==null||source==null||!"file".equals(source.optString("kind"))){controller.pause();return;}
        Uri uri=Uri.parse(source.optString("url"));if(!allowedRemote(uri)||!"/api/app/cinema/v2/media/file".equals(uri.getPath())){controller.pause();return;}
        String identity=media.optString("id")+"|"+media.optLong("cycle");double position=media.optDouble("position",0);
        if(!Double.isFinite(position)||position<0)return;
        if(!identity.equals(cinemaMedia)||!uri.toString().equals(cinemaSource)||controller.getCurrentMediaItem()==null){
            cinemaMedia=identity;cinemaSource=uri.toString();
            controller.setMediaItem(new MediaItem.Builder().setMediaId(requestId).setUri(uri).setMediaMetadata(new MediaMetadata.Builder().setTitle(media.optString("title","Wakhan")).build()).build());controller.seekTo((long)(position*1000));controller.prepare();
        }else if(Math.abs(controller.getCurrentPosition()/1000.0-position)>2)controller.seekTo((long)(position*1000));
        cinemaApplying=true;controller.setPlayWhenReady(media.optBoolean("playing")&&!cinemaMuted);cinemaApplying=false;publish();
    }
    @Override protected void handleOnPause(){visible=false;handler.removeCallbacks(tick);if(cinemaBound)cinemaSession().foreground(false);}
    @Override protected void handleOnResume(){visible=true;if(cinemaBound){cinemaSession().foreground(true);if(controller!=null)controller.pause();}handler.removeCallbacks(tick);tick.run();}
    @Override protected void handleOnDestroy() {
        destroyed=true;clearCinema();if(cinemaSession!=null)cinemaSession.dispose();handler.removeCallbacksAndMessages(null);
        if(connecting!=null)MediaController.releaseFuture(connecting);controller=null;
    }
}
