package app.wakhan.music;

import android.os.Handler;
import android.os.Looper;
import android.net.Uri;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

/** Fresh Cinema v2 session transport. Playback primitives never own microphones. */
final class CinemaSession {
    interface Sink { void apply(JSONObject snapshot); void unavailable(); }
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final Sink sink;
    private String code="", session="", token="";
    private boolean foreground=true, busy=false, stopped=false;
    private int epoch=0;
    CinemaSession(Sink sink) { this.sink=sink; }
    static boolean valid(JSONObject value) {
        return value!=null && value.optString("code").matches("[A-Z0-9]{4,8}")
            && value.optString("session").matches("[A-Za-z0-9_-]{16,80}")
            && value.optString("token").matches("wka1\\.[A-Za-z0-9_-]{24}\\.[a-f0-9]{32}");
    }
    void bind(JSONObject value) {
        epoch++;code=value.optString("code");session=value.optString("session");token=value.optString("token");stopped=false;busy=false;tick();
    }
    private final Runnable pulse=()->tick();
    void foreground(boolean value) { foreground=value;main.removeCallbacks(pulse);if(!value)tick(); }
    private void tick() {
        if(stopped||foreground)return;
        main.removeCallbacks(pulse);main.postDelayed(pulse,3000);
        if(busy)return;busy=true;final int request=epoch;final String key=token;
        final String address="https://music.kabulcafe.uk/api/app/cinema/v2/room/events?code="+Uri.encode(code)+"&session="+Uri.encode(session);
        network.execute(()->{
            JSONObject result=null;int status=0;
            try {
                HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();
                c.setInstanceFollowRedirects(false);c.setConnectTimeout(8000);c.setReadTimeout(10000);c.setRequestProperty("X-Init",key);
                try {
                    status=c.getResponseCode();if(status==200)try(InputStream input=c.getInputStream();ByteArrayOutputStream bytes=new ByteArrayOutputStream()) {
                        byte[] block=new byte[8192];int n;while((n=input.read(block))!=-1){if(bytes.size()+n>1000000)throw new java.io.IOException("response_limit");bytes.write(block,0,n);}
                        result=new JSONObject(bytes.toString("UTF-8"));
                    }
                } finally { c.disconnect(); }
            } catch(Exception ignored) {}
            final JSONObject value=result;final int response=status;
            main.post(()->{if(stopped||request!=epoch)return;busy=false;if(response==401||response==403||response==404||response==409){sink.unavailable();stop();return;}if(!foreground&&value!=null&&value.optBoolean("ok")){JSONObject snapshot=value.optJSONObject("snapshot");if(snapshot!=null)sink.apply(snapshot);}});
        });
    }
    void stop() { epoch++;stopped=true;busy=false;code="";session="";token="";main.removeCallbacks(pulse); }
    void dispose() { stop();network.shutdownNow(); }
}
