/* Live Home shell. Match UI/rules live in the one shared games service. */
(()=>{'use strict';
 const root=document.getElementById('wakhan-home-final'),phone=root.querySelector('.hc-phone'),content=phone.querySelector('.hc-content'),header=phone.querySelector('.hc-header'),nav=phone.querySelector('.hc-nav'),overlay=phone.querySelector('.hc-overlay'),dialog=overlay.querySelector('.hc-dialog'),dialogBody=overlay.querySelector('.hc-dialog-content');
 const games=[{id:'fiskot',name:'فیس‌کوت',min:4,max:4},{id:'ludo',name:'لدو',min:2,max:4},{id:'chess',name:'شطرنج',min:2,max:2},{id:'ono',name:'Ono',min:2,max:6},{id:'patpal',name:'پت‌پال',min:4,max:16},{id:'bazaar',name:'گم در بازار',min:4,max:10}];
 const friends=[],initial={};const state={view:'home',party:[]};let lastTrigger=null,toastTimer=0,gameHome=null,serverOffset=0;
 const liveHome={balance:null,salons:[],loading:true,error:false},liveAmount=()=>liveHome.balance===null?'—':Number(liveHome.balance).toLocaleString('en-US',{maximumFractionDigits:2});
 const fa=n=>String(n),game=id=>games.find(g=>g.id===id)||games[0],capacity=g=>g.min===g.max?g.max+' نفر':g.min+' تا '+g.max+' نفر';
 const native=value=>window.WakhanHomeNativeSend?.(value);
 function el(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;}
 function icon(name){const n=el('i');n.dataset.lucide=name;n.setAttribute('aria-hidden','true');return n;}
 function art(id,size){const n=el('span','hc-art');n.dataset.art=id;n.setAttribute('aria-hidden','true');if(size){n.style.width=size+'px';n.style.height=size+'px';}return n;}
 function button(label,action,cls='hc-secondary',symbol){const n=el('button',cls+' cursor-interaction');n.type='button';if(symbol)n.append(icon(symbol));if(label)n.append(document.createTextNode(label));if(action)n.dataset.action=action;return n;}
 function iconButton(label,action,symbol){const n=button('',action,'hc-icon',symbol);n.setAttribute('aria-label',label);return n;}
 function avatar(name,color){const n=el('span','hc-avatar',name.slice(0,1));if(color)n.style.background='radial-gradient(circle at 30% 20%,'+color+',#25283e)';return n;}
 function icons(){if(globalThis.lucide)lucide.createIcons({attrs:{width:18,height:18}});}

 function save(){}
 function heading(title,label,action){const n=el('div','hc-section-head');n.append(el('h3',null,title));if(label)n.append(button(label,action,'hc-text-action','chevron-left'));return n;}
 function homeChrome(){native({type:'navigation-chrome',view:state.view,blocked:!overlay.hidden,category:rankState.category,period:rankState.period});}
 function closeDialog(){overlay.hidden=true;homeChrome();[header,content,nav].forEach(n=>n.inert=false);if(lastTrigger?.isConnected)lastTrigger.focus({preventScroll:true});}
 function showDialog(title,key,body,trigger){lastTrigger=trigger||lastTrigger;dialog.dataset.kind=key;dialog.querySelector('h3').textContent=title;dialogBody.replaceChildren(body);dialog.querySelector('.hc-message').textContent='';overlay.hidden=false;[header,content,nav].forEach(n=>n.inert=true);homeChrome();const h=dialog.getBoundingClientRect().height;phone.style.setProperty('--sheet-top',Math.max(90,Math.min(140,phone.clientHeight-h-24))+'px');dialog.querySelector('[data-action=close]').focus({preventScroll:true});icons();}
 function toast(text){phone.querySelector('.hc-toast')?.remove();clearTimeout(toastTimer);const n=el('div','hc-toast',text);n.setAttribute('role','status');phone.style.setProperty('--toast-top','110px');phone.append(n);toastTimer=setTimeout(()=>n.remove(),2800);}
 window.WakhanHomeNativeNotice=toast;
 function renderHeader(){header.replaceChildren();if(state.view==='home'){const wallet=button('','wallet','hc-wallet');wallet.setAttribute('aria-label','موجودی سکه: '+liveAmount());const coin=el('span','hc-coin-mark');coin.append(icon('coins'));const amount=el('span','hc-wallet-value');amount.append(el('b',null,liveAmount()));wallet.append(coin,amount,el('span','hc-wallet-add','+'));const tools=el('div','hc-tools'),bell=iconButton('دعوت‌های بازی','game-invites','bell');if(gameHome?.invites?.length)bell.append(el('span','hc-dot'));tools.append(bell);header.append(wallet,tools);}else{header.append(iconButton('برگشت','back','chevron-right'));const brand=el('div','hc-brand');brand.append(el('h2',null,'برترین‌ها'));header.append(brand,el('div','hc-tools'));}}
 function homeGameCard(g,featured){
 const card=button('',null,'hm-game-card'+(featured?' is-featured':''));card.dataset.openGame=g.id;card.setAttribute('aria-label','ورود به '+g.name+'، '+capacity(g));
 const scene=art(g.id);scene.classList.add('hm-cover-art');const copy=el('span','hm-cover-copy');copy.append(el('b',null,g.name));
 const cap=el('span','hm-cover-capacity');cap.append(icon('users-round'),el('span',null,g.min===g.max?String(g.max):g.min+'–'+g.max));copy.append(cap);card.append(scene,copy);
 return card;
}


function rankAtmosphere(){
 const scene=el('div','gm-rank-sky gm-award-backdrop');scene.setAttribute('aria-hidden','true');
 ['gold','silver','bronze'].forEach(metal=>{const light=el('span','gm-stage-light');light.dataset.light=metal;scene.append(light);});
 scene.append(el('span','gm-stage-reflection'));return scene;
}

const rankNames={overall:'برترین‌ها',games:'برترین بازیکنان',purchase:'بیشترین خرید',activity:'بیشترین فعالیت'};
const rankState={category:rankNames[initial.rankCategory]?initial.rankCategory:'overall',period:['week','month'].includes(initial.rankPeriod)?initial.rankPeriod:'month',game:'fiskot'};
const rankData=new Map();let rankConnectionError=false;
const rankNum=n=>Number(n||0).toLocaleString('en-US',{maximumFractionDigits:2});
const rankKey=(category,period)=>category+':'+period;
function currentRanks(){return rankData.get(rankKey(state.view==='ranking'?rankState.category:'overall',state.view==='ranking'?rankState.period:'month'));}
function rankValue(p,category){return rankNum(p.score)+(category==='purchase'?' سکه':' امتیاز');}
function rankUserButton(p,cls){const b=button('',null,cls);b.dataset.rankUser=String(p.id);b.setAttribute('aria-label','جایگاه '+p.name);return b;}
function rankPortrait(p){const a=avatar(p?.name||'—');if(p?.photo){a.textContent='';const im=el('img');im.src=p.photo;im.alt='';im.onerror=()=>{im.remove();a.textContent=String(p.name||'').slice(0,1);};a.append(im);}return a;}
function patchPodium(podium,data){
 const existing=new Map([...podium.children].map(n=>[n.dataset.rankKey,n])),wanted=[];
 [2,1,3].forEach(place=>{const p=data?.items?.[place-1],key=p?'user:'+p.id:'empty:'+place;let b=existing.get(key);
  if(!b){b=p?rankUserButton(p,'gm-winner'):el('div','gm-winner');b.dataset.rankKey=key;const portrait=el('span','gm-winner-portrait'),frame=el('span','gm-portrait-frame');frame.setAttribute('aria-hidden','true');frame.append(el('span','gm-frame-orbit'),el('span','gm-frame-gem'));portrait.append(rankPortrait(p),frame,el('span','gm-medal'));const step=el('span','gm-step');step.append(el('b'),el('small'));b.append(portrait,step);}
  b.dataset.place=String(place);const portrait=b.querySelector('.gm-winner-portrait');
  const imageKey=JSON.stringify([p?.name,p?.photo]);if(b.dataset.imageKey!==imageKey){b.dataset.imageKey=imageKey;portrait.querySelector('.hc-avatar').replaceWith(rankPortrait(p));}
  b.querySelector('.gm-medal').textContent=String(place);const crown=portrait.querySelector('[data-lucide=crown],svg.lucide-crown');if(place===1&&!crown)portrait.append(icon('crown'));if(place!==1)crown?.remove();
  const name=b.querySelector('.gm-step>b'),value=b.querySelector('.gm-step>small');const text=p?.name||'—',score=p?rankValue(p,data.category):'—';if(name.textContent!==text)name.textContent=text;if(value.textContent!==score)value.textContent=score;
  wanted.push(b);
 });
 [...podium.children].filter(n=>!wanted.includes(n)).forEach(n=>n.remove());wanted.forEach((n,i)=>{if(podium.children[i]!==n)podium.insertBefore(n,podium.children[i]||null);});
}
function rankPodium(data){const n=el('div','gm-podium');n.setAttribute('aria-label','سه نفر برتر');patchPodium(n,data);return n;}
function rankMini(){const box=el('section','gm-top-three'),head=heading('برترین‌ها','همه','rankings');head.append(el('small','gm-period','این ماه'));box.append(rankAtmosphere(),head,rankPodium(rankData.get('overall:month')));return box;}
function showRankUser(id,trigger){const data=currentRanks(),p=data?.items.find(p=>p.id===id)||data?.me;if(!p||p.id!==id)return;const box=el('div'),profile=el('div','hc-rank-profile');profile.append(rankPortrait(p),el('h4',null,p.name),el('span',null,p.position?'رتبهٔ '+p.position:'هنوز رتبه‌ای ندارید'));box.append(profile,el('p',null,rankValue(p,data.category)),el('p',null,data.rule));showDialog('جایگاه کاربر','rank-user',box,trigger);}
function updateRankingUI(){
 const data=currentRanks(),podium=content.querySelector('.gm-podium');if(podium)patchPodium(podium,data);
 if(state.view!=='ranking'){icons();return;}
 const list=content.querySelector('.hc-rank-list');if(!list)return;const old=new Map([...list.children].map(n=>[n.dataset.rankUser,n])),nodes=[];
 for(const p of data?.items.slice(3)||[]){let row=old.get(p.id);if(!row){row=rankUserButton(p,'hc-rank-row');row.append(el('span','hc-rank-number'),rankPortrait(p),el('b'),el('small'));}const key=JSON.stringify([p.name,p.photo]);if(row.dataset.imageKey!==key){row.dataset.imageKey=key;row.querySelector('.hc-avatar').replaceWith(rankPortrait(p));}row.querySelector('.hc-rank-number').textContent=String(p.position);row.querySelector('b').textContent=p.name;row.querySelector('small').textContent=rankValue(p,data.category);row.classList.toggle('hc-rank-self',p.own);nodes.push(row);}
 [...list.children].filter(n=>!nodes.includes(n)).forEach(n=>n.remove());nodes.forEach((n,i)=>{if(list.children[i]!==n)list.insertBefore(n,list.children[i]||null);});
 const note=content.querySelector('.hm-live-ranking-note');note.textContent=rankConnectionError?'دریافت رتبه‌های تازه ممکن نشد.':!data?'در حال دریافت رتبه‌ها…':!data.available?data.rule:!data.items.length?'در این دوره هنوز امتیازی ثبت نشده است.':'';note.hidden=!note.textContent;
 const own=content.querySelector('.hc-rank-own-total');own.hidden=!data?.me;own.querySelector('b').textContent=data?.me?.position?String(data.me.position):'—';own.querySelector('small').textContent=data?.me?rankValue(data.me,data.category):'';icons();
}
function renderRanks(){
 const box=el('section','hc-rank-page'),toolbar=el('div','hc-rank-toolbar'),periods=el('div','hc-rank-periods');[['این هفته','week'],['این ماه','month']].forEach(([n,v])=>{const b=button(n,null,'hc-rank-period');b.dataset.rankPeriod=v;b.setAttribute('aria-pressed',String(rankState.period===v));periods.append(b);});toolbar.append(periods,iconButton('شیوهٔ محاسبهٔ رتبه','rank-info','info'));box.append(toolbar);const tabs=el('div','hc-rank-categories');[['کلی','overall'],['بازی‌ها','games'],['خرید','purchase'],['فعالیت','activity']].forEach(([n,v])=>{const b=button(n,null,'hc-rank-category');b.dataset.rankCategory=v;b.setAttribute('aria-pressed',String(rankState.category===v));tabs.append(b);});
 const list=el('div','hc-rank-list'),own=el('div','hc-rank-own-total');own.append(el('span',null,'رتبهٔ شما'),el('b'),el('small'));box.append(tabs,el('h3','hc-rank-heading',rankNames[rankState.category]),rankPodium(currentRanks()),list,el('p','hm-live-ranking-note'),own);content.replaceChildren(box);updateRankingUI();homeChrome();
}
function gameRankShortcut(){return button('رتبه‌بندی','game-rank','hc-page-info','trophy');}
root.addEventListener('click',event=>{const category=event.target.closest('[data-rank-category]'),period=event.target.closest('[data-rank-period]'),user=event.target.closest('[data-rank-user]');if(category){rankState.category=category.dataset.rankCategory;rankConnectionError=false;renderRanks();icons();save();}else if(period){rankState.period=period.dataset.rankPeriod;rankConnectionError=false;renderRanks();icons();save();}else if(user){showRankUser(user.dataset.rankUser,user);}});

const homeTabMotion={memory:new Map(),captured:new Map(),contentAnimation:null,queued:false,beforeSignature:''};
const homeFinalEpoch=performance.now();
const homeFinalPreference=matchMedia('(prefers-reduced-motion: reduce)');
const homeTabGroups=[['navigation','.hc-nav'],['rank-category','.hc-rank-categories'],['rank-period','.hc-rank-periods']];
function homeFinalSignature(){return [state.view,state.selected,rankState.category,rankState.period,rankState.game].join(':');}
function homeTabKey(button){return button.dataset.action||button.dataset.rankCategory||button.dataset.rankPeriod||'';}
function homeTabGeometry(node,group){const a=node.getBoundingClientRect(),b=group.getBoundingClientRect();return {x:a.left-b.left-group.clientLeft,y:a.top-b.top-group.clientTop,width:a.width,height:a.height,groupWidth:group.clientWidth};}
function homeTabTransform(rect){return 'translate3d('+rect.x+'px,'+rect.y+'px,0)';}
function captureHomeTabs(){
 for(const [key,selector] of homeTabGroups){
  const group=root.querySelector(selector);if(!group||!group.getClientRects().length)continue;
  const active=group.querySelector(':scope > button[aria-current="page"],:scope > button[aria-pressed="true"]');if(!active)continue;
  const indicator=group.querySelector(':scope > .hm-selection');homeTabMotion.captured.set(key,{key:homeTabKey(active),rect:homeTabGeometry(indicator||active,group)});
 }
}
function syncHomeTabs(animate=true){
 for(const n of root.querySelectorAll('.gm-stage-light,.gm-stage-reflection,.gm-frame-orbit')){if(n.dataset.motionPhase)continue;const offset=parseFloat(getComputedStyle(n).animationDelay)||0;n.style.animationDelay=(offset-(performance.now()-homeFinalEpoch)/1000)+'s';n.dataset.motionPhase='1';}
 for(const [key,selector] of homeTabGroups){
  const group=root.querySelector(selector);if(!group||!group.getClientRects().length)continue;
  const active=group.querySelector(':scope > button[aria-current="page"],:scope > button[aria-pressed="true"]');if(!active)continue;
  group.dataset.smoothTabs=key;
  const target=homeTabGeometry(active,group),activeKey=homeTabKey(active),previous=homeTabMotion.memory.get(key),captured=homeTabMotion.captured.get(key);
  let indicator=group.querySelector(':scope > .hm-selection');
  const unchanged=indicator&&previous?.indicator===indicator&&previous.key===activeKey&&Math.abs(previous.rect.x-target.x)<.5&&Math.abs(previous.rect.width-target.width)<.5;
  if(unchanged)continue;
  if(!indicator){indicator=el('span','hm-selection');indicator.setAttribute('aria-hidden','true');group.prepend(indicator);}
  const origin=captured||(previous?{key:previous.key,rect:previous.rect}:null);
  indicator.getAnimations().forEach(a=>a.cancel());
  indicator.style.width=target.width+'px';indicator.style.height=target.height+'px';indicator.style.transform=homeTabTransform(target);
  if(animate&&!homeFinalPreference.matches&&origin&&origin.key!==activeKey&&Math.abs(origin.rect.groupWidth-target.groupWidth)<1){
   indicator.animate([{transform:homeTabTransform(origin.rect),width:origin.rect.width+'px',height:origin.rect.height+'px'},{transform:homeTabTransform(target),width:target.width+'px',height:target.height+'px'}],{duration:key==='rank-period'?280:320,easing:'cubic-bezier(.2,.8,.25,1)'});
  }
  homeTabMotion.memory.set(key,{indicator,key:activeKey,rect:target});
 }
 homeTabMotion.captured.clear();
}
function scheduleHomeMotion(event){
 if(!homeTabMotion.queued){homeTabMotion.beforeSignature=homeFinalSignature();captureHomeTabs();}
 if(homeTabMotion.queued)return;homeTabMotion.queued=true;
 requestAnimationFrame(()=>{
  homeTabMotion.queued=false;syncHomeTabs();
  if(homeTabMotion.beforeSignature!==homeFinalSignature()){
   homeTabMotion.contentAnimation?.cancel();
   if(!homeFinalPreference.matches)homeTabMotion.contentAnimation=content.animate([{opacity:.68,transform:'translateY(4px)'},{opacity:1,transform:'translateY(0)'}],{duration:200,easing:'cubic-bezier(.2,.8,.25,1)'});
  }
 });
}
root.addEventListener('click',scheduleHomeMotion,true);
root.addEventListener('change',scheduleHomeMotion,true);
let homeFinalWidth=phone.clientWidth;
const homeFinalResize=new ResizeObserver(()=>{const width=phone.clientWidth;if(Math.abs(width-homeFinalWidth)<.5)return;homeFinalWidth=width;syncHomeTabs(false);});homeFinalResize.observe(phone);
homeFinalPreference.addEventListener('change',()=>{if(homeFinalPreference.matches){homeTabMotion.contentAnimation?.cancel();for(const m of homeTabMotion.memory.values())m.indicator.getAnimations().forEach(a=>a.cancel());}syncHomeTabs(false);});
window.addEventListener('pagehide',()=>homeFinalResize.disconnect(),{once:true});

function friendStrip(){const list=el('div','hc-friends');friends.forEach(p=>{const b=button('',null,'hc-friend');b.dataset.friend=p.id;b.setAttribute('aria-label',p.full+'، آنلاین');b.setAttribute('aria-pressed',String(state.party.includes(p.id)));const av=avatar(p.name,p.color);if(p.photo){av.textContent='';const im=el('img');im.src=p.photo;im.alt='';im.onerror=()=>{im.remove();av.prepend(document.createTextNode(p.name.slice(0,1)));};av.append(im);}av.append(el('i','hc-online'));b.append(av,el('span',null,p.name));list.append(b);});const add=iconButton('دوستان','friends','user-round-plus');add.className='hc-invite-friends cursor-interaction';list.append(add);return list;};
function patchSalons(){
 const list=content.querySelector('.hc-salons');if(!list)return;const existing=new Map([...list.children].map(n=>[n.dataset.salon,n])),nodes=[];
 for(const s of liveHome.salons.slice(0,4)){let b=existing.get(s.code);if(!b){b=button('',null,'hc-salon');b.dataset.salon=s.code;const mark=el('span','hc-salon-mark'),copy=el('span','hc-salon-copy'),stub=el('span','hc-salon-stub');copy.append(el('b'),el('small'));stub.append(icon('chevron-left'));b.append(mark,copy,stub);}
  b.setAttribute('aria-label',s.name+'، '+s.live+' نفر حاضر');const mark=b.querySelector('.hc-salon-mark'),key=JSON.stringify([s.name,s.photo]);if(b.dataset.imageKey!==key){b.dataset.imageKey=key;mark.replaceChildren(rankPortrait(s));}b.querySelector('b').textContent=s.name;b.querySelector('small').textContent=s.live+' نفر حاضر'+(s.status==='watching'?' · در حال تماشا':s.status==='music'?' · موسیقی':'');nodes.push(b);
 }
 [...list.children].filter(n=>!nodes.includes(n)).forEach(n=>n.remove());nodes.forEach((n,i)=>{if(list.children[i]!==n)list.insertBefore(n,list.children[i]||null);});const note=content.querySelector('.gm-salon-section>.hm-live-note');if(note){note.hidden=nodes.length>0;note.textContent=liveHome.loading?'در حال دریافت سالون‌ها…':'برای دیدن سالون‌ها، «همه» را باز کنید.';}icons();
}

 function renderNow(){const n=el('section','hm-now');n.append(heading('همین حالا','مچ‌های باز','game-list'),el('div','hm-now-list'));return n;}
 function patchNow(){const list=content.querySelector('.hm-now-list');if(!list)return;list.replaceChildren();const row=(match,label,action)=>{const n=el('article','hm-now-row'),copy=el('span','hm-now-copy');copy.append(el('b',null,game(match.game).name),el('small',null,label+' · '+match.count+'/'+match.maximum));const b=button(action==='resume'?'برگشت':'پیوستن',null,'hc-join');b.dataset.gameMatch=match.id;n.append(art(match.game),copy,b);return n;};
  if(gameHome?.resume)list.append(row(gameHome.resume,'مچ شما','resume'));
  for(const invite of gameHome?.invites||[]){if(invite.expires*1000+serverOffset<=Date.now())continue;const n=el('article','hm-now-row'),copy=el('span','hm-now-copy'),timer=el('small');timer.dataset.gameExpires=String(invite.expires);copy.append(el('b',null,game(invite.match.game).name),el('small',null,'دعوت '+invite.sender.name),timer);const actions=el('span','hm-game-invite-actions');for(const [title,accept] of [['پیوستن',true],['لغو',false]]){const b=button(title,null,accept?'hc-join':'hc-text-action');b.dataset.gameInvite=invite.id;b.dataset.accept=String(accept);actions.append(b);}n.append(art(invite.match.game),copy,actions);list.append(n);}
  for(const match of gameHome?.one_needed||[])if(match.id!==gameHome?.resume?.id)list.append(row(match,'با تو شروع می‌شود','join'));
  if(!list.children.length){const n=el('div','hm-now-row hm-live-empty');n.append(icon('gamepad-2'),el('span',null,'فعلاً مچ بازی باز نیست'),button('ساخت بازی','game-list','hc-join'));list.append(n);}icons();updateTimers();
 }
 function updateTimers(){if(document.documentElement.dataset.wkHostActive==='false')return;for(const n of root.querySelectorAll('[data-game-expires]')){const sec=Math.max(0,Math.ceil((Number(n.dataset.gameExpires)*1000+serverOffset-Date.now())/1000));n.textContent=sec+' ثانیه';if(!sec)n.closest('.hm-now-row')?.remove();}}
 function renderHome(){content.replaceChildren();const online=el('section','gm-online');online.classList.toggle('is-empty',!friends.length);online.append(friendStrip());content.append(online);if(liveHome.error)content.append(button('دریافت اطلاعات تازه','native-refresh','hc-secondary','refresh-cw'));const library=el('section','hm-game-library');library.append(heading('بازی‌ها'));const adventures=el('div','hm-adventures');['patpal','bazaar'].forEach(id=>adventures.append(homeGameCard(game(id),true)));const table=el('div','hm-table-games');['fiskot','ludo','chess','ono'].forEach(id=>table.append(homeGameCard(game(id),false)));library.append(adventures,table);content.append(library,renderNow(),rankMini());const salons=el('section','gm-salon-section');salons.append(heading('سالون‌ها','همه','salons'),el('div','hc-salons'),el('p','hm-live-note'));content.append(salons);patchSalons();patchNow();}
 function render(){const changed=phone.dataset.screen!==state.view;phone.dataset.screen=state.view;closeDialog();renderHeader();if(state.view==='ranking')renderRanks();else renderHome();nav.hidden=true;nav.replaceChildren();icons();syncHomeTabs();homeChrome();if(changed)scrollTo(0,0);}
window.addEventListener('wakhan:home-live-data',event=>{const data=event.detail||{},before=JSON.stringify(friends);liveHome.balance=Number.isFinite(data.balance)&&data.balance>=0?data.balance:null;liveHome.loading=data.loading===true;liveHome.error=data.error===true;liveHome.salons=Array.isArray(data.salons)?data.salons:[];friends.splice(0,friends.length,...(Array.isArray(data.friends)?data.friends.filter(p=>p.online===true):[]));if(state.view==='home'){let retry=content.querySelector('[data-action=native-refresh]');if(liveHome.error&&!retry){retry=button('دریافت اطلاعات تازه','native-refresh','hc-secondary','refresh-cw');content.querySelector('.gm-online')?.after(retry);}else if(!liveHome.error)retry?.remove();const amount=header.querySelector('.hc-wallet-value b');if(amount)amount.textContent=liveAmount();if(before!==JSON.stringify(friends)){const online=content.querySelector('.gm-online');if(online){online.classList.toggle('is-empty',!friends.length);online.replaceChildren(friendStrip());}}patchSalons();}else if(!header.children.length)renderHeader();icons();});
window.addEventListener('wakhan:home-live-salons',event=>{liveHome.salons=Array.isArray(event.detail)?event.detail:[];if(state.view==='home')patchSalons();});
window.addEventListener('wakhan:home-live-rankings',event=>{const data=event.detail;if(!data||!rankNames[data.category]||!['week','month'].includes(data.period))return;rankConnectionError=false;rankData.set(rankKey(data.category,data.period),data);updateRankingUI();});
window.addEventListener('wakhan:home-rankings-error',()=>{rankConnectionError=true;updateRankingUI();});

 root.addEventListener('click',event=>{const b=event.target.closest('button');if(event.target===overlay){closeDialog();return;}if(!b)return;const a=b.dataset.action;
  if(b.dataset.openGame){native({type:'game',game:b.dataset.openGame});return;}
  if(b.dataset.gameMatch){native({type:'game-match',match:b.dataset.gameMatch});return;}
  if(b.dataset.gameInvite){b.disabled=true;native({type:'game-invite',invite:b.dataset.gameInvite,accept:b.dataset.accept==='true'});setTimeout(()=>{if(b.isConnected)b.disabled=false},1000);return;}
  if(b.dataset.salon){native({type:'salon',code:b.dataset.salon});return;}
  if(b.dataset.friend){native({type:'dm',uid:b.dataset.friend});return;}
  if(a==='wallet')native({type:'wallet'});else if(a==='friends')native({type:'people'});else if(a==='game-invites')native({type:'game-invites'});else if(a==='game-list')native({type:'games-catalog'});else if(a==='salons')native({type:'salons'});else if(a==='native-refresh')native({type:'refresh'});else if(a==='rankings'){state.view='ranking';render();}else if(a==='back'){state.view='home';render();}else if(a==='close')closeDialog();else if(a==='rank-info'){const box=el('div');box.append(el('p',null,currentRanks()?.rule||'در حال دریافت شیوهٔ محاسبه…'));showDialog('شیوهٔ رتبه‌بندی','rank-info',box,b);}
 });
 root.addEventListener('keydown',event=>{if(event.key==='Escape'&&!overlay.hidden)closeDialog();});
 window.addEventListener('wakhan:games-home',event=>{gameHome=event.detail;if(gameHome?.server_time)serverOffset=Date.now()-gameHome.server_time*1000;if(state.view==='home'){patchNow();const b=header.querySelector('[data-action=game-invites]');if(b){b.querySelector('.hc-dot')?.remove();if(gameHome?.invites?.length)b.append(el('span','hc-dot'));}}});
 window.addEventListener('wakhan:home-live-route',event=>{if(event.detail?.type==='open-game'){native({type:'game',game:event.detail.game});return;}if(state.view!=='home'){state.view='home';render();}else{closeDialog();homeChrome();}scrollTo(0,0);});
 window.WakhanHomeDesign=Object.freeze({openGame(id){native({type:'game',game:id});},openHome(){state.view='home';render();},getView(){return {screen:state.view};}});
 const timer=setInterval(updateTimers,200);window.addEventListener('pagehide',()=>{clearInterval(timer);clearTimeout(toastTimer)},{once:true});
 render();window.dispatchEvent(new CustomEvent('wakhan:home-native-ready'));
})();
