/* Only sanitized view data crosses this boundary; sign-in credentials stay in the parent. */
(()=>{
 const fragment=new URLSearchParams(location.hash.slice(1)),nonce=fragment.get('bridge');
 function applyInsets(value){const sides=['top','right','bottom','left'];if(!value||sides.some(k=>!Number.isFinite(value[k])||value[k]<0||value[k]>Math.max(innerHeight,innerWidth)/2))return;for(const side of sides)document.documentElement.style.setProperty('--wk-home-safe-'+side,value[side]+'px');}
 if(parent!==window&&nonce)applyInsets(Object.fromEntries(['top','right','bottom','left'].map(k=>[k,Number(fragment.get('safe-'+k)||0)])));
 const send=value=>{if(parent!==window&&nonce)parent.postMessage({channel:'wakhan-home-r17',nonce,...value},'*');};
 window.WakhanHomeHost={sharedNavigation:parent!==window&&!!nonce,navigate:route=>send({type:'navigate',route}),onIntent:intent=>{
  if(intent.type==='open-salon'){send({type:'salon',code:intent.salonId});return;}
  if(intent.type==='open-game')send({type:'game',game:intent.gameId||intent.game});
 }};
 window.WakhanHomeNativeSend=send;
 let latest=null;
 window.addEventListener('message',event=>{const data=event.data;if(event.source!==parent||data?.channel!=='wakhan-home-r17'||data.nonce!==nonce)return;
  if(data.type==='visibility'){document.documentElement.dataset.wkHostActive=String(data.active===true);}
  else if(data.type==='insets'){applyInsets(data.data);}
  else if(data.type==='snapshot'){latest=data.data;window.dispatchEvent(new CustomEvent('wakhan:home-live-data',{detail:latest}));}
  else if(data.type==='notice')window.WakhanHomeNativeNotice?.(data.text);
  else if(data.type==='games-home')window.dispatchEvent(new CustomEvent('wakhan:games-home',{detail:data.data}));
  else if(data.type==='salons')window.dispatchEvent(new CustomEvent('wakhan:home-live-salons',{detail:data.data}));
  else if(data.type==='rankings-error')window.dispatchEvent(new CustomEvent('wakhan:home-rankings-error'));
  else if(data.type==='rankings')window.dispatchEvent(new CustomEvent('wakhan:home-live-rankings',{detail:data.data}));
  else if(['route','open-games','open-game'].includes(data.type))window.dispatchEvent(new CustomEvent('wakhan:home-live-route',{detail:data}));
 });
 window.addEventListener('wakhan:home-native-ready',()=>{if(latest)window.dispatchEvent(new CustomEvent('wakhan:home-live-data',{detail:latest}));send({type:'ready'});});
})();
