import Foundation

/// Fresh Cinema v2 background synchronization. Only signed, room-scoped snapshots.
final class CinemaSession: NSObject, URLSessionTaskDelegate {
    private var config: [String:String] = [:]
    private var timer: Timer?, task: URLSessionDataTask?
    private var generation=0, foreground=true
    private let receive: ([String:Any])->Void
    private let unavailable: ()->Void
    private lazy var http: URLSession = { let c=URLSessionConfiguration.ephemeral;c.urlCache=nil;c.timeoutIntervalForRequest=10;return URLSession(configuration:c,delegate:self,delegateQueue:nil) }()
    init(receive:@escaping ([String:Any])->Void, unavailable:@escaping ()->Void){self.receive=receive;self.unavailable=unavailable}
    static func valid(_ value:[String:Any])->Bool {
        let patterns=["code":"^[A-Z0-9]{4,8}$","session":"^[A-Za-z0-9_-]{16,80}$","token":"^wka1\\.[A-Za-z0-9_-]{24}\\.[a-f0-9]{32}$"]
        return patterns.allSatisfy { key,pattern in guard let v=value[key]as? String else{return false};return v.range(of:pattern,options:.regularExpression) != nil }
    }
    func bind(_ value:[String:Any]){stop();config=value.compactMapValues{$0 as? String}}
    func setForeground(_ value:Bool){foreground=value;timer?.invalidate();timer=nil;if !value {poll();timer=Timer.scheduledTimer(withTimeInterval:3,repeats:true){[weak self]_ in self?.poll()}}}
    private func poll(){
        guard !foreground,task==nil,let code=config["code"],let sid=config["session"],let key=config["token"]else{return}
        var u=URLComponents(string:"https://music.kabulcafe.uk/api/app/cinema/v2/room/events")!;u.queryItems=[URLQueryItem(name:"code",value:code),URLQueryItem(name:"session",value:sid)]
        guard let url=u.url else{return};var request=URLRequest(url:url);request.setValue(key,forHTTPHeaderField:"X-Init");request.cachePolicy = .reloadIgnoringLocalCacheData;let epoch=generation
        task=http.dataTask(with:request){[weak self]data,response,error in DispatchQueue.main.async {
            guard let self=self,epoch==self.generation else{return};self.task=nil
            if let status=(response as? HTTPURLResponse)?.statusCode,[401,403,404,409].contains(status){self.unavailable();self.stop();return}
            guard !self.foreground,error==nil,let data=data,data.count<=1000000,let value=(try? JSONSerialization.jsonObject(with:data))as? [String:Any],value["ok"]as? Bool==true,let snapshot=value["snapshot"]as? [String:Any]else{return};self.receive(snapshot)
        }};task?.resume()
    }
    func stop(){generation+=1;timer?.invalidate();timer=nil;task?.cancel();task=nil;config=[:]}
    func urlSession(_ session:URLSession, task:URLSessionTask, willPerformHTTPRedirection response:HTTPURLResponse, newRequest request:URLRequest, completionHandler:@escaping (URLRequest?)->Void){completionHandler(nil)}
    func dispose(){stop();http.invalidateAndCancel()}
}
