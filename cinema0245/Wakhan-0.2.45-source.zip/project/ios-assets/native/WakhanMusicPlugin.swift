import Foundation
import AVFoundation
import MediaPlayer
import UIKit
import Capacitor

/// AVPlayer owns audio while WKWebView is suspended. No hidden video/keepalive.
@objc(WakhanMusicPlugin)
public class WakhanMusicPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "WakhanMusicPlugin"
    public let jsName = "WakhanMusic"
    public let pluginMethods: [CAPPluginMethod] = ["loadTrack", "control", "state", "stopAll"].map { CAPPluginMethod(name: $0, returnType: CAPPluginReturnPromise) }
    private let player = AVPlayer()
    private var itemObserver: NSKeyValueObservation?
    private var playbackObserver: NSKeyValueObservation?
    private var timeObserver: Any?
    private var requestID = "", source = "", wanted = false, ended = false, ready = false
    private var foreground=true, interrupted=false, cinemaBound=false, cinemaMuted=false
    private var cinemaMedia=""
    private lazy var cinema = CinemaSession(receive:{[weak self]value in self?.applyCinema(value)},unavailable:{[weak self]in self?.player.pause()})
    private func matches(_ value: String, _ pattern: String) -> Bool { value.range(of: pattern, options: .regularExpression) != nil }
    private func allowed(_ raw: String) -> URL? {
        guard let u = URL(string: raw), u.user == nil, u.password == nil, u.fragment == nil else { return nil }
        if u.isFileURL {
            let folder = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("wakhan-music").resolvingSymlinksInPath()
            let file = u.resolvingSymlinksInPath()
            return file.deletingLastPathComponent() == folder && matches(file.lastPathComponent,"^u[0-9]{1,18}_[a-f0-9]{64}\\.mp3$") && FileManager.default.fileExists(atPath:file.path) ? file : nil
        }
        guard u.scheme == "https", u.port == nil || u.port == 443, let host = u.host else { return nil }
        if host == "music.kabulcafe.uk" && (matches(u.path,"^/(a|api/app/music/media)/[A-Za-z0-9_-][A-Za-z0-9_.-]*$") || (u.path == "/api/app/cinema/v2/media/file" && URLComponents(url:u,resolvingAgainstBaseURL:false)?.queryItems?.contains(where:{$0.name=="lease"}) == true)) { return u }
        if host == "api.audius.co" && matches(u.path,"^/v1/tracks/[A-Za-z0-9]{1,30}/stream$") && u.query == "app_name=Wakhan" { return u }
        if host == "archive.org" && matches(u.path,"^/download/[A-Za-z0-9_.-]{1,180}/.+\\.mp3$") && u.query == nil { return u }
        if host == "ccmixter.org" && matches(u.path,"^/content/[^/]+/[^/]+\\.mp3$") && u.query == nil { return u }
        return nil
    }
    public override func load() {
        foreground = UIApplication.shared.applicationState == .active
        NotificationCenter.default.addObserver(self, selector:#selector(background), name:UIApplication.willResignActiveNotification, object:nil)
        NotificationCenter.default.addObserver(self, selector:#selector(active), name:UIApplication.didBecomeActiveNotification, object:nil)
        NotificationCenter.default.addObserver(self, selector:#selector(interruption(_:)), name:AVAudioSession.interruptionNotification, object:nil)
        NotificationCenter.default.addObserver(self, selector:#selector(routeChanged(_:)), name:AVAudioSession.routeChangeNotification, object:nil)
        NotificationCenter.default.addObserver(self, selector:#selector(finished(_:)), name:AVPlayerItem.didPlayToEndTimeNotification, object:nil)
        playbackObserver = player.observe(\.timeControlStatus, options:[.new]) { [weak self] _,_ in DispatchQueue.main.async { self?.publish() } }
        timeObserver = player.addPeriodicTimeObserver(forInterval:CMTime(seconds:1,preferredTimescale:600),queue:.main) { [weak self] _ in if self?.foreground == true { self?.publish() } }
        MPRemoteCommandCenter.shared().playCommand.addTarget { [weak self] _ in DispatchQueue.main.async { self?.cinemaMuted=false;self?.wanted=true;self?.applyIntent() };return .success }
        MPRemoteCommandCenter.shared().pauseCommand.addTarget { [weak self] _ in DispatchQueue.main.async { self?.cinemaMuted=true;self?.wanted=false;self?.player.pause();self?.publish() };return .success }
        MPRemoteCommandCenter.shared().changePlaybackPositionCommand.addTarget { [weak self] event in guard let e=event as? MPChangePlaybackPositionCommandEvent else{return .commandFailed};DispatchQueue.main.async { self?.player.seek(to:CMTime(seconds:max(0,e.positionTime),preferredTimescale:600)) };return .success }
    }
    private func session() {
        do { let s=AVAudioSession.sharedInstance();if s.category != .playAndRecord { try s.setCategory(.playback,mode:.default) };try s.setActive(true) } catch { fail() }
    }
    private func snapshot() -> JSObject {
        let p=player.currentTime().seconds,d=player.currentItem?.duration.seconds ?? 0
        return ["id":requestID,"active":!requestID.isEmpty && !ended,"ready":ready,"buffering":player.timeControlStatus == .waitingToPlayAtSpecifiedRate,"ended":ended,"playing":player.rate>0,"wanted":wanted,"position":p.isFinite ? max(0,p):0,"duration":d.isFinite ? max(0,d):0,"backgroundOnly":cinemaBound]
    }
    private func publish() {
        guard !requestID.isEmpty else{return};var info=MPNowPlayingInfoCenter.default().nowPlayingInfo ?? [:];let p=player.currentTime().seconds,d=player.currentItem?.duration.seconds ?? 0
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime]=p.isFinite ? max(0,p):0;info[MPNowPlayingInfoPropertyPlaybackRate]=player.rate;info[MPMediaItemPropertyPlaybackDuration]=d.isFinite ? max(0,d):0;MPNowPlayingInfoCenter.default().nowPlayingInfo=info
        notifyListeners("state",data:snapshot())
    }
    private func fail() { player.pause();wanted=false;var value=snapshot();value["error"]="PLAYBACK_FAILED";notifyListeners("state",data:value) }
    private func applyIntent() { if wanted && !interrupted && (!cinemaBound || !foreground) { session();player.play() } else { player.pause() };publish() }
    private func loadSource(_ u: URL, position:Double, title:String, artist:String) {
        player.pause();source=u.absoluteString;ready=false;ended=false;itemObserver=nil
        let item=AVPlayerItem(url:u),id=requestID;player.replaceCurrentItem(with:item)
        MPNowPlayingInfoCenter.default().nowPlayingInfo=[MPMediaItemPropertyTitle:title,MPMediaItemPropertyArtist:artist]
        itemObserver=item.observe(\.status,options:[.initial,.new]) { [weak self,weak item] _,_ in DispatchQueue.main.async {
            guard let self=self,let item=item,self.player.currentItem === item,self.requestID==id else{return}
            if item.status == .failed { self.fail();return }
            if item.status == .readyToPlay && !self.ready {
                self.ready=true;let start=position
                self.player.seek(to:CMTime(seconds:max(0,start),preferredTimescale:600),toleranceBefore:.zero,toleranceAfter:.zero) { [weak self] _ in DispatchQueue.main.async { guard self?.requestID==id else{return};self?.applyIntent() } }
            };self.publish()
        } }
    }
    @objc public func loadTrack(_ call: CAPPluginCall) {
        guard let id=call.getString("id"),matches(id,"^[A-Za-z0-9_-]{1,64}$"),let raw=call.getString("source"),let u=allowed(raw) else {call.reject("INVALID_AUDIO_SOURCE");return}
        let context=call.getObject("cinema")
        if let value=context,(!CinemaSession.valid(value) || u.host != "music.kabulcafe.uk" || u.path != "/api/app/cinema/v2/media/file"){call.reject("INVALID_CINEMA_SESSION");return}
        DispatchQueue.main.async { self.clearCinema();self.requestID=id;self.wanted=call.getBool("playing") ?? true
            if let value=context {self.cinemaBound=true;self.cinema.bind(value);self.cinema.setForeground(self.foreground)}
            self.loadSource(u,position:max(0,call.getDouble("position") ?? 0),title:call.getString("title") ?? "Wakhan",artist:call.getString("artist") ?? "");call.resolve(self.snapshot())
        }
    }
    @objc public func control(_ call: CAPPluginCall) {
        DispatchQueue.main.async { guard call.getString("id")==self.requestID else {call.resolve();return}
            switch call.getString("action") ?? "" {
            case "play":self.cinemaMuted=false;self.wanted=true;self.applyIntent()
            case "pause":self.cinemaMuted=true;self.wanted=false;self.player.pause()
            case "seek":self.player.seek(to:CMTime(seconds:max(0,call.getDouble("position") ?? 0),preferredTimescale:600))
            case "stop":self.stop()
            default:call.reject("INVALID_PLAYER_ACTION");return
            };call.resolve(self.snapshot())
        }
    }
    @objc public func state(_ call: CAPPluginCall) { DispatchQueue.main.async { call.resolve(self.snapshot()) } }
    @objc public func stopAll(_ call: CAPPluginCall) { DispatchQueue.main.async { self.stop();call.resolve() } }
    private func clearCinema(){cinema.stop();cinemaBound=false;cinemaMedia="";cinemaMuted=false}
    private func stop(){clearCinema();wanted=false;player.pause();player.replaceCurrentItem(with:nil);itemObserver=nil;requestID="";source="";ready=false;ended=false;MPNowPlayingInfoCenter.default().nowPlayingInfo=nil}
    @objc private func background(){foreground=false;if cinemaBound {cinema.setForeground(false)}}
    @objc private func active(){foreground=true;if cinemaBound {cinema.setForeground(true);player.pause()};publish()}
    private func applyCinema(_ value:[String:Any]){
        guard cinemaBound,!foreground,let media=value["media"]as? [String:Any],let file=media["source"]as? [String:Any],file["kind"]as? String=="file",let raw=file["url"]as? String,let url=allowed(raw),url.path=="/api/app/cinema/v2/media/file",let position=media["position"]as? Double,position.isFinite,position>=0 else{wanted=false;player.pause();return}
        let identity=(media["id"]as? String ?? "")+"|"+String(media["cycle"]as? Int ?? 0)
        wanted=(media["playing"]as? Bool ?? false) && !cinemaMuted
        if cinemaMedia != identity || source != raw {cinemaMedia=identity;loadSource(url,position:position,title:media["title"]as? String ?? "Wakhan",artist:"")}
        else {let current=player.currentTime().seconds;if current.isFinite && abs(current-position)>2 {player.seek(to:CMTime(seconds:position,preferredTimescale:600))};applyIntent()}
    }
    @objc private func finished(_ n:Notification) {
        guard let item=n.object as? AVPlayerItem,item === player.currentItem else{return};ended=true;wanted=false;publish()
    }
    @objc private func interruption(_ n:Notification) {
        guard let raw=n.userInfo?[AVAudioSessionInterruptionTypeKey]as? UInt,let type=AVAudioSession.InterruptionType(rawValue:raw) else{return}
        if type == .began {interrupted=true;player.pause()}else if let raw=n.userInfo?[AVAudioSessionInterruptionOptionKey]as? UInt,AVAudioSession.InterruptionOptions(rawValue:raw).contains(.shouldResume) {interrupted=false;applyIntent()}else{interrupted=false;wanted=false;cinemaMuted=true};publish()
    }
    @objc private func routeChanged(_ n:Notification) { if let raw=n.userInfo?[AVAudioSessionRouteChangeReasonKey]as? UInt,AVAudioSession.RouteChangeReason(rawValue:raw) == .oldDeviceUnavailable {wanted=false;cinemaMuted=true;player.pause();publish()} }
    deinit { cinema.dispose();NotificationCenter.default.removeObserver(self);if let token=timeObserver {player.removeTimeObserver(token)} }
}
