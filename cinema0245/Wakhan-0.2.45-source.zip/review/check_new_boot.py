import asyncio,json,os,sys,io,wave
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];BASE=os.environ.get('WK_REVIEW_BASE','http://127.0.0.1:5176');OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
INIT=r'''(()=>{if(window!==top)return;window.CapacitorCustomPlatform={name:'ios'};const names={WakhanLocale:['preferred','bars','safeArea','orientation'],WakhanDownloads:['download','source','remove','cancel','addListener','removeListener'],App:['addListener','removeListener','minimizeApp'],Keyboard:['addListener','removeListener'],Browser:['open','close','addListener','removeListener'],StatusBar:['setStyle','setBackgroundColor','hide','show'],SplashScreen:['hide','show'],Haptics:['impact','selectionChanged','notification'],PushNotifications:['addListener','removeListener','checkPermissions','register','unregister']};window.Capacitor={PluginHeaders:Object.entries(names).map(([name,methods])=>({name,methods:methods.map(name=>({name,rtype:name==='addListener'?'callback':'promise'}))})),nativePromise:async(plugin,method,args)=>{if(plugin==='WakhanLocale'&&method==='preferred')return {languages:['fa'],country:'AF'};if(plugin==='WakhanLocale'&&method==='safeArea'){window.__nativeInsetsCalls=(window.__nativeInsetsCalls||0)+1;return {width:innerWidth,top:59,bottom:34,left:0,right:0}};return {}},nativeCallback:()=>Promise.resolve('testcallback')};const session={origin:'https://music.kabulcafe.uk',key:'wka1.'+'A'.repeat(24)+'.'+'a'.repeat(32),user:{id:1,first_name:'Test'},new:false};localStorage.setItem('wkv_session',JSON.stringify(session));localStorage.setItem('wk_native_lang','fa');window.__bootMutations=0;window.__bootLoop=false;let mutationStart=performance.now(),mutationBurst=0;new MutationObserver(events=>{__bootMutations+=events.length;if(performance.now()-mutationStart>100){mutationStart=performance.now();mutationBurst=0}mutationBurst+=events.length;if(mutationBurst>300&&window.WakhanMusicUI){__bootLoop=true;WakhanMusicUI.dispose()}}).observe(document,{subtree:true,attributes:true,attributeFilter:['class']});})()'''
async def main():
 results=[]
 async with async_playwright()as p:
  engines=['chromium','webkit'] if '--both' in sys.argv else ['chromium']
  for engine in engines:
   args={'executable_path':'/usr/bin/chromium','args':['--no-sandbox']}if engine=='chromium'and Path('/usr/bin/chromium').exists()else {}
   browser=await getattr(p,engine).launch(**args);context=await browser.new_context(viewport={'width':393,'height':852},is_mobile=True,has_touch=True);await context.add_init_script(INIT);page=await context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(e.stack));page.on('console',lambda msg:print('BROWSER',msg.text,flush=True)if 'REVIEW_VOICE_LEAVE' in msg.text else None)
   chart_calls=0;audio_calls=0;chart_delay=0
   async def route(r):
    nonlocal chart_calls,audio_calls
    u=urlsplit(r.request.url);path=u.path
    if path=='/api/app/music/media/review.wav':
     buffer=io.BytesIO()
     with wave.open(buffer,'wb')as audio:audio.setnchannels(1);audio.setsampwidth(2);audio.setframerate(44100);audio.writeframes(bytes(44100*2*5))
     await r.fulfill(content_type='audio/wav',body=buffer.getvalue());return
    if path.startswith('/api/'):
     value={'ok':True,'items':[]}
     if path=='/api/app/config':value.update(email=True,native=False,push=False)
     elif path=='/api/app/me':value.update(uid=1,name='Test',username='test',complete=True)
     elif path=='/api/me':value.update(me={'id':1,'name':'Test','bal':0},favs=[],groups=[],phist=[],srch=[],ysrch=[],yhist=[],stats={'plays':0,'srch':0,'watched':0})
     elif path=='/api/app/home/rankings':q=parse_qs(u.query);value.update(category=q.get('category',['overall'])[0],period=q.get('period',['month'])[0],start=1,available=True,rule='',me=None,salons=[])
     elif path=='/api/app/chat/people':value.update(self={'id':1,'name':'Test'})
     elif path=='/api/v51/hall':value.update(hall={'code':'REVIEW','name':'بررسی','owner_id':1,'is_owner':True,'locks':[],'can':{'chat':True,'mic':True}})
     elif path=='/api/c/REVIEW':value.update(vid='',playing=False,t=0,ver=1,timeline_revision=1,mine=0,owner=1,seats=[{'id':1,'name':'Test'},None,None,None,None,None,None,None],room='REVIEW',sync_epoch='test')
     elif path=='/api/app/music/chart':
      chart_calls+=1
      if chart_delay:await asyncio.sleep(chart_delay)
      value.update(partial=True,sources=[{'id':'audius','available':True,'count':50},{'id':'archive','available':False,'count':0},{'id':'ccmixter','available':False,'count':0}],items=[{'id':'au.review'+str(i),'title':'Track '+str(i),'artist':'Review','provider':'audius','cover':'https://art-review.invalid/'+str(i)+'.svg','duration':180,'downloadable':False}for i in range(50)])
     elif path=='/api/app/music/search':value.update(items=[{'id':'yt.abcdefghijk','title':'آهنگ یک','artist':'هنرمند','provider':'youtube','cover':'https://art-review.invalid/yt.svg','duration':180,'downloadable':False,'persistent':False,'embed':True,'stream':'https://www.youtube.com/watch?v=abcdefghijk','source_url':'https://www.youtube.com/watch?v=abcdefghijk','license':'online-playback'},{'id':'sc.aHR0cHM6Ly9zb3VuZGNsb3VkLmNvbS9hcnRpc3Qvc29uZw','title':'آهنگ دو','artist':'Artist','provider':'soundcloud','cover':'https://art-review.invalid/sc.svg','duration':180,'downloadable':False,'persistent':False,'embed':True,'stream':'https://soundcloud.com/artist/song','source_url':'https://soundcloud.com/artist/song','license':'online-playback'}])
     elif path=='/api/v60/audio':
      audio_calls+=1;value.update(playback='audio',src='/a/review.wav?lease=test',dur=5,title='آهنگ',artist='هنرمند')
     elif path=='/api/app/music/resolve':
      ident=parse_qs(u.query)['id'][0];provider='youtube'if ident.startswith('yt.')else'soundcloud';source='https://www.youtube.com/watch?v=abcdefghijk'if provider=='youtube'else'https://soundcloud.com/artist/song';value.update(item=dict(id=ident,title='آهنگ',artist='هنرمند',provider=provider,cover='https://art-review.invalid/yt.svg',duration=180,downloadable=False,persistent=False,embed=True,stream=source,source_url=source,license='online-playback'))
     elif path=='/api/app/chat/history':value.update(peer={'id':2,'name':'Yas'},messages=[{'id':i,'sender':2,'text':'پیام '+str(i),'ts':1700000000+i,'media':[{'id':'review_image_00000001','kind':'image'}]if i==56 else []}for i in range(1,61)],cursor=60,first_unread=1,changed=[],removed=[],can_send=True,wallpaper=None)
     elif path.startswith('/api/app/dm/media/'):
      await asyncio.sleep(.35);await r.fulfill(content_type='image/svg+xml',body='<svg xmlns="http://www.w3.org/2000/svg" width="260" height="600"><rect width="260" height="600" fill="#8c5cbb"/></svg>');return
     elif path=='/api/app/chat/inbox':value.update(threads=[])
     elif path=='/api/wallet':value.update(balance=0)
     elif path=='/api/app/salon/home':value.update(mine=None,followed=[],joined=[],recent=[])
     elif path=='/api/app/games/socket':value={'ok':False,'err':'review_offline'}
     elif path=='/api/app/games/home':value.update(invites=[],one_needed=[],resume=None)
     await r.fulfill(json=value);return
    if path=='/a/review.wav':
     buffer=io.BytesIO()
     with wave.open(buffer,'wb')as audio:audio.setnchannels(1);audio.setsampwidth(2);audio.setframerate(44100);audio.writeframes(bytes(44100*2*5))
     await r.fulfill(content_type='audio/wav',body=buffer.getvalue());return
    local=ROOT/'project/public'/path.removeprefix('/s/').lstrip('/')
    if local.is_file():await r.fulfill(path=str(local));return
    await r.fulfill(status=404,body='')
   await page.route('https://music.kabulcafe.uk/**',route)
   await page.route('https://art-review.invalid/**',lambda r:r.fulfill(content_type='image/svg+xml',body='<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1000"><rect width="1000" height="1000" fill="#694f82"/></svg>'))
   await page.goto(BASE);await page.wait_for_function('!!window.WakhanMusicUI',timeout=20000);await page.evaluate("go('h')");await page.wait_for_timeout(500)
   assert not await page.evaluate('window.__bootLoop'), 'startup entered mutation loop'
   await page.wait_for_function("!document.getElementById('wk-intro2')",timeout=12000)
   await page.locator('.wk-approved-home-frame').wait_for();assert await page.locator('#nav').is_visible()
   timings=[];handlers=[]
   for tab in ['p','h','m','h','c','h','d','h','p','h']:
    sample=await page.evaluate("""async t=>{const start=performance.now();go(t);const handler=performance.now()-start;await new Promise(requestAnimationFrame);const el=t==='p'?document.getElementById('wk-music')?.shadowRoot?.querySelector('.page'):t==='c'?document.getElementById('wk-cinema')?.shadowRoot?.querySelector('.page'):t==='h'?document.querySelector('.wk-approved-home-frame'):t==='m'?document.querySelector('[data-wk-page=m] .wk3'):document.querySelector('[data-wk-page=d] .wkchat');let visible=!!el,opacity=1,node=el;while(node){const css=getComputedStyle(node);opacity*=Number(css.opacity);if(css.display==='none'||css.visibility==='hidden'||node.hidden)visible=false;node=node.parentElement||node.getRootNode()?.host}const rect=el?.getBoundingClientRect();visible=visible&&!!rect&&rect.width>0&&rect.height>0&&opacity>.95;return {handler,frame:performance.now()-start,visible,opacity,element:el?.className}}""",tab);assert sample['visible'],(tab,sample);timings.append(sample['frame']);handlers.append(sample['handler']);await page.wait_for_timeout(120);assert not await page.evaluate('__bootLoop')
   a=await page.evaluate('__bootMutations');await page.wait_for_timeout(300);z=await page.evaluate('__bootMutations');assert z-a<15,(a,z)
   glass=await page.locator('#nav .bar').evaluate('e=>getComputedStyle(e).backgroundImage');assert 'rgba' in glass,glass
   assert max(handlers)<250,{'handlers':handlers,'frames':timings}
   assert max(timings)<2000,timings
   def delay_chart(value):
    nonlocal chart_delay
    chart_delay=value
   navigation={}
   room_result={}
   changes={}
   sources={}
   salon={}
   salon_audit={}
   assert not errors,errors
   await page.screenshot(path=str(OUT/(engine+'-home-after-intro.png')))
   offline_result={}
   results.append(dict(engine=engine,full_bootstrap=True,intro_removed=True,home_visible=True,actual_content_visible_on_next_frame=True,navigation_handler_ms=[round(v,2)for v in handlers],tab_to_frame_ms=[round(v,2)for v in timings],glass_background=glass,no_mutation_loop=True,errors=errors,physical_device=False));print('PASS',engine,results[-1],flush=True);await browser.close()
 (OUT/'new-bootstrap-results.json').write_text(json.dumps(results,indent=2))
asyncio.run(main())
