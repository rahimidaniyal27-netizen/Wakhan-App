import asyncio,json,sqlite3,sys,subprocess,re
from pathlib import Path
from aiohttp import web
from aiohttp.test_utils import TestServer
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'server'),str(ROOT/'server-tests')]
from test_cinema_service import Me,People
from wakhan_cinema.service import CinemaService
VIDEO=ROOT/'review/fixture.mp4'
if not VIDEO.exists():subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=purple:s=320x180:r=24','-f','lavfi','-i','sine=frequency=440:sample_rate=44100','-t','3','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-movflags','+faststart',str(VIDEO)],check=True)
class Content:
 def __init__(self,data):self.data=data
 async def read(self,n):return self.data[:n]
 async def iter_chunked(self,n):
  for i in range(0,len(self.data),n):yield self.data[i:i+n]
class Response:
 def __init__(self,data,status=200,extra=None):self.status=status;self.content=Content(data);self.headers={'Content-Type':'video/mp4','Content-Length':str(len(data)),'Accept-Ranges':'bytes',**(extra or{})}
 async def __aenter__(self):return self
 async def __aexit__(self,*args):pass
 def release(self):pass
async def main():
 db=sqlite3.connect(':memory:');db.executescript("""CREATE TABLE wka_accounts(uid INTEGER PRIMARY KEY,done INTEGER,blocked INTEGER);INSERT INTO wka_accounts VALUES(1,1,0),(2,1,0);CREATE TABLE wks_titles(id TEXT PRIMARY KEY,kind TEXT,title TEXT,poster TEXT,backdrop TEXT,year INTEGER,descr TEXT,genres TEXT,cat TEXT,score REAL);CREATE TABLE wks_sources(tid TEXT,ep TEXT,sid TEXT PRIMARY KEY,provider TEXT,url TEXT,rights TEXT,title TEXT,thumb TEXT,dur REAL,ts INTEGER,s INTEGER,e INTEGER,lang TEXT,sub TEXT,q TEXT);INSERT INTO wks_titles VALUES('one','movie','Film One','','',2026,'Test','','',1),('two','movie','Film Two','','',2026,'Test','','',2);INSERT INTO wks_sources VALUES('one','','one','commons','https://cdn.example/one.mp4','room','Film One','',3,1,0,0,'fa','','720p'),('two','','two','commons','https://cdn.example/two.mp4','room','Film Two','',3,1,0,0,'fa','','720p');""")
 service=CinemaService({'DB':db,'WME':Me(),'WM_COMMUNITY70':People()},workers=False);room=service.store.create(1,'Fresh Salon 🇦🇫');service.store.update(room['code'],notice='ورود به سالون؛ این پیام با چت حرکت می‌کند')
 async def fetch(url,headers=None,method='GET'):
  data=VIDEO.read_bytes();length=len(data);match=re.fullmatch(r'bytes=(\d+)-(\d*)',(headers or{}).get('Range',''))
  if match:
   lo=int(match[1]);hi=min(length-1,int(match[2])if match[2]else length-1);return Response(data[lo:hi+1],206,{'Content-Range':f'bytes {lo}-{hi}/{length}'})
  return Response(data)
 service.files.fetch=fetch
 app=web.Application();service.routes(app);server=TestServer(app);await server.start_server();origin=str(server.make_url('')).rstrip('/');service.origin=origin;service.catalog.origin=origin;service.files.origin=origin
 fixture=ROOT/'project/public/__review_cinema.html';fixture.write_text('''<!doctype html><meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover"><style>body{margin:0;background:#0f0a1d}</style><main id=pane></main><script type=module>import{installCinema}from'/src/cinema/index.mjs';const uid=Number(new URL(location).searchParams.get('uid'));let route='c';const origin=ORIGIN;const request=async(path,body)=>{const r=await fetch(origin+path,{method:body===undefined?'GET':'POST',headers:{'X-Review-Uid':String(uid),'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});return r.json()};window.cinema=installCinema({pane:document.querySelector('#pane'),request,origin,getUid:()=>uid,getRoute:()=>route,navigate:tab=>{route=tab;cinema.onRoute()},getIce:async()=>[],fetchBinary:(url,options)=>fetch(url,{...options,headers:{'X-Review-Uid':String(uid)}})});window.routeTo=tab=>{route=tab;cinema.onRoute()};cinema.open();</script>'''.replace('ORIGIN',json.dumps(origin)))
 # Test-only CORS for the local app, never ship this auth adapter or middleware.
 @web.middleware
 async def cors(req,handler):
  if req.method=='OPTIONS':res=web.Response(status=204)
  else:res=await handler(req)
  if not res.prepared:res.headers.update({'Access-Control-Allow-Origin':'http://127.0.0.1:5181','Access-Control-Allow-Headers':'Content-Type,X-Review-Uid','Access-Control-Allow-Methods':'GET,POST,OPTIONS'})
  return res
 # App frozen by TestServer; use a separate proxy with actual service handlers/CORS installed before startup.
 await server.close();service.stopped=False;app=web.Application(middlewares=[cors]);service.routes(app);server=TestServer(app);await server.start_server();origin=str(server.make_url('')).rstrip('/');service.origin=origin;service.catalog.origin=origin;service.files.origin=origin;fixture.write_text(fixture.read_text().replace(json.loads(json.dumps(str(service.files.origin))),origin)) if False else None
 # Rewrite the prior port in the HTML.
 html=fixture.read_text();html=re.sub(r'const origin="http://127.0.0.1:\d+"', 'const origin='+json.dumps(origin),html);fixture.write_text(html)
 results=[]
 try:
  async with async_playwright()as p:
   browser=await p.chromium.launch(**({'executable_path':'/usr/bin/chromium'}if Path('/usr/bin/chromium').exists()else{}),args=['--no-sandbox','--allow-loopback-in-peer-connection','--force-webrtc-ip-handling-policy=default','--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream','--autoplay-policy=no-user-gesture-required']);contexts=[];pages=[];errors=[]
   for uid in[1,2]:
    context=await browser.new_context(viewport={'width':393,'height':852},permissions=['microphone']);contexts.append(context);page=await context.new_page();page.on('pageerror',lambda e:(errors.append(str(e)),print('JS',e.stack,flush=True)));page.on('console',lambda m:print('CONSOLE',m.text,flush=True)if m.type=='error'else None);page.on('websocket',lambda ws:print('WS',ws.url,flush=True));pages.append(page);await page.goto('http://127.0.0.1:5181/__review_cinema.html?uid='+str(uid));await page.wait_for_function('!!window.cinema');await page.evaluate('(code)=>cinema.enter(code)',room['code']);print('ENTER',uid,await page.evaluate('cinema.context()'),flush=True);await page.wait_for_function('cinema.context().session&&cinema.context().connection==="online"')
   a,b=pages
   assert await a.locator('.message.notice').count()==1
   assert await a.locator('.room-header').get_by_text('اعلان').count()==0
   results.append('notice is a single scrollable message; no pinned room announcement')
   await a.locator('[data-action=mic]').first.click();await a.wait_for_function('cinema.voice.tracks().some(t=>t.enabled&&t.readyState==="live")');await b.locator('[data-action=mic]').first.click();await b.wait_for_function('cinema.voice.tracks().some(t=>t.enabled&&t.readyState==="live")');await a.wait_for_timeout(1200);rtc=await a.evaluate('[...cinema.voice.peers()].map(([id,p])=>({id,connection:p.connectionState,gathering:p.iceGatheringState,candidates:(p.localDescription?.sdp.match(/a=candidate/g)||[]).length,local:p.localDescription?.type,remote:p.remoteDescription?.type}))');assert rtc and all(v['local']and v['remote']for v in rtc),rtc
   if not all(v['connection']=='connected'for v in rtc)and any(v['candidates']for v in rtc):await a.wait_for_function('[...cinema.voice.peers().values()].every(p=>p.connectionState==="connected")',timeout=15000)
   results.append({'voice_signaling':'real two-context offer/answer exchange','media_connection':'connected'if all(v['connection']=='connected'for v in rtc)else'blocked: browser environment gathers zero ICE candidates','fake_device_microphones':True})
   await a.evaluate('''async()=>{const t=cinema.context();await fetch(ORIGIN+'/api/app/cinema/v2/room/command',{method:'POST',headers:{'X-Review-Uid':'1','Content-Type':'application/json'},body:JSON.stringify({code:t.room.code,session:t.session,key:crypto.randomUUID(),kind:'load',payload:{item:{provider:'archive',id:'one'}}})})}'''.replace('ORIGIN',json.dumps(origin)))
   await a.wait_for_function('cinema.media.state().playing&&cinema.media.state().position>0.15');results.append('actual MP4 decoded and played over authorized HTTP range proxy')
   await a.locator('[data-action=toggle]').click();await a.wait_for_function('!cinema.media.state().playing');pos=await a.evaluate('cinema.media.state().position');await a.wait_for_timeout(400);assert abs(pos-await a.evaluate('cinema.media.state().position'))<.2
   await a.locator('[data-action=end]').click();await a.wait_for_function('!cinema.context().media');assert await a.evaluate('cinema.voice.tracks().some(t=>t.enabled&&t.readyState==="live")');results.append('pause stops decoded player; ending playback keeps live microphone')
   await a.evaluate("routeTo('p')");assert await a.locator('#wk-cinema-floating .mini').is_visible();await a.evaluate("routeTo('c');cinema.open()");assert await a.locator('#wk-cinema .page').is_visible();assert await a.locator('#wk-cinema .room').is_hidden();await a.locator('#wk-cinema-floating [data-action=restore]').click();assert await a.locator('#wk-cinema-floating .mini').is_hidden();assert await a.locator('#wk-cinema .room').is_visible();assert await a.evaluate('cinema.voice.tracks().some(t=>t.enabled&&t.readyState==="live")');results.append('tab route opens lobby; one mini restores room; voice persists across tabs')
   await a.locator('input[name=text]').fill('سلام');await a.locator('.composer [type=submit]').click();await b.get_by_text('سلام',exact=True).wait_for();results.append('real WebSocket delivers chat to the second viewer')
   async def command(kind,payload):
    state=await a.evaluate('cinema.context()');session=service.rooms.sessions[state['session']];result=await service.commands.execute(session,kind,payload,'browser-'+str(service.store.now()));await service.broadcast(room['code']);return result
   await command('load',{'item':{'provider':'archive','id':'one'}});await command('queue.add',{'item':{'provider':'archive','id':'two'}})
   await a.wait_for_function("cinema.context().media?.provider_id==='two'",timeout=12000);await a.wait_for_function("cinema.context().media?.cycle===1",timeout=12000);results.append('decoded video naturally ends, advances FIFO queue, and repeats when empty')
   await a.evaluate('cinema.open()');await a.locator('[data-action=section][data-tab=home]').click();await a.locator('.movie').first.click();await a.locator('[data-action=personal-play]').first.click();await a.wait_for_function('!!cinema.context().personal&&cinema.media.state().playing');assert await a.evaluate('cinema.voice.tracks().some(t=>t.enabled&&t.readyState==="live")');await a.locator('.personal [data-action=end]').click();await a.wait_for_function('!cinema.context().personal');results.append('archive details and personal playback use real service while room voice stays live')
   await a.screenshot(path=str(ROOT/'review/fresh-room-chromium.png'));assert not errors,errors
   await browser.close();(ROOT/'review/real-cinema-browser.json').write_text(json.dumps({'ok':True,'checks':results,'errors':errors,'physical_devices':False,'live_youtube':False,'rtc':rtc},ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False))
 finally:
  fixture.unlink(missing_ok=True);await server.close();db.close()
asyncio.run(main())
