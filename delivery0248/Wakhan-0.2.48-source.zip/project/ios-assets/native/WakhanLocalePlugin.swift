import UIKit
import Capacitor

/// Same plugin name as on Android: phone languages, and the colour behind the bars.
@objc(WakhanLocalePlugin)
public class WakhanLocalePlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "WakhanLocalePlugin"
    public let jsName = "WakhanLocale"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "orientation", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "preferred", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "bars", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "safeArea", returnType: CAPPluginReturnPromise)
    ]

    public override func load() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardFrame(_:)), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardFrame(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc private func keyboardFrame(_ notification: Notification) {
        DispatchQueue.main.async {
            guard let web = self.bridge?.webView, web.bounds.width > 0 else { return }
            let info = notification.userInfo ?? [:]
            let frame = (info[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue ?? .zero
            let converted = web.convert(frame, from: nil)
            let intersection = web.bounds.intersection(converted)
            let overlap: CGFloat = notification.name == UIResponder.keyboardWillHideNotification || intersection.isNull || intersection.maxY < web.bounds.maxY - 1 ? 0 : max(0, intersection.height)
            let payload: [String: Any] = ["overlap": overlap, "width": web.bounds.width, "height": web.bounds.height, "duration": (info[UIResponder.keyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0.25, "curve": (info[UIResponder.keyboardAnimationCurveUserInfoKey] as? NSNumber)?.intValue ?? 0]
            guard let data = try? JSONSerialization.data(withJSONObject: payload), let json = String(data: data, encoding: .utf8) else { return }
            web.evaluateJavaScript("window.dispatchEvent(new CustomEvent('wakhanKeyboardFrame',{detail:" + json + "}))", completionHandler: nil)
        }
    }
    @objc func orientation(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            let fullscreen = call.getBool("fullscreen") ?? false
            let previous = WakhanOrientationState.fullscreen
            WakhanOrientationState.generation += 1
            let generation = WakhanOrientationState.generation
            WakhanOrientationState.fullscreen = fullscreen
            guard let scene = self.bridge?.webView?.window?.windowScene else { call.resolve(); return }
            if #available(iOS 16.0, *) {
                self.bridge?.viewController?.setNeedsUpdateOfSupportedInterfaceOrientations()
                self.bridge?.viewController?.parent?.setNeedsUpdateOfSupportedInterfaceOrientations()
                scene.requestGeometryUpdate(.iOS(interfaceOrientations: WakhanOrientationState.mask)) { _ in
                    DispatchQueue.main.async { if WakhanOrientationState.generation == generation { WakhanOrientationState.fullscreen = previous } }
                }
            } else { UIViewController.attemptRotationToDeviceOrientation() }
            call.resolve()
        }
    }
    deinit { NotificationCenter.default.removeObserver(self) }

    @objc func preferred(_ call: CAPPluginCall) {
        call.resolve(["languages": Locale.preferredLanguages])
    }

    /// Report only the unsafe edges still exposed inside this web view. A web
    /// view already below the status bar returns zero, avoiding a second inset.
    @objc func safeArea(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard let web = self.bridge?.webView, let window = web.window,
                  web.bounds.width > 0, web.bounds.height > 0 else {
                call.reject("web view is not visible")
                return
            }
            let frame = web.convert(web.bounds, to: window)
            let safe = window.safeAreaLayoutGuide.layoutFrame
            call.resolve([
                "width": Double(web.bounds.width),
                "top": Double(min(frame.height, max(0, safe.minY - frame.minY))),
                "right": Double(min(frame.width, max(0, frame.maxX - safe.maxX))),
                "bottom": Double(min(frame.height, max(0, frame.maxY - safe.maxY))),
                "left": Double(min(frame.width, max(0, safe.minX - frame.minX)))
            ])
        }
    }

    @objc func bars(_ call: CAPPluginCall) {
        var hex = (call.getString("color") ?? "#071019").trimmingCharacters(in: .whitespaces)
        if hex.hasPrefix("#") { hex.removeFirst() }
        guard hex.count == 6, let n = UInt32(hex, radix: 16) else { call.reject("bad colour"); return }
        let c = UIColor(red: CGFloat((n >> 16) & 255) / 255, green: CGFloat((n >> 8) & 255) / 255, blue: CGFloat(n & 255) / 255, alpha: 1)
        DispatchQueue.main.async {
            let vc = self.bridge?.viewController
            (vc?.parent?.view ?? vc?.view)?.backgroundColor = c
            call.resolve()
        }
    }
}
