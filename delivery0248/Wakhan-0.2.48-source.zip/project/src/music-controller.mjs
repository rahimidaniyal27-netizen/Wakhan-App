import {externalAudio} from './music-audio.mjs';
import {installPullRefresh,sourceSummary} from './music-refresh.mjs';
import {createMusicTransport} from './music-transport.mjs';
import {createMusicQueue} from './music-queue.mjs';
import {createMusicLibrary} from './music-library.mjs';
import {escapeHTML as h,icon,button,cover,clock,trackRows,musicCSS,playerFitCSS} from './music-view.mjs';

export function installMusic({request,getUid,getRoute,navigate,audio:directAudio,prepare,claim,release,downloadPlugin=null,convertFileSrc=x=>x,fetchBinary=fetch,getInsets=()=>null,initialView='home',offlineMode=false,reconnect=()=>{},hooks}){
 const host=document.createElement('div');host.id='wk-music';host.style.cssText='position:fixed;inset:0;z-index:45;pointer-events:none';const shadow=host.attachShadow({mode:'open'});document.body.append(host);
 const style=document.createElement('style');style.textContent=musicCSS+playerFitCSS+'\n.page[hidden]{display:block!important;visibility:hidden;pointer-events:none}';const page=document.createElement('main');page.className='page';page.hidden=true;const mini=document.createElement('aside');mini.className='mini';mini.hidden=true;const modal=document.createElement('div');modal.hidden=true;const notice=document.createElement('div');notice.className='notice';notice.setAttribute('role','status');notice.hidden=true;const dock=document.createElement('div');dock.className='embed-dock';dock.hidden=true;shadow.append(style,page,dock,mini,modal,notice);
 const audio=createMusicTransport({direct:directAudio,dock,visible:()=>active()&&view==='player'&&!document.hidden});
 const positionEmbed=()=>{const slot=page.querySelector('.embed-slot'),show=!!slot&&active()&&view==='player';if(dock.hidden===show)dock.hidden=!show;if(show){const r=slot.getBoundingClientRect(),b=host.getBoundingClientRect();Object.assign(dock.style,{left:(r.left-b.left)+'px',top:(r.top-b.top)+'px',width:r.width+'px',height:r.height+'px'})}audio.visibility()};page.addEventListener('scroll',positionEmbed,{passive:true});document.addEventListener('visibilitychange',positionEmbed);
 const globalStyle=document.createElement('style');globalStyle.textContent='body.wk-music-page{background:var(--bg,#0f0a1d)!important}body.wk-music-page>header,body.wk-music-page #view{visibility:hidden!important}body.wk-music-page.wk-music-keyboard #nav{display:none!important}body.wk-music-playing #mini,body.wk-music-playing #wmr-dock,body.wk-music-playing #fp{display:none!important}';document.head.append(globalStyle);
 let user=String(getUid()),view=initialView,returnView='home',tracks=[],chart=[],sources=[],recommendations=[],lists=[],downloads=[],selectedList=null,query='',chartLoading=false,searchLoading=false,chartError=false,partial=false,updated=0,sequence=0,searchSequence=0,currentState=null,displayedCurrent='',disposed=false,noticeTimer=0,searchTimer=0,dragging=false,rowsScroll=0,listGeneration=0;
 let homeDirty=true,drawFrame=0,entryFrame=0,entrySerial=0;
 function scheduleHome(){homeDirty=true;if(!drawFrame&&active()&&view==='home')drawFrame=requestAnimationFrame(()=>{drawFrame=0;if(!disposed&&active()&&view==='home'&&homeDirty)draw()})}
 function entryRefresh(){const generation=++entrySerial,owner=String(getUid());if(entryFrame)cancelAnimationFrame(entryFrame);entryFrame=requestAnimationFrame(()=>{entryFrame=0;setTimeout(()=>{if(!disposed&&generation===entrySerial&&owner===String(getUid())&&active()){void refresh();void loadLibrary()}},0)})}
 function sourceStatus(){if(active()&&view==='home'){const label=page.querySelector('.section-line .subtle');if(label)label.textContent=sourceSummary({sources,loading:chartLoading,error:chartError,partial,updated})}}
 const progress=new Map(),downloadKeys=new Map(),artwork=new Map();let artActive=0;const artWaiters=[];
 async function sessionArt(url){
  if(artwork.has(url))return artwork.get(url);
  const owner=user;
  const task=(async()=>{if(artActive>=6)await new Promise(r=>artWaiters.push(r));artActive++;
   try{const r=await fetchBinary(url,{cache:'no-store'});if(!r.ok)throw Error('artwork');const blob=await r.blob();if(blob.size>3*1024*1024||!blob.type.startsWith('image/'))throw Error('artwork');if(disposed||owner!==user)return '';return URL.createObjectURL(blob)}catch{return ''}finally{artActive--;artWaiters.shift()?.()}
  })();artwork.set(url,task);return task;
 }
 function clearArtwork(){for(const task of artwork.values())void task.then(url=>{if(url)URL.revokeObjectURL(url)});artwork.clear()}
 function loadArtwork(img){if(img.dataset.artReady)return;img.dataset.artReady='1';const address=img.dataset.audiusCover;void sessionArt(address).then(url=>{if(url&&img.isConnected&&img.dataset.audiusCover===address&&img.getAttribute('src')!==url)img.src=url})}
 const artObserver=new IntersectionObserver(entries=>{for(const e of entries)if(e.isIntersecting){artObserver.unobserve(e.target);loadArtwork(e.target)}},{rootMargin:'160px'});
 function hydrateArt(){artObserver.disconnect();for(const img of shadow.querySelectorAll('[data-audius-cover]'))if(!img.dataset.artReady)artObserver.observe(img)}
 function toast(text){notice.textContent=text;notice.hidden=false;clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>notice.hidden=true,2600)}
 const library=createMusicLibrary({uid:getUid,native:downloadPlugin,convertFileSrc,fetchBinary,onProgress:e=>{if(e.key)downloadKeys.set(e.key,e.id);if(e.url){const t=Array.from(pendingDownloads.values()).find(t=>t.stream===e.url);if(t)progress.set(t.id,e.total>0?Math.min(99,Math.floor(e.loaded/e.total*100)):null)}if(view==='downloads')paintProgress()}});
 let nativeProgress;downloadPlugin?.addListener('progress',e=>{const p=e.total>0?Math.min(99,Math.floor(e.loaded/e.total*100)):null;progress.set(downloadKeys.get(e.key)||e.key,p);paintProgress()}).then(x=>nativeProgress=x).catch(()=>{});
 async function resolve(id,valid=null){const r=await request('/api/app/music/resolve?id='+encodeURIComponent(id));if(!r?.ok||!r.item)throw Error('unavailable');return valid?externalAudio({track:r.item,fetchBinary,valid}):r.item}
 const queue=createMusicQueue({audio,resolve,local:id=>library.get(id),prepare:async(track,position,playing,seq)=>{claim(track);window.WakhanPlayback?.intent?.();await audio.prepare(track,position,playing);if(track.embed)return true;return prepare(track,position,playing,seq)},onChange:state=>{currentState=state;paintPlayback();if(displayedCurrent!==state.current?.id){displayedCurrent=state.current?.id||'';if(view==='player'||view==='queue')draw();else markSelected()}},onError:error=>toast(({offline:'این آهنگ دانلود نشده',subscription_required:'پخش این منبع به اشتراک نیاز دارد',audio_timeout:'آماده‌سازی طول کشید؛ دوباره بزن',audio_unavailable:'منبع صوتی پاسخ نداد'})[error]||'پخش نشد؛ دوباره بزن')});
 function checkUser(){const next=String(getUid());if(next===user)return false;user=next;homeDirty=true;page.replaceChildren();++sequence;++searchSequence;++listGeneration;queue.stop();release();library.dispose();chart=[];sources=[];recommendations=[];tracks=[];downloads=[];lists=[];selectedList=null;view='home';query='';progress.clear();downloadKeys.clear();pendingDownloads.clear();clearArtwork();modal.hidden=true;chartLoading=false;searchLoading=false;chartError=false;searchResults=[];listTracks=[];listBusy=false;menuTrack=null;addTrack=null;return true;}
 function active(){return getRoute()==='p'&&!document.body.classList.contains('native87-auth')}
 function chrome(){const on=active();if(page.hidden===on)page.hidden=!on;document.body.classList.toggle('wk-music-page',on);document.body.classList.toggle('wk-music-playing',!!currentState?.current);audio.visibility();mini.hidden=!currentState?.current||on&&view==='player'||document.body.matches('.wkchat-thread,.slr-on,.wmc-theater,.h2-open,.wm78-room-open,.native87-auth')||getRoute()==='h'&&document.body.classList.contains('wk-games-active');positionEmbed();if((!on||view!=='home')&&!pullIndicator.hidden)pull.cancel();if(!on){modal.hidden=true;if(document.body.classList.contains('wk-music-keyboard'))document.body.classList.remove('wk-music-keyboard');host.removeAttribute('data-keyboard');host.style.height='';host.style.bottom='0px'}}
 function top(title='',back=true){return `<div class="top">${title?'<h1>'+h(title)+'</h1>':button('search','search','جستجو','round')}${back?button('back','back','برگشت','round'):button('refresh','refresh','تازه‌سازی','round')}</div>`}
 const loading=()=>'<div aria-label="در حال بارگذاری">'+Array.from({length:5},()=>'<div class="loader"></div>').join('')+'</div>';
 const ids=()=>new Set(downloads.map(t=>t.id));
 function rows(items,ranked=false){tracks=items;return trackRows(items,{current:currentState?.current,downloaded:ids(),ranked})}
 function draw(){
  if(disposed)return;let html='';tracks=[];
  if(view==='home'){
   const first=recommendations[0]||chart[0];html=`<div class="top"><h1>گوش کن</h1><button class="chip" data-action="downloads">${icon('download')}دانلودها${downloads.length?'<span class="count">'+downloads.length+'</span>':''}</button></div><button class="search-entry" data-action="search">${icon('search')}<span>آهنگ، خواننده یا لینک…</span></button>`;
   if(first)html+=`<section class="feature"><div class="feature-copy"><small>${recommendations.length?'برای تو':'پیشنهاد امروز'}</small><h1 dir="auto">${h(first.title)}</h1><p dir="auto">${h(first.artist)}</p><button class="play-pill" data-action="hero">${icon('play')}پخش</button></div>${cover(first)}</section>`;
   html+=`<div class="shortcuts"><button class="chip" data-action="playlists">${icon('library')}لیست‌های من</button></div>`;
   if(!navigator.onLine)html+='<div class="status">آفلاین'+icon('wifi')+'</div>';
   html+='<div class="section-line"><h2>۵۰ آهنگ برتر</h2><span class="subtle">'+h(sourceSummary({sources,loading:chartLoading,error:chartError,partial,updated}))+'</span></div>';
   if(!chart.length)html+=chartLoading?loading():`<div class="empty">${chartError?'فهرست دریافت نشد':'آهنگی در دسترس نیست'}<br><button class="chip" data-action="refresh">تلاش دوباره</button></div>`;
   else html+=rows(chart,true);
  }else if(view==='search'){
   html=top('',true)+`<form class="search-form" role="search">${button('submit-search','search','جستجو')}<input type="search" placeholder="آهنگ یا هنرمند" aria-label="جستجو" value="${h(query)}" autocomplete="off"></form><section id="results">${searchLoading?loading():rows(searchResults)}</section>`;
  }else if(view==='downloads'){
   html=top('دانلودها')+`<div class="status"><b>${downloads.length} آهنگ · ${formatBytes(downloads.reduce((n,t)=>n+(Number(t.bytes)||0),0))}</b>${icon(navigator.onLine?'download':'wifi')}</div>`;
   if(downloads.length)html+=`<button class="banner-play" data-action="play-downloads">${icon('play')}پخش همه</button>`+rows(downloads);
   else html+='<div class="empty">هنوز دانلودی نداری</div>';
   if(pendingDownloads.size)html+='<div class="section-line"><h2>در حال دانلود</h2></div>'+Array.from(pendingDownloads.values(),t=>`<article class="track">${cover(t)}<span class="track-copy"><strong dir="auto">${h(t.title)}</strong><small data-progress="${h(t.id)}">ذخیره…</small></span>${button('cancel-download','close','لغو','','data-id="'+h(t.id)+'"')}</article>`).join('');
  }else if(view==='playlists'){
   html=top('لیست‌های من')+`<button class="banner-play" data-action="new-list">${icon('plus')}لیست جدید</button>`+lists.map(l=>`<button class="list-item" data-action="open-list" data-id="${h(l.id)}"><span class="list-art">${icon('library')}</span><span><strong>${h(l.name)}</strong><small>${l.ids.length} آهنگ</small></span>${icon('back')}</button>`).join('');
   if(!lists.length)html+='<div class="empty">لیستت را بساز</div>';
  }else if(view==='detail'){
   html=top(selectedList?.name||'')+`<div class="shortcuts"><button class="chip" data-action="play-list">${icon('play')}پخش همه</button><button class="chip" data-action="rename-list">ویرایش</button>${button('delete-list','trash','حذف','round')}</div>`;
   html+=listBusy?loading():listTracks.length?rows(listTracks):'<div class="empty">آهنگی در دسترس نیست</div>';
  }else if(view==='player'){
   const s=currentState,t=s?.current;if(!t){view='home';draw();return}
   html=`<div class="player">${top('',true)}${cover(t,'player-cover')}<div class="track-meta"><div><h1 class="title" dir="auto">${h(t.title)}</h1><p class="artist" dir="auto">${h(t.artist)}</p><a class="source-link" data-action="credits">${h(providerName(t.provider))}</a></div>${button('current-more','more','گزینه‌ها','round')}</div><div class="player-actions"><button class="chip" data-action="add-list">${icon('plus')}افزودن به لیست</button>${t.downloadable?button('current-download',ids().has(t.id)?'check':'download',ids().has(t.id)?'دانلود شده':'دانلود','round'):''}${button('queue','queue','صف پخش','round')}</div><div><input class="seek" type="range" min="0" max="${s.duration||1}" value="${s.time}" step="0.1" aria-label="زمان پخش"><div class="times"><span data-time>${clock(s.time)}</span><span data-duration>${clock(s.duration)}</span></div></div><div class="controls">${button('shuffle','shuffle','تصادفی',s.shuffle?'on':'','aria-pressed="'+s.shuffle+'"')}${button('previous','previous','قبلی')}${button('toggle',s.paused?'play':'pause',s.paused?'پخش':'مکث','play')}${button('next','next','بعدی')}${button('repeat','repeat',s.repeat==='one'?'تکرار همین آهنگ':s.repeat==='all'?'تکرار صف':'تکرار خاموش',s.repeat==='off'?'':'on')}</div><div class="error" data-play-error>${s.loading?'آماده‌سازی…':s.error?(s.error==='subscription_required'?'پخش این منبع به اشتراک نیاز دارد':s.error==='audio_unavailable'?'منبع صوتی پاسخ نداد':'دوباره پخش را بزن'):t.local?'آفلاین':''}</div></div>`;
  }else if(view==='queue')html=top('صف پخش')+rows(currentState?.queue||[]);
  if(view==='home')homeDirty=false;page.innerHTML=html;positionEmbed();page.dataset.view=view;chrome();paintPlayback();paintProgress();hydrateArt();
  const input=page.querySelector('input[type=search]');if(input){input.addEventListener('input',()=>{query=input.value;clearTimeout(searchTimer);searchTimer=setTimeout(search,350)});page.querySelector('form').addEventListener('submit',e=>{e.preventDefault();void search()})}
  const seek=page.querySelector('.seek');if(seek){seek.addEventListener('pointerdown',()=>dragging=true);seek.addEventListener('input',()=>{dragging=true;page.querySelector('[data-time]').textContent=clock(seek.value)});seek.addEventListener('change',()=>{queue.seek(seek.value);dragging=false});seek.addEventListener('pointercancel',()=>dragging=false);seek.addEventListener('blur',()=>dragging=false)}
 }
 function markSelected(){page.querySelectorAll('[data-track]').forEach(el=>el.classList.toggle('selected',el.dataset.track===currentState?.current?.id))}
 function formatBytes(n){return n>1024*1024?Math.round(n/1024/1024)+' MB':Math.round(n/1024)+' KB'}
 function providerName(id){return {audius:'Audius',archive:'Internet Archive',ccmixter:'ccMixter',youtube:'YouTube',soundcloud:'SoundCloud'}[id]||id}
 let recommendationGeneration=0,lastListenId='',lastListenTime=0,listened=0,lastSent=0;
 async function refreshRecommendations(){const gen=++recommendationGeneration,owner=String(getUid());try{const r=await request('/api/app/music/recommendations');if(disposed||gen!==recommendationGeneration||owner!==String(getUid())||!r?.ok)return;const next=r.items||[],changed=JSON.stringify(recommendations[0]||null)!==JSON.stringify(next[0]||null);recommendations=next;if(changed)scheduleHome()}catch{}}
 function learn(){const s=currentState;if(!s?.current)return;const id=s.current.id,now=Number(s.time)||0;if(id!==lastListenId){lastListenId=id;listened=0;lastSent=0;lastListenTime=now;return}const delta=now-lastListenTime;lastListenTime=now;if(!s.paused&&delta>0&&delta<=2)listened+=delta;if(listened-lastSent>=30){lastSent=listened;void request('/api/app/music/listen',{id,seconds:30}).catch(()=>{})}}
 function paintPlayback(){
  const s=currentState,t=s?.current;learn();chrome();if(!t){delete mini.dataset.track;mini.replaceChildren();return}
  if(mini.dataset.track!==t.id){
   try{navigator.mediaSession.metadata=new MediaMetadata({title:t.title,artist:t.artist,artwork:t.provider==='audius'?[]:[{src:t.cover}]});for(const [action,handler] of Object.entries({play:()=>audio.play(),pause:()=>audio.pause(),nexttrack:()=>queue.next(1),previoustrack:()=>queue.next(-1),seekto:e=>queue.seek(e.seekTime)}))navigator.mediaSession.setActionHandler(action,handler)}catch{}
mini.dataset.track=t.id;mini.innerHTML=`<button class="open" data-action="player">${cover(t)}<span class="track-copy"><strong dir="auto">${h(t.title)}</strong><small dir="auto">${h(t.artist)}</small></span></button>${button('next','next','بعدی','skip')}${button('toggle',s.paused?'play':'pause',s.paused?'پخش':'مکث','play')}${button('stop','close','توقف و بستن','mini-close')}<div class="progress"><i></i></div>`}
  hydrateArt();mini.querySelector('.progress i').style.width=Math.min(100,s.duration?s.time/s.duration*100:0)+'%';
  for(const container of [mini,page])for(const b of container.querySelectorAll('[data-action=toggle]')){const key=s.paused?'play':'pause';if(b.dataset.icon!==key){b.dataset.icon=key;b.innerHTML=icon(key);b.setAttribute('aria-label',s.paused?'پخش':'مکث')}}
  if(view==='player'){
   const seek=page.querySelector('.seek');if(seek&&!dragging){seek.max=s.duration||1;seek.value=s.time;page.querySelector('[data-time]').textContent=clock(s.time);page.querySelector('[data-duration]').textContent=clock(s.duration)}
   const msg=page.querySelector('[data-play-error]');if(msg)msg.textContent=s.loading?'آماده‌سازی…':s.error?(s.error==='subscription_required'?'پخش این منبع به اشتراک نیاز دارد':s.error==='audio_unavailable'?'منبع صوتی پاسخ نداد':'دوباره پخش را بزن'):t.local?'آفلاین':'';
  }
 }
 let searchResults=[],listTracks=[],listBusy=false;const pendingDownloads=new Map();
 async function refresh(){if(offlineMode){reconnect();return}checkUser();void refreshRecommendations();const serial=++sequence,owner=user;let changed=false;chartLoading=true;chartError=false;if(!chart.length)scheduleHome();else sourceStatus()
  try{const data=await request('/api/app/music/chart?entry='+Date.now());if(disposed||serial!==sequence||owner!==String(getUid()))return;if(!data?.ok)throw Error('chart');const next=data.items||[];changed=JSON.stringify(chart)!==JSON.stringify(next);chart=next;sources=Array.isArray(data.sources)?data.sources:[];partial=!!data.partial;updated=data.updated||0;chartError=false;}
  catch{if(serial===sequence)chartError=true}
  finally{if(serial===sequence){chartLoading=false;if(changed||!chart.length)scheduleHome();else sourceStatus()}}
 }
 async function search(){const q=query.trim(),serial=++searchSequence,owner=String(getUid());searchLoading=!!q;if(!q){searchResults=[];if(view==='search')draw();return}if(view==='search'){const out=page.querySelector('#results');if(out)out.innerHTML=loading()}
  try{const data=await request('/api/app/music/search?q='+encodeURIComponent(q));if(serial!==searchSequence||owner!==String(getUid())||disposed)return;if(!data?.ok)throw Error('search');searchResults=data.items||[]}
  catch{if(serial===searchSequence){searchResults=[];toast('جستجو در دسترس نیست')}}
  finally{if(serial===searchSequence){searchLoading=false;if(view==='search'){const input=page.querySelector('input');const focused=shadow.activeElement===input;if(focused){const out=page.querySelector('#results');out.innerHTML=rows(searchResults)||'<div class="empty">پیدا نشد</div>';hydrateArt();markSelected()}else draw()}}}
 }
 async function loadLibrary(){const owner=String(getUid());try{const results=await Promise.all([library.downloads(),library.lists()]);if(owner!==String(getUid())||disposed)return;[downloads,lists]=results;if(['downloads','playlists'].includes(view))draw()}catch{toast('حافظه در دسترس نیست')}}
 function show(which){if(view!=='player')returnView=view;view=which;page.scrollTop=0;draw();if(which==='downloads'||which==='playlists')void loadLibrary()}
 function openPlayer(){if(currentState?.current){if(!active())navigate('p');show('player')}}
 async function play(items,index=0){if(!items[index])return;claim(items[index]);const operation=queue.play(items,index);show('player');await operation;}
 async function download(t){if(ids().has(t.id)){toast('قبلاً دانلود شده');return}if(library.active(t.id))return;const owner=String(getUid());pendingDownloads.set(t.id,t);if(view==='downloads')draw();toast('دانلود شروع شد');try{const fresh=await resolve(t.id);await library.download(fresh);if(owner===String(getUid())){await loadLibrary();if(active()&&view!=='search')draw();toast('ذخیره شد')}}catch{if(owner===String(getUid()))toast('دانلود نشد')}finally{pendingDownloads.delete(t.id);if(view==='downloads')draw()}}
 function paintProgress(){for(const n of page.querySelectorAll('[data-progress]')){n.textContent=progress.get(n.dataset.progress)!=null?progress.get(n.dataset.progress)+'٪':'ذخیره…'}}
 function sheet(title,html){modal.hidden=false;modal.className='modal';modal.innerHTML=`<section class="sheet" role="dialog" aria-modal="true" aria-label="${h(title)}"><div class="sheet-top"><strong dir="auto">${h(title)}</strong>${button('close-sheet','close','بستن','round')}</div>${html}</section>`;modal.querySelector('button')?.focus()}
 let menuTrack=null,addTrack=null;
 function more(t){if(!t)return;menuTrack=t;sheet(t.title,`<button data-action="menu-play">${icon('play')}پخش</button><button data-action="menu-add">${icon('plus')}افزودن به لیست</button><button data-action="menu-queue">${icon('queue')}افزودن به صف</button>${t.downloadable?`<button data-action="menu-download">${icon(ids().has(t.id)?'trash':'download')}${ids().has(t.id)?'حذف دانلود':'دانلود'}</button>`:'<small>فقط آنلاین</small>'}${view==='detail'?'<button data-action="remove-from-list">'+icon('trash')+'حذف از لیست</button>':''}<button data-action="credits">اعتبار و مجوز</button>`)}
 async function chooseList(t){addTrack=t;await loadLibrary();sheet('افزودن به لیست',`<button data-action="new-list">${icon('plus')}لیست جدید</button>`+lists.map(l=>`<button data-action="save-to-list" data-id="${h(l.id)}">${h(l.name)}${l.ids.includes(t.id)?icon('check'):''}</button>`).join(''))}
 function listForm(rename=false){let saving=false;const listId=rename?selectedList.id:crypto.randomUUID();sheet(rename?'نام لیست':'لیست جدید',`<form data-list-form><input aria-label="نام لیست" placeholder="نام لیست" maxlength="60" value="${h(rename?selectedList?.name:'')}" required><button type="submit" class="submit">ذخیره</button></form>`);modal.querySelector('input').focus();modal.querySelector('form').onsubmit=async e=>{e.preventDefault();if(saving)return;const name=modal.querySelector('input').value.trim();if(!name)return;saving=true;modal.querySelector('.submit').disabled=true;try{const l=await library.saveList({id:listId,name,ids:rename?selectedList.ids:addTrack?[addTrack.id]:[]});addTrack=null;if(rename)selectedList=l;modal.hidden=true;await loadLibrary();draw()}catch{saving=false;const button=modal.querySelector('.submit');if(button)button.disabled=false;toast('ذخیره نشد')}}}
 async function openList(id){selectedList=lists.find(l=>l.id===id);if(!selectedList)return;view='detail';listBusy=true;listTracks=[];draw();const generation=++listGeneration,owner=String(getUid());const results=await Promise.all(selectedList.ids.map(async id=>{try{return await library.get(id)||await resolve(id)}catch{return null}}));if(generation!==listGeneration||owner!==String(getUid()))return;listTracks=results.filter(Boolean);listBusy=false;if(view==='detail')draw()}
 async function action(e){const b=e.target.closest('[data-action]');if(!b||b.disabled)return;const a=b.dataset.action,i=Number(b.dataset.index||0),t=tracks[i];
  if(a==='stop'){queue.stop();release();if(view==='player'||view==='queue'){view='home';draw()}}
  else if(a==='toggle'){window.WakhanPlayback?.intent?.();queue.toggle()}
  else if(a==='next')await queue.next(1);
  else if(a==='previous')await queue.next(-1);
  else if(a==='shuffle'){queue.setShuffle(!currentState.shuffle);draw()}
  else if(a==='repeat'){queue.setRepeat({all:'one',one:'off',off:'all'}[currentState.repeat]);draw()}
  else if(a==='hero')await play(recommendations.length?recommendations:chart,0);
  else if(a==='play')await play(tracks.slice(),i);
  else if(a==='play-downloads')await play(downloads,0);
  else if(a==='play-list')await play(listTracks,0);
  else if(a==='player')openPlayer();
  else if(a==='search'){show('search');page.querySelector('input')?.focus({preventScroll:true})}
  else if(a==='submit-search'){e.preventDefault();void search()}
  else if(a==='refresh')void refresh();
  else if(['downloads','playlists','queue'].includes(a))show(a);
  else if(a==='back'){if(view==='player')view=returnView==='player'?'home':returnView;else if(view==='detail')view='playlists';else view='home';draw()}
  else if(a==='more')more(t);
  else if(a==='current-more')more(currentState.current);
  else if(a==='close-sheet')modal.hidden=true;
  else if(a==='new-list')listForm();
  else if(a==='rename-list')listForm(true);
  else if(a==='add-list')await chooseList(currentState.current);
  else if(a==='menu-add')await chooseList(menuTrack);
  else if(a==='open-list')await openList(b.dataset.id);
  else if(a==='save-to-list'){const l=lists.find(x=>x.id===b.dataset.id);if(l&&addTrack){await library.saveList({...l,ids:[...l.ids,addTrack.id]});addTrack=null;modal.hidden=true;await loadLibrary();toast('اضافه شد')}}
  else if(a==='delete-list'){sheet('حذف لیست؟','<button data-action="confirm-delete">حذف</button>')}
  else if(a==='confirm-delete'){await library.deleteList(selectedList.id);modal.hidden=true;show('playlists')}
  else if(a==='remove-from-list'){selectedList=await library.saveList({...selectedList,ids:selectedList.ids.filter(x=>x!==menuTrack.id)});modal.hidden=true;await loadLibrary();await openList(selectedList.id)}
  else if(a==='menu-play'){modal.hidden=true;await play([menuTrack])}
  else if(a==='menu-queue'){queue.append(menuTrack);modal.hidden=true;toast('به صف اضافه شد')}
  else if(a==='current-download'){void download(currentState.current)}
  else if(a==='menu-download'){modal.hidden=true;if(ids().has(menuTrack.id)){await library.remove(menuTrack.id);await loadLibrary();draw()}else void download(menuTrack)}
  else if(a==='cancel-download'){await library.cancel(b.dataset.id);pendingDownloads.delete(b.dataset.id);draw()}
  else if(a==='credits'){const c=modal.hidden?currentState.current:menuTrack||currentState.current;if(c)sheet('اعتبار و مجوز',`<small dir="auto">${h(c.attribution)}</small><a href="${h(c.source_url)}" target="_blank" rel="noopener">${h(providerName(c.provider))} ↗</a>${['youtube','soundcloud'].includes(c.provider)?'<small>پخش آنلاین · بدون دانلود</small>':`<a href="${h(c.license.startsWith('http')?c.license:'https://openaudiofoundation.org/open-music-license.pdf')}" target="_blank" rel="noopener">مجوز ↗</a>`}${c.metric?'<small>'+h(c.metric==='album_downloads'?'رتبه بر اساس دانلود آلبوم':c.metric==='weekly_trending'?'رتبهٔ هفتگی منبع':'رتبهٔ منبع')+'</small>':''}${c.provider==='audius'?'<a href="https://audius.co/documents/ApiTerms.pdf" target="_blank" rel="noopener">شرایط Audius ↗</a><a href="https://audius.co/legal/privacy-policy" target="_blank" rel="noopener">حریم خصوصی ↗</a>':''}`)}
 }
 shadow.addEventListener('click',e=>{void action(e).catch(()=>toast('انجام نشد'))});modal.addEventListener('click',e=>{if(e.target===modal)modal.hidden=true});
 function keyboard(){
  if(!active()){host.removeAttribute('data-keyboard');if(document.body.classList.contains('wk-music-keyboard'))document.body.classList.remove('wk-music-keyboard');host.style.height='';host.style.bottom='0px';return}
  const on=active(),focused=!!shadow.activeElement?.matches('input,textarea'),v=window.WakhanKeyboard?.viewport?.(),height=Math.min(innerHeight,v?.height||window.visualViewport?.height||innerHeight),shown=on&&height<innerHeight-120;
  host.toggleAttribute('data-keyboard',shown);document.body.classList.toggle('wk-music-keyboard',shown||on&&focused);
  if(shown){host.style.height=height+'px';host.style.bottom='auto'}else{host.style.height='';host.style.bottom='0px'}
 }
 const focusKeyboard=()=>queueMicrotask(keyboard);shadow.addEventListener('focusin',focusKeyboard);shadow.addEventListener('focusout',focusKeyboard);window.addEventListener('wakhanKeyboardFrame',keyboard);window.visualViewport?.addEventListener('resize',keyboard);
 async function syncInsets(){try{const v=await getInsets();if(v&&Number.isFinite(v.width)&&v.width>0&&Number.isFinite(v.top)&&v.top>=0){const scale=innerWidth/v.width;if(scale>=.25&&scale<=4&&v.top*scale<innerHeight/2){host.style.setProperty('--wk-music-top',v.top*scale+'px');if(Number.isFinite(v.bottom)&&v.bottom>=0&&v.bottom*scale<innerHeight/2)host.style.setProperty('--wk-safe-bottom',v.bottom*scale+'px');positionEmbed()}}}catch{}}
 const pullIndicator=document.createElement('div');pullIndicator.className='pull-refresh';pullIndicator.hidden=true;pullIndicator.setAttribute('role','status');pullIndicator.setAttribute('aria-label','تازه‌سازی');pullIndicator.innerHTML=icon('refresh');shadow.append(pullIndicator);
 const pull=installPullRefresh({element:page,enabled:()=>active()&&view==='home'&&!offlineMode&&modal.hidden&&!shadow.activeElement?.matches('input,textarea'),busy:()=>chartLoading,refresh,onState:({phase,distance,progress})=>{pullIndicator.hidden=phase==='idle'||!active()||view!=='home';pullIndicator.dataset.phase=phase;pullIndicator.style.transform=`translateY(${distance}px)`;pullIndicator.style.setProperty('--pull-turn',String(progress*270)+'deg');pullIndicator.setAttribute('aria-label',phase==='refreshing'?'تازه‌سازی…':phase==='ready'?'رها کن':'پایین بکش')}});
 function onRoute(before){const on=getRoute()==='p';if(!on){shadow.activeElement?.blur();entrySerial++;if(entryFrame){cancelAnimationFrame(entryFrame);entryFrame=0}}const changed=checkUser();if(on&&(before!=='p'||changed)){view='home';returnView='home';if(page.scrollTop)page.scrollTop=0;if(changed||!page.firstElementChild||page.dataset.view!=='home')draw();else if(homeDirty)scheduleHome();entryRefresh()}chrome();if(on&&!page.firstElementChild)draw()};
 const oldPlayer=hooks.getPlayer();hooks.setPlayer(()=>{const changed=checkUser();if(changed||!page.firstElementChild)draw();else if(view==='home'&&homeDirty)scheduleHome();if(changed&&active())entryRefresh()});
 const observer=new MutationObserver(()=>{const changed=checkUser();chrome();if(changed&&active()){draw();entryRefresh()}});observer.observe(document.body,{attributes:true,attributeFilter:['class','data-th']});
 const connection=()=>{if(active())draw()};window.addEventListener('online',connection);window.addEventListener('offline',connection);window.addEventListener('resize',syncInsets);
 void syncInsets();if(active()){draw();if(!offlineMode)entryRefresh();else void loadLibrary()}
 return {queue,library,refresh,openPlayer,onRoute,async warm(){checkUser();if(!page.firstElementChild)draw();await Promise.allSettled([refresh(),loadLibrary()]);if(!disposed&&view==='home')draw()},back(){if(!active())return false;if(!modal.hidden){modal.hidden=true;return true}if(view==='home')return false;if(view==='player')view=returnView==='player'?'home':returnView;else if(view==='detail')view='playlists';else view='home';draw();return true},stop(){queue.stop();release()},dispose(){if(disposed)return;++entrySerial;if(entryFrame)cancelAnimationFrame(entryFrame);if(drawFrame)cancelAnimationFrame(drawFrame);pull.dispose();pullIndicator.remove();disposed=true;++sequence;++searchSequence;clearTimeout(noticeTimer);clearTimeout(searchTimer);queue.dispose();audio.dispose();document.removeEventListener('visibilitychange',positionEmbed);library.dispose();clearArtwork();artObserver.disconnect();nativeProgress?.remove();observer.disconnect();window.removeEventListener('online',connection);window.removeEventListener('offline',connection);window.removeEventListener('resize',syncInsets);window.removeEventListener('wakhanKeyboardFrame',keyboard);window.visualViewport?.removeEventListener('resize',keyboard);hooks.setPlayer(oldPlayer);host.remove();globalStyle.remove();document.body.classList.remove('wk-music-page','wk-music-playing','wk-music-keyboard')}};
}
