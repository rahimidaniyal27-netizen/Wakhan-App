/* Voice capture only. Upload and conversation ownership remain in the Chat service. */
export function microphoneError(error){
 const messages={
  NotAllowedError:'اجازهٔ استفاده از مایک داده نشده است. در تنظیمات گوشی، اجازهٔ مایک واخان را فعال کنید.',
  PermissionDeniedError:'اجازهٔ استفاده از مایک داده نشده است. در تنظیمات گوشی، اجازهٔ مایک واخان را فعال کنید.',
  NotFoundError:'مایک در دسترس نیست. اتصال مایک یا هدفون را بررسی کنید.',
  DevicesNotFoundError:'مایک در دسترس نیست. اتصال مایک یا هدفون را بررسی کنید.',
  NotReadableError:'مایک مصروف است. تماس یا برنامهٔ دیگری را که از مایک استفاده می‌کند ببندید و دوباره تلاش کنید.',
  TrackStartError:'مایک مصروف است. تماس یا برنامهٔ دیگری را که از مایک استفاده می‌کند ببندید و دوباره تلاش کنید.',
  SecurityError:'دسترسی برنامه به مایک مجاز نیست. اجازهٔ مایک را در تنظیمات گوشی بررسی کنید.',
  NotSupportedError:'ضبط صدا در این نسخهٔ گوشی پشتیبانی نمی‌شود.',
  AbortError:'ضبط صدا قطع شد. دوباره تلاش کنید.',
  InvalidStateError:'مایک هنوز برای ضبط آماده نیست. گفتگو را دوباره باز کنید و تلاش کنید.',
  UnknownError:'گوشی آغاز ضبط با مایک را نپذیرفت. تماس یا ضبط صدای دیگر را پایان دهید و دوباره تلاش کنید.',
  OverconstrainedError:'تنظیمات مایک با این گوشی سازگار نیست. مایک یا هدفون دیگری را امتحان کنید.'
 };
 const value=Error(error?.captureStage==='ui'?'نمایش نوار ضبط ناکام شد. گفتگو را دوباره باز کنید و تلاش کنید.':messages[error?.name]||(/[\u0600-\u06ff]/.test(error?.message||'')?error.message:'ارتباط با مایک برقرار نشد. دوباره تلاش کنید.'));value.code=error?.name||'Error';value.captureStage=error?.captureStage||'unknown';value.originalMessage=typeof error?.message==='string'?error.message:'';value.captureDetails=error?.captureDetails||null;return value;
}

const formats=['audio/mp4','audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus'];
const allowed=new Set(['audio/mp4','audio/aac','audio/webm','audio/ogg','audio/mpeg','audio/x-m4a']);
export function createVoiceRecording({
 mediaDevices=globalThis.navigator?.mediaDevices,Recorder=globalThis.MediaRecorder,
 audioSession=globalThis.navigator?.audioSession,hasExternalCapture=()=>false,
 onState=()=>{},onResult=()=>{},onError=()=>{},now=()=>Date.now(),
 setTimer=setTimeout,clearTimer=clearTimeout,setTicker=setInterval,clearTicker=clearInterval
}={}){
 let pending=false,version=0,job=null,pendingLease=null,captureStage='idle';
 // Safari rejects audio capture while its AudioSession is explicitly playback-only.
 // Own the recording role only for this capture and restore it without muting a live hall.
 function claimSession(lease){if(!audioSession||typeof audioSession.type!=='string')return lease||null;const value=lease||{previous:audioSession.type,released:false};audioSession.type='play-and-record';return value;}
 function releaseSession(lease){if(!lease||lease.released)return;lease.released=true;try{if(audioSession.type==='play-and-record'&&!hasExternalCapture())audioSession.type=lease.previous;}catch{}}
 function captureDetails(lease){return {audioSessionBefore:lease?.previous??null,audioSessionCurrent:audioSession?.type??null,audioSessionRequested:audioSession?'play-and-record':null};}
 const notify=(stage,seconds)=>{try{onState(stage,seconds);}catch(error){error.captureStage='ui';throw error;}};
 const release=stream=>{for(const track of stream?.getTracks()||[])try{track.stop();}catch{}};
 const error=value=>onError(microphoneError(value));
 function finish(current){
  if(current.done)return;current.done=true;
  clearTimer(current.limit);clearTicker(current.ticker);release(current.stream);releaseSession(current.lease);
  if(job===current){job=null;onState('idle');}
  if(current.failed){error(current.failed);return;}
  if(!current.send)return;
  const mime=(current.chunks.find(chunk=>chunk.type)?.type||current.recorder.mimeType||current.mime||'').split(';')[0].toLowerCase();
  if(!allowed.has(mime)){error(Error('قالب صدای ضبط‌شده پشتیبانی نمی‌شود. دوباره تلاش کنید.'));return;}
  const blob=new Blob(current.chunks,{type:mime});
  if(!blob.size){error(Error('صدایی ثبت نشد. کمی صحبت کنید و دوباره تلاش کنید.'));return;}
  if(blob.size>1_500_000){error(Error('اندازهٔ پیام صوتی بسیار بزرگ است. یک پیام کوتاه‌تر ضبط کنید.'));return;}
  Promise.resolve().then(()=>onResult({blob,seconds:Math.min(120,Math.max(1,Math.round((now()-current.started)/1000)))})).catch(error);
 }
 function stop(send=false){
  if(pending){pending=false;++version;releaseSession(pendingLease);pendingLease=null;onState('idle');}
  if(!job||job.stopping)return;
  const current=job;current.stopping=true;current.send=send;
  try{if(current.recorder.state!=='inactive')current.recorder.stop();else finish(current);}
  catch(e){current.failed=e;finish(current);}
 }
 async function start(){
  if(job||pending)return false;
  if(!mediaDevices?.getUserMedia||typeof Recorder!=='function'){onState('idle');error({name:'NotSupportedError'});return false;}
  pending=true;const request=++version;let stream,lease;
  try{
   captureStage='audio-session';lease=claimSession();pendingLease=lease;notify('requesting');captureStage='permission';
   stream=await mediaDevices.getUserMedia({audio:true,video:false});
   if(request!==version){release(stream);releaseSession(lease);return false;}
   captureStage='audio-session';claimSession(lease);
   const supported=formats.filter(type=>{try{return Recorder.isTypeSupported?.(type);}catch{return false;}});
   const choices=supported.flatMap(mimeType=>[{mimeType,audioBitsPerSecond:64_000},{mimeType}]);choices.push({audioBitsPerSecond:64_000},{});
   let current,lastError;
   for(const options of choices){
    let recorder;
    try{
     captureStage='recorder-constructor';recorder=new Recorder(stream,options);
     current={stream,lease,recorder,mime:options.mimeType||'',chunks:[],size:0,started:now(),send:false,done:false,stopping:false};job=current;
     const candidate=current;
     recorder.ondataavailable=event=>{if(candidate.done||!event.data?.size)return;candidate.chunks.push(event.data);candidate.size+=event.data.size;if(candidate.size>=1_350_000)stop(true);};
     recorder.onerror=event=>{candidate.failed=event.error||{name:'AbortError'};candidate.failed.captureStage='recording';candidate.send=false;stop(false);finish(candidate);};
     recorder.onstop=()=>finish(candidate);
     captureStage='recorder-start';recorder.start(250);break;
    }catch(error){
     error.captureStage=captureStage;lastError=error;if(current)current.done=true;
     if(recorder){recorder.ondataavailable=null;recorder.onerror=null;recorder.onstop=null;try{if(recorder.state!=='inactive')recorder.stop();}catch{}}
     current=null;job=null;
    }
   }
   if(!current)throw lastError||Object.assign(Error('unsupported'),{name:'NotSupportedError'});
   pending=false;pendingLease=null;
   if(current.done)return false;
   current.limit=setTimer(()=>stop(true),120_000);
   current.ticker=setTicker(()=>{if(job===current)notify('recording',Math.floor((now()-current.started)/1000));},500);
   notify('recording',0);return true;
  }catch(e){
   if(request!==version){release(stream);releaseSession(lease);return false;}
   e.captureDetails??=captureDetails(lease);pending=false;pendingLease=null;if(job){clearTimer(job.limit);clearTicker(job.ticker);job.done=true;job=null;}
   release(stream);releaseSession(lease);try{onState('idle');}catch{}e.captureStage??=captureStage;error(e);return false;
  }
 }
 return {start,stop,get starting(){return pending;},get recording(){return !!job&&!job.done;}};
}
