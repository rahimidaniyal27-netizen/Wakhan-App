/* One owner of queue advancement; catalogue refreshes never replace its snapshot. */
export function createMusicQueue({audio,resolve,local,prepare,onChange=()=>{},onError=()=>{},online=()=>navigator.onLine,random=Math.random}){
 let queue=[],index=-1,current=null,serial=0,endedSerial=-1,busy=false,error='',repeat='all',shuffle=false,disposed=false;const history=[];
 const emit=()=>onChange(state());
 function state(){return {queue:queue.slice(),index,current,loading:busy,error,repeat,shuffle,paused:audio.paused,time:Number(audio.currentTime)||0,duration:Number(audio.duration)||current?.duration||0}}
 async function start(i,position=0,playing=true){
  if(disposed||!queue[i])return false;
  const seq=++serial;index=i;current=queue[i];busy=true;error='';emit();
  try{
   const saved=await local(current.id);if(seq!==serial||disposed)return false;
   if(!saved&&!online())throw Error('offline');
   const track=saved?{...current,...saved}:await resolve(current.id);
   if(seq!==serial||disposed)return false;
   if(!track||!track.stream)throw Error('unavailable');current={...track,local:!!saved};
   const ok=await prepare(current,position,playing,seq);
   if(seq!==serial||disposed)return false;
   if(ok===false)throw Error('play');busy=false;emit();return true;
  }catch(e){if(seq===serial&&!disposed){busy=false;error=e.message==='offline'?'offline':'play';emit();onError(error)}return false}
 }
 async function play(items,i=0){if(!Array.isArray(items)||!items[i])return false;queue=items.slice();history.length=0;return start(i)}
 async function next(step=1,automatic=false){
  if(!queue.length||disposed)return false;
  if(automatic&&repeat==='one')return start(index);
  if(step<0&&(Number(audio.currentTime)||0)>3){audio.currentTime=0;emit();return true}
  if(step<0&&history.length)return start(history.pop());
  let candidates=queue.map((x,i)=>i).filter(i=>i!==index);
  if(!online()){
   const downloaded=await Promise.all(candidates.map(async i=>(await local(queue[i].id))?i:null));candidates=downloaded.filter(i=>i!==null);
  }
  if(!candidates.length){if(!automatic&&online())return start(index);audio.pause();emit();return false}
  let i;
  if(shuffle&&step>0)i=candidates[Math.floor(random()*candidates.length)];
  else{
   i=step>0?candidates.find(i=>i>index):candidates.slice().reverse().find(i=>i<index);
   if(i===undefined){if(automatic&&repeat==='off'){audio.pause();emit();return false}i=step>0?candidates[0]:candidates[candidates.length-1]}
  }
  if(step>0)history.push(index);if(history.length>100)history.shift();return start(i);
 }
 function ended(){if(disposed||!current||busy||endedSerial===serial)return;endedSerial=serial;void next(1,true)}
 function toggle(){if(!current)return;if(error){if(audio.readyState>=1){error='';void audio.play().catch(()=>{error='play';emit();onError('play')});emit();return}return start(index,audio.currentTime)}if(audio.paused){void audio.play().catch(()=>onError('play'))}else audio.pause();emit()}
 function seek(value){if(current){audio.currentTime=Math.max(0,Math.min(Number(value)||0,state().duration));emit()}}
 const failed=()=>{if(current&&!busy){error='play';emit();onError('play')}};audio.addEventListener('error',failed);
 const update=()=>{if(current)emit()};audio.addEventListener('ended',ended);for(const e of ['play','pause','timeupdate','durationchange','waiting','canplay'])audio.addEventListener(e,update);
 function stop(){++serial;audio.pause();current=null;queue=[];index=-1;busy=false;error='';emit()}
 return {state,play,next,toggle,seek,stop,retry:()=>start(index,audio.currentTime),setRepeat(v){repeat=['all','one','off'].includes(v)?v:'all';emit()},setShuffle(v){shuffle=!!v;emit()},append(track){if(!queue.some(x=>x.id===track.id))queue.push(track);emit()},remove(i){if(i===index||i<0||i>=queue.length)return;queue.splice(i,1);if(i<index)index--;emit()},dispose(){disposed=true;stop();audio.removeEventListener('ended',ended);audio.removeEventListener('error',failed);for(const e of ['play','pause','timeupdate','durationchange','waiting','canplay'])audio.removeEventListener(e,update)}};
}
