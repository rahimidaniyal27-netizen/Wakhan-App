import Foundation
import Capacitor

@objc(WakhanDownloadsPlugin)
public class WakhanDownloadsPlugin: CAPPlugin, CAPBridgedPlugin, URLSessionDownloadDelegate {
    public let identifier = "WakhanDownloadsPlugin"
    public let jsName = "WakhanDownloads"
    public let pluginMethods: [CAPPluginMethod] = ["download", "source", "cancel", "remove"].map { CAPPluginMethod(name: $0, returnType: CAPPluginReturnPromise) }
    private struct Job { let key: String; let call: CAPPluginCall; let cover: URL; var audio: Bool; var bytes: Int64 }
    private var jobs: [Int: Job] = [:]
    private let serial = OperationQueue()
    private lazy var session: URLSession = { serial.maxConcurrentOperationCount = 1; let c = URLSessionConfiguration.default; c.requestCachePolicy = .reloadIgnoringLocalCacheData; c.urlCache = nil; c.timeoutIntervalForRequest = 25; c.timeoutIntervalForResource = 900; return URLSession(configuration: c, delegate: self, delegateQueue: serial) }()
    private var folder: URL { let u = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("wakhan-music"); try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true); var value = u; var r = URLResourceValues(); r.isExcludedFromBackup = true; try? value.setResourceValues(r); return u }
    private func valid(_ k: String) -> Bool { k.range(of: "^u[0-9]{1,18}_[a-f0-9]{64}$", options: .regularExpression) != nil }
    private func allowed(_ u: URL) -> Bool { guard u.scheme == "https", u.user == nil, u.password == nil, u.port == nil || u.port == 443, let h = u.host else { return false }; return h == "archive.org" || h == "ccmixter.org" || h.range(of: "^ia[0-9]+\\.(us|eu)\\.archive\\.org$", options: .regularExpression) != nil }
    private func file(_ k: String, _ ext: String) -> URL { folder.appendingPathComponent(k + ext) }
    private func result(_ k: String) -> JSObject { ["source": file(k,".mp3").absoluteString, "cover": file(k,".image").absoluteString] }
    @objc func download(_ call: CAPPluginCall) {
        guard let k = call.getString("key"), valid(k), let raw = call.getString("source"), let u = URL(string: raw), allowed(u), let coverRaw = call.getString("cover"), let cover = URL(string: coverRaw), allowed(cover) else { call.reject("INVALID_SOURCE"); return }
        serial.addOperation { [self] in
            guard !jobs.values.contains(where: { $0.key == k }) else { call.reject("DOWNLOAD_ACTIVE"); return }
            let task = session.downloadTask(with: u); task.taskDescription = k; jobs[task.taskIdentifier] = Job(key:k,call:call,cover:cover,audio:true,bytes:0); task.resume()
        }
    }
    @objc func source(_ call: CAPPluginCall) { guard let k = call.getString("key"), valid(k), FileManager.default.fileExists(atPath:file(k,".mp3").path), FileManager.default.fileExists(atPath:file(k,".image").path) else { call.reject("FILE_MISSING"); return }; call.resolve(result(k)) }
    @objc func cancel(_ call: CAPPluginCall) { guard let k = call.getString("key"), valid(k) else { call.resolve(); return }; session.getAllTasks { tasks in tasks.filter { ($0.taskDescription ?? "") == k }.forEach { $0.cancel() } }; serial.addOperation { [self] in for (id,job) in jobs where job.key == k { jobs.removeValue(forKey:id); job.call.reject("CANCELLED") } }; call.resolve() }
    @objc func remove(_ call: CAPPluginCall) { guard let k = call.getString("key"), valid(k) else { call.reject("INVALID_KEY"); return }; for ext in [".mp3",".image"] { try? FileManager.default.removeItem(at:file(k,ext)) }; call.resolve() }
    public func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(request.url.map { allowed($0) } == true ? request : nil) }
    public func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) { guard let job = jobs[downloadTask.taskIdentifier] else { downloadTask.cancel(); return }; let limit: Int64 = job.audio ? 120*1024*1024 : 8*1024*1024; if totalBytesWritten > limit || totalBytesExpectedToWrite > limit { downloadTask.cancel(); return }; notifyListeners("progress",data:["key":job.key,"loaded":totalBytesWritten,"total":totalBytesExpectedToWrite]) }
    public func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard var job = jobs.removeValue(forKey:downloadTask.taskIdentifier) else { return }
        do {
            guard (downloadTask.response as? HTTPURLResponse)?.statusCode == 200 else { throw NSError(domain:"Download",code:1) }
            let size = (try FileManager.default.attributesOfItem(atPath:location.path)[.size] as? NSNumber)?.int64Value ?? 0
            guard size > 20, size <= (job.audio ? 120*1024*1024 : 8*1024*1024) else { throw NSError(domain:"Download",code:2) }
            let dest = file(job.key,job.audio ? ".mp3" : ".image"); try? FileManager.default.removeItem(at:dest); try FileManager.default.moveItem(at:location,to:dest); job.bytes += size
            if job.audio { job.audio = false; let next = session.downloadTask(with:job.cover); next.taskDescription = job.key; jobs[next.taskIdentifier] = job; next.resume() }
            else { var r = result(job.key); r["bytes"] = job.bytes; job.call.resolve(r) }
        } catch { for ext in [".mp3",".image"] { try? FileManager.default.removeItem(at:file(job.key,ext)) }; job.call.reject("DOWNLOAD_FAILED") }
    }
    public func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) { guard error != nil, let job = jobs.removeValue(forKey:task.taskIdentifier) else { return }; for ext in [".mp3",".image"] { try? FileManager.default.removeItem(at:file(job.key,ext)) }; job.call.reject("DOWNLOAD_FAILED") }
}
