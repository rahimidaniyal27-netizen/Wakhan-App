import sys,json,asyncio,mimetypes,re,urllib.parse
from pathlib import Path
from aiohttp import web,ClientSession,ClientTimeout
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'project';chart=json.loads((ROOT/'research/live-chart.json').read_text());cache={};app=web.Application()
def rewrite(t):
 t=dict(t);t['cover']='/asset?u='+urllib.parse.quote(t['cover'],safe='')
 if t['provider']=='archive':t['stream']='/asset?u='+urllib.parse.quote(t['stream'],safe='')
 return t
async def api(req):
 if req.path.endswith('/resolve'):
  t=next((x for x in chart['items']if x['id']==req.query.get('id')),None);return web.json_response({'ok':bool(t),'item':rewrite(t) if t else None})
 r=dict(chart);r['items']=[rewrite(t)for t in chart['items']];return web.json_response(r)
async def asset(req):
 u=req.query.get('u','');host=urllib.parse.urlsplit(u).hostname
 if not host or not (host=='archive.org' or host.endswith('.audiusindex.org') or host.endswith('.audius.co') or 'open-audio-validator.com' in host or 'figment.io' in host or 'audius' in host):return web.Response(status=403)
 if u not in cache:
  async with app['http'].get(u) as r:
   if r.status!=200:return web.Response(status=r.status)
   b=await r.read();cache[u]=(b,r.headers.get('Content-Type','application/octet-stream'))
 b,typ=cache[u];headers={'Cache-Control':'no-store','Accept-Ranges':'bytes'};status=200
 if 'Range' in req.headers:
  m=re.fullmatch(r'bytes=(\d+)-(\d*)',req.headers['Range'])
  if m:
   a=int(m[1]);z=int(m[2])if m[2]else len(b)-1;headers['Content-Range']=f'bytes {a}-{z}/{len(b)}';b=b[a:z+1];status=206
 return web.Response(body=b,status=status,headers=headers,content_type=typ.split(';')[0])
async def static(req):
 name=req.match_info['path'] or 'review/music-preview.html';f=(P/name).resolve()
 if not f.is_relative_to(P.resolve())or not f.is_file():return web.Response(status=404)
 return web.FileResponse(f)
app.router.add_get('/api/app/music/{kind}',api);app.router.add_get('/asset',asset);app.router.add_get('/{path:.*}',static)
async def start(a):a['http']=ClientSession(trust_env=True,timeout=ClientTimeout(total=30))
async def stop(a):await a['http'].close();cache.clear()
app.on_startup.append(start);app.on_cleanup.append(stop)
web.run_app(app,host='127.0.0.1',port=8784)
