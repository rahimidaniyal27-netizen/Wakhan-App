import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'screenshots';OUT.mkdir(exist_ok=True)
async def main():
 errors=[];results=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
  ctx=await browser.new_context(viewport={'width':393,'height':852},is_mobile=True,has_touch=True)
  page=await ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.set_default_timeout(15000)
  await page.goto('http://127.0.0.1:8784/review/music-preview.html');await page.wait_for_function('window.ready');await page.locator('#wk-music .track').first.wait_for();await page.wait_for_timeout(1200)
  print('ready',await page.locator('#wk-music .track').count(),errors,flush=True)
  assert await page.locator('#wk-music .track').count()==50
  assert (await page.locator('#wk-music .top button').first.bounding_box())['y']>=63
  assert await page.locator('#wk-music .page').evaluate('e=>e.scrollWidth<=e.clientWidth')
  await page.screenshot(path=str(OUT/'music-home.png'))
  await page.evaluate("route('h');route('p')");await page.wait_for_timeout(100)
  assert await page.evaluate("calls.filter(x=>x.includes('/chart')).length")>=2
  await page.locator('#wk-music [data-action=search]').tap();await page.locator('#wk-music input[type=search]').fill('Kabul');await page.wait_for_timeout(800);assert await page.evaluate("calls.some(x=>x.includes('/search?q=Kabul'))")
  await page.evaluate('window.testKeyboardHeight=492;window.WakhanKeyboard={viewport:()=>({height:window.testKeyboardHeight})};window.dispatchEvent(new Event("wakhanKeyboardFrame"))');assert (await page.locator('#wk-music').bounding_box())['height']==492;await page.evaluate('window.testKeyboardHeight=852;window.dispatchEvent(new Event("wakhanKeyboardFrame"))');assert (await page.locator('#wk-music').bounding_box())['height']==852;await page.screenshot(path=str(OUT/'music-search.png'));await page.locator('#wk-music [data-action=back]').tap();assert (await page.locator('#wk-music').bounding_box())['height']==852
  # IA track has explicit CC rights and its real cover. Exercise durable file storage.
  await page.locator('#wk-music .track [data-action=more]').nth(1).tap();await page.locator('#wk-music [data-action=menu-download]').tap()
  for i in range(90):
   if await page.evaluate('async()=>(await ui.library.downloads()).length'):break
   await page.wait_for_timeout(500)
  assert await page.evaluate('async()=>(await ui.library.downloads()).length')==1
  await page.locator('#wk-music [data-action=downloads]').tap();await page.locator('#wk-music .track').first.wait_for();await page.screenshot(path=str(OUT/'music-downloads.png'))
  await ctx.set_offline(True);await page.locator('#wk-music [data-action=play-downloads]').tap();await page.wait_for_timeout(500)
  assert await page.evaluate('ui.queue.state().current.local')
  assert await page.evaluate('!audio.paused')
  await page.screenshot(path=str(OUT/'music-offline-player.png'))
  await page.locator('#wk-music [data-action=add-list]').tap();await page.locator('#wk-music [data-action=new-list]').tap();await page.locator('#wk-music .sheet input').fill('شب‌های من');await page.locator('#wk-music .sheet .submit').tap();await page.wait_for_timeout(300);assert await page.evaluate('async()=>(await ui.library.lists()).length')==1, await page.evaluate('async()=>await ui.library.lists()')
  await ctx.set_offline(False);await page.reload();await page.wait_for_function('window.ready');await page.locator('#wk-music [data-action=downloads]').tap();await page.locator('#wk-music .track').first.wait_for();assert await page.evaluate('async()=>(await ui.library.downloads()).length')==1
  await page.evaluate('switchUser(2)');assert await page.evaluate('async()=>(await ui.library.downloads()).length')==0;assert await page.evaluate('async()=>(await ui.library.lists()).length')==0
  for width,height in [(320,640),(430,932)]:
   await page.set_viewport_size({'width':width,'height':height});await page.evaluate("route('p')");await page.wait_for_timeout(100);assert await page.locator('#wk-music .page').evaluate('e=>e.scrollWidth<=e.clientWidth');results.append(dict(width=width,no_horizontal_overflow=True))
  assert not errors,errors
  (ROOT/'ui-results.json').write_text(json.dumps(dict(results=results,chart_entry_refresh=True,offline_playback=True,restart_persistence=True,account_isolation=True,errors=errors,physical_phone_tested=False),indent=2));print('PASS',results,flush=True);await browser.close()
asyncio.run(main())
