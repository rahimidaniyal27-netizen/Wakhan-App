// A room entry owns one local announcement, ordered after the existing chat.
// Minimise/restore keeps that entry; leaving or changing account starts a new one.
export function createSalonAnnouncementFeed(){
 let entry=null;
 function ensure(uid,room){const key=String(uid||'')+'|'+String(room||'');if(!uid||!room){entry=null;return null}if(entry?.key!==key)entry={key,text:null,history:false,anchor:0};return entry}
 return {
  ensure,
  leave(){entry=null},
  meta(uid,room,hall){const e=ensure(uid,room);if(e&&e.text===null)e.text=String(hall?.notice||'').trim().slice(0,300)},
  messages(uid,room,messages){const e=ensure(uid,room);if(e&&!e.history){e.anchor=Math.max(0,...messages.map(m=>Number(m.id)||0));e.history=true}},
  saved(uid,room,text){const e=ensure(uid,room);if(e)e.text=String(text||'').trim().slice(0,300)},
  /* a salon is a room: you see only what was said after you came in; the salon notice always opens your chat */
  rows(uid,room,messages){const e=ensure(uid,room);if(!e?.history)return [];const fresh=messages.filter(m=>{const id=Number(m.id);return !(id>0)||id>e.anchor});return e.text?[{kind:'salon_notice',id:'entry-notice',text:e.text},...fresh]:fresh}
 };
}
