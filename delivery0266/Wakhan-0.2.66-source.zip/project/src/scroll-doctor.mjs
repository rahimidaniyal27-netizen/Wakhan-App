/* «Scroll doctor»: notices a swipe that should have scrolled but did not, writes down exactly what was on the screen
   at that moment, and frees the page from any lock that is left over. A long press on the chosen tab in the bottom bar
   shows the notes (with a copy button), so the real cause on the phone can be read instead of guessed. */
export function installScrollDoctor(){
 if(window.__wkDoctor)return window.__wkDoctor;
 const KEY='wk_scroll_doctor',notes=[];try{notes.push(...JSON.parse(localStorage.getItem(KEY)||'[]').slice(-8))}catch{}
 const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(notes.slice(-8)))}catch{}};
 const tab=()=>{try{return typeof TAB!=='undefined'?TAB:'?'}catch{return '?'}};
 const desc=n=>{if(!n||!n.tagName)return String(n&&n.nodeName||n);let s=n.tagName.toLowerCase();if(n.id)s+='#'+n.id;const c=typeof n.className==='string'?n.className.trim().split(/\s+/).slice(0,3).join('.'):'';if(c)s+='.'+c;return s};
 const style=n=>{try{const c=getComputedStyle(n);return `${c.position} z${c.zIndex} pe:${c.pointerEvents} ta:${c.touchAction} op:${c.opacity} vis:${c.visibility} ov:${c.overflowY}`}catch{return ''}};
 const up=n=>n.parentElement||(n.getRootNode&&n.getRootNode()!==document&&n.getRootNode().host)||null;
 function scroller(el){for(let n=el;n&&n!==document.documentElement&&n!==document.body;n=up(n)){if(!(n instanceof Element))continue;const c=getComputedStyle(n);if(/(auto|scroll)/.test(c.overflowY)&&n.scrollHeight>n.clientHeight+2)return n}return document.scrollingElement||document.documentElement}
 function snapshot(x,y,extra={}){const he=document.documentElement,b=document.body,hs=getComputedStyle(he),bs=getComputedStyle(b),se=document.scrollingElement||he;
  let stack=[];try{stack=document.elementsFromPoint(x,y).slice(0,6).map(n=>desc(n)+' ['+style(n)+']')}catch{}
  const ov=window.WakhanOverlays?.active;
  return {at:new Date().toISOString().slice(11,19),tab:tab(),...extra,
   html:`ov:${hs.overflowY} ta:${hs.touchAction}`,body:`pos:${bs.position} ov:${bs.overflowY} ta:${bs.touchAction} inline:${b.getAttribute('style')||''}`.slice(0,220),
   classes:b.className.slice(0,240),overlay:ov?desc(ov):'',inert:[...b.children].filter(n=>n.inert).map(desc).slice(0,6),
   doc:`top:${Math.round(se.scrollTop)} h:${se.scrollHeight} vh:${se.clientHeight}`,stack};
 }
 /* frees what can safely be freed: chat lock while the chat is not shown, a body lock without an open overlay */
 function repair(){const b=document.body,done=[];
  if(tab()!=='d'&&b.matches('.wkchat-thread,.wkchat-inbox')){b.classList.remove('wkchat-thread','wkchat-inbox');done.push('chat-lock')}
  try{window.WakhanOverlays?.sync?.()}catch{}
  if(!window.WakhanOverlays?.active){if(b.style.position==='fixed'){const y=-parseInt(b.style.top||'0',10)||0;for(const k of ['position','top','left','right','width','overflow'])b.style.removeProperty(k);window.scrollTo(0,y);done.push('body-lock')}
   for(const n of [document.documentElement,b])if(n.style.overflow==='hidden'||n.style.overflowY==='hidden'){n.style.removeProperty('overflow');n.style.removeProperty('overflow-y');done.push('inline-overflow')}
   for(const n of b.children)if(n.inert&&n.dataset.wkOverlayCovered){n.inert=false;delete n.dataset.wkOverlayCovered;done.push('inert')}}
  const veil=document.getElementById('sl-veil');if(veil&&!document.querySelector('.slr')){veil.remove();done.push('veil')}
  return done}
 let s=null,prevented=0,who=[];
 /* who blocked the finger: remember a short trace of whoever cancels a touch move while a swipe is being watched */
 try{const pd=Event.prototype.preventDefault;Event.prototype.preventDefault=function(){try{if(s&&this.type==='touchmove'&&who.length<3){const st=String(new Error().stack||'').split('\n').map(l=>l.trim()).filter(l=>l&&l!=='Error'&&!/scroll-doctor|preventDefault/.test(l)).slice(0,3).join(' | ').slice(0,300);if(st&&!who.includes(st))who.push(st)}}catch{}return pd.call(this)}}catch{}
 addEventListener('touchstart',e=>{if(e.touches.length!==1){s=null;return}const t=e.touches[0],path=e.composedPath?e.composedPath():[e.target],el=path[0]instanceof Element?path[0]:e.target;const sc=scroller(el);
  s={x:t.clientX,y:t.clientY,t:Date.now(),el,sc,top:sc.scrollTop,h:sc.scrollHeight,vh:sc.clientHeight};prevented=0;who=[]},{passive:true,capture:true});
 addEventListener('touchmove',e=>{if(s&&e.defaultPrevented)prevented++},{passive:true});
 addEventListener('touchend',e=>{if(!s)return;const a=s;s=null;const t=e.changedTouches[0];if(!t)return;const dy=t.clientY-a.y,dx=t.clientX-a.x,ms=Date.now()-a.t;
  if(Math.abs(dy)<70||Math.abs(dx)>Math.abs(dy)*.7||ms>1500)return;
  const sc=a.sc;if(!sc||!sc.isConnected||a.h<=a.vh+20)return;const goingDown=dy<0,room=goingDown?a.top<a.h-a.vh-4:a.top>4;if(!room)return;
  setTimeout(()=>{if(Math.abs(sc.scrollTop-a.top)>2)return;               /* it did move: all fine */
   const note=snapshot(a.x,a.y,{swipe:`${Math.round(dy)}px ${ms}ms`,target:desc(a.el),scroller:desc(sc)+` top:${Math.round(a.top)} h:${a.h} vh:${a.vh}`,prevented,who:who.slice()});
   note.fixed=repair();notes.push(note);while(notes.length>8)notes.shift();save()},120)},{passive:true,capture:true});
 /* long press (0.9 s) on the chosen tab: show the notes */
 let lp=0,lx=0,ly=0;
 addEventListener('touchstart',e=>{clearTimeout(lp);const b=e.target.closest&&e.target.closest('#nav>button.on');if(!b)return;const t=e.touches[0];lx=t.clientX;ly=t.clientY;lp=setTimeout(()=>show(lx,ly),900)},{passive:true,capture:true});
 addEventListener('touchmove',e=>{const t=e.touches[0];if(lp&&t&&Math.hypot(t.clientX-lx,t.clientY-ly)>12){clearTimeout(lp);lp=0}},{passive:true,capture:true});
 addEventListener('touchend',()=>{clearTimeout(lp);lp=0},{passive:true,capture:true});
 function text(){const now=snapshot(innerWidth/2,innerHeight/2,{note:'now (screen centre)'});return JSON.stringify({version:window.WakhanVersion||document.documentElement.dataset.wkVersion||'',ua:navigator.userAgent.slice(-60),notes,now},null,1)}
 function show(){document.getElementById('wk-doctor')?.remove();const p=document.createElement('div');p.id='wk-doctor';
  p.style.cssText='position:fixed;left:10px;right:10px;bottom:calc(env(safe-area-inset-bottom,0px) + 96px);max-height:60vh;z-index:2147483600;display:flex;flex-direction:column;gap:8px;padding:12px;border-radius:22px;background:rgba(14,10,30,.97);border:1px solid rgba(255,255,255,.18);color:#fff;font:12px/1.5 ui-monospace,Menlo,monospace;direction:ltr;box-shadow:0 20px 50px rgba(0,0,0,.6)';
  const body=text();p.innerHTML=`<b style="font:800 14px Vazirmatn,system-ui;direction:rtl;text-align:right">گزارش اسکرول (${notes.length} مورد)</b><pre style="margin:0;overflow:auto;flex:1;white-space:pre-wrap;word-break:break-all;-webkit-overflow-scrolling:touch"></pre><div style="display:flex;gap:8px;direction:rtl"><button data-k="copy" style="flex:1;height:42px;border-radius:21px;border:0;background:#fff;color:#15112b;font:800 14px Vazirmatn,system-ui">کپی</button><button data-k="clear" style="height:42px;padding:0 14px;border-radius:21px;border:1px solid rgba(255,255,255,.3);background:none;color:#fff;font:700 13px Vazirmatn,system-ui">پاک کردن</button><button data-k="x" style="height:42px;padding:0 16px;border-radius:21px;border:1px solid rgba(255,255,255,.3);background:none;color:#fff;font:700 13px Vazirmatn,system-ui">بستن</button></div>`;
  p.querySelector('pre').textContent=body;document.body.append(p);
  p.addEventListener('click',async e=>{const k=e.target.closest('[data-k]')?.dataset.k;if(k==='x')p.remove();
   if(k==='clear'){notes.length=0;save();p.remove()}
   if(k==='copy'){let ok=false;try{await navigator.clipboard.writeText(body);ok=true}catch{}if(!ok){try{const r=document.createRange();r.selectNodeContents(p.querySelector('pre'));const sel=getSelection();sel.removeAllRanges();sel.addRange(r);ok=document.execCommand('copy')}catch{}}e.target.textContent=ok?'کپی شد ✓':'کپی نشد'}})}
 window.__wkDoctor={notes,show,repair,snapshot:()=>snapshot(innerWidth/2,innerHeight/2)};return window.__wkDoctor;
}
