import unittest,tempfile,json,sqlite3,importlib.util,sys,zipfile
from pathlib import Path
from unittest.mock import patch
R=Path(__file__).resolve().parents[1];spec=importlib.util.spec_from_file_location('installer',R/'sign-and-publish.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Transaction(unittest.TestCase):
 def fixture(self,root):
  (root/'releases').mkdir();(root/'releases/latest.json').write_text('{"build":56}');(root/'native_wakhan2.py').write_bytes(b'unchanged entry');(root/'wakhan_music').mkdir()
  for n in m.BACKEND_PACKAGE_SHA:(root/'wakhan_music'/n).write_bytes(b'old '+n.encode())
  hashes={n:m.sha(root/'wakhan_music'/n)for n in m.BACKEND_PACKAGE_SHA}
  database=root/'private.sqlite';db=sqlite3.connect(database);db.execute('CREATE TABLE coins(uid INTEGER,amount INTEGER)');db.execute('INSERT INTO coins VALUES(1,100)');db.commit();db.close()
  with zipfile.ZipFile(root/'Wakhan-0.2.42-source.zip','w')as z:
   verification=dict(backend_entry_sha256=m.sha(root/'native_wakhan2.py'),backend_sha256={})
   for p in (R/'server/wakhan_music').glob('*.py'):
    n='server/wakhan_music/'+p.name;verification['backend_sha256'][n]=m.sha(p);z.writestr(n,p.read_bytes())
   z.writestr('source-verification.json',json.dumps(verification))
  return hashes,database
 def prepare(self,root,report):
  hashes,database=self.fixture(root);backup=m.backup_database
  with patch.object(m,'BACKEND_ENTRY_SHA',m.sha(root/'native_wakhan2.py')),patch.object(m,'BACKEND_PACKAGE_SHA',hashes),patch.object(m,'check_health'),patch.object(m,'service_python',return_value=Path(sys.executable)),patch.object(m,'backup_database',side_effect=lambda path,dest:backup(database,dest)):
   state=m.prepare_backend(root,root,report)
  return state,hashes
 def test_commit_and_rollback_restore_backend_latest_and_preserve_live_data(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);report={};state,hashes=self.prepare(root,report)
   with patch.object(m,'BACKEND_ENTRY_SHA',m.sha(root/'native_wakhan2.py')),patch.object(m,'BACKEND_PACKAGE_SHA',hashes),patch.object(m,'restart_and_health')as restart:
    m.commit_backend(state,report);self.assertEqual(m.sha(root/'wakhan_music/discovery.py'),state['sha256']['discovery.py']);self.assertTrue(state['changed']);restart.assert_called_once()
    state['latest_attempted']=True;(root/'releases/latest.json').write_text('{"build":57}');m.rollback_backend(state,report);self.assertFalse(state['changed']);self.assertEqual(restart.call_count,2)
   self.assertEqual(json.loads((root/'releases/latest.json').read_text())['build'],56)
   for n,h in hashes.items():self.assertEqual(m.sha(root/'wakhan_music'/n),h)
   self.assertEqual((root/'native_wakhan2.py').read_bytes(),b'unchanged entry');db=sqlite3.connect(root/'private.sqlite');self.assertEqual(db.execute('SELECT amount FROM coins').fetchone()[0],100);db.close()
   backup=Path(report['database_backup']);self.assertEqual(backup.stat().st_mode&0o777,0o600)
 def test_failed_restart_can_be_rolled_back(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);report={};state,hashes=self.prepare(root,report)
   with patch.object(m,'BACKEND_ENTRY_SHA',m.sha(root/'native_wakhan2.py')),patch.object(m,'BACKEND_PACKAGE_SHA',hashes),patch.object(m,'restart_and_health',side_effect=[RuntimeError('health'),None]):
    with self.assertRaisesRegex(RuntimeError,'health'):m.commit_backend(state,report)
    m.rollback_backend(state,report)
   self.assertTrue(report['backend_rolled_back']);self.assertEqual(set(p.name for p in (root/'wakhan_music').iterdir()),set(hashes))
 def test_drift_before_commit_leaves_old_package_untouched(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);state,hashes=self.prepare(root,{});(root/'native_wakhan2.py').write_bytes(b'new independent change')
   with patch.object(m,'BACKEND_PACKAGE_SHA',hashes),patch.object(m,'restart_and_health')as restart:
    with self.assertRaisesRegex(RuntimeError,'EXISTING_BACKEND_CHANGED'):m.commit_backend(state,{})
    restart.assert_not_called()
   self.assertFalse(state['moved_original'])
 def test_failed_new_package_rename_also_restores_original(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);state,hashes=self.prepare(root,{});original=m.os.replace
   def failing(a,b):
    if a==state['work']/'wakhan_music':raise OSError('rename failed')
    return original(a,b)
   with patch.object(m,'BACKEND_ENTRY_SHA',m.sha(root/'native_wakhan2.py')),patch.object(m,'BACKEND_PACKAGE_SHA',hashes),patch.object(m.os,'replace',side_effect=failing),patch.object(m,'restart_and_health'):
    with self.assertRaises(OSError):m.commit_backend(state,{})
    m.rollback_backend(state,{})
   for n,h in hashes.items():self.assertEqual(m.sha(root/'wakhan_music'/n),h)
if __name__=='__main__':unittest.main()
