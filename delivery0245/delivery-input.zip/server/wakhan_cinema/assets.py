"""Authenticated salon images and chat uploads; no executable or user-supplied path."""
import asyncio,base64,hashlib,io,re,secrets
from pathlib import Path
from aiohttp import web
from .store import CinemaError
class Assets:
 def __init__(self,service):
  self.s=service;self.root=Path(service.n.get('DATA')or'.')/'cinema-v2';self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
  with service.store.db:service.store.db.execute('CREATE TABLE IF NOT EXISTS wkc_assets(key TEXT PRIMARY KEY,code TEXT,uid INTEGER NOT NULL,kind TEXT NOT NULL,ts REAL NOT NULL)')
 @staticmethod
 def image(value):
  from PIL import Image,ImageOps
  if not isinstance(value,str)or len(value)>6_000_000:raise CinemaError('image_too_large',413)
  match=re.fullmatch(r'data:image/(?:jpeg|png|webp);base64,([A-Za-z0-9+/=]+)',value)
  if not match:raise CinemaError('bad_image')
  try:
   data=base64.b64decode(match[1],validate=True)
   with Image.open(io.BytesIO(data))as image:
    if image.width*image.height>20_000_000:raise CinemaError('image_too_large',413)
    image=ImageOps.exif_transpose(image).convert('RGB');image.thumbnail((1920,1920));out=io.BytesIO();image.save(out,format='JPEG',quality=85,optimize=True);return out.getvalue()
  except CinemaError:raise
  except Exception as error:raise CinemaError('bad_image')from error
 async def upload(self,request,uid):
  body=await self.s.body(request);session=self.s.session(uid,body);room=self.s.store.room(session.code);kind=body.get('kind');perm=self.s.rooms.permissions(room,uid,session.seat);self.s.me.slow(uid,'cinema_upload',10,60)
  if kind not in {'photo','background','chat'}:raise CinemaError('bad_upload')
  if kind!='chat'and not perm['owner']or kind=='chat'and not perm['chat']:raise CinemaError('forbidden',403)
  data=await asyncio.to_thread(self.image,body.get('data'));key=secrets.token_hex(24)+'.jpg';path=self.root/key
  with path.open('xb')as file:file.write(data)
  with self.s.store.db:self.s.store.db.execute('INSERT INTO wkc_assets VALUES(?,?,?,?,?)',(key,session.code,uid,kind,self.s.store.now()))
  url='/api/app/cinema/v2/photo/'+key
  if kind!='chat':self.s.store.update(session.code,settings={**room['settings'],kind:url})
  await self.s.broadcast(session.code);return{'ok':True,'url':url}
 async def photo(self,request):
  user=self.s.n['WM_APP'].check_key(request.headers.get('X-Init',''))
  if not user:raise web.HTTPUnauthorized()
  uid=int(user['id']);self.s.rooms.account(uid);key=request.match_info.get('key','')
  if not re.fullmatch(r'[A-Za-z0-9_-]{8,120}\.(?:jpg|jpeg|png|webp)',key):raise web.HTTPNotFound()
  asset=self.s.store.one('SELECT *FROM wkc_assets WHERE key=?',(key,))
  if asset:
   if asset['code']and not self.s.rooms.visible(asset['code'],uid):raise web.HTTPForbidden()
   path=self.root/key
  else:
   # Import only pre-existing images owned by a visible migrated room.
   visible=any(self.s.rooms.visible(room['code'],uid)and any(str(v).endswith('/'+key)for v in [room['settings'].get('photo'),room['settings'].get('background')])for room in self.s.rooms.all())
   if not visible:raise web.HTTPNotFound()
   path=Path(self.s.n.get('BASE')or'.')/'data/wm51_halls'/key
  if not path.is_file()or path.is_symlink()or path.stat().st_size>6_000_000:raise web.HTTPNotFound()
  return web.FileResponse(path,headers={'Cache-Control':'private,max-age=300','X-Content-Type-Options':'nosniff','Content-Type':'image/jpeg'})
