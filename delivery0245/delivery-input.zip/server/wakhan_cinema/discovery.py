"""Public catalogue discovery. Personal and shared playback grants stay distinct."""
import asyncio,hashlib,json,re,time
from urllib.parse import urlencode,urljoin,urlsplit
from .media import public_url
from .store import CinemaError

def free_license(raw):
 try:
  url=urlsplit(str(raw or''));return url.hostname in {'creativecommons.org','www.creativecommons.org'}and(url.path.startswith(('/publicdomain/zero/','/publicdomain/mark/','/licenses/by/','/licenses/by-sa/')))
 except ValueError:return False

class Discovery:
 def __init__(self,catalog):self.catalog=catalog;self.cache={};self.pending={};self.ids={};self.available={};self.slots=asyncio.Semaphore(4)
 async def archive(self,query):
  q='mediatype:movies'+(' AND ('+query.replace('"',' ')[:100]+')'if query else'')
  params={'q':q,'output':'json','rows':'20','sort[]':'downloads desc','fl[]':['identifier','title','creator','year','description','licenseurl']}
  data=await self.catalog.streaming.metadata('https://archive.org/advancedsearch.php?'+urlencode(params,doseq=True));out=[]
  for row in(data.get('response')or{}).get('docs')or[]:
   ident=str(row.get('identifier')or'')
   if not re.fullmatch(r'[A-Za-z0-9_.-]{1,180}',ident):continue
   license=row.get('licenseurl');license=license[0]if isinstance(license,list)and license else license
   out.append({'provider':'archive','external':ident,'url':'https://archive.org/details/'+ident,'title':str(row.get('title')or ident)[:200],'cover':'https://archive.org/services/img/'+ident,'duration':0,'rights':'room'if free_license(license)else'solo','license':str(license or''),'score':20-len(out)})
  return out
 async def commons(self,query):
  params={'action':'query','format':'json','generator':'search','gsrsearch':'filetype:video '+(query or'documentary'),'gsrnamespace':6,'gsrlimit':12,'prop':'imageinfo','iiprop':'url|mime|size|extmetadata','iiurlwidth':480}
  data=await self.catalog.streaming.metadata('https://commons.wikimedia.org/w/api.php?'+urlencode(params));out=[]
  for row in(data.get('query')or{}).get('pages',{}).values():
   info=(row.get('imageinfo')or[{}])[0];url=info.get('url');meta=info.get('extmetadata')or{};license=(meta.get('LicenseUrl')or{}).get('value','')
   if not public_url(url)or not str(info.get('mime')or'').startswith('video/'):continue
   out.append({'provider':'commons','external':str(row['pageid']),'url':url,'title':str(row.get('title')or'').removeprefix('File:')[:200],'cover':info.get('thumburl')or'','duration':float(info.get('duration')or 0),'rights':'room'if free_license(license)else'solo','license':license,'score':15-len(out)})
  return out
 async def peertube(self,query):
  data=await self.catalog.streaming.metadata('https://sepiasearch.org/api/v1/search/videos?'+urlencode({'search':query or'documentary','count':12,'sort':'-views'}));out=[]
  for row in data.get('data')or[]:
   url=str(row.get('url')or'');u=urlsplit(url);uuid=str(row.get('uuid')or'')
   if not public_url(url)or not re.fullmatch(r'[a-fA-F0-9-]{36}',uuid):continue
   licence=(row.get('licence')or{}).get('id');out.append({'provider':'peertube','external':u.netloc+'/'+uuid,'url':'https://'+u.netloc+'/api/v1/videos/'+uuid,'title':str(row.get('name')or'')[:200],'cover':urljoin(url,row.get('previewUrl')or row.get('thumbnailUrl')or''),'duration':float(row.get('duration')or 0),'rights':'room'if licence in {1,2,7}else'solo','license':str((row.get('licence')or{}).get('label')or''),'score':12-len(out)})
  return out
 def ingest(self,items):
  store=self.catalog.store
  ids=[]
  with store.db:
   store.db.executescript("CREATE TABLE IF NOT EXISTS wks_titles(id TEXT PRIMARY KEY,kind TEXT,title TEXT,poster TEXT DEFAULT '',backdrop TEXT DEFAULT '',year INTEGER DEFAULT 0,descr TEXT DEFAULT '',genres TEXT DEFAULT '',cat TEXT DEFAULT '',score REAL DEFAULT 0,ts INTEGER);CREATE TABLE IF NOT EXISTS wks_sources(tid TEXT,ep TEXT DEFAULT '',sid TEXT,provider TEXT,url TEXT,lang TEXT DEFAULT '',sub TEXT DEFAULT '',q TEXT DEFAULT '',rights TEXT DEFAULT 'solo',dur REAL DEFAULT 0,title TEXT DEFAULT '',thumb TEXT DEFAULT '',s INTEGER DEFAULT 0,e INTEGER DEFAULT 0,ts INTEGER,PRIMARY KEY(tid,ep,sid));")
   for item in items[:64]:
    identity='cv2_'+hashlib.sha256((item['provider']+':'+item['external']).encode()).hexdigest()[:32];title=' '.join(str(item['title']).split())[:200];cover=item.get('cover')or''
    if not title or not public_url(item['url']):continue
    if cover and not public_url(cover):cover=''
    store.db.execute("INSERT OR IGNORE INTO wks_titles(id,kind,title,poster,backdrop,descr,score,ts)VALUES(?,'movie',?,?,?, ?,?,?)",(identity,title,cover,cover,str(item.get('license')or'')[:300],float(item.get('score')or 0),int(time.time())))
    store.db.execute("INSERT OR REPLACE INTO wks_sources(tid,ep,sid,provider,url,rights,dur,title,thumb,ts)VALUES(?,'',?,?,?,?,?,?,?,?)",(identity,identity,item['provider'],item['url'],item['rights'],item.get('duration')or 0,title,cover,int(time.time())))
    ids.append(identity)
  return ids
 async def search(self,query):
  query=' '.join(str(query).split())[:100];now=time.monotonic()
  if query in self.cache and now-self.cache[query]<300:return self.results(query)
  if query not in self.pending:
   async def fetch():
    try:
     async def bounded(fn):
      try:
       async with self.slots:return (True,await asyncio.wait_for(fn(query),8))
      except Exception:return(False,[])
     results=await asyncio.gather(*(bounded(fn)for fn in[self.archive,self.commons,self.peertube]));self.available[query]=any(ok for ok,rows in results);self.ids.pop(query,None);self.ids[query]=self.ingest([item for ok,rows in results for item in rows]);
     while len(self.ids)>100:
      old=next(iter(self.ids));self.ids.pop(old,None);self.available.pop(old,None);self.cache.pop(old,None)
     if self.available[query]:self.cache[query]=time.monotonic()
     while len(self.cache)>100:self.cache.pop(next(iter(self.cache)))
    finally:self.pending.pop(query,None)
   self.pending[query]=asyncio.create_task(fetch())
  await asyncio.shield(self.pending[query]);items=self.results(query)
  if not items and not self.available.get(query):raise CinemaError('archive_unavailable',503)
  return items
 def results(self,query):
  items=self.catalog.archive(query);known={item['id']for item in items}
  for ident in self.ids.get(query,[]):
   if ident not in known:
    card=self.catalog.store.one('SELECT id,title,poster,backdrop,kind,descr,score FROM wks_titles WHERE id=?',(ident,))
    if card:card.update(provider='archive',cover=card['poster']or card['backdrop']or'');items.append(card);known.add(ident)
  return items[:48]
 async def close(self):
  tasks=list(self.pending.values())
  for task in tasks:task.cancel()
  if tasks:await asyncio.gather(*tasks,return_exceptions=True)
