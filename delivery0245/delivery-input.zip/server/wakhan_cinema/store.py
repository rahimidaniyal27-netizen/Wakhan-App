"""Durable Cinema data. Room codes and account relationships migrate as data only."""
import json
import secrets
import time

class CinemaError(Exception):
    def __init__(self, code, status=400):
        super().__init__(code)
        self.code, self.status = code, status

SCHEMA = '''
CREATE TABLE IF NOT EXISTS wkc_migrations(version INTEGER PRIMARY KEY,ts REAL NOT NULL);
CREATE TABLE IF NOT EXISTS wkc_reserved_codes(code TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS wkc_rooms(code TEXT PRIMARY KEY,owner INTEGER NOT NULL,name TEXT NOT NULL,notice TEXT NOT NULL DEFAULT '',settings TEXT NOT NULL DEFAULT '{}',personal INTEGER NOT NULL DEFAULT 0,revision INTEGER NOT NULL DEFAULT 1,ts REAL NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS wkc_personal_owner ON wkc_rooms(owner) WHERE personal=1;
CREATE TABLE IF NOT EXISTS wkc_follows(uid INTEGER NOT NULL,code TEXT NOT NULL,ts REAL NOT NULL,PRIMARY KEY(uid,code));
CREATE TABLE IF NOT EXISTS wkc_members(code TEXT NOT NULL,uid INTEGER NOT NULL,role TEXT NOT NULL DEFAULT 'member',via TEXT NOT NULL DEFAULT 'join',ts REAL NOT NULL,PRIMARY KEY(code,uid));
CREATE TABLE IF NOT EXISTS wkc_visits(uid INTEGER NOT NULL,code TEXT NOT NULL,ts REAL NOT NULL,PRIMARY KEY(uid,code));
CREATE TABLE IF NOT EXISTS wkc_rules(code TEXT NOT NULL,uid INTEGER NOT NULL,kind TEXT NOT NULL,ts REAL NOT NULL,PRIMARY KEY(code,uid,kind));
CREATE TABLE IF NOT EXISTS wkc_knocks(code TEXT NOT NULL,uid INTEGER NOT NULL,status TEXT NOT NULL,ts REAL NOT NULL,PRIMARY KEY(code,uid));
CREATE TABLE IF NOT EXISTS wkc_events(code TEXT PRIMARY KEY,title TEXT NOT NULL,starts REAL NOT NULL,remind INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS wkc_messages(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT NOT NULL,uid INTEGER NOT NULL,kind TEXT NOT NULL,body TEXT NOT NULL,key TEXT NOT NULL,ts REAL NOT NULL,deleted INTEGER NOT NULL DEFAULT 0,UNIQUE(uid,key));
CREATE INDEX IF NOT EXISTS wkc_messages_room ON wkc_messages(code,id);
CREATE TABLE IF NOT EXISTS wkc_reactions(message INTEGER NOT NULL,uid INTEGER NOT NULL,value TEXT NOT NULL,PRIMARY KEY(message,uid));
CREATE TABLE IF NOT EXISTS wkc_queue(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT NOT NULL,uid INTEGER NOT NULL,item TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'approved',position INTEGER NOT NULL,ts REAL NOT NULL);
CREATE INDEX IF NOT EXISTS wkc_queue_room ON wkc_queue(code,status,position,id);
CREATE TABLE IF NOT EXISTS wkc_votes(item INTEGER NOT NULL,uid INTEGER NOT NULL,PRIMARY KEY(item,uid));
CREATE TABLE IF NOT EXISTS wkc_playback(code TEXT PRIMARY KEY,media TEXT,version INTEGER NOT NULL DEFAULT 0,position REAL NOT NULL DEFAULT 0,playing INTEGER NOT NULL DEFAULT 0,anchor REAL NOT NULL DEFAULT 0,history TEXT NOT NULL DEFAULT '[]');
CREATE TABLE IF NOT EXISTS wkc_commands(uid INTEGER NOT NULL,key TEXT NOT NULL,code TEXT NOT NULL,result TEXT NOT NULL,ts REAL NOT NULL,PRIMARY KEY(uid,key));
CREATE TABLE IF NOT EXISTS wkc_history(uid INTEGER NOT NULL,item TEXT NOT NULL,media TEXT NOT NULL,position REAL NOT NULL DEFAULT 0,ts REAL NOT NULL,PRIMARY KEY(uid,item));
'''
DEFAULTS = {'privacy':'public','mic':'free','chat':True,'seats':8,'capacity':0,'approval':False,'share':True,'background':'','dim':0.25,'locks':[],'language':'fa','topic':'','chatAccess':'all'}

class CinemaStore:
    def __init__(self, db, now=time.time):
        self.db, self.now = db, now
    def rows(self, sql, args=()):
        cursor = self.db.execute(sql, args)
        names = [c[0] for c in cursor.description or ()]
        return [dict(zip(names,row)) for row in cursor.fetchall()]
    def one(self, sql, args=()):
        rows = self.rows(sql,args)
        return rows[0] if rows else None
    def exists(self, table):
        return self.one("SELECT name FROM sqlite_master WHERE type='table' AND name=?",(table,)) is not None
    def initialize(self):
        with self.db:
            self.db.executescript(SCHEMA)
            if not self.one('SELECT version FROM wkc_migrations WHERE version=1'):
                self.migrate()
                self.db.execute('INSERT INTO wkc_migrations VALUES(1,?)',(self.now(),))
    def migrate(self):
        # No user tables are deleted, and no historical Python module is imported.
        rooms = self.rows('SELECT code,owner,ts FROM rooms') if self.exists('rooms') else []
        personal = {r['code']:r for r in self.rows('SELECT uid,code,name,created_at FROM wm_personal_cinemas')} if self.exists('wm_personal_cinemas') else {}
        history={r['code']:r['uid']for r in self.rows('SELECT code,uid FROM wm_cinema_code_history')}if self.exists('wm_cinema_code_history')else{}
        current={p['uid']:code for code,p in personal.items()}
        for code in {r['code']for r in rooms}|set(history)|set(personal):self.db.execute('INSERT OR IGNORE INTO wkc_reserved_codes VALUES(?)',(code,))
        rooms=[r for r in rooms if r['code']not in history or current.get(history[r['code']])==r['code']]
        for code,p in personal.items():
            if not any(r['code']==code for r in rooms):rooms.append({'code':code,'owner':p['uid'],'ts':p['created_at']})
        halls = {r['uid']:r for r in self.rows('SELECT * FROM wm51_halls')} if self.exists('wm51_halls') else {}
        layouts = {r['code']:r for r in self.rows('SELECT * FROM wka_room_layout')} if self.exists('wka_room_layout') else {}
        metas={r['code']:r for r in self.rows('SELECT *FROM wka_room_meta')}if self.exists('wka_room_meta')else{}
        decors = {r['code']:r for r in self.rows('SELECT * FROM wks_salon')} if self.exists('wks_salon') else {}
        for room in rooms:
            code,owner = room['code'],int(room['owner']);p=personal.get(code);h=halls.get(owner,{});layout=layouts.get(code,{});decor=decors.get(code,{})
            settings={**DEFAULTS,'privacy':{'all':'public','friends':'friends','closed':'invite'}.get(h.get('enter'),'public'),'mic':{'all':'free','friends':'friends','owner':'ask'}.get(h.get('mic','all'),'ask'),'chat':h.get('chat','all')!='owner','chatAccess':h.get('chat','all'),'seats':max(2,min(16,int(layout.get('seats')or 8))),'capacity':int(decor.get('cap')or 0),'approval':bool(decor.get('approval')),'share':bool(decor.get('share',1)),'background':('/api/app/cinema/v2/photo/'+h['bgphoto'])if h.get('bgphoto')else'','dim':float(decor.get('dim',.25)),'locks':sorted({int(x)for x in str(h.get('locks')or'').split(',')if x.isdigit()and int(x)<16}),'photo':('/api/app/cinema/v2/photo/'+h['photo'])if h.get('photo')else'','decor':decor.get('decor')or'pamir'}
            if not settings['capacity']:settings['capacity']=settings['seats']
            settings.update(language=metas.get(code,{}).get('language')or'fa',topic=metas.get(code,{}).get('topic')or'')
            name=(p or {}).get('name')or h.get('name')or 'سالون'
            self.db.execute('INSERT OR IGNORE INTO wkc_rooms(code,owner,name,notice,settings,personal,ts)VALUES(?,?,?,?,?,?,?)',(code,owner,name,h.get('notice')or'',json.dumps(settings),int(p is not None),room.get('ts')or self.now()))
            if self.exists('wm51_bans'):
                for ban in self.rows('SELECT uid,kind,ts FROM wm51_bans WHERE owner=?',(owner,)):
                    self.db.execute('INSERT OR IGNORE INTO wkc_rules VALUES(?,?,?,?)',(code,ban['uid'],{'ban':'ban','mute':'mic'}.get(ban['kind'],ban['kind']),ban['ts']))
        for old,new,columns in [('wka_room_favorites','wkc_follows','uid,code,ts'),('wm51_visits','wkc_visits','uid,code,ts')]:
            if self.exists(old):self.db.execute('INSERT OR IGNORE INTO '+new+'('+columns+') SELECT '+columns+' FROM '+old)
        if self.exists('wks_members'):
            self.db.execute("INSERT OR IGNORE INTO wkc_members(code,uid,via,ts) SELECT code,uid,via,ts FROM wks_members")
        if self.exists('wks_chatban'):
            self.db.execute("INSERT OR IGNORE INTO wkc_rules(code,uid,kind,ts) SELECT code,uid,'chat',ts FROM wks_chatban")
        if self.exists('wks_knocks'):
            self.db.execute('INSERT OR IGNORE INTO wkc_knocks SELECT code,uid,status,ts FROM wks_knocks')
        if self.exists('wks_progress')and self.exists('wks_sources')and self.exists('wks_titles'):
            for progress in self.rows('SELECT *FROM wks_progress'):
                source=self.one("SELECT *FROM wks_sources WHERE tid=?AND ep=?ORDER BY rights='room'DESC,ts DESC LIMIT 1",(progress['tid'],progress['ep']))
                title=self.one('SELECT *FROM wks_titles WHERE id=?',(progress['tid'],))
                if not source or not title:continue
                media={'id':'archive:'+progress['tid']+':'+progress['ep']+':'+source['sid'],'provider':'archive','provider_id':progress['tid'],'episode':progress['ep'],'version_id':source['sid'],'title':source.get('title')or title['title'],'cover':source.get('thumb')or title.get('cover')or title.get('poster')or title.get('backdrop')or'','duration':progress['dur']}
                self.db.execute('INSERT OR IGNORE INTO wkc_history VALUES(?,?,?,?,?)',(progress['uid'],media['id'],json.dumps(media),progress['pos'],progress['ts']))
        if self.exists('room_hosts'):
            for row in self.rows('SELECT code,uid FROM room_hosts'):
                self.db.execute("INSERT INTO wkc_members(code,uid,role,via,ts)VALUES(?,?,'assistant','migration',?)ON CONFLICT(code,uid)DO UPDATE SET role='assistant'",(row['code'],row['uid'],self.now()))
        if self.exists('wks_events'):
            self.db.execute('INSERT OR IGNORE INTO wkc_events SELECT code,title,ts,remind FROM wks_events')
    def room(self, code):
        row=self.one('SELECT * FROM wkc_rooms WHERE code=?',(code,))
        if row:row['settings']={**DEFAULTS,**json.loads(row['settings'])}
        return row
    def create(self,uid,name):
        existing=self.one('SELECT code FROM wkc_rooms WHERE owner=? AND personal=1',(uid,))
        if existing:return self.room(existing['code'])
        for _ in range(30):
            code=''.join(secrets.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789')for _ in range(6))
            if self.room(code)or self.one('SELECT code FROM wkc_reserved_codes WHERE code=?',(code,)):continue
            with self.db:self.db.execute('INSERT INTO wkc_rooms(code,owner,name,settings,personal,ts)VALUES(?,?,?,?,1,?)',(code,uid,name,json.dumps(DEFAULTS),self.now()))
            with self.db:self.db.execute('INSERT OR IGNORE INTO wkc_reserved_codes VALUES(?)',(code,))
            return self.room(code)
        raise CinemaError('code_unavailable',503)
    def update(self,code,**fields):
        if not set(fields)<={'name','notice','settings'}:raise ValueError('invalid fields')
        if 'settings'in fields:fields['settings']=json.dumps(fields['settings'])
        with self.db:self.db.execute('UPDATE wkc_rooms SET '+','.join(k+'=?'for k in fields)+',revision=revision+1 WHERE code=?',(*fields.values(),code))
        return self.room(code)
    def bump(self,code):
        with self.db:self.db.execute('UPDATE wkc_rooms SET revision=revision+1 WHERE code=?',(code,))
    def follow(self,uid,code,on):
        if not self.room(code):raise CinemaError('not_found',404)
        with self.db:
            if on:self.db.execute('INSERT OR IGNORE INTO wkc_follows VALUES(?,?,?)',(uid,code,self.now()))
            else:self.db.execute('DELETE FROM wkc_follows WHERE uid=? AND code=?',(uid,code))
    def playback(self,code):
        row=self.one('SELECT * FROM wkc_playback WHERE code=?',(code,))
        if not row or not row['media']:return None
        value=json.loads(row['media']);value.update(version=row['version'],playing=bool(row['playing']),position=max(0,row['position']+(max(0,self.now()-row['anchor'])if row['playing']else 0)))
        return value
    def set_playback(self,code,media,*,playing=False,position=0,history=None):
        old=self.one('SELECT * FROM wkc_playback WHERE code=?',(code,))or{}
        version=int(old.get('version',0))+1
        with self.db:self.db.execute('INSERT INTO wkc_playback VALUES(?,?,?,?,?,?,?)ON CONFLICT(code)DO UPDATE SET media=excluded.media,version=excluded.version,position=excluded.position,playing=excluded.playing,anchor=excluded.anchor,history=excluded.history',(code,json.dumps(media)if media else None,version,max(0,float(position)),int(bool(playing)),self.now(),json.dumps(history)if history is not None else old.get('history','[]')))
        self.bump(code);return self.playback(code)
    def queue(self,code):
        rows=self.rows('SELECT q.*, (SELECT count(*)FROM wkc_votes v WHERE v.item=q.id)AS votes FROM wkc_queue q WHERE code=?ORDER BY position,id',(code,))
        for row in rows:row['item']=json.loads(row['item'])
        return rows
    def messages(self,code,after=0):
        rows=self.rows('SELECT * FROM wkc_messages WHERE code=?AND id>? ORDER BY id LIMIT 100',(code,after))
        for row in rows:row['body']=json.loads(row['body'])
        return rows
    def cached(self,uid,key,code):
        row=self.one('SELECT code,result FROM wkc_commands WHERE uid=?AND key=?',(uid,key))
        if row and row['code']!=code:raise CinemaError('command_scope',409)
        return json.loads(row['result'])if row else None
    def remember(self,uid,key,code,result):
        with self.db:self.db.execute('INSERT OR IGNORE INTO wkc_commands VALUES(?,?,?,?,?)',(uid,key,code,json.dumps(result),self.now()))
