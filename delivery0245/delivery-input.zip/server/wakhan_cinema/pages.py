"""Resolve public provider pages through declared video metadata, without running page scripts."""
import html,json,re
from html.parser import HTMLParser
from urllib.parse import urljoin,urlsplit
from .media import public_url
from .store import CinemaError
class Page(HTMLParser):
 def __init__(self):super().__init__();self.sources=[];self.scripts=[];self.script=None
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='meta'and a.get('property','').lower()in {'og:video','og:video:url','og:video:secure_url'}:self.sources.append(a.get('content',''))
  if tag in {'source','video'}and a.get('src'):self.sources.append(a['src'])
  if tag=='script'and a.get('type')in {'application/ld+json','application/json'}:self.script=''
 def handle_data(self,data):
  if self.script is not None:self.script+=data
 def handle_endtag(self,tag):
  if tag=='script'and self.script is not None:self.scripts.append(self.script);self.script=None
 def metadata(self):
  def walk(value):
   if isinstance(value,dict):
    for k,v in value.items():
     if k in {'contentUrl','contentURL','file','fileUrl','src'}and isinstance(v,str):self.sources.append(v)
     elif isinstance(v,(list,dict)):walk(v)
   elif isinstance(value,list):
    for item in value:walk(item)
  for raw in self.scripts:
   try:walk(json.loads(raw))
   except(ValueError,TypeError):pass
  return self.sources
async def resolve_page(files,url,provider):
 allowed={'namasha':{'namasha.com','www.namasha.com'},'farsinama':{'farsinama.com','www.farsinama.com'},'nixvido':{'nixvido.com','www.nixvido.com','watanmovie.com','www.watanmovie.com'}}
 if not public_url(url)or urlsplit(url).hostname not in allowed.get(provider,set()):raise CinemaError('unsupported_source')
 response=await files.fetch(url,headers={'User-Agent':'Mozilla/5.0'})
 async with response:
  if response.status!=200:raise CinemaError('source_unavailable',502)
  if response.headers.get('Content-Type','').startswith(('video/','application/vnd.apple.mpegurl')):return url
  raw=await response.content.read(2_000_001)
  if len(raw)>2_000_000:raise CinemaError('source_page_large',502)
  page=Page();text=raw.decode('utf-8','replace');page.feed(text);sources=page.metadata()
  # Structured public MP4/HLS literals are common on these provider pages.
  sources+=re.findall(r'''https?:(?:\\/|/){2}[^\s<>"']+?\.(?:mp4|m3u8)(?:\?[^\s<>"']*)?''',text)
  valid=[]
  for source in sources:
   source=urljoin(url,html.unescape(source.replace('\\/','/')))
   if public_url(source)and re.search(r'\.(mp4|m3u8)(?:$|\?)',source,re.I):valid.append(source)
  if not valid:raise CinemaError('no_playable_file',502)
  return next((s for s in valid if'.mp4'in urlsplit(s).path.lower()),valid[0])
