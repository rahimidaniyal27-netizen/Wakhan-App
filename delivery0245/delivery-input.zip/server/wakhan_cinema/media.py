"""Room-scoped byte-range streaming. Only server catalogue references are leased."""
import asyncio,base64,hashlib,hmac,ipaddress,json,re,secrets,socket,time
from urllib.parse import urlsplit,urljoin,urlencode
import aiohttp
from aiohttp import web
from aiohttp.abc import AbstractResolver
from .store import CinemaError

class PublicResolver(AbstractResolver):
    async def resolve(self,host,port=0,family=socket.AF_INET):
        addresses=await asyncio.get_running_loop().getaddrinfo(host,port,type=socket.SOCK_STREAM,family=family)
        result=[]
        for family,_,proto,_,address in addresses:
            ip=address[0]
            if not ipaddress.ip_address(ip).is_global:raise OSError('non_public_address')
            result.append({'hostname':host,'host':ip,'port':port,'family':family,'proto':proto,'flags':socket.AI_NUMERICHOST})
        return result
    async def close(self):pass

def public_url(raw):
    try:
        u=urlsplit(raw);host=(u.hostname or'').lower()
        if u.scheme!='https'or not host or u.username or u.password or u.port not in(None,443)or u.fragment:return False
        if host in {'localhost','metadata.google.internal'}or host.endswith(('.local','.localhost','.internal')):return False
        try:return ipaddress.ip_address(host).is_global
        except ValueError:return True
    except(TypeError,ValueError):return False

class CinemaMedia:
    def __init__(self,store,rooms,*,origin='https://music.kabulcafe.uk',key=None,session=None):
        self.store,self.rooms,self.origin=store,rooms,origin;self.key=key or secrets.token_bytes(32);self.http=session;self.owns_http=session is None;self.leases={}
    def sign(self,payload):
        data=base64.urlsafe_b64encode(json.dumps(payload,separators=(',',':'),sort_keys=True).encode()).rstrip(b'=');signature=base64.urlsafe_b64encode(hmac.new(self.key,b'cinema-file-v2:'+data,hashlib.sha256).digest()).rstrip(b'=');return(data+b'.'+signature).decode()
    def verify(self,token):
        try:
            if not isinstance(token,str)or len(token)>6000:raise ValueError()
            data,signature=token.encode().split(b'.');want=base64.urlsafe_b64encode(hmac.new(self.key,b'cinema-file-v2:'+data,hashlib.sha256).digest()).rstrip(b'=')
            if not hmac.compare_digest(signature,want):raise ValueError()
            payload=json.loads(base64.urlsafe_b64decode(data+b'='*((-len(data))%4)))
            if payload.get('purpose')!='cinema_file'or payload.get('expires',0)<=time.time():raise ValueError()
            return payload
        except(ValueError,TypeError,KeyError,json.JSONDecodeError):raise web.HTTPForbidden()
    def present(self,media,uid,room):
        out={**media,'source':dict(media.get('source')or{})}
        if out['source'].get('kind')=='file':
            cache_key=(uid,room,media['id'],json.dumps(out['source'],sort_keys=True));cached=self.leases.get(cache_key)
            if cached and cached[0]>time.time()+300:out['source']['url']=cached[1];return out
            payload={'purpose':'cinema_file','uid':uid,'room':room,'media':media['id'],'provider':media['provider'],'source':{k:v for k,v in out['source'].items()if k!='url'},'expires':int(time.time())+7200}
            out['source']['url']=self.origin+'/api/app/cinema/v2/media/file?'+urlencode({'lease':self.sign(payload)});self.leases[cache_key]=(payload['expires'],out['source']['url'])
            while len(self.leases)>2000:self.leases.pop(next(iter(self.leases)))
        return out
    def authorize(self,request):
        payload=self.verify(request.query.get('lease'));uid=payload.get('uid')
        if type(uid)is not int:raise web.HTTPForbidden()
        self.rooms.account(uid)
        code=payload.get('room')
        if code:
            playing=self.store.playback(code)
            if not self.rooms.visible(code,uid)or uid not in self.rooms.present(code)or not playing or playing['id']!=payload.get('media'):raise web.HTTPForbidden()
        if payload.get('provider')=='archive':
            ref=payload.get('source')or{};row=self.store.one('SELECT rights FROM wks_sources WHERE tid=?AND ep=?AND sid=?',(ref.get('catalog_title'),ref.get('catalog_episode',''),ref.get('catalog_source')))
            if not row or row['rights']not in({'room'}if code else{'room','personal','solo'}):raise web.HTTPForbidden()
        return payload
    async def session(self):
        if self.http is None:self.http=aiohttp.ClientSession(connector=aiohttp.TCPConnector(resolver=PublicResolver(),limit=24,ttl_dns_cache=120),timeout=aiohttp.ClientTimeout(total=None,connect=10,sock_read=35))
        return self.http
    async def fetch(self,url,*,headers=None,method='GET'):
        for attempt in range(4):
            if not public_url(url):raise CinemaError('source_not_public',502)
            response=await(await self.session()).request(method,url,headers=headers or{},allow_redirects=False)
            if response.status in {301,302,303,307,308}:
                target=urljoin(url,response.headers.get('Location',''));response.release();url=target;continue
            return response
        raise CinemaError('redirect_limit',502)
    async def metadata(self,url):
        response=await self.fetch(url)
        async with response:
            if response.status!=200:raise CinemaError('source_unavailable',502)
            raw=await response.content.read(2_000_001)
            if len(raw)>2_000_000:raise CinemaError('source_metadata_large',502)
            return json.loads(raw)
    async def resolve(self,payload):
        source=payload['source'];provider=payload['provider'];code=payload.get('room')
        if source.get('resource'):
            raw=source['resource']
            if not public_url(raw):raise CinemaError('source_not_public',502)
            return raw
        if provider=='archive':
            row=self.store.one('SELECT provider,url,rights FROM wks_sources WHERE tid=?AND ep=?AND sid=?',(source.get('catalog_title'),source.get('catalog_episode',''),source.get('catalog_source')))
            if not row or row['rights']not in({'room'}if code else{'room','personal','solo'}):raise web.HTTPForbidden()
            url=row['url'];kind=row['provider']
            if kind=='peertube':
                data=await self.metadata(url);files=[f for f in data.get('files',[])if public_url(f.get('fileUrl'))];files.sort(key=lambda f:abs(int((f.get('resolution')or{}).get('id')or 0)-720))
                if files:return files[0]['fileUrl']
                playlists=data.get('streamingPlaylists')or[]
                if playlists and public_url(playlists[0].get('playlistUrl')):return playlists[0]['playlistUrl']
                raise CinemaError('no_playable_file',502)
            if kind in {'namasha','farsinama','nixvido'}:
                from .pages import resolve_page
                return await resolve_page(self,url,kind)
            if kind=='aparat':return await self.aparat(str(urlsplit(url).path).strip('/').split('/')[-1])
            if kind=='archive'and'/details/'in url:
                ident=urlsplit(url).path.strip('/').split('/')[-1]
                if not re.fullmatch(r'[A-Za-z0-9_.-]{1,200}',ident):raise CinemaError('bad_source')
                data=await self.metadata('https://archive.org/metadata/'+ident);files=[f for f in data.get('files',[])if str(f.get('name','')).lower().endswith('.mp4')and str(f.get('source',''))=='original']or[f for f in data.get('files',[])if str(f.get('name','')).lower().endswith('.mp4')]
                if not files:raise CinemaError('no_playable_file',502)
                from urllib.parse import quote
                return'https://archive.org/download/'+ident+'/'+quote(files[0]['name'],safe='/')
            return url
        if provider=='aparat':return await self.aparat(source.get('provider_id',''))
        raise CinemaError('unsupported_source')
    async def aparat(self,ident):
        if not re.fullmatch(r'[A-Za-z0-9]{3,40}',str(ident)):raise CinemaError('bad_aparat')
        data=await self.metadata('https://www.aparat.com/etc/api/video/videohash/'+ident);video=data.get('video')or{};files=[]
        for group in video.get('file_link_all')or[]:
            height=int(re.sub(r'[^0-9]','',str(group.get('profile')or group.get('text')or'0'))or 0)
            urls=group.get('urls')or[]
            for raw in urls:
                host=(urlsplit(raw).hostname or'').lower()
                if public_url(raw)and any(host==base or host.endswith('.'+base)for base in ['aparat.com','aparat.ir','aparatcdn.com','arvanvod.ir','arvancloudstorage.ir']):files.append((abs(height-720),raw))
        if not files:raise CinemaError('aparat_unavailable',502)
        return sorted(files)[0][1]
    async def file(self,request):
        payload=self.authorize(request);range_value=request.headers.get('Range')
        if range_value and not re.fullmatch(r'bytes=(?:[0-9]+-[0-9]*|-[0-9]+)',range_value):raise web.HTTPRequestRangeNotSatisfiable()
        headers={'Accept-Encoding':'identity','User-Agent':'Mozilla/5.0'}
        if range_value:headers['Range']=range_value
        try:source=await self.resolve(payload);upstream=await self.fetch(source,headers=headers,method='HEAD'if request.method=='HEAD'else'GET')
        except(web.HTTPException,CinemaError):raise
        except Exception:raise web.HTTPBadGateway(text='source_unavailable')
        async with upstream:
            if upstream.status==416:return web.Response(status=416,headers={'Content-Range':upstream.headers.get('Content-Range','bytes */0')})
            if upstream.status not in{200,206}:raise web.HTTPBadGateway(text='source_unavailable')
            mime=upstream.headers.get('Content-Type','application/octet-stream').split(';',1)[0].lower()
            if request.method=='HEAD':
                out={k:upstream.headers[k]for k in ['Content-Length','Content-Range','Accept-Ranges','Content-Type']if k in upstream.headers};out['Cache-Control']='private,no-store';return web.Response(status=upstream.status,headers=out)
            if mime in{'application/vnd.apple.mpegurl','application/x-mpegurl','audio/mpegurl'}or urlsplit(source).path.lower().endswith('.m3u8'):
                raw=await upstream.content.read(2_000_001)
                if len(raw)>2_000_000:raise web.HTTPBadGateway()
                lines=[]
                def resource(raw):
                    target=urljoin(source,raw)
                    if not public_url(target):raise web.HTTPBadGateway()
                    child={**payload,'source':{**payload['source'],'resource':target}};return self.origin+'/api/app/cinema/v2/media/file?'+urlencode({'lease':self.sign(child)})
                for line in raw.decode('utf-8-sig').splitlines():
                    if line and not line.startswith('#'):line=resource(line)
                    elif'URI="'in line:line=re.sub(r'URI="([^"]+)"',lambda m:'URI="'+resource(m.group(1))+'"',line)
                    lines.append(line)
                return web.Response(text='\n'.join(lines),content_type='application/vnd.apple.mpegurl',headers={'Cache-Control':'private,no-store'})
            if not(mime.startswith(('video/','audio/'))or mime in{'application/octet-stream','binary/octet-stream'}):raise web.HTTPBadGateway(text='not_media')
            out={'Content-Type':mime,'Accept-Ranges':'bytes','Cache-Control':'private,no-store','X-Content-Type-Options':'nosniff'}
            for key in ['Content-Length','Content-Range','ETag','Last-Modified']:
                if key in upstream.headers:out[key]=upstream.headers[key]
            response=web.StreamResponse(status=upstream.status,headers=out);await response.prepare(request)
            if request.method!='HEAD':
                try:
                    async for chunk in upstream.content.iter_chunked(65536):await response.write(chunk)
                except(ConnectionError,asyncio.CancelledError):return response
            await response.write_eof();return response
    async def close(self):
        if self.owns_http and self.http:await self.http.close()
