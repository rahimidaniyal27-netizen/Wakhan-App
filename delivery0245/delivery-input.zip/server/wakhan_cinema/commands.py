import json
import math
from .store import CinemaError,DEFAULTS

def require(value,code='forbidden',status=403):
    if not value:raise CinemaError(code,status)

def integer(value,low,high):
    if isinstance(value,bool):raise CinemaError('bad_input')
    try:number=int(value)
    except(TypeError,ValueError):raise CinemaError('bad_input')
    if number!=float(value)or not low<=number<=high:raise CinemaError('bad_input')
    return number

class Commands:
    def __init__(self,store,rooms,catalog):self.store,self.rooms,self.catalog=store,rooms,catalog
    async def execute(self,session,kind,payload,key):
        store,rooms=self.store,self.rooms;code,uid=session.code,session.uid;room=store.room(code);perm=rooms.permissions(room,uid,session.seat)
        if kind in {'play','pause','seek','load','next','previous','stop','metadata'}:require(perm['control'],'control_forbidden')
        if kind in {'settings','notice','seat.lock','member.kick','member.ban','member.mic','member.chat','member.assistant','knock.approve','knock.reject','event'}:require(perm['owner'],'not_owner')
        if kind=='leave':rooms.leave(session);return{'ok':True,'left':True}
        if kind=='ping':rooms.touch(session);return{'ok':True}
        if kind=='mic':
            muted=bool(payload.get('muted',True));require(muted or perm['mic'],'mic_forbidden');session.muted=muted;store.bump(code)
        elif kind=='seat':
            seat=integer(payload.get('seat',-1),-1,room['settings']['seats']-1)
            if seat>=0:
                require(seat not in room['settings']['locks']or perm['owner'],'seat_locked');require(not any(s.id!=session.id and s.seat==seat for s in rooms.peers(session)),'seat_taken',409)
            session.seat=seat
            if seat<0:session.muted=True
            store.bump(code)
        elif kind=='seat.lock':
            seat=integer(payload.get('seat'),0,room['settings']['seats']-1);require(not any(s.seat==seat for s in rooms.peers(session)),'seat_occupied',409);locks=set(room['settings']['locks']);locks.add(seat)if payload.get('locked')else locks.discard(seat);store.update(code,settings={**room['settings'],'locks':sorted(locks)})
        elif kind in {'settings','notice'}:
            change={};settings=dict(room['settings'])
            if kind=='notice'or'notice'in payload:change['notice']=' '.join(str(payload.get('notice')or'').split())[:300]
            if'name'in payload:
                name=' '.join(str(payload['name']).split())[:60];require(name,'name_required',400);change['name']=name
            for k in ['privacy','mic','chat','seats','capacity','approval','share','dim','language','topic','decor','chatAccess']:
                if k not in payload:continue
                value=payload[k]
                if k=='privacy':require(value in {'public','friends','invite'},'bad_input',400)
                elif k=='mic':require(value in {'free','ask','friends'},'bad_input',400)
                elif k=='decor':require(value in {'pamir','valley','redhall','river'},'bad_input',400)
                elif k=='chatAccess':require(value in {'all','friends','owner'},'bad_input',400)
                elif k=='seats':
                    value=integer(value,2,16);require(all(s.seat<value for s in rooms.peers(session)),'seats_occupied',409)
                elif k=='capacity':value=integer(value,0,128);require(value==0 or value>=len(rooms.present(code)),'capacity_occupied',409)
                elif k=='dim':
                    value=float(value);require(math.isfinite(value)and 0<=value<=.85,'bad_input',400)
                elif k in {'chat','approval','share'}:require(type(value)is bool,'bad_input',400)
                else:value=str(value)[:80]
                settings[k]=value
            settings['locks']=[i for i in settings['locks']if i<settings['seats']]
            if settings!=room['settings']:change['settings']=settings
            if change:store.update(code,**change)
        elif kind=='message':
            require(perm['chat'],'chat_forbidden');text=str(payload.get('text')or'').strip();image=str(payload.get('image')or'');require((text or image)and len(text)<=2000,'bad_message',400)
            body={'text':text}
            if image:
                require(image.startswith('/api/app/cinema/v2/photo/'),'bad_image',400);asset=store.one("SELECT *FROM wkc_assets WHERE key=?AND code=?AND uid=?AND kind='chat'",(image.rsplit('/',1)[-1],code,uid));require(asset,'bad_image',400);body['image']=image
            reply=payload.get('reply')
            if reply is not None:
                reply=integer(reply,1,2**63-1);require(store.one('SELECT id FROM wkc_messages WHERE id=?AND code=?AND deleted=0',(reply,code)),'bad_reply',400);body['reply']=reply
            with store.db:store.db.execute("INSERT OR IGNORE INTO wkc_messages(code,uid,kind,body,key,ts)VALUES(?,?,'text',?,?,?)",(code,uid,json.dumps(body),key,store.now()))
            store.bump(code)
        elif kind in {'message.delete','message.edit','message.react'}:
            message=integer(payload.get('id'),1,2**63-1);row=store.one('SELECT *FROM wkc_messages WHERE id=?AND code=?',(message,code));require(row,'message_missing',404)
            if kind=='message.react':
                emoji=str(payload.get('value')or'');require(emoji in {'❤️','😂','👍','😮','😢','🙏',''},'bad_reaction',400)
                with store.db:
                    if emoji:store.db.execute('INSERT INTO wkc_reactions VALUES(?,?,?)ON CONFLICT(message,uid)DO UPDATE SET value=excluded.value',(message,uid,emoji))
                    else:store.db.execute('DELETE FROM wkc_reactions WHERE message=?AND uid=?',(message,uid))
            else:
                require(row['uid']==uid or perm['owner'],'not_message_owner')
                with store.db:
                    if kind=='message.delete':store.db.execute('UPDATE wkc_messages SET deleted=1 WHERE id=?',(message,))
                    else:
                        require(perm['chat'],'chat_forbidden');text=str(payload.get('text')or'').strip();require(0<len(text)<=2000,'bad_message',400);body=json.loads(row['body']);body.update(text=text,edited=True);store.db.execute('UPDATE wkc_messages SET body=?WHERE id=?',(json.dumps(body),message))
            store.bump(code)
        elif kind=='load':
            media=await self.catalog.resolve(payload.get('item')or{},room=code);old=store.playback(code);row=store.one('SELECT history FROM wkc_playback WHERE code=?',(code,));history=json.loads(row['history'])if row else[]
            if old:history.append({k:v for k,v in old.items()if k not in {'source','position','playing','version'}})
            store.set_playback(code,media,playing=True,position=0,history=history[-30:])
        elif kind in {'play','pause','seek'}:
            media=store.playback(code);require(media,'no_media',409);require(payload.get('id')==media['id'],'media_changed',409)
            position=media['position']if kind!='seek'else float(payload.get('position',0));require(math.isfinite(position),'bad_time',400);position=max(0,position)
            if media.get('duration'):position=min(position,media['duration'])
            store.set_playback(code,{k:v for k,v in media.items()if k not in {'version','position','playing'}},playing=kind=='play'or kind=='seek'and media['playing'],position=position)
        elif kind=='metadata':
            media=store.playback(code);require(media and media['id']==payload.get('id'),'media_changed',409);duration=float(payload.get('duration')or 0);require(math.isfinite(duration)and 0<duration<=21600,'bad_duration',400)
            if not media.get('duration'):store.set_playback(code,{**{k:v for k,v in media.items()if k not in {'position','playing','version'}},'duration':duration},playing=media['playing'],position=media['position'])
        elif kind=='stop':store.set_playback(code,None)
        elif kind in {'next','ended','previous'}:
            media=store.playback(code);require(media,'no_media',409)
            if kind=='ended':
                require(payload.get('id')==media['id']and payload.get('cycle')==media.get('cycle',0),'stale_end',409)
                require(media.get('duration')and media['position']>=media['duration']-3,'premature_end',409)
            if kind=='previous':
                row=store.one('SELECT history FROM wkc_playback WHERE code=?',(code,));history=json.loads(row['history'])if row else[];require(history,'no_previous',409);previous=history.pop();resolved=await self.catalog.resolve({'provider':previous['provider'],'id':previous.get('provider_id')or previous['id'],'episode':previous.get('episode'),'version':previous.get('version_id')},room=code);store.set_playback(code,resolved,playing=True,history=history)
            else:
                first=store.one("SELECT *FROM wkc_queue WHERE code=?AND status='approved'ORDER BY position,id LIMIT 1",(code,))
                if first:
                    item=json.loads(first['item']);resolved=await self.catalog.resolve(item,room=code)
                    with store.db:store.db.execute('DELETE FROM wkc_queue WHERE id=?',(first['id'],))
                    row=store.one('SELECT history FROM wkc_playback WHERE code=?',(code,));history=json.loads(row['history'])if row else[];history.append({k:v for k,v in media.items()if k not in {'source','position','playing','version'}});store.set_playback(code,resolved,playing=True,history=history[-30:])
                else:media['cycle']=media.get('cycle',0)+1;store.set_playback(code,{k:v for k,v in media.items()if k not in {'version','position','playing'}},playing=True,position=0)
        elif kind=='queue.add':
            require(perm['share']or perm['control'],'sharing_disabled');require((store.one('SELECT count(*)AS n FROM wkc_queue WHERE code=?',(code,))or{}).get('n',0)<100,'queue_full',409);require(perm['control']or(store.one("SELECT count(*)AS n FROM wkc_queue WHERE code=?AND uid=?AND status='pending'",(code,uid))or{}).get('n',0)<5,'suggestion_limit',409);resolved=await self.catalog.resolve(payload.get('item')or{},room=code);status='approved'if perm['control']else'pending';position=(store.one('SELECT max(position)AS n FROM wkc_queue WHERE code=?',(code,))or{}).get('n')or 0
            item={k:v for k,v in (payload.get('item')or{}).items()if k in {'id','provider','provider_id','episode','version'}};item.update(title=resolved['title'],cover=resolved.get('cover'),duration=resolved.get('duration'))
            with store.db:store.db.execute('INSERT INTO wkc_queue(code,uid,item,status,position,ts)VALUES(?,?,?,?,?,?)',(code,uid,json.dumps(item),status,position+1,store.now()))
            store.bump(code)
        elif kind in {'queue.remove','queue.approve','queue.reject','queue.move','queue.vote'}:
            item_id=integer(payload.get('id'),1,2**63-1);row=store.one('SELECT *FROM wkc_queue WHERE id=?AND code=?',(item_id,code));require(row,'queue_missing',404)
            if kind=='queue.vote':
                with store.db:
                    if payload.get('on',True):store.db.execute('INSERT OR IGNORE INTO wkc_votes VALUES(?,?)',(item_id,uid))
                    else:store.db.execute('DELETE FROM wkc_votes WHERE item=?AND uid=?',(item_id,uid))
            else:
                require(perm['control']or kind=='queue.remove'and row['uid']==uid,'control_forbidden')
                with store.db:
                    if kind in {'queue.remove','queue.reject'}:store.db.execute('DELETE FROM wkc_queue WHERE id=?',(item_id,))
                    elif kind=='queue.approve':store.db.execute("UPDATE wkc_queue SET status='approved'WHERE id=?",(item_id,))
                    else:
                        ordered=store.queue(code);indices=[r['id']for r in ordered];i=indices.index(item_id);j=max(0,min(len(indices)-1,i+integer(payload.get('direction'),-1,1)));indices[i],indices[j]=indices[j],indices[i]
                        for rank,ident in enumerate(indices):store.db.execute('UPDATE wkc_queue SET position=?WHERE id=?',(rank,ident))
            store.bump(code)
        elif kind.startswith('member.'):
            target=integer(payload.get('uid'),1,2**63-1);require(target!=room['owner'],'owner_protected');target_sessions=[s for s in rooms.peers(session)if s.uid==target]
            if kind in {'member.kick','member.ban'}:
                if kind=='member.ban':
                    with store.db:store.db.execute("INSERT OR REPLACE INTO wkc_rules VALUES(?,?,'ban',?)",(code,target,store.now()))
                for s in target_sessions:rooms.leave(s)
            elif kind=='member.assistant':
                with store.db:
                    store.db.execute("UPDATE wkc_members SET role='member'WHERE code=?AND role='assistant'",(code,))
                    if payload.get('on',True):store.db.execute("INSERT INTO wkc_members VALUES(?,?,'assistant','owner',?)ON CONFLICT(code,uid)DO UPDATE SET role='assistant'",(code,target,store.now()))
            elif kind in {'member.mic','member.chat'}:
                rule='mic'if kind=='member.mic'else'chat'
                with store.db:
                    if payload.get('blocked',True):store.db.execute('INSERT OR REPLACE INTO wkc_rules VALUES(?,?,?,?)',(code,target,rule,store.now()))
                    else:
                        store.db.execute('DELETE FROM wkc_rules WHERE code=?AND uid=?AND kind=?',(code,target,rule))
                        if rule=='mic':store.db.execute("INSERT OR REPLACE INTO wkc_rules VALUES(?,?,'mic_grant',?)",(code,target,store.now()))
                if rule=='mic'and payload.get('blocked',True):
                    for s in target_sessions:s.muted=True
            else:raise CinemaError('unknown_command')
            store.bump(code)
        elif kind in {'knock.approve','knock.reject'}:
            target=integer(payload.get('uid'),1,2**63-1)
            with store.db:
                store.db.execute('UPDATE wkc_knocks SET status=?WHERE code=?AND uid=?',('admitted'if kind=='knock.approve'else'rejected',code,target))
                if kind=='knock.approve':store.db.execute("INSERT OR IGNORE INTO wkc_members VALUES(?,?,'member','admit',?)",(code,target,store.now()))
            store.bump(code)
        elif kind=='event':
            with store.db:
                if payload.get('remove'):store.db.execute('DELETE FROM wkc_events WHERE code=?',(code,))
                else:
                    title=str(payload.get('title')or'').strip()[:80];starts=float(payload.get('starts')or 0);require(title and store.now()-3600<=starts<=store.now()+60*86400,'bad_event',400);store.db.execute('INSERT OR REPLACE INTO wkc_events VALUES(?,?,?,?)',(code,title,starts,int(bool(payload.get('remind',True)))))
            store.bump(code)
        else:raise CinemaError('unknown_command')
        return{'ok':True}
