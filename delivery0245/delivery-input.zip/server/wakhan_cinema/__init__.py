from .store import CinemaStore
from .rooms import Rooms
from .service import CinemaService

def install_model(namespace):
    store=CinemaStore(namespace['DB']);store.initialize();rooms=Rooms(store,namespace['WM_COMMUNITY70']);namespace['WKC_STORE']=store;namespace['WKC_ROOMS']=rooms;namespace['WKS_SALON']=rooms
    return rooms

def install(app,namespace):
    rooms=namespace.get('WKC_ROOMS')or install_model(namespace)
    cinema=CinemaService(namespace,store=rooms.store,rooms=rooms);cinema.routes(app);namespace['WKC_CINEMA']=cinema
    return cinema
