"""Transactional Cinema v2 deployment. Original accounts, wallet, games and music remain common services."""
import json,os,shutil,sqlite3,subprocess,tempfile,time,urllib.request,urllib.error,shlex,re,hashlib
from pathlib import Path
from transform_backend import FILES,RETIRE,transform
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(value,code):
 if not value:raise RuntimeError(code)
def verify(live,baseline):
 for name,digest in baseline.items():
  p=live/name;require(p.is_file()and not p.is_symlink()and sha(p)==digest,'CINEMA_BASE_CHANGED:'+name)
def health(fresh):
 with urllib.request.urlopen('http://127.0.0.1:10010/health',timeout=5)as r:require(json.load(r).get('ok')is True,'HEALTH_INVALID')
 for path,wanted in ([('/api/app/cinema/v2/salons',401),('/api/app/cinema/v2/library',401),('/api/c/ABCDEF',404),('/api/cv/ABCDEF/poll',404)]if fresh else[]):
  try:
   with urllib.request.urlopen('http://127.0.0.1:10010'+path,timeout=5)as r:status=r.status
  except urllib.error.HTTPError as e:status=e.code
  require(status==wanted,'CINEMA_ROUTE_HEALTH:'+path)
 for path in ['/api/app/music/chart','/api/app/games/catalog','/api/app/chat/inbox']:
  try:
   with urllib.request.urlopen('http://127.0.0.1:10010'+path,timeout=5)as r:status=r.status
  except urllib.error.HTTPError as e:status=e.code
  require(status==401,'COMMON_ROUTE_HEALTH:'+path)
def configuration():
 raw=subprocess.run(['systemctl','show','wakhan-app.service','-p','ExecStart','--value'],check=True,capture_output=True,text=True).stdout
 match=re.search(r'argv\[\]=([^;]+)',raw);require(match,'SERVICE_COMMAND_UNRECOGNIZED');args=shlex.split(match[1]);require('--config'in args and args,'SERVICE_CONFIG_MISSING');path=Path(args[args.index('--config')+1]);require(path.is_file()and not path.is_symlink(),'SERVICE_CONFIG_INVALID');config=json.loads(path.read_text());python=Path(args[0]);require(python.is_absolute()and python.is_file(),'SERVICE_PYTHON_INVALID');return python,config
def prepare(directory,live,report,copy_atomic):
 baseline=json.loads((directory/'backend-baseline.json').read_text());verify(live,baseline);health(False);require(not(live/'wakhan_cinema').exists(),'CINEMA_V2_ALREADY_PRESENT')
 work=Path(tempfile.mkdtemp(prefix='.wakhan-cinema245-',dir=live));os.chmod(work,0o700);backup=work/'original';backup.mkdir(mode=0o700);candidate=work/'candidate';candidate.mkdir(mode=0o700)
 for path in live.glob('*.py'):
  require(not path.is_symlink(),'BACKEND_SYMLINK:'+path.name)
  if path.name not in RETIRE:shutil.copy2(path,candidate/path.name)
 for package in ['wakhan_games','wakhan_music']:
  root=live/package;require(root.is_dir()and not root.is_symlink(),'COMMON_PACKAGE_MISSING:'+package);shutil.copytree(root,candidate/package,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for name in FILES:
  shutil.copy2(live/name,backup/name);out=transform(name,(live/name).read_text());(candidate/name).write_text(out)
 for name in RETIRE:shutil.copy2(live/name,backup/name)
 shutil.copytree(directory/'server/wakhan_cinema',candidate/'wakhan_cinema',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 python,config=configuration();database=Path(config['database']);require(database.is_file()and not database.is_symlink(),'LIVE_DATABASE_INVALID')
 dbbackup=work/'database.before.sqlite'
 with sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True)as source,sqlite3.connect(dbbackup)as target:source.backup(target);require(target.execute('PRAGMA quick_check').fetchone()[0]=='ok','DB_BACKUP_INVALID')
 os.chmod(dbbackup,0o600);smoke_db=work/'smoke.sqlite';shutil.copy2(dbbackup,smoke_db);smoke={**config,'base':str(candidate),'data':str(work/'smoke-data'),'database':str(smoke_db)};cfg=work/'smoke-config.json';cfg.write_text(json.dumps(smoke));os.chmod(cfg,0o600)
 script=work/'smoke.py';script.write_text('''import asyncio,json,sys\nfrom pathlib import Path\nsys.path.insert(0,str(Path(sys.argv[1])))\nfrom native_runtime import create_app\nasync def main():\n app=create_app(json.loads(Path(sys.argv[2]).read_text()),workers=False);ns=app['wakhan_namespace'];assert ns.get('WKC_CINEMA')and'CIN'not in ns and'CV'not in ns;app.freeze();await app.startup();await app.cleanup()\nasyncio.run(main())\n''')
 result=subprocess.run([str(python),str(script),str(candidate),str(cfg)],cwd=candidate,capture_output=True,timeout=90)
 # Do not expose configuration or arbitrary exception text through the user report.
 if result.returncode:
  (work/'smoke-errors.log').write_bytes(result.stderr);os.chmod(work/'smoke-errors.log',0o600);raise RuntimeError('FRESH_BACKEND_PREFLIGHT_FAILED; log='+str(work/'smoke-errors.log'))
 latest=live/'releases/latest.json';require(not latest.is_symlink(),'LATEST_PATH_INVALID')
 if latest.exists():shutil.copy2(latest,work/'latest.before.json')
 report.update(existing_backend_verified=True,backend_preflight_verified=True,database_backup=str(dbbackup),backend_original_backup=str(backup),retired_backend_modules=list(RETIRE))
 return dict(live=live,work=work,backup=backup,candidate=candidate,baseline=baseline,changed=False,had_latest=latest.exists(),latest_attempted=False,copy_atomic=copy_atomic,database=database)
def start_and_check(fresh):
 subprocess.run(['systemctl','start','wakhan-app.service'],check=True,timeout=45)
 for attempt in range(30):
  try:health(fresh);return
  except(Exception):
   if attempt==29:raise
   time.sleep(.3)
def commit(state,report):
 verify(state['live'],state['baseline']);state['changed']=True;subprocess.run(['systemctl','stop','wakhan-app.service'],check=True,timeout=45)
 live=state['live'];candidate=state['candidate']
 for name in FILES:state['copy_atomic'](candidate/name,live/name)
 for name in RETIRE:
  (live/name).unlink()
  for cache in (live/'__pycache__').glob(Path(name).stem+'.*.pyc'):cache.unlink()
 shutil.copytree(candidate/'wakhan_cinema',live/'wakhan_cinema',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 owner=(live/'native_runtime.py').stat()
 for p in [live/'wakhan_cinema',*(live/'wakhan_cinema').rglob('*')]:os.chown(p,owner.st_uid,owner.st_gid);os.chmod(p,0o755 if p.is_dir()else 0o644)
 start_and_check(True)
 report.update(services_changed=True,database_changed=True,database_changes='Cinema v2 tables added; historical account, wallet, media and salon data retained',cinema_backend_sha256={p.relative_to(live).as_posix():sha(p)for p in(live/'wakhan_cinema').glob('*')if p.is_file()},backend_transformed_sha256={name:sha(live/name)for name in FILES})
def rollback(state,report):
 live=state['live']
 if state.get('changed'):
  subprocess.run(['systemctl','stop','wakhan-app.service'],check=True,timeout=45)
  for name in[*FILES,*RETIRE]:
   target=live/name
   if target.exists():state['copy_atomic'](state['backup']/name,target)
   else:shutil.copy2(state['backup']/name,target)
  fresh=live/'wakhan_cinema'
  if fresh.exists():os.replace(fresh,state['work']/'failed-new-package')
  # New tables may stay unused. Never restore an old DB over concurrent wallet/chat writes.
  start_and_check(False);state['changed']=False;report['backend_rolled_back']=True
 if state.get('latest_attempted'):
  target=live/'releases/latest.json'
  if state['had_latest']:
   if target.exists():state['copy_atomic'](state['work']/'latest.before.json',target)
   else:shutil.copy2(state['work']/'latest.before.json',target)
  elif target.exists():target.unlink()
  state['latest_attempted']=False;report['latest_rolled_back']=True
