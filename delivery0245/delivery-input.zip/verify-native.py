"""Compare both native payloads with the exact reviewed Cinema v2 source."""
import hashlib,json,plistlib,sys,zipfile
from pathlib import Path
root=Path(sys.argv[1])if len(sys.argv)>1 else Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
source_path=root/'Wakhan-0.2.45-source.zip'
with zipfile.ZipFile(source_path)as src:
 assert src.testzip()is None
 manifest=json.loads(src.read('source-verification.json'))
 assert manifest['version']=='0.2.45-beta'and manifest['build']==60 and manifest['server_update_required']is True
 for name,digest in manifest['source_sha256'].items():assert sha(src.read('project/'+name))==digest,name
 for name,digest in manifest['backend_sha256'].items():assert sha(src.read(name))==digest,name
 assert len(manifest['deleted_files'])==22
 result=dict(version='0.2.45-beta',build=60,source_sha256=sha(source_path.read_bytes()),server_update_required=True,physical_device_verified=False)
 for platform,filename in [('android','app-release-unsigned.apk'),('ios','Wakhan-0.2.45-beta.ipa')]:
  with zipfile.ZipFile(root/filename)as z:
   assert z.testzip()is None
   if platform=='ios':
    info=next(n for n in z.namelist()if n.count('/')==2 and n.endswith('.app/Info.plist'));v=plistlib.loads(z.read(info));base=info.rsplit('/',1)[0];prefix=base+'/'
    assert v['CFBundleIdentifier']=='app.wakhan.music'and v['CFBundleShortVersionString']=='0.2.45'and str(v['CFBundleVersion'])=='60'
    binary=z.read(base+'/'+v['CFBundleExecutable'])
    for marker in (b'CinemaSession',b'/api/app/cinema/v2/room/events',b'wakhanKeyboardFrame',b'WakhanDownloadsPlugin',b'IdleTimerDisabled'):assert marker in binary,(platform,marker)
    assert 'audio'in v.get('UIBackgroundModes',[])
   else:
    prefix='assets/';binary=b''.join(z.read(n)for n in z.namelist()if n.endswith('.dex'))
    for marker in (b'CinemaSession',b'/api/app/cinema/v2/room/events',b'WakhanDownloads'):assert marker in binary,(platform,marker)
   assert b'room-sync'not in binary
   release=json.loads(z.read(prefix+'public/wakhan-release.json'));assert release['version']=='0.2.45-beta'and release['build']==60 and release['server_update_required']is True
   for name,digest in manifest['source_sha256'].items():
    if name.startswith('public/')and name not in('public/build-flags.json','public/wakhan-release.json'):assert sha(z.read(prefix+name))==digest,(platform,name)
   js=b''.join(z.read(n)for n in z.namelist()if n.startswith(prefix+'public/assets/index-')and n.endswith('.js'))
   for marker in(b'/api/app/cinema/v2/',b'wk-cinema-floating',b'wakhan-cinema-state',b'wakhan-music-v1',b'wakhan-games-v1'):assert marker in js,(platform,marker)
   for marker in(b'room-sync',b'wm-cinema-v2',b'SLR3'):assert marker not in js,(platform,marker)
   result[platform+'_assets_match_source']=True
 result['sha256']={name:sha((root/name).read_bytes())for name in('app-release-unsigned.apk','app-release.aab','Wakhan-0.2.45-beta.ipa')}
(root/'native-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
