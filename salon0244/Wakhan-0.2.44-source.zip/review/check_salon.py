async def exercise_salon(page,out,engine):
 await page.route('https://music.kabulcafe.uk/api/app/rooms/REVIEW/video*',lambda r:r.fulfill(path=str(out/'salon-fixture.mp4'),content_type='video/mp4'))
 await page.evaluate('''()=>{
 window.__salonSaved={api,vcLeave};window.__salonCalls=[];window.__voiceLeaves=0;window.__notice='';window.__own=true;window.__favorite=false;window.__allowMic=true;
 window.__media=()=>({kind:'native',provider:'youtube',formats:[{url:'/api/app/rooms/REVIEW/video?vid=aaaaaaaaaaa&lease=review'}]});
 window.__serverRoom={ok:true,room:'REVIEW',_cid:'REVIEW',vid:'',playing:false,t:0,ver:10,timeline_revision:1,mine:0,can:true,owner:1,seats:[{id:1,name:'Test'},null,null,null,null,null,null,null]};
 window.__gameID='a'.repeat(32);window.__game=()=>({ok:true,id:__gameID,game:'ludo',version:1,status:'waiting',count:1,minimum:2,maximum:4,can_start:false,host:1,seat:0,public:false,server_time:Date.now()/1000,members:[{id:1,name:'Test',seat:0,host:true,online:true}],origin:{code:'REVIEW',name:'Review'}});
 window.__hall=()=>({code:'REVIEW',owner_id:1,is_owner:__own,name:'Review',notice:__notice,locks:[],can:{mic:__allowMic,chat:true},muted:[]});
 api=async(path,body)=>{
 const p=String(path).split('?')[0];__salonCalls.push({path:String(path),body});
 if(p==='/api/c/REVIEW'){if(body){if(body.a==='leave')return {ok:true};if(['play','pause','seek'].includes(body.a)){__serverRoom={...__serverRoom,t:body.t,playing:body.a==='seek'?__serverRoom.playing:body.a==='play',ver:__serverRoom.ver+1,timeline_revision:__serverRoom.timeline_revision+1};}}return structuredClone(__serverRoom)}
 if(p==='/api/app/salon/screen'){__serverRoom={...__serverRoom,vid:'',media:null,playing:false,t:0,ver:__serverRoom.ver+1,timeline_revision:__serverRoom.timeline_revision+1};return {ok:true}}
 if(p==='/api/v51/hall'){if(body){if(!__own)return {ok:false,err:'owner'};__notice=String(body.notice||'').trim().slice(0,300)}return {ok:true,hall:__hall()}}
 if(p==='/api/app/salon/room')return {ok:true,code:'REVIEW',name:'Review',is_owner:__own,owner:{id:1,name:'Test'},bg:'',dim:0};
 if(p==='/api/app/salon/profile')return {ok:true,profile:{code:'REVIEW',name:'Review',is_owner:__own,owner:{id:1,name:'Test'},seats:8,seated:1,present:1,members_preview:[],privacy:'public',mic:'free',chat:true}};
 if(p==='/api/app/rooms')return {ok:true,halls:[{code:'REVIEW',name:'Review',favorite:__favorite}]};
 if(p==='/api/app/rooms/favorite'){__favorite=body.favorite;return {ok:true}}
 if(p==='/api/app/salon/home')return {ok:true,mine:null,followed:__favorite?[{code:'REVIEW',name:'Review'}]:[],joined:[],recent:[]};
 if(p==='/api/app/games/home')return {ok:true,server_time:Date.now()/1000,invites:[],one_needed:[],resume:{id:__gameID,version:1}};
 if(p==='/api/app/games/create'||p==='/api/app/games/'+__gameID||p==='/api/app/games/'+__gameID+'/action')return __game();
 if(p==='/api/app/cinema/yt/search')return {ok:true,items:[{id:'bbbbbbbbbbb',title:'نتیجهٔ یوتیوب',ch:'Review',thumb:'https://art-review.invalid/yt.svg',dur:60}]};
 if(p==='/api/app/cinema/search')return {ok:true,items:[]};
 if(p==='/api/v70/hall')return {ok:true,messages:[],cursor:0};
 return __salonSaved.api(path,body);
 };
 go('c');CID='REVIEW';CV='hall';CG.token='review';CS=structuredClone(__serverRoom);CVER=10;rCinema();
 window.__voiceContext=new AudioContext();const stream=__voiceContext.createMediaStreamDestination().stream;window.__voiceTrack=stream.getAudioTracks()[0];VC.stream=stream;SX.mic=stream;SX.micJob=null;SX.micBusy=false;VC.on=true;VC.cid='REVIEW';VC.mute=false;VC.members=[{id:1,mute:false}];
 vcLeave=function(){console.log("REVIEW_VOICE_LEAVE",new Error().stack);__voiceLeaves++;__voiceTrack.stop();VC.on=false};
 }''')
 await page.locator('.slr').wait_for()
 # The actual announcement button opens a working owner editor, escaped when pinned.
 await page.locator('.slr [data-a=notice]').click()
 field=page.locator('.wk-salon-notice textarea');await field.wait_for();await field.fill('اعلان آزمایشی <img src=x>')
 await page.locator('.wk-salon-notice [data-save]').click();await page.wait_for_function("!document.querySelector('.wk-salon-notice')")
 assert 'اعلان آزمایشی' in await page.locator('.r-pinned').inner_text();assert await page.locator('.r-pinned img').count()==0
 await page.evaluate('''async()=>{__own=false;await WakhanSalonNotice.load()}''')
 await page.locator('.r-pinned').click();assert await page.locator('.wk-salon-notice textarea').count()==0;await page.locator('.wk-salon-notice [data-close]').click()
 # Follow is an icon-only explicit action with durable server state.
 await page.locator('.slr [data-a=salon]').click();follow=page.locator('.s8-follow');await follow.wait_for();await page.wait_for_function("!document.querySelector('.s8-follow').disabled")
 assert (await follow.inner_text()).strip()=='';assert await follow.get_attribute('aria-pressed')=='false';await follow.click();await page.wait_for_function("document.querySelector('.s8-follow')?.getAttribute('aria-pressed')==='true'")
 await page.locator('.s8-pf [data-x=back]').click();await page.locator('.s8-pf').wait_for(state='detached')
 # A current YouTube lease stays native; it must not be erased or target a hidden player.
 await page.evaluate('''()=>{__serverRoom={...__serverRoom,vid:'aaaaaaaaaaa',media:__media(),playing:true,t:5,ver:20,timeline_revision:2};cinSet(structuredClone(__serverRoom))}''')
 video=page.locator('.slr video.r-nv');await video.wait_for();await page.wait_for_function("document.querySelector('.slr video.r-nv').readyState>=1",timeout=10000)
 assert await page.evaluate("CS.media?.kind==='native'&&CS.media.provider==='youtube'")
 await page.locator('.slr .r-ctl [data-a=pp]').click(force=True)
 try:await page.wait_for_function('!CS.playing',timeout=2500)
 except:
  print('PAUSE DEBUG',await page.evaluate("({state:CS,can:SLR3.k.canCtl(),calls:__salonCalls.slice(-14),cPlay:String(cPlay),typing:SLR3.k.root().className})"),flush=True);raise
 assert await video.evaluate('v=>v.paused')
 await page.locator('.slr .r-ctl [data-a=pp]').click(force=True);await page.wait_for_function('CS.playing')
 # Fullscreen IME is rooted in the physical viewport, outside the rotated stage.
 await page.locator('.slr .r-ctl [data-a=fs]').click(force=True);await page.set_viewport_size({'width':852,'height':393});await page.wait_for_timeout(80)
 await page.locator('.slr .r-fbot [data-a=fchat]').click(force=True)
 geometry=[]
 for platform in ['ios','android']:
  await page.evaluate("p=>{document.documentElement.classList.remove('wk-ios','wk-android');document.documentElement.classList.add('wk-'+p)}",platform)
  if platform=='android':await page.set_viewport_size({'width':852,'height':223})
  await page.evaluate("window.dispatchEvent(new CustomEvent('wakhanKeyboardFrame',{detail:{overlap:170,duration:0,curve:0}}))")
  await page.wait_for_timeout(80)
  box=await page.locator('.slr>.r-fin').evaluate('e=>({bottom:e.getBoundingClientRect().bottom,rotatedParent:!!e.parentElement.closest(".r-stw")})');assert not box['rotatedParent'];assert 190<=box['bottom']<=224,(platform,box);geometry.append({'platform':platform,**box})
 await page.evaluate("SLR3.k.root().querySelector('.r-fbot [data-a=fs]').click();window.dispatchEvent(new CustomEvent('wakhanKeyboardFrame',{detail:{overlap:0,duration:0,curve:0}}))")
 await page.set_viewport_size({'width':393,'height':852});await page.locator('.slr .r-bb input').focus();await page.set_viewport_size({'width':393,'height':500});await page.wait_for_timeout(180)
 bar=await page.locator('.slr .r-bb').bounding_box();assert 480<=bar['y']+bar['height']<=500,bar
 await page.locator('.slr .r-bb input').evaluate('e=>e.blur()');await page.set_viewport_size({'width':393,'height':852});await page.wait_for_timeout(150)
 # Stop clears only media: real stream track stays live and no voice leave is called.
 await page.evaluate('WakhanSalonMedia.stop()');await page.wait_for_function("!CS.vid")
 voice=await page.evaluate("({live:__voiceTrack.readyState==='live',enabled:__voiceTrack.enabled,on:VC.on,leaves:__voiceLeaves,mine:CS.mine})");assert voice=={'live':True,'enabled':True,'on':True,'leaves':0,'mine':0},voice
 # Opening/creating/resuming/acting in a game must not mute or leave the salon.
 await page.evaluate("WakhanGames.openCatalog({origin:'REVIEW'})");await page.wait_for_function("TAB==='h'");await page.locator('.wk-games-frame').wait_for()
 await page.evaluate("async()=>{await WakhanGames.rpc('create',{game:'ludo'});await WakhanGames.openMatch(__gameID,{origin:'REVIEW'});await WakhanGames.rpc('action',{match:__gameID,version:1,action:{type:'recruit',on:true}})}")
 voice2=await page.evaluate("({live:__voiceTrack.readyState==='live',enabled:__voiceTrack.enabled,on:VC.on,leaves:__voiceLeaves})");assert voice2=={'live':True,'enabled':True,'on':True,'leaves':0},voice2
 game=page.frame_locator('.wk-games-frame');mic=game.locator('.voice button[aria-label="میکروفون سالون"]');await mic.wait_for(timeout=10000)
 await mic.click();await page.wait_for_function('VC.mute');assert await page.evaluate("__voiceTrack.readyState==='live'&&!__voiceTrack.enabled")
 await page.evaluate("()=>{__allowMic=false;H2.state.info={...__hall(),can:{mic:false,chat:true}};H2.state.infoAt=Date.now()}")
 await mic.click();await page.wait_for_timeout(180);assert await page.evaluate('VC.mute&&!__voiceTrack.enabled')
 await page.evaluate('__allowMic=true')
 await mic.click()
 try:await page.wait_for_function('!VC.mute',timeout=2500)
 except:
  print('GAME MIC DEBUG',await page.evaluate("({muted:VC.mute,on:VC.on,enabled:__voiceTrack.enabled,tab:TAB,cv:CV,leaves:__voiceLeaves,voice:document.querySelector('.wk-games-frame').contentDocument.querySelector('.voice')?.textContent,calls:__salonCalls.slice(-16)})"),flush=True);raise
 assert await page.evaluate('__voiceTrack.enabled')
 speaker=game.locator('.voice button').filter(has_text='صدا روشن');await speaker.click();await page.wait_for_function('SX.speaker===false');assert await page.evaluate('SLR3.k.deaf()')
 await game.locator('.voice button').filter(has_text='صدا خاموش').click();await page.wait_for_function('SX.speaker===true')
 # The normal Cinema tab is the list; only the mini-card opens the active salon.
 await page.locator('#nav [data-wk-tab=c]').click();await page.wait_for_function("TAB==='c'&&CV==='lobby'");await page.locator('.sl').wait_for();assert await page.evaluate("__voiceTrack.readyState==='live'&&VC.on")
 await page.locator('.s9-card [data-c=open]').click(force=True);await page.locator('.slr').wait_for();await page.wait_for_function("!SLR9.card()");assert await page.locator('.s9-card:visible').count()==0
 # Returning via the game's Back action also removes the redundant mini-card.
 await page.evaluate("WakhanGames.openMatch(__gameID,{origin:'REVIEW'})");await game.locator('header .back').click();await page.locator('.slr').wait_for();await page.wait_for_function("!SLR9.card()")
 assert await page.evaluate("__voiceLeaves===0&&__voiceTrack.readyState==='live'"),await page.evaluate("({leaves:__voiceLeaves,track:__voiceTrack.readyState,tab:TAB,cv:CV,cs:CS,calls:__salonCalls.slice(-15)})")
 await page.screenshot(path=str(out/(engine+'-salon-return.png')))
 # Cinema Home YouTube searches now use the YouTube API and show actual results.
 await page.evaluate('WakhanCinema.open()');await page.locator('.sl [data-x=top][data-t=home]').click();await page.locator('.sl [data-x=hsrc][data-s=youtube]').click();await page.locator('.sl [data-x=search]').click()
 await page.locator('.sl input[data-k=dq]').fill('شفیق مرید');await page.locator('.sl input[data-k=dq]').press('Enter');await page.locator('.sl .yv').wait_for();assert 'نتیجهٔ یوتیوب' in await page.locator('.sl .sl-body').inner_text()
 assert await page.evaluate("__salonCalls.some(x=>x.path.startsWith('/api/app/cinema/yt/search?q='))")
 await page.screenshot(path=str(out/(engine+'-cinema-youtube-search.png')))
 await page.evaluate('''()=>{api=__salonSaved.api;vcLeave=__salonSaved.vcLeave;__voiceTrack.stop();__voiceContext.close();VC.on=false;VC.stream=null;SX.mic=null;SLR3.unmount();CID='';CS=null;CV='lobby';go('h')}''')
 return dict(actual_slr3=True,announcement_saved_and_pinned=True,announcement_guest_readonly=True,follow_icon_only=True,follow_persisted=True,native_youtube_not_erased=True,pause_controls_visible_player=True,fullscreen_keyboard=geometry,android_composer_above_keyboard=True,media_stop_preserves_live_voice=True,game_actions_preserve_voice=True,game_mic_controls_salon=True,cinema_tab_opens_list=True,mini_removed_on_card_and_game_return=True,youtube_search_uses_youtube_endpoint=True,physical_device=False,live_provider_network=False)
