async def exercise_sources(page,out,engine):
 await page.evaluate(r'''()=>{
  const all=[];window.__testPlayers=all;
  class Player{constructor(node,o){this.o=o;this.frame=document.createElement('iframe');this.frame.src='about:blank';this.frame.title='YouTube';node.replaceWith(this.frame);this.t=0;this.d=180;all.push(this);setTimeout(()=>o.events.onReady({target:this}),0)}getIframe(){return this.frame}playVideo(){this.o.events.onStateChange({data:1})}pauseVideo(){this.o.events.onStateChange({data:2})}getCurrentTime(){return this.t}getDuration(){return this.d}seekTo(t){this.t=t}destroy(){this.frame.remove()}finish(){this.o.events.onStateChange({data:0})}}
  Object.defineProperty(window,'YT',{configurable:true,value:{Player}});
  const sc=[];window.__testSC=sc;
  function Widget(frame){const handlers={};const w={bind(k,fn){handlers[k]=fn;if(k==='ready')setTimeout(fn,0)},play(){handlers.play?.()},pause(){handlers.pause?.()},getDuration(fn){fn(180000)},seekTo(t){handlers.progress?.({currentPosition:t})},finish(){handlers.finish?.()}};sc.push(w);return w}Widget.Events={READY:'ready',PLAY:'play',PAUSE:'pause',PLAY_PROGRESS:'progress',FINISH:'finish',ERROR:'error'};window.SC={Widget};
 }''')
 await page.evaluate("go('p')")
 await page.locator('#wk-music [data-action=search]').click()
 await page.locator('#wk-music input[type=search]').fill('external review')
 await page.locator('#wk-music .search-form').evaluate('e=>e.requestSubmit()')
 await page.locator('#wk-music [data-track="yt.abcdefghijk"]').wait_for()
 assert await page.locator('#wk-music [data-track^="sc."]').count()==1
 await page.locator('#wk-music [data-track="yt.abcdefghijk"] [data-action=play]').click()
 await page.wait_for_function('__testPlayers.length===1')
 await page.wait_for_timeout(100)
 dock=page.locator('#wk-music .embed-dock');assert await dock.is_visible();assert (await dock.bounding_box())['height']>=200
 assert await page.locator('#wk-music [data-action=current-download]').count()==0
 await page.evaluate('window.__testFrame=document.querySelector("#wk-music").shadowRoot.querySelector(".embed-dock iframe")')
 # Pausing, opening queue, back to player: same iframe must remain alive, no reparent/reload.
 await page.locator('#wk-music [data-action=queue]').click()
 await page.locator('#wk-music [data-action=back]').click()
 # queue back is Home, reopen via mini.
 await page.locator('#wk-music .mini [data-action=player]').click()
 assert await page.evaluate('__testFrame===document.querySelector("#wk-music").shadowRoot.querySelector(".embed-dock iframe")')
 await page.locator('#wk-music .controls [data-action=toggle]').click()
 # Ended twice must advance exactly once into SoundCloud, not skip two tracks.
 await page.evaluate('__testPlayers[0].finish();__testPlayers[0].finish()')
 await page.wait_for_function('__testSC.length===1')
 await page.wait_for_timeout(100)
 assert await dock.is_visible();assert (await dock.locator('iframe').get_attribute('src')).startswith('https://w.soundcloud.com/player/')
 await page.evaluate("go('h')")
 assert not await dock.is_visible()
 await page.evaluate("go('p')")
 assert await page.locator('#wk-music .page').get_attribute('data-view')=='home'
 assert await page.locator('#wk-music .page').evaluate('e=>e.scrollTop')<2
 await page.screenshot(path=str(out/(engine+'-music-approved.png')))
 await page.evaluate('WakhanMusicUI.stop()')
 return dict(unified_youtube_soundcloud_search=True,official_visible_players=True,minimum_embed_height=200,embed_identity_survives_draw=True,duplicate_ended_advanced_once=True,embed_pauses_on_exit=True,top_on_return=True,live_provider_network=False)
