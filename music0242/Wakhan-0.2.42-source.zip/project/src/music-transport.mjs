/* Official visible embeds and direct audio share one queue, never two ended owners. */
export function createMusicTransport({direct,dock,visible=()=>true,youtube=loadYouTube,soundcloud=loadSoundCloud}){
 const events=new EventTarget(),forward=new Map();let external=false,player=null,frame=null,epoch=0,dead=false,time=0,duration=0,paused=true,ended=false,ready=false,track=null,readyTask=null,deadline=0;
 const emit=name=>events.dispatchEvent(new Event(name));
 const destroy=()=>{clearTimeout(deadline);try{player?.pauseVideo?.();player?.pause?.();player?.destroy?.()}catch{}player=null;frame=null;dock.replaceChildren();ready=false};
 for(const name of ['play','pause','timeupdate','durationchange','waiting','canplay','ended','error']){const fn=()=>{if(!external)emit(name)};direct.addEventListener(name,fn);forward.set(name,fn)}
 function live(n){return !dead&&external&&epoch===n}
 function state(n,on){if(!live(n))return;if(on&&!visible()){try{player?.pauseVideo?.();player?.pause?.()}catch{}on=false}const changed=paused===on;paused=!on;if(changed)emit(on?'play':'pause')}
 function finish(n){if(!live(n)||ended)return;ended=true;paused=true;emit('ended')}
 async function prepare(t,position=0,playing=true){
  const n=++epoch;destroy();direct.pause();external=!!t.embed;track=t;time=position;duration=Number(t.duration)||0;paused=true;ended=false;if(!external)return true;deadline=setTimeout(()=>{if(live(n)&&!ready)emit('error')},20000);
  readyTask=(async()=>{
   if(t.provider==='youtube'){
    const id=/^yt\.([\w-]{11})$/.exec(t.id)?.[1];if(!id)throw Error('track');const YT=await youtube();if(!live(n))return false;
    const node=document.createElement('div');dock.append(node);
    player=new YT.Player(node,{videoId:id,playerVars:{controls:1,playsinline:1,rel:0,autoplay:playing&&visible()?1:0},events:{onReady:e=>{if(!live(n))return;ready=true;frame=e.target.getIframe();if(position)e.target.seekTo(position,true);if(playing&&visible())e.target.playVideo();else e.target.pauseVideo();emit('canplay')},onStateChange:e=>{if(!live(n))return;if(e.data===1){ended=false;state(n,true)}else if(e.data===2||e.data===5)state(n,false);else if(e.data===0)finish(n);else if(e.data===3)emit('waiting')},onAutoplayBlocked:()=>{if(live(n)){state(n,false);emit('pause')}},onError:()=>{if(live(n)){state(n,false);emit('error')}}}});frame=player.getIframe?.();
   }else if(t.provider==='soundcloud'){
    const u=new URL(t.source_url);if(u.protocol!=='https:'||u.hostname!=='soundcloud.com'||!/^\/[\w-]+\/[\w-]+$/.test(u.pathname))throw Error('track');
    const SC=await soundcloud();if(!live(n))return false;frame=document.createElement('iframe');frame.title='SoundCloud';frame.allow='autoplay';frame.src='https://w.soundcloud.com/player/?'+new URLSearchParams({url:u.href,auto_play:playing&&visible()?'true':'false',show_artwork:'true',visual:'true'});dock.append(frame);player=SC.Widget(frame);
    const bind=(key,fn)=>player.bind(SC.Widget.Events[key],x=>{if(live(n))fn(x)});
    bind('READY',()=>{ready=true;player.getDuration(ms=>{if(live(n)){duration=ms/1000;emit('durationchange')}});if(position)player.seekTo(position*1000);if(playing&&visible())player.play();else player.pause();emit('canplay')});bind('PLAY',()=>{ended=false;state(n,true)});bind('PAUSE',()=>state(n,false));bind('PLAY_PROGRESS',x=>{time=x.currentPosition/1000;emit('timeupdate')});bind('FINISH',()=>finish(n));bind('ERROR',()=>{state(n,false);emit('error')});
   }else throw Error('provider');return true;
  })();return readyTask;
 }
 const tick=setInterval(()=>{if(!external||!ready||track?.provider!=='youtube')return;const t=Number(player?.getCurrentTime?.()),d=Number(player?.getDuration?.());if(Number.isFinite(t))time=t;if(d>0&&d!==duration){duration=d;emit('durationchange')}emit('timeupdate')},500);
 const api={addEventListener:(...a)=>events.addEventListener(...a),removeEventListener:(...a)=>events.removeEventListener(...a),get paused(){return external?paused:direct.paused},get ended(){return external?ended:direct.ended},get readyState(){return external?(ready?1:0):direct.readyState},get currentTime(){return external?time:direct.currentTime},set currentTime(v){if(!external){direct.currentTime=v;return}time=Number(v)||0;if(track.provider==='youtube')player?.seekTo?.(time,true);else player?.seekTo?.(time*1000);emit('timeupdate')},get duration(){return external?duration:direct.duration},async play(){if(!external)return direct.play();if(!visible())throw Error('visible_player_required');await readyTask;if(!ready) return;ended=false;if(track.provider==='youtube')player?.playVideo?.();else player?.play?.()},pause(){if(!external)return direct.pause();if(paused)return;try{if(track?.provider==='youtube')player?.pauseVideo?.();else player?.pause?.()}catch{}state(epoch,false)},prepare,visibility(){if(external&&!visible())api.pause()},dispose(){dead=true;++epoch;clearInterval(tick);destroy();for(const [name,fn]of forward)direct.removeEventListener(name,fn)}};return api;
}
const scripts=new Map();
function loadScript(url,check){if(check())return Promise.resolve(check());if(scripts.has(url))return scripts.get(url);const task=new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=url;script.async=true;let timer,interval;const done=(err)=>{clearTimeout(timer);clearInterval(interval);if(err){script.remove();reject(err)}else resolve(check())};script.onerror=()=>done(Error('player_unavailable'));interval=setInterval(()=>{if(check())done()},50);timer=setTimeout(()=>done(Error('player_timeout')),15000);document.head.append(script)});scripts.set(url,task);task.catch(()=>scripts.delete(url));return task}
export const loadYouTube=()=>loadScript('https://www.youtube.com/iframe_api',()=>window.YT?.Player?window.YT:null);
export const loadSoundCloud=()=>loadScript('https://w.soundcloud.com/player/api.js',()=>window.SC?.Widget?window.SC:null);
