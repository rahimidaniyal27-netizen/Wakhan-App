import {installMusic} from './music-controller.mjs';
import {installNativeMusic} from './native-music.mjs';
import {installMediaSession} from './media-session.mjs';
export function offlineEligible(broker,error=null){return !!(broker.valid(broker.session)&&broker.session.origin===broker.origin&&(!error||error.code==='net'))}
/* A local-only surface for this vault session. Never unlocks online account APIs. */
export function openOfflineMusic({broker,platform,native,musicPlugin,audioSession,downloads,convertFileSrc,getInsets,reconnect=()=>location.reload()}){
 if(!offlineEligible(broker))throw Error('offline_session_required');
 document.body.replaceChildren();document.body.className='';document.documentElement.dir='rtl';
 const style=document.createElement('style');style.textContent='body{--bg:#0f0a1d;--txt:#f7f1fc;background:var(--bg);color:var(--txt)}#wk-offline-connect{position:fixed;left:16px;right:16px;bottom:calc(10px + env(safe-area-inset-bottom,0px));z-index:51;text-align:center}#wk-offline-connect button{font:14px Tahoma;color:#e7dbff;background:#58466d66;border:1px solid #e9dfff45;border-radius:25px;width:100%;min-height:52px;backdrop-filter:blur(12px)}';document.head.append(style);
 const connect=document.createElement('nav');connect.id='wk-offline-connect';const retry=document.createElement('button');retry.type='button';retry.textContent='اتصال دوباره';retry.onclick=reconnect;connect.append(retry);document.body.append(connect);
 const element=document.createElement('audio');element.preload='metadata';document.body.append(element);
 const engine=installNativeMusic({player:musicPlugin,enabled:native&&platform==='android',origin:broker.origin}),audio=engine.wrap(element);window.WakhanNativeMusic=engine;
 window.WakhanPlayback=installMediaSession({session:audioSession,enabled:native&&!!audioSession});
 let go=()=>{},draw=()=>{},generation=0;
 const ui=installMusic({request:async()=>{throw Error('offline')},getUid:()=>broker.session.user.id,getRoute:()=> 'p',navigate:()=>{},audio,initialView:'downloads',offlineMode:true,reconnect,downloadPlugin:downloads,convertFileSrc,getInsets,claim:()=>{++generation},release:()=>{++generation},prepare:async(t,position,playing)=>{
  const token=++generation;
  if(native&&platform==='android')return engine.prepare({src:t.nativeSource||t.stream,title:t.title,artist:t.artist},position,playing,token);
  return new Promise(resolve=>{const done=ok=>{clearTimeout(timer);audio.removeEventListener('loadedmetadata',ready);audio.removeEventListener('error',fail);resolve(ok)},fail=()=>done(false),ready=async()=>{if(token!==generation)return done(false);try{audio.currentTime=position;if(playing)await audio.play();done(true)}catch{done(false)}};const timer=setTimeout(fail,20000);audio.addEventListener('loadedmetadata',ready,{once:true});audio.addEventListener('error',fail,{once:true});audio.src=t.stream;audio.load()});
 },hooks:{getGo:()=>go,setGo:fn=>go=fn,getPlayer:()=>draw,setPlayer:fn=>draw=fn}});
 const size=async()=>{try{const v=await getInsets?.();if(v&&v.width>0&&v.bottom>=0&&v.bottom*innerWidth/v.width<innerHeight/2)connect.style.bottom=(10+v.bottom*innerWidth/v.width)+'px'}catch{}};void size();window.addEventListener('resize',size);
 const online=()=>reconnect();window.addEventListener('online',online);window.WakhanMusicUI=ui;requestAnimationFrame(()=>window.WakhanIntroReady?.());
 const dispose=ui.dispose;ui.dispose=()=>{window.removeEventListener('online',online);window.removeEventListener('resize',size);dispose();void engine.shutdown();void window.WakhanPlayback?.shutdown?.();element.remove();connect.remove();style.remove()};return ui;
}
