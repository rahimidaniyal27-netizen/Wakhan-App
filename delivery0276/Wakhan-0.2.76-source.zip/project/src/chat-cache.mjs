// A Telegram-like copy of recent chats kept on this phone (IndexedDB): the last messages of each conversation, its header
// (name, photo, wallpaper) and the pictures in it. A chat that was opened before opens at once from this copy, and the
// server's answer then only brings what is new. Everything is per account and is wiped on logout.
const NAME='wakhan-chat-cache',VERSION=1,MSGS=50,THREADS=40,MEDIA=300,MEDIA_MAX=3_000_000;

function openDb(){
 return new Promise(resolve=>{
  try{
   if(typeof indexedDB==='undefined')return resolve(null);
   const r=indexedDB.open(NAME,VERSION);
   r.onupgradeneeded=()=>{const d=r.result;for(const s of ['threads','media','meta'])if(!d.objectStoreNames.contains(s))d.createObjectStore(s);};
   r.onsuccess=()=>resolve(r.result);r.onerror=()=>resolve(null);r.onblocked=()=>resolve(null);
  }catch(e){resolve(null);}
 });
}

export function createChatCache(getUid){
 let dbp=null;const db=()=>dbp||(dbp=openDb());
 const uid=()=>String(getUid?.()||'');
 const k=key=>uid()+'|'+key;
 const run=async(store,mode,fn)=>{const d=await db();if(!d)return null;return new Promise(resolve=>{try{const t=d.transaction(store,mode),s=t.objectStore(store);let out=null;const r=fn(s);if(r&&'onsuccess' in r)r.onsuccess=()=>{out=r.result};t.oncomplete=()=>resolve(out??null);t.onerror=t.onabort=()=>resolve(null);}catch(e){resolve(null);}});};
 const timers=new Map();
 // a list of keys in the order they were last used, to drop the oldest when there are too many (one update at a time)
 let queue=Promise.resolve();
 const touch=(...a)=>(queue=queue.then(()=>touchNow(...a)).catch(()=>{}));
 async function touchNow(list,key,max,store){
  const order=(await run('meta','readonly',s=>s.get(list)))||[];const i=order.indexOf(key);if(i>=0)order.splice(i,1);order.push(key);
  const drop=order.length>max?order.splice(0,order.length-max):[];
  await run('meta','readwrite',s=>s.put(order,list));
  if(drop.length)await run(store,'readwrite',s=>{for(const d of drop)s.delete(d);return null;});
 }
 return {
  async thread(key){if(!uid())return null;const v=await run('threads','readonly',s=>s.get(k(key)));return v&&Array.isArray(v.messages)?v:null;},
  saveThread(key,data,messages,cursor){
   if(!uid())return;const id=k(key);clearTimeout(timers.get(id));
   // written a moment later, so a burst of polls costs one write
   timers.set(id,setTimeout(async()=>{timers.delete(id);
    try{const clean={...(data||{})};delete clean.messages;delete clean.changed;delete clean.removed;delete clean.typing;
     const rows=(messages||[]).filter(m=>m&&m.id>0).slice(-MSGS);
     await run('threads','readwrite',s=>s.put({at:Date.now(),data:clean,messages:rows,cursor:cursor||0},id));await touch(uid()+'|threads',id,THREADS,'threads');}catch(e){}
   },1200));
  },
  async media(path){if(!uid())return null;const v=await run('media','readonly',s=>s.get(k(path)));return v instanceof Blob?v:null;},
  async saveMedia(path,blob){if(!uid()||!(blob instanceof Blob)||!blob.size||blob.size>MEDIA_MAX)return;const id=k(path);
   try{await run('media','readwrite',s=>s.put(blob,id));await touch(uid()+'|media',id,MEDIA,'media');}catch(e){}},
  async wipe(){for(const t of timers.values())clearTimeout(t);timers.clear();try{const d=await db();d?.close();}catch(e){}dbp=null;
   await new Promise(resolve=>{try{const r=indexedDB.deleteDatabase(NAME);r.onsuccess=r.onerror=r.onblocked=()=>resolve();}catch(e){resolve();}});},
 };
}
