import sys,json,sqlite3,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'deployment'))
from preserve_salon_data import migrate
class Preserve(unittest.TestCase):
 def setUp(self):
  self.db=sqlite3.connect(':memory:')
  for name,columns in json.loads((ROOT/'review/legacy-schema.json').read_text()).items():
   parts=['"'+r['name']+'" '+(r.get('type')or'TEXT')for r in columns];pk=sorted((r for r in columns if r.get('pk')),key=lambda r:r['pk'])
   if pk:parts.append('PRIMARY KEY('+','.join('"'+r['name']+'"'for r in pk)+')')
   self.db.execute('CREATE TABLE "'+name+'"('+','.join(parts)+')')
  self.db.execute('CREATE UNIQUE INDEX message_client ON wm70_room_messages(sender,client_key)')
  self.db.executescript((ROOT/'review/cinema245-schema.sql').read_text());self.db.execute('CREATE TABLE wallet(uid INTEGER PRIMARY KEY,balance INTEGER)');self.db.execute('INSERT INTO wallet VALUES(1,12345)')
  settings=dict(privacy='friends',mic='free',chatAccess='friends',chat=True,seats=12,capacity=25,dim=.4,decor='river',locks=[0,3],photo='/api/app/cinema/v2/photo/abcdefgh12345678.jpg')
  self.db.execute('INSERT INTO wkc_rooms(code,owner,name,notice,settings,personal,ts)VALUES(?,?,?,?,?,?,?)',('ROOM01',1,'نام فعلی','اعلان فعلی',json.dumps(settings),1,1))
  self.db.execute("INSERT INTO wkc_follows VALUES(2,'ROOM01',10)");self.db.execute("INSERT INTO wkc_members VALUES('ROOM01',3,'assistant','invite',10)");self.db.execute("INSERT INTO wkc_rules VALUES('ROOM01',4,'chat',10)")
  self.db.execute("INSERT INTO wkc_messages(code,uid,kind,body,key,ts)VALUES('ROOM01',2,'text',?, 'one',20)",(json.dumps({'text':'پیام جدید'}),))
  self.db.execute("INSERT INTO wkc_events VALUES('ROOM01','فیلم',30,1)")
  self.db.execute("INSERT INTO wkc_history VALUES(2,'one',?,12,20)",(json.dumps({'provider':'archive','provider_id':'movie','episode':'S1E1','duration':120}),));self.db.commit()
 def tearDown(self):self.db.close()
 def test_current_state_reaches_original_interface(self):
  migrate(self.db);hall=dict(self.db.execute('SELECT *FROM wm51_halls').fetchone());self.assertEqual(hall['name'],'نام فعلی');self.assertEqual(hall['notice'],'اعلان فعلی');self.assertEqual(hall['locks'],'0,3');self.assertEqual(hall['enter'],'friends');self.assertEqual(hall['chat'],'friends');self.assertEqual(self.db.execute('SELECT uid FROM room_hosts').fetchone()[0],3);self.assertEqual(self.db.execute('SELECT uid FROM wks_chatban').fetchone()[0],4)
 def test_personal_salon_settings_win_over_historical_rooms(self):
  self.db.execute("INSERT INTO wkc_rooms(code,owner,name,settings,personal,ts)VALUES('OLD999',1,'Old room','{}',0,999)");self.db.commit();migrate(self.db);self.assertEqual(self.db.execute('SELECT name FROM wm51_halls WHERE uid=1').fetchone()[0],'نام فعلی')
 def test_no_wallet_or_cinema_v2_data_removed(self):
  before=self.db.execute('SELECT *FROM wkc_messages').fetchall();migrate(self.db);self.assertEqual(self.db.execute('SELECT balance FROM wallet').fetchone()[0],12345);self.assertEqual([tuple(r)for r in self.db.execute('SELECT *FROM wkc_messages')],before)
 def test_repeated_migration_does_not_duplicate_messages(self):
  migrate(self.db);migrate(self.db);self.assertEqual(self.db.execute('SELECT count(*)FROM wm70_room_messages').fetchone()[0],1)
 def test_playback_progress_is_preserved(self):
  migrate(self.db);self.assertEqual(tuple(self.db.execute('SELECT tid,ep,pos,dur FROM wks_progress').fetchone()),('movie','S1E1',12,120))
 def test_latest_existing_progress_wins(self):
  self.db.execute("INSERT INTO wks_progress VALUES(2,'movie','S1E1',99,120,9999999999)");self.db.commit();migrate(self.db);self.assertEqual(self.db.execute('SELECT pos FROM wks_progress').fetchone()[0],99)
if __name__=='__main__':unittest.main()
