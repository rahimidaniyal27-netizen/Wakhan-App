"""Restore the prior salon interface's data projections without rewinding the DB."""
import json,re,time
from pathlib import Path

def migrate(db):
 db.row_factory=__import__('sqlite3').Row
 tables={r[0]for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
 def rows(name):return [dict(r)for r in db.execute('SELECT *FROM '+name)]if name in tables else[]
 def up(table,data,keys):
  names=list(data);sql='INSERT INTO '+table+'('+','.join('"'+n+'"'for n in names)+')VALUES('+','.join('?'for n in names)+')ON CONFLICT('+','.join('"'+n+'"'for n in keys)+')DO UPDATE SET '+','.join('"'+n+'"=excluded."'+n+'"'for n in names if n not in keys)
  db.execute(sql,list(data.values()))
 now=int(time.time());rooms=rows('wkc_rooms');bycode={r['code']:r for r in rooms};counts={'salons':0,'messages':0,'progress':0}
 with db:
  for room in rooms:
   code=room['code'];owner=room['owner'];s=json.loads(room['settings']);decor=s.get('decor')or'pamir'
   db.execute('INSERT OR IGNORE INTO rooms(code,owner,ts)VALUES(?,?,?)',(code,owner,room['ts']))
   if room['personal']:
    previous=db.execute('SELECT code FROM wm_personal_cinemas WHERE uid=?',(owner,)).fetchone()
    if previous and previous[0]!=code:db.execute('INSERT OR IGNORE INTO wm_cinema_code_history VALUES(?,?)',(previous[0],owner))
    up('wm_personal_cinemas',dict(uid=owner,code=code,name=room['name'],created_at=int(room['ts'])),['uid'])
   def photo(value):
    m=re.fullmatch(r'/api/app/cinema/v2/photo/([A-Za-z0-9_-]+\.(?:jpg|jpeg|png|webp))',str(value or''));return m[1]if m else''
   # The original hall schema stores profile/background images as image keys.
   old=db.execute('SELECT *FROM wm51_halls WHERE uid=?',(owner,)).fetchone()
   hall=dict(old)if old else dict(uid=owner,name='',photo='',ts=now,notice='',enter='all',mic='all',chat='all',bg='pamir',clear_id=0,bgphoto='',locks='')
   hall.update(name=room['name'],notice=room['notice'],photo=photo(s.get('photo'))or hall.get('photo',''),bgphoto=photo(s.get('background'))or hall.get('bgphoto',''),ts=now,enter={'public':'all','friends':'friends','invite':'closed'}.get(s.get('privacy'),'all'),mic={'free':'all','friends':'friends','ask':'owner'}.get(s.get('mic'),'owner'),chat=s.get('chatAccess')or('all'if s.get('chat')else'owner'),bg=decor,locks=','.join(str(x)for x in s.get('locks',[])))
   up('wm51_halls',hall,['uid']);up('wka_room_layout',dict(code=code,seats=s.get('seats',8),background=decor),['code'])
   up('wks_salon',dict(code=code,decor=decor,cap=s.get('capacity',0),ts=now,dim=s.get('dim',.25),approval=int(bool(s.get('approval'))),share=int(bool(s.get('share',True)))),['code'])
   up('wka_room_meta',dict(code=code,language=s.get('language')or'fa',topic=s.get('topic')or'',event_title='',starts=0),['code']);counts['salons']+=1
   for table in ['wka_room_favorites','wks_members','wks_chatban','room_hosts']:
    db.execute('DELETE FROM '+table+' WHERE code=?',(code,))
   db.execute('DELETE FROM wm51_bans WHERE owner=?',(owner,))
  for source,target,keys,columns in [('wkc_follows','wka_room_favorites',['uid','code'],['uid','code','ts']),('wkc_visits','wm51_visits',['uid','code'],['uid','code','ts']),('wkc_members','wks_members',['code','uid'],['code','uid','via','ts']),('wkc_knocks','wks_knocks',['code','uid'],['code','uid','status','ts'])]:
   for row in rows(source):
    if row['code']in bycode:up(target,{k:row[k]for k in columns},keys)
  for member in rows('wkc_members'):
   if member['code']in bycode and member['role']=='assistant':db.execute('INSERT OR IGNORE INTO room_hosts VALUES(?,?)',(member['code'],member['uid']))
  for rule in rows('wkc_rules'):
   if rule['code']not in bycode:continue
   if rule['kind']=='chat':up('wks_chatban',{k:rule[k]for k in ['code','uid','ts']},['code','uid'])
   else:up('wm51_bans',dict(owner=bycode[rule['code']]['owner'],uid=rule['uid'],kind='mute'if rule['kind']=='mic'else'ban',ts=rule['ts']),['owner','uid','kind'])
  for event in rows('wkc_events'):
   if event['code']in bycode:up('wks_events',dict(code=event['code'],title=event['title'],ts=event['starts'],remind=event['remind'],made=now),['code'])
  for msg in rows('wkc_messages'):
   if msg['deleted']or msg['code']not in bycode:continue
   body=json.loads(msg['body']);text=body.get('text','');detail=json.dumps(body,ensure_ascii=False)
   result=db.execute('INSERT OR IGNORE INTO wm70_room_messages(room,sender,text,kind,detail,client_key,ts)VALUES(?,?,?,?,?,?,?)',(msg['code'],msg['uid'],text,msg['kind'],detail,'cinema245:'+str(msg['id']),int(msg['ts'])))
   counts['messages']+=result.rowcount
  for progress in rows('wkc_history'):
   media=json.loads(progress['media'])
   if media.get('provider')!='archive':continue
   tid=media.get('provider_id');ep=media.get('episode')or''
   if not tid:continue
   old=db.execute('SELECT ts FROM wks_progress WHERE uid=?AND tid=?AND ep=?',(progress['uid'],tid,ep)).fetchone()
   if old and old[0]>progress['ts']:continue
   up('wks_progress',dict(uid=progress['uid'],tid=tid,ep=ep,pos=progress['position'],dur=media.get('duration')or 0,ts=int(progress['ts'])),['uid','tid','ep']);counts['progress']+=1
 return counts

def image_copies(db,base,data):
 """Return validated source/target pairs; copy only images changed in build60."""
 pairs=[]
 for row in db.execute('SELECT key FROM wkc_assets WHERE kind IN(\'photo\',\'background\')'):
  key=row[0]
  if not re.fullmatch(r'[A-Za-z0-9_-]{8,120}\.(?:jpg|jpeg|png|webp)',key):continue
  source=Path(data)/'cinema-v2'/key;target=Path(base)/'data/wm51_halls'/key
  if source.is_file()and not source.is_symlink()and source.stat().st_size<=6_000_000:pairs.append((source,target))
 return pairs
