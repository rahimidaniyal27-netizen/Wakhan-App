"""Guarded restoration of the exact previous Cinema controllers and current data."""
import json,os,shutil,sqlite3,subprocess,tempfile,time,urllib.request,urllib.error,shlex,re,hashlib
from pathlib import Path
from preserve_salon_data import migrate,image_copies
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(value,code):
 if not value:raise RuntimeError(code)
def verify(live,files):
 for name,digest in files.items():
  p=live/name;require(p.is_file()and not p.is_symlink()and sha(p)==digest,'RESTORE_SOURCE_CHANGED:'+name)
def health():
 with urllib.request.urlopen('http://127.0.0.1:10010/health',timeout=5)as r:require(json.load(r).get('ok')is True,'HEALTH_INVALID')
 for path in ['/api/app/music/chart','/api/app/games/catalog','/api/app/chat/inbox','/api/app/salon/home']:
  try:
   with urllib.request.urlopen('http://127.0.0.1:10010'+path,timeout=5)as r:status=r.status
  except urllib.error.HTTPError as e:status=e.code
  require(status==401,'RESTORED_ROUTE_HEALTH:'+path)
def configuration():
 raw=subprocess.run(['systemctl','show','wakhan-app.service','-p','ExecStart','--value'],check=True,capture_output=True,text=True).stdout
 m=re.search(r'argv\[\]=([^;]+)',raw);require(m,'SERVICE_COMMAND_UNRECOGNIZED');args=shlex.split(m[1]);require('--config'in args,'SERVICE_CONFIG_MISSING');path=Path(args[args.index('--config')+1]);require(path.is_file()and not path.is_symlink(),'SERVICE_CONFIG_INVALID');return Path(args[0]),json.loads(path.read_text())
def prepare(directory,live,report,copy_atomic):
 baseline=json.loads((directory/'restore-baseline.json').read_text());verify(live,baseline['current']);original=Path(baseline['original_backup']);require(original.is_dir()and not original.is_symlink(),'ORIGINAL_BACKUP_MISSING');verify(original,baseline['original'])
 work=Path(tempfile.mkdtemp(prefix='.wakhan-restore246-',dir=live));os.chmod(work,0o700);candidate=work/'candidate';candidate.mkdir();backup=work/'current';backup.mkdir(mode=0o700)
 for p in live.glob('*.py'):
  require(not p.is_symlink(),'SERVER_SYMLINK');shutil.copy2(p,candidate/p.name)
 for package in ['wakhan_games','wakhan_music']:shutil.copytree(live/package,candidate/package,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for name in baseline['original']:
  if(live/name).exists():shutil.copy2(live/name,backup/name)
  shutil.copy2(original/name,candidate/name)
 python,config=configuration();database=Path(config['database']);require(database.is_file()and not database.is_symlink(),'DATABASE_INVALID');dbbackup=work/'database.before.sqlite'
 with sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True)as source,sqlite3.connect(dbbackup)as target:source.backup(target);require(target.execute('PRAGMA quick_check').fetchone()[0]=='ok','DB_BACKUP_INVALID')
 os.chmod(dbbackup,0o600);smoke_db=work/'smoke.sqlite';shutil.copy2(dbbackup,smoke_db)
 with sqlite3.connect(smoke_db)as db:migrate(db)
 cfg=work/'smoke-config.json';cfg.write_text(json.dumps({**config,'base':str(candidate),'data':str(work/'smoke-data'),'database':str(smoke_db)}));os.chmod(cfg,0o600)
 script=work/'smoke.py';script.write_text('import asyncio,json,sys\nfrom pathlib import Path\nsys.path.insert(0,sys.argv[1])\nfrom native_runtime import create_app\nasync def main():\n app=create_app(json.loads(Path(sys.argv[2]).read_text()),workers=False);ns=app["wakhan_namespace"];assert "CIN"in ns and"CV"in ns and"WKC_CINEMA"not in ns;app.freeze();await app.startup();await app.cleanup()\nasyncio.run(main())\n')
 result=subprocess.run([str(python),str(script),str(candidate),str(cfg)],cwd=candidate,capture_output=True,timeout=90)
 if result.returncode:
  log=work/'preflight-errors.log';log.write_bytes(result.stderr);os.chmod(log,0o600);raise RuntimeError('RESTORE_PREFLIGHT_FAILED; log='+str(log))
 latest=live/'releases/latest.json';require(not latest.is_symlink(),'LATEST_PATH_INVALID')
 if latest.exists():shutil.copy2(latest,work/'latest.before.json')
 report.update(existing_backend_verified=True,backend_preflight_verified=True,database_backup=str(dbbackup),backend_original_backup=str(original),backend_current_backup=str(backup))
 return dict(live=live,work=work,candidate=candidate,backup=backup,baseline=baseline,database=database,config=config,changed=False,had_latest=latest.exists(),latest_attempted=False,copy_atomic=copy_atomic)
def start_check():
 subprocess.run(['systemctl','start','wakhan-app.service'],check=True,timeout=45)
 for n in range(30):
  try:health();return
  except Exception:
   if n==29:raise
   time.sleep(.3)
def install_file(state,source,target):
 if target.exists():state['copy_atomic'](source,target)
 else:
  owner=(state['live']/'native_runtime.py').stat();fd,tmp=tempfile.mkstemp(prefix='.restore-',dir=target.parent)
  with os.fdopen(fd,'wb')as out:out.write(source.read_bytes());out.flush();os.fsync(out.fileno());os.fchmod(out.fileno(),0o644);os.fchown(out.fileno(),owner.st_uid,owner.st_gid)
  os.replace(tmp,target)
def commit(state,report):
 verify(state['live'],state['baseline']['current']);state['changed']=True;subprocess.run(['systemctl','stop','wakhan-app.service'],check=True,timeout=45)
 for name in state['baseline']['original']:install_file(state,state['candidate']/name,state['live']/name)
 # Synchronize only salon projections in the current DB. Never restore an old DB.
 with sqlite3.connect(state['database'])as db:
  copies=image_copies(db,state['live'],state['config']['data']);counts=migrate(db)
 for source,target in copies:
  target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():require(not target.is_symlink()and sha(target)==sha(source),'PHOTO_COLLISION')
  else:install_file(state,source,target)
 start_check();report.update(restored_backend_sha256={n:sha(state['live']/n)for n in state['baseline']['original']},data_preservation=counts,services_changed=True,database_changed=True,database_changes='Current salon settings, follows, messages and progress projected to prior interface; all Cinema v2 tables retained; no database rollback')
def rollback(state,report):
 live=state['live']
 if state.get('changed'):
  subprocess.run(['systemctl','stop','wakhan-app.service'],check=True,timeout=45)
  for name in state['baseline']['original']:
   source=state['backup']/name;target=live/name
   if source.exists():install_file(state,source,target)
   else:target.unlink(missing_ok=True)
  subprocess.run(['systemctl','start','wakhan-app.service'],check=True,timeout=45);state['changed']=False;report['backend_rolled_back']=True
 if state.get('latest_attempted'):
  target=live/'releases/latest.json'
  if state['had_latest']:install_file(state,state['work']/'latest.before.json',target)
  else:target.unlink(missing_ok=True)
  state['latest_attempted']=False;report['latest_rolled_back']=True
