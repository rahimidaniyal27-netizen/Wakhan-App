async def exercise_navigation(page,delay_chart,chart_calls):
 await page.evaluate("go('p')")
 await page.wait_for_function("document.querySelector('#wk-music').shadowRoot.querySelectorAll('.track').length===50")
 await page.wait_for_timeout(100)
 await page.evaluate("window.__retainedMusic=document.querySelector('#wk-music').shadowRoot.querySelector('.track');document.querySelector('#wk-music').shadowRoot.querySelector('.page').scrollTop=300;go('h')")
 before=chart_calls();delay_chart(.8)
 value=await page.evaluate("""async()=>{
 const start=performance.now(),writes=WakhanPages.stats.writes,skips=WakhanPages.stats.externalRenders;document.querySelector('#nav').shadowRoot.querySelector('[data-wk-tab=p]').click();
 const handler=performance.now()-start;await new Promise(requestAnimationFrame);
 const root=document.querySelector('#wk-music').shadowRoot,view=root.querySelector('.page');
 return {handler,frame:performance.now()-start,retained:root.querySelector('.track')===__retainedMusic,top:view.scrollTop===0,selected:document.querySelector('#nav').shadowRoot.querySelector('[data-wk-tab=p]').getAttribute('aria-current'),legacyRenderWrites:WakhanPages.stats.writes-writes,externalRenderSkips:WakhanPages.stats.externalRenders-skips,animations:[...view.getAnimations(),...document.getElementById('view').getAnimations()].length}
 }""")
 assert value['retained']and value['top']and value['selected']=='page',value
 assert value['legacyRenderWrites']==0 and value['externalRenderSkips']==1 and value['animations']==0,value
 await page.wait_for_timeout(120);assert chart_calls()>before
 await page.wait_for_timeout(850);delay_chart(0)
 assert await page.evaluate("document.querySelector('#wk-music').shadowRoot.querySelector('.track')===__retainedMusic"),'unchanged refresh rebuilt the music rows'
 # Cached views show immediately even when a subsequent refresh is slow.
 inset_calls=await page.evaluate('__nativeInsetsCalls');metrics=[]
 for tab in ['m','h','c','d','p','h','m','p']:
  sample=await page.evaluate("""async tab=>{const start=performance.now();go(tab);const handler=performance.now()-start;await new Promise(requestAnimationFrame);return {tab,handler,frame:performance.now()-start}}""",tab);metrics.append(sample);await page.wait_for_timeout(30)
 assert await page.evaluate('__nativeInsetsCalls')==inset_calls,'tab entry repeated the native geometry request'
 await page.evaluate("window.dispatchEvent(new Event('resize'))");await page.wait_for_function(f'__nativeInsetsCalls>{inset_calls}')
 assert await page.evaluate('__nativeInsetsCalls')==inset_calls+1,'resize requests were not coalesced'
 return dict(native_insets_reused=True,native_insets_refresh_on_resize=True,retained_music_nodes=True,refresh_independent_of_tab_paint=True,refresh_after_entry=True,unchanged_chart_does_not_rebuild=True,no_full_page_blur_animation=True,no_retired_music_renderer=True,scroll_reset=True,delayed_chart_ms=800,metrics=metrics,physical_device=False)
