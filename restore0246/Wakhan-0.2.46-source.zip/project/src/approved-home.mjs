import {createRankFeed} from './home-rank-feed.mjs';
/* Approved Home only. Existing shell programs, media and chat renderers stay intact. */
export function installApprovedHome({getRoute,getView,getUid,request,fetchBinary,origin,assetOrigin,navigate,openWallet,openChat,openSalon,openPeople,notice,bars,hooks,closeTools=()=>{},getInsets=()=>null}){
 const nativeHomeURL=new URL('/home-ui/index.html',assetOrigin).href;
 const nonce=Array.from(crypto.getRandomValues(new Uint8Array(18)),v=>v.toString(16).padStart(2,'0')).join('');
 const state={frame:null,user:null,busy:false,last:0,command:null,homeView:'home',hasRanks:false,rankingData:null,gamesData:null,insetSequence:0,disposed:false,snapshot:{balance:null,friends:[],salons:[],loading:true,error:false},photos:new Map()};
 const style=document.createElement('style');style.dataset.wakhanApprovedHome='';style.textContent=`
 body.wk-approved-home{overflow:hidden!important;background:#0f0a1d!important}
 body.wk-approved-home>header{display:none!important}
 body.wk-approved-home #view{position:fixed!important;inset:0!important;width:auto!important;max-width:none!important;min-height:0!important;max-height:none!important;height:auto!important;padding:0!important;margin:0!important;overflow:hidden!important;transform:none!important}
 body.wk-approved-home #view>[data-wk-page-active]{display:block;height:100%}
 body.wk-approved-home #view iframe.wk-approved-home-frame{display:block!important;width:100%!important;height:100%!important;min-height:0!important;max-height:none!important;max-width:none!important;position:static!important;transform:none!important;border:0!important;opacity:1!important;background:#0f0a1d;color-scheme:dark}
 `;document.head.append(style);
 const insetProbe=document.createElement('i');insetProbe.setAttribute('aria-hidden','true');insetProbe.style.cssText='position:fixed;visibility:hidden;pointer-events:none;width:0;height:0;padding:var(--wk-home-safe-top,var(--wk-safe-top,env(safe-area-inset-top,0px))) var(--wk-home-safe-right,env(safe-area-inset-right,0px)) var(--wk-home-safe-bottom,var(--wk-safe-bottom,env(safe-area-inset-bottom,0px))) var(--wk-home-safe-left,env(safe-area-inset-left,0px));';document.body.append(insetProbe);
 function insets(){const css=getComputedStyle(insetProbe);return Object.fromEntries(['top','right','bottom','left'].map(side=>[side,Math.max(0,parseFloat(css.getPropertyValue('padding-'+side))||0)]));}
 function postInsets(){post({type:'insets',data:insets()});}
 function visible(){const on=getRoute()==='h';document.body.classList.toggle('wk-approved-home',on);if(state.visible!==on){state.visible=on;bars?.(on);}return on;}
 // Keep the scroll canvas behind the bars. Only the child's initial padding
 // and controls consume safe insets; scrolling content may pass behind the clock.
 async function syncInsets(){
  if(state.disposed||getRoute()!=='h')return;const sequence=++state.insetSequence;
  try{
   const value=await getInsets();
   if(state.disposed||sequence!==state.insetSequence||getRoute()!=='h'||!value)return;
   const sides=['top','right','bottom','left'];
   if(!Number.isFinite(value.width)||value.width<=0||sides.some(side=>!Number.isFinite(value[side])||value[side]<0))return;
   const scale=innerWidth/value.width;if(scale<.25||scale>4)return;
   const insets=Object.fromEntries(sides.map(side=>[side,value[side]*scale]));
   if(insets.top+insets.bottom>=innerHeight||insets.left+insets.right>=innerWidth)return;
   for(const side of sides)document.documentElement.style.setProperty('--wk-home-safe-'+side,insets[side]+'px');
   postInsets();
  }catch{} // CSS safe-area values remain the fallback for older native binaries.
 }
 function post(value){state.frame?.contentWindow?.postMessage({channel:'wakhan-home-r17',nonce,...value},'*');}
 function resetUser(uid){if(state.user===uid)return;state.user=uid;for(const p of state.photos.values())URL.revokeObjectURL(p.url);state.photos.clear();state.snapshot={balance:null,friends:[],salons:[],loading:true,error:false};state.last=0;state.gamesData=null;post({type:'games-home',data:null});state.hasRanks=false;state.rankingData=null;rankFeed?.invalidate();post({type:'snapshot',data:state.snapshot});}
 async function photo(person,viewer){
  if(!person.avatar)return null;
  let address;try{address=new URL(person.avatar,origin);if(address.origin!==new URL(origin).origin)return null;}catch{return null;}
  const prior=state.photos.get(String(person.id));if(prior?.source===address.href)return prior.url;
  const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),8000);
  try{const response=await fetchBinary(address.href,{signal:abort.signal});if(!response.ok)return null;const blob=await response.blob();if(viewer!==state.user||viewer!==Number(getUid())||!blob.type.startsWith('image/')||blob.size>3*1024*1024)return null;const url=URL.createObjectURL(blob);if(prior)URL.revokeObjectURL(prior.url);state.photos.set(String(person.id),{source:address.href,url});while(state.photos.size>128){const [key,value]=state.photos.entries().next().value;URL.revokeObjectURL(value.url);state.photos.delete(key);}return url;}catch{return null;}finally{clearTimeout(timer);}
 }
 async function refresh(force=false){
  if(!visible()||document.visibilityState==='hidden')return;
  const uid=Number(getUid());if(!Number.isSafeInteger(uid)||uid<=0)return;resetUser(uid);if(state.busy||!force&&Date.now()-state.last<8000)return;
  state.busy=true;state.last=Date.now();
  try{
   const values=await Promise.allSettled([request('/api/wallet'),request('/api/app/chat/people'),request('/api/app/salon/home')]);
   if(uid!==Number(getUid()))return;
   const [wallet,people,salons]=values.map(v=>v.status==='fulfilled'&&v.value?.ok?v.value:null);
   if(wallet&&Number.isFinite(Number(wallet.balance))&&Number(wallet.balance)>=0)state.snapshot.balance=Number(wallet.balance);
   if(people){
    const online=(people.items||[]).filter(p=>Number.isSafeInteger(Number(p.id))&&Number(p.id)>0&&p.online===true).slice(0,12);
    const photos=await Promise.all(online.map(p=>photo(p,uid)));
    if(uid!==Number(getUid()))return;
    state.snapshot.friends=online.map((p,i)=>({id:String(p.id),name:String(p.name||'کاربر').slice(0,80),full:String(p.name||'کاربر').slice(0,80),photo:photos[i],online:true}));

   }
   if(salons&&!state.hasRanks){const seen=new Set();let rooms=[salons.mine,...salons.followed||[],...salons.joined||[],...salons.recent||[]].filter(Boolean);if(!rooms.length){try{const discover=await request('/api/app/salon/discover?f=all');if(discover?.ok)rooms=discover.items||[];}catch{}}
    state.snapshot.salons=await salonRows(rooms.filter(p=>p.code&&!seen.has(String(p.code))&&seen.add(String(p.code))).sort((a,b)=>(Number(b.live)||0)-(Number(a.live)||0)||String(a.code).localeCompare(String(b.code))),uid);
   }
   state.snapshot.loading=false;state.snapshot.error=!wallet||!people||!salons;post({type:'snapshot',data:state.snapshot});
  }finally{state.busy=false;}
 }
 async function salonRows(rooms,uid){
  return Promise.all((Array.isArray(rooms)?rooms:[]).filter(r=>typeof r.code==='string'&&r.code.length<=80).slice(0,4).map(async r=>({code:r.code,name:String(r.name||'سالون').slice(0,80),live:Math.max(0,Number(r.live)||0),status:String(r.status||'idle'),topic:String(r.topic||'').slice(0,120),photo:await photo({id:'salon:'+r.code,avatar:r.photo},uid)})));
 }
 const rankFeed=createRankFeed({request,getIdentity:()=>Number(getUid()),isVisible:()=>!state.disposed&&getRoute()==='h'&&!document.hidden&&['home','ranking'].includes(state.homeView),onData:async result=>{
  const uid=Number(getUid());resetUser(uid);
  const clean=async p=>{if(!p||!Number.isSafeInteger(Number(p.id))||Number(p.id)<=0||!Number.isFinite(p.score)||p.score<0)return null;return {id:String(p.id),name:String(p.name||'کاربر').slice(0,80),score:p.score,position:Number.isSafeInteger(p.position)&&p.position>0?p.position:null,own:p.own===true,photo:await photo(p,uid)};};
  const items=(await Promise.all(result.items.slice(0,50).map(clean))).filter(Boolean);
  const me=await clean(result.me),salons=await salonRows(result.salons,uid);
  if(state.disposed||uid!==Number(getUid()))return;
  state.hasRanks=true;state.snapshot.salons=salons;post({type:'salons',data:salons});
  state.rankingData={category:result.category,period:result.period,start:result.start,available:result.available===true,rule:String(result.rule||'').slice(0,800),items,me};post({type:'rankings',data:state.rankingData});
 },onError:()=>post({type:'rankings-error'})});
 function mount(){
  if(!visible())return;const pane=getView();
  if(!state.frame?.isConnected){void syncInsets();const frame=document.createElement('iframe');frame.className='wk-approved-home-frame';frame.title='خانهٔ واخان';frame.src=nativeHomeURL+'#'+new URLSearchParams({bridge:nonce,...Object.fromEntries(Object.entries(insets()).map(([k,v])=>['safe-'+k,String(v)]))});frame.setAttribute('allow','');frame.onload=()=>{postInsets();post({type:'snapshot',data:state.snapshot});if(state.command)post(state.command);};pane.replaceChildren(frame);state.frame=frame;}
  void refresh();void rankFeed.tick();
 }
 function routeHome(){mount();state.command={type:'route',view:'home',origin:'home'};post(state.command);}
 function openGamesFromSalon(){closeTools();let code=null;try{code=String(window.SLR3?.k?.cid?.()||'')||null}catch{}window.WakhanGames?.openCatalog({origin:code});}
 const receive=event=>{
  const msg=event.data;if(event.source!==state.frame?.contentWindow||msg?.channel!=='wakhan-home-r17'||msg.nonce!==nonce)return;
  if(msg.type==='ready'){if(state.gamesData)post({type:'games-home',data:state.gamesData});postInsets();post({type:'snapshot',data:state.snapshot});if(state.rankingData)post({type:'rankings',data:state.rankingData});if(state.command)post(state.command);void refresh();return;}
  if(getRoute()!=='h')return;
  if(msg.type==='game'){const id=String(msg.game||'');if(['patpal','bazaar','fiskot','ludo','chess','ono'].includes(id))window.WakhanGames?.open(id,{origin:null});return;}
  if(msg.type==='game-match'){const id=String(msg.match||'');if(state.gamesData?.resume?.id===id||state.gamesData?.one_needed?.some(p=>p.id===id))void window.WakhanGames?.openMatch(id,{join:state.gamesData?.resume?.id!==id});return;}
  if(msg.type==='games-catalog'){window.WakhanGames?.openCatalog();return;}
  if(msg.type==='game-invites'){window.WakhanGames?.openInvites();return;}
  if(msg.type==='game-invite'){const id=String(msg.invite||'');if(state.gamesData?.invites?.some(p=>p.id===id))void window.WakhanGames?.replyInvite(id,msg.accept===true).catch(()=>post({type:'notice',text:'دعوت دیگر معتبر نیست؛ فهرست تازه می‌شود.'}));return;}
  if(msg.type==='navigation-chrome'){state.homeView=String(msg.view||'home');window.WakhanNavigation?.setHomeState(state.homeView,msg.blocked===true);if(['home','ranking'].includes(state.homeView))rankFeed.select(state.homeView==='home'?'overall':msg.category,state.homeView==='home'?'month':msg.period);return;}
  if(msg.type==='refresh'){void refresh(true);void rankFeed.tick(true);return;}
  if(msg.type==='navigate'){const routes={music:'p',cinema:'c',chats:'d',account:'m'};if(routes[msg.route])navigate(routes[msg.route]);return;}
  if(msg.type==='wallet'){void openWallet();return;}
  if(msg.type==='people'){openPeople();return;}
  if(msg.type==='dm'){const uid=Number(msg.uid);if(Number.isSafeInteger(uid)&&state.snapshot.friends.some(p=>Number(p.id)===uid))openChat(uid);return;}
  if(msg.type==='salon'){const code=String(msg.code||'');if(state.snapshot.salons.some(p=>p.code===code))void openSalon(code);return;}
  if(msg.type==='salons'){navigate('c');return;}
 };
 window.addEventListener('message',receive);
 const originalHome=hooks.getHome(),replacementHome=function(){mount();};hooks.setHome(replacementHome);
 const previousGo=hooks.getGo(),replacementGo=function(...args){visibleBefore(args[0]);const result=previousGo.apply(this,args);visible();if(getRoute()==='h')routeHome();return result;};hooks.setGo(replacementGo);
 function visibleBefore(tab){if(tab!=='h')document.body.classList.remove('wk-approved-home');}
 const salonGames=event=>{if(getRoute()!=='c')return;const b=event.target?.closest?.('.wkr-tabs button[data-tab="game"],[data-wakhan-games]');if(!b)return;event.preventDefault();event.stopImmediatePropagation();openGamesFromSalon();};
 document.addEventListener('click',salonGames,true);
 const resume=()=>{if(document.visibilityState==='visible'){void syncInsets();void refresh();void rankFeed.tick(true);}};document.addEventListener('visibilitychange',resume);
 window.addEventListener('resize',syncInsets);window.addEventListener('orientationchange',syncInsets);
 const timer=setInterval(()=>{if(getRoute()==='h')void refresh();},20000);
 if(getRoute()==='h')mount();
 return {mount,refresh,syncInsets,onRoute(){visibleBefore(getRoute());visible();if(getRoute()==='h')routeHome()},setGamesData(data){state.gamesData=data;post({type:'games-home',data});},openGamesFromSalon,openGame(id,entry='home'){if(entry==='salon')openGamesFromSalon();else window.WakhanGames?.open(id);},dispose(){state.disposed=true;rankFeed.dispose();++state.insetSequence;clearInterval(timer);window.removeEventListener('message',receive);window.removeEventListener('resize',syncInsets);window.removeEventListener('orientationchange',syncInsets);document.removeEventListener('click',salonGames,true);document.removeEventListener('visibilitychange',resume);style.remove();insetProbe.remove();for(const side of ['top','right','bottom','left'])document.documentElement.style.removeProperty('--wk-home-safe-'+side);for(const p of state.photos.values())URL.revokeObjectURL(p.url);state.photos.clear();if(hooks.getHome()===replacementHome)hooks.setHome(originalHome);if(hooks.getGo()===replacementGo)hooks.setGo(previousGo);document.body.classList.remove('wk-approved-home');}};
}
