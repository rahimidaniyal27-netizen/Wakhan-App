import {escapeHTML as h} from './music-view.mjs';
export function installSalonAnnouncement({request,context,onData=()=>{}}){
 let dialog=null,epoch=0,loading=null,disposed=false;
 const current=c=>!disposed&&c?.room&&context()?.room===c.room&&context()?.uid===c.uid;
 async function load(){const c=context();if(!c?.room)return null;const key=c.uid+'|'+c.room;if(loading?.key===key)return loading.task;
  const task=(async()=>{try{const r=await request('/api/v51/hall?code='+encodeURIComponent(c.room));if(current(c)&&r?.ok&&r.hall){onData(r.hall);return r.hall}}catch{}return null})().finally(()=>{if(loading?.task===task)loading=null});loading={key,task};return task;
 }

 const style=document.createElement('style');style.textContent='.wk-salon-notice{position:fixed;inset:auto 12px 12px;margin:auto;width:min(480px,calc(100% - 24px));padding:18px;border-radius:24px;border:1px solid #ffffff35;background:#201831f5;color:#fff;font:14px/1.8 Tahoma;max-height:85dvh;overflow:auto}.wk-salon-notice::backdrop{background:#0007;backdrop-filter:blur(4px)}.wk-salon-notice header{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}.wk-salon-notice button{min-height:44px;border:1px solid #ffffff30;border-radius:14px;background:#ffffff10;color:inherit;padding:8px 16px;font:inherit}.wk-salon-notice textarea{width:100%;min-height:120px;max-height:40dvh;padding:12px;background:#ffffff0b;border:1px solid #ffffff30;border-radius:14px;color:inherit;font:16px/1.8 Tahoma}.wk-salon-notice p{white-space:pre-wrap;overflow-wrap:anywhere}.wk-salon-notice .error{color:#ffc1cc;font-size:12px}';document.head.append(style);
 function close(){epoch++;dialog?.remove();dialog=null}
 async function open(){close();const c=context(),serial=epoch;if(!c?.room)return;const hall=await load();if(serial!==epoch||!current(c))return;
  dialog=document.createElement('dialog');dialog.className='wk-salon-notice';dialog.dir='rtl';const owner=hall?.is_owner===true;
  dialog.innerHTML='<header><b>اعلان سالون</b><button data-close aria-label="بستن">×</button></header>'+(hall?(owner?'<textarea maxlength="300" aria-label="اعلان سالون" placeholder="اعلان را بنویس…">'+h(hall.notice||'')+'</textarea><small data-count></small><button data-save>ذخیره</button>':'<p>'+h(hall.notice||'هنوز اعلانی نیست')+'</p>'):'<p>اعلان دریافت نشد</p>')+'<p class="error" role="status"></p>';
  document.body.append(dialog);dialog.querySelector('[data-close]').onclick=close;dialog.addEventListener('cancel',close);dialog.showModal();
  const input=dialog.querySelector('textarea');if(input){const count=()=>dialog?.querySelector('[data-count]')?.replaceChildren(document.createTextNode(input.value.length+'/300'));input.addEventListener('input',count);count();dialog.querySelector('[data-save]').onclick=async e=>{const button=e.currentTarget;if(button.disabled)return;button.disabled=true;const host=dialog;try{const r=await request('/api/v51/hall',{code:c.room,notice:input.value});if(!current(c)||host!==dialog)return;if(!r?.ok||!r.hall)throw Error('save');onData(r.hall);close()}catch{if(host===dialog)host.querySelector('.error').textContent='ذخیره نشد؛ دوباره بزن'}finally{if(button.isConnected)button.disabled=false}};}
 }
 const timer=setInterval(()=>{if(!document.hidden&&context()?.visible)void load()},5000);
 return {open,load,close,dispose(){disposed=true;close();clearInterval(timer);style.remove()}};
}
