import test from 'node:test';
import assert from 'node:assert/strict';
import {SessionBroker} from '../src/session.mjs';
import {createNativeSignIn,signInAvailability,useNativeProvider,normalizeEmailCode} from '../src/sign-in.mjs';
import {welcomeMarkup} from '../src/auth-view.mjs';
import {COPY} from '../src/auth-locales.mjs';
import {ICONS} from '../src/auth-copy.mjs';

const key='wka1.'+'A'.repeat(24)+'.'+'b'.repeat(32);
const login={ok:true,key,uid:42,name:'Existing',complete:true};
const challenge={ok:true,challenge:'c'.repeat(43),proof:'p'.repeat(43),nonce:'n'.repeat(43),client_id:'ios.apps.googleusercontent.com',server_client_id:'web.apps.googleusercontent.com'};
function fixture(handler){
 const memory=new Map(),requests=[];
 const store={get:async k=>memory.get(k)||null,set:async(k,v)=>memory.set(k,v),remove:async k=>memory.delete(k)};
 const broker=new SessionBroker({origin:'https://music.kabulcafe.uk',store,fetch:async(url,init)=>{requests.push({url,init,body:init?.body?JSON.parse(init.body):null});return handler?handler(url,init):Response.json(url.endsWith('/challenge')?challenge:login)}});
 return {memory,requests,broker};
}
test('visible methods are Google, native Apple on iOS, and email; Facebook is absent',()=>{
 const config={email:true,facebook:true,signin:{version:1,google:{ios:true,android:true},apple:{ios:true}}};
 assert.deepEqual(signInAvailability(config,'ios',true),{email:true,google:true,apple:true});
 assert.equal(signInAvailability(config,'android',true).apple,false);
 assert.equal(signInAvailability(config,'web',false).google,false);
 assert.equal(signInAvailability({google:true,native:true},'ios',true).google,true);assert.equal(useNativeProvider({google:true,native:true},'google','ios'),false);assert.equal(useNativeProvider(config,'google','ios'),true);
 for(const platform of ['ios','android']){
  const html=welcomeMarkup({lang:'fa',copy:COPY,icons:ICONS,brandSrc:'/brand.svg',available:signInAvailability(config,platform,true)});
  assert(!html.includes('data-provider="facebook"'));
  assert.equal(html.includes('data-provider="apple"'),platform==='ios');
  assert(html.includes('data-provider="email"'));
 }
});
test('Google native flow sends server nonce to SDK and token only to our exchange, then accepts same UID',async()=>{
 const f=fixture();let options;
 const signIn=createNativeSignIn({broker:f.broker,platform:'ios',plugin:{signIn:async value=>{options=value;return {idToken:'t'.repeat(150)}}}});
 await signIn('google');
 assert.equal(options.nonce,challenge.nonce);assert.equal(options.serverClientId,challenge.server_client_id);
 assert.equal(f.broker.session.user.id,42);
 assert.deepEqual(f.requests.map(r=>new URL(r.url).pathname),['/api/app/signin/challenge','/api/app/signin/exchange']);
 assert.equal(f.requests[1].body.id_token,'t'.repeat(150));
 assert(!JSON.stringify([...f.memory]).includes('t'.repeat(150)));
});
test('Apple is sent through same verified server exchange',async()=>{
 const f=fixture();let provider;
 await createNativeSignIn({broker:f.broker,platform:'ios',plugin:{signIn:async o=>{provider=o.provider;return{idToken:'a'.repeat(100)}}}})('apple');
 assert.equal(provider,'apple');assert.equal(f.requests[0].body.provider,'apple');assert.equal(f.broker.session.user.id,42);
});
test('linking carries the existing key and never replaces the current session',async()=>{
 const f=fixture((url)=>Response.json(url.endsWith('/challenge')?challenge:{ok:true,linked:'google',uid:42}));await f.broker.accept(login);
 await createNativeSignIn({broker:f.broker,platform:'android',plugin:{signIn:async()=>({idToken:'a'.repeat(100)})}})('google',{link:true});
 assert.equal(f.broker.session.key,key);
 for(const r of f.requests)assert.equal(r.init.headers['X-Init'],key);
 assert.equal(f.requests[0].body.link,true);
});
test('SDK cancellation sends no credential and permits another attempt',async()=>{
 const f=fixture();let calls=0;
 const signIn=createNativeSignIn({broker:f.broker,platform:'android',plugin:{signIn:async()=>{if(!calls++)throw{code:'cancelled'};return{idToken:'a'.repeat(100)}}}});
 await assert.rejects(()=>signIn('google'),e=>e.code==='cancelled');
 assert.equal(f.requests.length,1);assert.equal(f.broker.session,null);
 await signIn('google');assert.equal(f.broker.session.user.id,42);
});
test('leaving sign-in during SDK account choice discards the result',async()=>{
 const f=fixture();let done,valid=true;
 const pending=createNativeSignIn({broker:f.broker,platform:'ios',plugin:{signIn:()=>new Promise(r=>done=r)}})('google',{valid:()=>valid});
 while(!done)await new Promise(setImmediate);
 valid=false;done({idToken:'a'.repeat(100)});assert.equal(await pending,null);assert.equal(f.requests.length,1);assert.equal(f.broker.session,null);
});
test('account change during exchange cannot sign back into previous account',async()=>{
 let done;const f=fixture(url=>url.endsWith('/challenge')?Response.json(challenge):new Promise(r=>done=r));
 const pending=createNativeSignIn({broker:f.broker,platform:'ios',plugin:{signIn:async()=>({idToken:'a'.repeat(100)})}})('google');
 while(!done)await new Promise(setImmediate);
 await f.broker.accept({...login,uid:7,key:'wka1.'+'C'.repeat(24)+'.'+'d'.repeat(32)});
 done(Response.json(login));assert.equal(await pending,null);assert.equal(f.broker.session.user.id,7);
});
test('account change during challenge creation cannot bind the result to the new account',async()=>{
 let done;const f=fixture(()=>new Promise(r=>done=r));let sdkCalls=0;
 const pending=createNativeSignIn({broker:f.broker,platform:'ios',plugin:{signIn:async()=>{sdkCalls++;return{idToken:'a'.repeat(100)}}}})('google');
 await f.broker.accept({...login,uid:7});done(Response.json(challenge));
 await assert.rejects(()=>pending,e=>e.code==='auth_changed');assert.equal(sdkCalls,0);assert.equal(f.broker.session.user.id,7);
});
test('wrong-account link response is rejected without replacing current account',async()=>{
 const f=fixture(url=>Response.json(url.endsWith('/challenge')?challenge:{ok:true,linked:'google',uid:7}));await f.broker.accept(login);
 await assert.rejects(()=>createNativeSignIn({broker:f.broker,platform:'ios',plugin:{signIn:async()=>({idToken:'a'.repeat(100)})}})('google',{link:true}),e=>e.code==='server_response');
 assert.equal(f.broker.session.user.id,42);
});
test('email code accepts Persian/Arabic digits and rejects malformed verification before network',async()=>{
 assert.equal(normalizeEmailCode('۱۲٣٤۵۶x۷'),'123456');
 const f=fixture();await assert.rejects(()=>f.broker.emailVerify('a@example.com','123'),e=>e.code==='code_bad');assert.equal(f.requests.length,0);
});
test('late email verification cannot replace a newly selected account',async()=>{
 let done;const f=fixture(()=>new Promise(r=>done=r));
 const pending=f.broker.emailVerify('a@example.com','123456');
 await f.broker.accept({...login,uid:7});done(Response.json(login));
 await assert.rejects(()=>pending,e=>e.code==='auth_changed');assert.equal(f.broker.session.user.id,7);
});
test('provider failures do not silently switch to old browser confirmation',async()=>{
 const f=fixture();await assert.rejects(()=>createNativeSignIn({broker:f.broker,platform:'ios',plugin:{signIn:async()=>{throw Error('SDK')}}})('google'),e=>e.code==='provider_fail');
 assert.equal(f.requests.length,1);assert.equal(f.broker.session,null);
});
test('current config needs one request; old servers retain email access',async()=>{
 const f=fixture(()=>Response.json({ok:true,email:true,signin:{version:1}}));assert.equal((await f.broker.config()).email,true);assert.equal(f.requests.length,1);
 const legacy=fixture(url=>url.endsWith('/signin/config')?new Response('Not Found',{status:404}):Response.json({ok:true,email:true,google:true}));
 assert.equal((await legacy.broker.config()).email,true);assert.equal(legacy.requests.length,2);
});
test('legacy Google browser sign-in stays available without the optional native provider SDK',()=>{
 const config={google:'public.apps.googleusercontent.com',native:true,email:false,signin:{version:1,google:{ios:false,android:false},apple:{ios:false}}};
 for(const platform of ['ios','android']){
  assert.equal(signInAvailability(config,platform,false).google,true);
  assert.equal(useNativeProvider(config,'google',platform),false);
  const html=welcomeMarkup({lang:'fa',copy:COPY,icons:ICONS,brandSrc:'/brand.svg',available:signInAvailability(config,platform,false)});
  assert.match(html,/data-provider="google"[^>]*aria-disabled="false"/);
 }
 assert.equal(signInAvailability(config,'web',false).google,false);
});
