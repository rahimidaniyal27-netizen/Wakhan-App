/* Provider tokens are handed directly to our server, never stored in the web view. */
import {AuthError} from './session.mjs';

export function signInAvailability(config={},platform='web',native=false){
 const modern=config.signin?.version===1;
 return {
  email:!!config.email,
  google:(['ios','android'].includes(platform)&&!!config.google&&!!config.native)||(native&&modern&&!!config.signin.google?.[platform]),
  apple:modern&&native&&platform==='ios'&&!!config.signin.apple?.ios
 };
}

export function useNativeProvider(config,provider,platform){
 return config?.signin?.version===1&&!!config.signin?.[provider]?.[platform];
}

export function createNativeSignIn({broker,plugin,platform}){
 let running=false;
 return async(provider,{link=false,valid=()=>true}={})=>{
  if(!['google','apple'].includes(provider))throw new AuthError('provider_bad');
  if(running)throw new AuthError('wait');
  running=true;
  try{
   const challenge=await broker.signInChallenge(provider,platform,link);
   if(!valid())return null;
   let credential;
   try{credential=await plugin.signIn({provider,nonce:challenge.nonce,clientId:challenge.client_id,serverClientId:challenge.server_client_id||''})}
   catch(e){throw new AuthError(e?.code==='cancelled'?'cancelled':'provider_fail')}
   if(!valid())return null;
   if(typeof credential?.idToken!=='string'||credential.idToken.length<50||credential.idToken.length>16384)throw new AuthError('provider_fail');
   return await broker.signInExchange(challenge,credential.idToken,{link,valid});
  }finally{running=false}
 };
}

export function normalizeEmailCode(value){return String(value??'').replace(/[۰-۹٠-٩]/g,c=>String(c.charCodeAt(0)-(c>='۰'&&c<='۹'?0x6f0:0x660))).replace(/[^0-9]/g,'').slice(0,6)}
