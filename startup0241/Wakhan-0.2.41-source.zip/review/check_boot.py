import asyncio,json,os,sys
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];BASE=os.environ.get('WK_REVIEW_BASE','http://127.0.0.1:5176');OUT=ROOT/'review';OUT.mkdir(exist_ok=True)
INIT=r'''(()=>{window.CapacitorCustomPlatform={name:'ios'};const names={WakhanLocale:['preferred','bars','safeArea','orientation'],WakhanDownloads:['download','source','remove','cancel','addListener','removeListener'],App:['addListener','removeListener','minimizeApp'],Keyboard:['addListener','removeListener'],Browser:['open','close','addListener','removeListener'],StatusBar:['setStyle','setBackgroundColor','hide','show'],SplashScreen:['hide','show'],Haptics:['impact','selectionChanged','notification'],PushNotifications:['addListener','removeListener','checkPermissions','register','unregister']};window.Capacitor={PluginHeaders:Object.entries(names).map(([name,methods])=>({name,methods:methods.map(name=>({name,rtype:name==='addListener'?'callback':'promise'}))})),nativePromise:async(plugin,method,args)=>{if(plugin==='WakhanLocale'&&method==='preferred')return {languages:['fa'],country:'AF'};if(plugin==='WakhanLocale'&&method==='safeArea')return {width:innerWidth,top:59,bottom:34,left:0,right:0};return {}},nativeCallback:()=>Promise.resolve('testcallback')};const session={origin:'https://music.kabulcafe.uk',key:'wka1.'+'A'.repeat(24)+'.'+'a'.repeat(32),user:{id:1,first_name:'Test'},new:false};localStorage.setItem('wkv_session',JSON.stringify(session));localStorage.setItem('wk_native_lang','fa');window.__bootMutations=0;window.__bootLoop=false;new MutationObserver(events=>{__bootMutations+=events.length;if(__bootMutations>150&&window.WakhanMusicUI){__bootLoop=true;WakhanMusicUI.dispose()}}).observe(document,{subtree:true,attributes:true,attributeFilter:['class']});})()'''
async def main():
 results=[]
 async with async_playwright()as p:
  engines=['chromium','webkit'] if '--both' in sys.argv else ['chromium']
  for engine in engines:
   args={'executable_path':'/usr/bin/chromium','args':['--no-sandbox']}if engine=='chromium'and Path('/usr/bin/chromium').exists()else {}
   browser=await getattr(p,engine).launch(**args);context=await browser.new_context(viewport={'width':393,'height':852},is_mobile=True,has_touch=True);await context.add_init_script(INIT);page=await context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   async def route(r):
    u=urlsplit(r.request.url);path=u.path
    if path.startswith('/api/'):
     value={'ok':True,'items':[]}
     if path=='/api/app/config':value.update(email=True,native=False,push=False)
     elif path=='/api/app/me':value.update(uid=1,name='Test',username='test',complete=True)
     elif path=='/api/me':value.update(me={'id':1,'name':'Test','bal':0},favs=[],groups=[],phist=[],srch=[],ysrch=[],yhist=[],stats={'plays':0,'srch':0,'watched':0})
     elif path=='/api/app/home/rankings':q=parse_qs(u.query);value.update(category=q.get('category',['overall'])[0],period=q.get('period',['month'])[0],start=1,available=True,rule='',me=None,salons=[])
     elif path=='/api/app/chat/people':value.update(self={'id':1,'name':'Test'})
     elif path=='/api/wallet':value.update(balance=0)
     elif path=='/api/app/salon/home':value.update(mine=None,followed=[],joined=[],recent=[])
     elif path=='/api/app/games/socket':value={'ok':False,'err':'review_offline'}
     elif path=='/api/app/games/home':value.update(invites=[],one_needed=[],resume=None)
     await r.fulfill(json=value);return
    local=ROOT/'project/public'/path.removeprefix('/s/').lstrip('/')
    if local.is_file():await r.fulfill(path=str(local));return
    await r.fulfill(status=404,body='')
   await page.route('https://music.kabulcafe.uk/**',route)
   await page.goto(BASE);await page.wait_for_function('!!window.WakhanMusicUI',timeout=20000);await page.evaluate("go('h')");await page.wait_for_timeout(500)
   assert not await page.evaluate('window.__bootLoop'), 'startup entered mutation loop'
   await page.wait_for_function("!document.getElementById('wk-intro2')",timeout=12000)
   await page.locator('.wk-approved-home-frame').wait_for();assert await page.locator('#nav').is_visible()
   timings=[]
   for tab in ['p','h','m','h','p','h']:
    timings.append(await page.evaluate('async t=>{const start=performance.now();go(t);await new Promise(requestAnimationFrame);return performance.now()-start}',tab));await page.wait_for_timeout(120);assert not await page.evaluate('__bootLoop')
   a=await page.evaluate('__bootMutations');await page.wait_for_timeout(300);z=await page.evaluate('__bootMutations');assert z-a<15,(a,z)
   glass=await page.locator('#nav .bar').evaluate('e=>getComputedStyle(e).backgroundImage');assert 'rgba' in glass,glass
   assert max(timings)<250,timings
   assert not errors,errors
   await page.screenshot(path=str(OUT/(engine+'-home-after-intro.png')))
   results.append(dict(engine=engine,full_bootstrap=True,intro_removed=True,home_visible=True,navigation_responsive=True,tab_to_frame_ms=[round(v,2)for v in timings],glass_background=glass,no_mutation_loop=True,errors=errors,physical_device=False));print('PASS',engine,results[-1],flush=True);await browser.close()
 (OUT/'bootstrap-results.json').write_text(json.dumps(results,indent=2))
asyncio.run(main())
