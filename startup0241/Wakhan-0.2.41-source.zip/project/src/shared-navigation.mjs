/* The same Home navigation owns every top-level tab. Shadow styles keep the
   retired tab artwork and per-page CSS from changing its appearance. */
const paths={
 h:'<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
 p:'<circle cx="8" cy="18" r="4"/><path d="M12 18V2l7 4"/>',
 c:'<path d="m12.296 3.464 3.02 3.956"/><path d="M20.2 6 3 11l-.9-2.4c-.3-1.1.3-2.2 1.3-2.5l13.5-4c1.1-.3 2.2.3 2.5 1.3z"/><path d="M3 11h18v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="m6.18 5.276 3.1 3.899"/>',
 d:'<path d="M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719"/>',
 m:'<circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 0 0-16 0"/>'
};
const labels={fa:['خانه','موسیقی','سینما','چت','من'],ps:['کور','موسیقي','سینما','چټ','زه'],en:['Home','Music','Cinema','Chat','Me'],de:['Start','Musik','Kino','Chat','Konto'],ar:['الرئيسية','الموسيقى','السينما','الدردشة','أنا'],ur:['ہوم','موسیقی','سنیما','چیٹ','میں'],tr:['Ana sayfa','Müzik','Sinema','Sohbet','Ben'],ru:['Главная','Музыка','Кино','Чат','Я'],fr:['Accueil','Musique','Cinéma','Chat','Moi'],es:['Inicio','Música','Cine','Chat','Yo'],hi:['होम','संगीत','सिनेमा','चैट','मैं'],bn:['হোম','সঙ্গীত','সিনেমা','চ্যাট','আমি'],zh:['首页','音乐','影院','聊天','我的'],ja:['ホーム','音楽','シネマ','チャット','マイページ'],ko:['홈','음악','시네마','채팅','마이']};

export function installSharedNavigation({getRoute,navigate,language=()=>document.documentElement.lang,getUnread=()=>0,getInsets=()=>null,hooks}){
 const host=document.getElementById('nav');if(!host)throw Error('navigation_host_missing');
 const previous=hooks.getRenderNav();let disposed=false,frame=0,sequence=0,homeView='home',homeBlocked=false;
 host.replaceChildren();host.classList.remove('tb2','wm76-nav');host.classList.add('wk-shared-nav');host.dataset.wkShared='1';
 const shadow=host.shadowRoot||host.attachShadow({mode:'open'});shadow.replaceChildren();
 const style=document.createElement('style');style.textContent=`
 :host{font-family:Tahoma,Arial,sans-serif;color:#f5f1fa}
 *,*:before,*:after{box-sizing:border-box;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
 .bar{position:relative;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:2px;width:100%;padding:6px 4px;border:1px solid #cad2e145;border-radius:29px;background:linear-gradient(135deg,rgba(49,41,67,.68),rgba(23,18,35,.64) 60%,rgba(42,34,57,.72));box-shadow:inset 0 1px #eff4ff46,inset 0 -1px #090d16,0 8px 22px #05010f3d;backdrop-filter:blur(var(--wk-glass-blur,12px)) saturate(130%);-webkit-backdrop-filter:blur(var(--wk-glass-blur,12px)) saturate(130%)}
 button{position:relative;z-index:1;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:5px;min-width:0;min-height:55px;padding:5px 0;border:0;border-radius:24px;background:none;color:#b9bbc8;font:10px/1.7 Tahoma,Arial,sans-serif;touch-action:manipulation;-webkit-tap-highlight-color:transparent;cursor:pointer}
 button[aria-current=page]{color:#f9eeff}
 button:focus-visible{outline:2px solid #d6b4fa;outline-offset:-3px}
 svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex:none}
 .label{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
 .lens{position:absolute;left:0;top:0;pointer-events:none;border-radius:24px;background:linear-gradient(135deg,#c0cbd64d,#9aa6b322);box-shadow:inset 0 1px #f6fbff77,inset 0 -1px #ffffff12,inset 0 0 0 1px #dce8f414;transition:transform .16s cubic-bezier(.2,.8,.25,1),width .16s cubic-bezier(.2,.8,.25,1)}
 .badge{position:absolute;top:1px;left:calc(50% + 5px);display:grid;place-items:center;min-width:15px;height:15px;padding:0 3px;border-radius:9px;background:#d6b4fa;color:#241532;font:bold 9px/1 Arial,sans-serif}
 @media(prefers-reduced-motion:reduce){.lens{transition:none}}
 `;
 const bar=document.createElement('div');bar.className='bar';const lens=document.createElement('i');lens.className='lens';lens.setAttribute('aria-hidden','true');bar.append(lens);
 const keys=['h','p','c','d','m'],buttons=new Map();
 for(const tab of keys){const b=document.createElement('button');b.type='button';b.dataset.wkTab=tab;b.innerHTML=`<svg viewBox="0 0 24 24" aria-hidden="true">${paths[tab]}</svg><span class="label"></span>`;b.addEventListener('click',()=>{if(!host.hidden&&!host.inert&&!(getRoute()==='h'&&homeBlocked))navigate(tab)});buttons.set(tab,b);bar.append(b);}
 shadow.append(style,bar);
 const hostStyle=document.createElement('style');hostStyle.dataset.wakhanSharedNavigation='';hostStyle.textContent=`
 #nav.wk-shared-nav{position:fixed!important;inset:auto calc(12px + var(--wk-nav-safe-right,env(safe-area-inset-right,0px))) calc(8px + var(--wk-nav-safe-bottom,var(--wk-safe-bottom,env(safe-area-inset-bottom,0px)))) calc(12px + var(--wk-nav-safe-left,env(safe-area-inset-left,0px)))!important;width:auto!important;height:auto!important;min-height:0!important;max-width:none!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;background:none!important;box-shadow:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;filter:none!important;transform:none!important;grid-template-columns:minmax(0,1fr)!important;gap:0!important;z-index:50!important}
 html.wk-economy #nav.wk-shared-nav{--wk-glass-blur:6px}
 #nav.wk-shared-nav:before,#nav.wk-shared-nav:after{display:none!important}
 #nav.wk-shared-nav[hidden]{display:none!important}
 #nav.wk-shared-nav[data-home-blocked]{opacity:.3!important;pointer-events:none!important}
 `;document.head.append(hostStyle);
 function active(){const tab=getRoute();return tab==='l'?'p':tab==='g'?'h':tab==='o'?'m':tab;}
 function place(){frame=0;if(disposed||host.hidden)return;const b=buttons.get(active());if(!b)return;lens.style.top=b.offsetTop+'px';lens.style.width=b.offsetWidth+'px';lens.style.height=b.offsetHeight+'px';lens.style.transform=`translateX(${b.offsetLeft}px)`;}
 function schedule(){if(!frame)frame=requestAnimationFrame(place);}
 function visibility(){const home=getRoute()==='h';const hidden=!!document.fullscreenElement||document.body.matches('.wkchat-thread,.slr-on,.wmc-theater,.h2-open,.wm78-room-open,.wm76-keyboard,.native87-auth')||home&&homeView==='arena';host.hidden=hidden;host.toggleAttribute('data-home-blocked',home&&homeBlocked);if(!hidden)schedule();}
 function render(){
  if(disposed)return;const text=labels[String(language()).split('-')[0]]||labels.en,selected=active();host.setAttribute('aria-label',String(language()).startsWith('fa')?'بخش‌های برنامه':'App navigation');
  keys.forEach((key,index)=>{const b=buttons.get(key),label=b.querySelector('.label');if(label.textContent!==text[index])label.textContent=text[index];b.setAttribute('aria-label',text[index]);b.classList.toggle('on',selected===key);if(selected===key)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
  const count=Math.max(0,Math.min(99,Number(getUnread())||0)),chat=buttons.get('d');let badge=chat.querySelector('.badge');if(count){if(!badge){badge=document.createElement('b');badge.className='badge';chat.append(badge)}badge.textContent=String(count)}else badge?.remove();
  visibility();schedule();
 }
 async function syncInsets(){const serial=++sequence;try{const v=await getInsets();if(disposed||serial!==sequence||!v||!Number.isFinite(v.width)||v.width<=0)return;const scale=innerWidth/v.width;if(scale<.25||scale>4)return;for(const side of ['bottom','left','right']){if(!Number.isFinite(v[side])||v[side]<0)return;}if((v.left+v.right)*scale>=innerWidth||v.bottom*scale>=innerHeight)return;for(const side of ['bottom','left','right'])host.style.setProperty('--wk-nav-safe-'+side,v[side]*scale+'px');schedule();}catch{}}
 const resize=()=>{schedule();void syncInsets()};const fullscreen=()=>{visibility();void syncInsets()};const resume=()=>{if(!document.hidden){render();void syncInsets()}};
 const observer=new MutationObserver(visibility);observer.observe(document.body,{attributes:true,attributeFilter:['class']});
 const sizing=new ResizeObserver(schedule);sizing.observe(bar);window.addEventListener('resize',resize);document.addEventListener('fullscreenchange',fullscreen);document.addEventListener('visibilitychange',resume);
 hooks.setRenderNav(render);render();void syncInsets();
 return {render,setHomeState(view,blocked=false){homeView=String(view||'home');homeBlocked=!!blocked;visibility();},syncInsets,dispose(){disposed=true;++sequence;if(frame)cancelAnimationFrame(frame);observer.disconnect();sizing.disconnect();window.removeEventListener('resize',resize);document.removeEventListener('fullscreenchange',fullscreen);document.removeEventListener('visibilitychange',resume);hostStyle.remove();shadow.replaceChildren(document.createElement('slot'));if(hooks.getRenderNav()===render)hooks.setRenderNav(previous);host.hidden=false;host.removeAttribute('data-home-blocked');host.removeAttribute('data-wk-shared');host.classList.remove('wk-shared-nav');for(const side of ['bottom','left','right'])host.style.removeProperty('--wk-nav-safe-'+side);}};
}
