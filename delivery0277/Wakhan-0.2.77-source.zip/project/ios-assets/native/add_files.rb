# adds Wakhan's own iOS files to the Xcode project and makes MainViewController the start screen
require 'xcodeproj'
require 'json'
proj = Xcodeproj::Project.open('ios/App/App.xcodeproj')
target = proj.targets.find { |t| t.name == 'App' }
group = proj.main_group.find_subpath('App', false)
Dir.glob('ios-assets/native/*.swift').map { |f| File.basename(f) }.sort.each do |f|
  next if group.files.any? { |x| x.path == f }
  ref = group.new_reference(f)
  target.add_file_references([ref])
end
# Official Google SDK 9 adds a nonce to the native flow. Pin the exact SDK.
url = 'https://github.com/google/GoogleSignIn-iOS'
package = proj.root_object.package_references.find { |p| p.isa == 'XCRemoteSwiftPackageReference' && p.repositoryURL == url }
unless package
  package = proj.new(Xcodeproj::Project::Object::XCRemoteSwiftPackageReference)
  package.repositoryURL = url
  proj.root_object.package_references << package
end
package.requirement = {'kind' => 'exactVersion', 'version' => '9.1.0'}
product = target.package_product_dependencies.find { |p| p.product_name == 'GoogleSignIn' }
unless product
  product = proj.new(Xcodeproj::Project::Object::XCSwiftPackageProductDependency)
  product.package = package
  product.product_name = 'GoogleSignIn'
  target.package_product_dependencies << product
  linked = proj.new(Xcodeproj::Project::Object::PBXBuildFile)
  linked.product_ref = product
  target.frameworks_build_phase.files << linked
end
# This optional file contains public client IDs only. Never put OAuth secrets in it.
settings_file = 'signin-public.json'
if File.file?(settings_file)
  settings = JSON.parse(File.read(settings_file))
  cid = settings.fetch('google_ios_client_id', '')
  server = settings.fetch('google_server_client_id', '')
  valid_id = /\A[A-Za-z0-9_-]+\.apps\.googleusercontent\.com\z/
  raise 'Invalid public Google client ID' unless cid.empty? || (valid_id.match?(cid) && valid_id.match?(server))
  plist_path = 'ios/App/App/Info.plist'
  plist = Xcodeproj::Plist.read_from_path(plist_path)
  unless cid.empty?
    plist['GIDClientID'] = cid
    plist['GIDServerClientID'] = server
    types = (plist['CFBundleURLTypes'] || []).reject { |x| x['CFBundleURLName'] == 'WakhanGoogleSignIn' }
    types << {'CFBundleURLName' => 'WakhanGoogleSignIn', 'CFBundleURLSchemes' => [cid.split('.').reverse.join('.')]}
    plist['CFBundleURLTypes'] = types
  end
  apple = settings.fetch('apple_enabled', false)
  raise 'Invalid Apple public flag' unless [true, false].include?(apple)
  plist['WakhanAppleSignIn'] = apple
  if apple
    entitlement_path = 'ios/App/App/WakhanSignIn.entitlements'
    entitlements = File.file?(entitlement_path) ? Xcodeproj::Plist.read_from_path(entitlement_path) : {}
    entitlements['com.apple.developer.applesignin'] = ['Default']
    Xcodeproj::Plist.write_to_path(entitlements, entitlement_path)
    target.build_configurations.each { |c| c.build_settings['CODE_SIGN_ENTITLEMENTS'] = 'App/WakhanSignIn.entitlements' }
  end
  Xcodeproj::Plist.write_to_path(plist, plist_path)
end
proj.save
sb = 'ios/App/App/Base.lproj/Main.storyboard'
s = File.read(sb)
s2 = s.gsub(/customClass="CAPBridgeViewController" customModule="Capacitor"/, 'customClass="MainViewController" customModule="App" customModuleProvider="target"')
raise 'storyboard: view controller not found' if s2 == s && !s.include?('MainViewController')
File.write(sb, s2)
puts 'iOS: Wakhan native files added'
