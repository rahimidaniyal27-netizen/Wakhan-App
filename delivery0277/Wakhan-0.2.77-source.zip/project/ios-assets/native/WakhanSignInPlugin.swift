import UIKit
import Capacitor
import AuthenticationServices
import GoogleSignIn

@objc(WakhanSignInPlugin)
public class WakhanSignInPlugin: CAPPlugin, CAPBridgedPlugin,
    ASAuthorizationControllerDelegate, ASAuthorizationControllerPresentationContextProviding {
    public let identifier = "WakhanSignInPlugin"
    public let jsName = "WakhanSignIn"
    public let pluginMethods: [CAPPluginMethod] = [CAPPluginMethod(name: "signIn", returnType: CAPPluginReturnPromise)]
    private var pending: CAPPluginCall?
    private var authorization: ASAuthorizationController?
    private var presentationWindow: UIWindow?

    public override func load() {
        NotificationCenter.default.addObserver(self, selector: #selector(openURL(_:)), name: .capacitorOpenURL, object: nil)
    }

    @objc private func openURL(_ notification: Notification) {
        guard let data = notification.object as? [String: Any], let url = data["url"] as? URL else { return }
        guard let client = Bundle.main.object(forInfoDictionaryKey: "GIDClientID") as? String,
              !client.isEmpty, url.scheme == client.components(separatedBy: ".").reversed().joined(separator: ".") else { return }
        _ = GIDSignIn.sharedInstance.handle(url)
    }

    @objc func signIn(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard self.pending == nil else { call.reject("Sign-in already open", "wait"); return }
            guard let nonce = call.getString("nonce"), nonce.range(of: "^[A-Za-z0-9_-]{32,128}$", options: .regularExpression) != nil,
                  let vc = self.bridge?.viewController, vc.view.window != nil else {
                call.reject("Sign-in unavailable", "provider_fail"); return
            }
            self.pending = call
            self.presentationWindow = vc.view.window
            switch call.getString("provider") {
            case "google":
                guard let client = call.getString("clientId"), let server = call.getString("serverClientId"),
                      client == Bundle.main.object(forInfoDictionaryKey: "GIDClientID") as? String,
                      server == Bundle.main.object(forInfoDictionaryKey: "GIDServerClientID") as? String,
                      !client.isEmpty, !server.isEmpty else {
                    self.finish(nil, "provider_fail"); return
                }
                GIDSignIn.sharedInstance.configuration = GIDConfiguration(clientID: client, serverClientID: server)
                // Explicit account choice, including when another Wakhan account was just logged out.
                GIDSignIn.sharedInstance.signOut()
                GIDSignIn.sharedInstance.signIn(withPresenting: vc, hint: nil, additionalScopes: nil, nonce: nonce) { [weak self] result, error in
                    DispatchQueue.main.async {
                        if let error = error as NSError? {
                            // Google SDK's documented kGIDSignInErrorCodeCanceled is -5.
                            self?.finish(nil, error.domain == kGIDSignInErrorDomain && error.code == -5 ? "cancelled" : "provider_fail")
                        } else { self?.finish(result?.user.idToken?.tokenString, nil) }
                    }
                }
            case "apple":
                guard Bundle.main.object(forInfoDictionaryKey: "WakhanAppleSignIn") as? Bool == true else {
                    self.finish(nil, "apple_off"); return
                }
                let request = ASAuthorizationAppleIDProvider().createRequest()
                request.requestedScopes = [.email, .fullName]
                request.nonce = nonce
                let controller = ASAuthorizationController(authorizationRequests: [request])
                controller.delegate = self
                controller.presentationContextProvider = self
                self.authorization = controller
                controller.performRequests()
            default: self.finish(nil, "provider_bad")
            }
        }
    }

    private func finish(_ token: String?, _ error: String?) {
        guard let call = pending else { return }
        pending = nil; authorization = nil; presentationWindow = nil
        if let token = token, !token.isEmpty { call.resolve(["idToken": token]) }
        else { call.reject("Sign-in did not complete", error ?? "provider_fail") }
    }

    public func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        // Sign-in starts only with a visible view controller; never choose another app scene.
        return presentationWindow ?? ASPresentationAnchor()
    }

    public func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        guard let credential = authorization.credential as? ASAuthorizationAppleIDCredential,
              let data = credential.identityToken, let token = String(data: data, encoding: .utf8) else {
            finish(nil, "provider_fail"); return
        }
        finish(token, nil)
    }

    public func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
        finish(nil, (error as? ASAuthorizationError)?.code == .canceled ? "cancelled" : "provider_fail")
    }

    deinit { NotificationCenter.default.removeObserver(self) }
}
