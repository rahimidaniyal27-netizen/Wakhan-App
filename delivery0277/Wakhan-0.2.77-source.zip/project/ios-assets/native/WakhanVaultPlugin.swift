import Foundation
import Security
import Capacitor

@objc(WakhanVaultPlugin)
public class WakhanVaultPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "WakhanVaultPlugin"
    public let jsName = "WakhanVault"
    public let pluginMethods = [
        CAPPluginMethod(name: "get", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "set", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "remove", returnType: CAPPluginReturnPromise)
    ]
    private let service = "app.wakhan.music.native.vault.v1"
    private let allowed: Set<String> = ["session", "pair", "server"]
    private var initialized = false

    public override func load() {
        // Keychain survives uninstall. An install marker prevents restoring an
        // old login after reinstalling the app. It stores no credential itself.
        let marker = "WakhanVaultInstalledV1"
        if UserDefaults.standard.bool(forKey: marker) {
            initialized = true
        } else {
            let status = SecItemDelete([kSecClass as String: kSecClassGenericPassword,
                                        kSecAttrService as String: service] as CFDictionary)
            if status == errSecSuccess || status == errSecItemNotFound {
                UserDefaults.standard.set(true, forKey: marker)
                initialized = true
            }
        }
    }

    private func query(_ call: CAPPluginCall) -> [String: Any]? {
        guard initialized else { call.reject("Secure storage unavailable", "VAULT_UNAVAILABLE"); return nil }
        guard let key = call.getString("key"), allowed.contains(key) else {
            call.reject("Invalid secure storage key", "VAULT_UNAVAILABLE"); return nil
        }
        return [kSecClass as String: kSecClassGenericPassword,
                kSecAttrService as String: service, kSecAttrAccount as String: key,
                kSecAttrSynchronizable as String: false]
    }

    @objc func get(_ call: CAPPluginCall) {
        guard var q = query(call) else { return }
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var item: CFTypeRef?
        let status = SecItemCopyMatching(q as CFDictionary, &item)
        if status == errSecItemNotFound { call.resolve(["value": NSNull()]); return }
        guard status == errSecSuccess, let data = item as? Data, data.count <= 65536,
              let value = String(data: data, encoding: .utf8) else {
            call.reject("Secure session could not be read", "VAULT_UNAVAILABLE"); return
        }
        call.resolve(["value": value])
    }

    @objc func set(_ call: CAPPluginCall) {
        guard let q = query(call) else { return }
        guard let value = call.getString("value"), value.utf16.count <= 16384,
              let data = value.data(using: .utf8) else {
            call.reject("Invalid secure storage value", "VAULT_UNAVAILABLE"); return
        }
        let attrs: [String: Any] = [kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        var status = SecItemUpdate(q as CFDictionary, attrs as CFDictionary)
        if status == errSecItemNotFound {
            var item = q; item.merge(attrs) { _, new in new }
            status = SecItemAdd(item as CFDictionary, nil)
        }
        if status == errSecSuccess { call.resolve() }
        else { call.reject("Secure session could not be saved", "VAULT_UNAVAILABLE") }
    }

    @objc func remove(_ call: CAPPluginCall) {
        guard let q = query(call) else { return }
        let status = SecItemDelete(q as CFDictionary)
        if status == errSecSuccess || status == errSecItemNotFound { call.resolve() }
        else { call.reject("Secure session could not be removed", "VAULT_UNAVAILABLE") }
    }
}
