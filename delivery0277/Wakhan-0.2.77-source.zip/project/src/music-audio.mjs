import {startupTask} from './music-startup.mjs';
import {musicSource} from './music-source.mjs';
/* Reuse the app's existing authenticated audio preparation, including its
   entitlement and lease checks. Do not use or conceal an IFrame player. */
export async function externalAudio({track,fetchBinary,origin='https://music.kabulcafe.uk',valid=()=>true,delay=ms=>new Promise(r=>setTimeout(r,ms)),now=Date.now,timeout=20000,signal}){
 if(!['youtube','soundcloud'].includes(track.provider))return track;
 const started=now(),owner=track.id;let attempts=0,legacy=false;
 while(valid()){
  if(signal?.aborted||!valid())throw Error('cancelled');
  if(now()-started>=timeout)throw Error('audio_timeout');
  const remaining=Math.max(1,timeout-(now()-started));
  const {response,data}=await startupTask(async()=>{const endpoint=legacy?'/api/v60/audio?url='+encodeURIComponent(track.source_url):'/api/app/music/audio-start?id='+encodeURIComponent(track.id);const response=await fetchBinary(origin+endpoint,{cache:'no-store',signal});if(!legacy&&[404,405].includes(response.status)){await response.body?.cancel().catch(()=>{});return {response,data:null}}return {response,data:await response.json()}},{signal,timeout:remaining});
  if(!valid()||signal?.aborted)throw Error('cancelled');
  if(!legacy&&[404,405].includes(response.status)){legacy=true;continue}
  if(response.status===401)throw Error('auth');
  if(response.status===403)throw Error(data.err==='subscription_required'||data.err==='subscription'?'subscription_required':'audio_unavailable');
  if(!legacy){const stream=musicSource(data?.src,origin);if(!response.ok||!data?.ok||!stream||!new URL(stream).pathname.startsWith('/api/app/music/play/'))throw Error(data?.err==='audio_timeout'?'audio_timeout':'audio_unavailable');return {...track,id:owner,embed:false,stream,duration:Number(data.dur)||track.duration,downloadable:false,persistent:false,playback:'audio'}}
  if(data.pending){const left=timeout-(now()-started);if(left<=0)throw Error('audio_timeout');await startupTask(()=>delay(Math.min(left,[200,500,1000][Math.min(attempts++,2)])),{signal,timeout:Math.max(1,left)});continue}
  if(!response.ok||!data.ok||typeof data.src!=='string'||!data.src.startsWith('/a/'))throw Error('audio_unavailable');
  const original=musicSource(new URL(data.src,origin).href,origin);if(!original)throw Error('audio_unavailable');const u=new URL(original);if(!u.searchParams.get('lease'))throw Error('audio_unavailable');const stream=musicSource(origin+'/api/app/music/media/'+encodeURIComponent(u.pathname.slice(3))+u.search,origin);if(!stream)throw Error('audio_unavailable');
  return {...track,id:owner,embed:false,stream,duration:Number(data.dur)||track.duration,downloadable:false,persistent:false,playback:'audio'};
 }
 throw Error('cancelled');
}
