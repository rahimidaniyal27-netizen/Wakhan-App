// Recent chats and their media stay private to the account that requested them.
// Disk reads have a short deadline; a busy IndexedDB must never hold up navigation.
const NAME='wakhan-chat-cache',VERSION=1,MSGS=50,THREADS=40,MEDIA=300,MEDIA_MAX=3_000_000;
const connections=new Set();let deletion=Promise.resolve();
const closeDb=d=>{if(d){connections.delete(d);try{d.close()}catch{}}};
function openDb(){return new Promise(resolve=>{let finished=false;const finish=d=>{if(finished){closeDb(d);return}finished=true;clearTimeout(timer);if(d){connections.add(d);d.onversionchange=()=>closeDb(d)}resolve(d)};const timer=setTimeout(()=>finish(null),1500);
 try{if(typeof indexedDB==='undefined')return finish(null);const r=indexedDB.open(NAME,VERSION);r.onupgradeneeded=()=>{const d=r.result;for(const s of ['threads','media','meta'])if(!d.objectStoreNames.contains(s))d.createObjectStore(s)};r.onsuccess=()=>finish(r.result);r.onerror=()=>finish(null);r.onblocked=()=>finish(null)}catch{finish(null)}
})}
const bounded=(task,ms)=>new Promise(resolve=>{const timer=setTimeout(()=>resolve(null),ms);Promise.resolve(task).then(value=>{clearTimeout(timer);resolve(value)},()=>{clearTimeout(timer);resolve(null)})});
export function createChatCache(getUid,{writeDelay=1200,readTimeout=120,mediaBudget=60_000_000}={}){
 let dbp=null,disposed=false,epoch=0,lastUid='',queue=Promise.resolve();const timers=new Map();
 const uid=()=>String(getUid?.()||'');
 function owner(){const now=uid();if(now!==lastUid){lastUid=now;++epoch;for(const t of timers.values())clearTimeout(t);timers.clear()}return {uid:now,epoch}}
 const valid=s=>!!s?.uid&&!disposed&&s.epoch===epoch&&s.uid===uid();
 async function db(){await deletion;if(disposed)return null;if(!dbp){const p=openDb();dbp=p;p.then(d=>{if(!d&&dbp===p)dbp=null;if(disposed)closeDb(d)})}return dbp}
 async function run(s,store,mode,fn){if(!valid(s))return null;const d=await db();if(!d||!valid(s))return null;return new Promise(resolve=>{let t,done=false;const finish=value=>{if(done)return;done=true;clearTimeout(timer);resolve(valid(s)?value:null)};const timer=setTimeout(()=>{try{t?.abort()}catch{}finish(null)},2000);try{t=d.transaction(store,mode);let value=null;const r=fn(t.objectStore(store));if(r&&'onsuccess'in r)r.onsuccess=()=>{value=r.result};t.oncomplete=()=>finish(value??null);t.onerror=t.onabort=()=>finish(null)}catch{finish(null)}})}
 const touch=(...args)=>queue=queue.then(()=>touchNow(...args)).catch(()=>{});
 async function touchNow(s,list,key,max,store,size=0){if(!valid(s))return;let order=(await run(s,'meta','readonly',st=>st.get(list)))||[];order=order.map(x=>typeof x==='string'?{key:x,size:0}:x).filter(x=>x&&typeof x.key==='string'&&x.key.startsWith(s.uid+'|')&&x.key!==key);order.push({key,size});let bytes=order.reduce((n,x)=>n+(Number(x.size)||0),0);const drop=[];while(order.length>max||(store==='media'&&bytes>mediaBudget&&order.length>1)){const x=order.shift();drop.push(x.key);bytes-=Number(x.size)||0}if(!valid(s))return;await run(s,'meta','readwrite',st=>st.put(order,list));if(drop.length)await run(s,store,'readwrite',st=>{for(const id of drop)st.delete(id)})}
 return {
  async thread(key){const s=owner(),id=s.uid+'|'+key;if(!valid(s))return null;const value=await bounded(run(s,'threads','readonly',st=>st.get(id)),readTimeout);return valid(s)&&value&&Array.isArray(value.messages)?value:null},
  saveThread(key,data,messages,cursor){const s=owner(),id=s.uid+'|'+key;if(!valid(s))return;clearTimeout(timers.get(id));let record;try{const clean={...(data||{})};for(const key of ['messages','changed','removed','typing'])delete clean[key];const rows=(messages||[]).filter(m=>m&&m.id>0).slice(-MSGS);const value={at:Date.now(),data:clean,messages:rows,cursor:cursor||0};record=typeof structuredClone==='function'?structuredClone(value):JSON.parse(JSON.stringify(value))}catch{return}
   timers.set(id,setTimeout(async()=>{timers.delete(id);if(!valid(s))return;await run(s,'threads','readwrite',st=>st.put(record,id));await touch(s,s.uid+'|threads',id,THREADS,'threads')},writeDelay))},
  async media(path){const s=owner(),id=s.uid+'|'+path;if(!valid(s))return null;const value=await bounded(run(s,'media','readonly',st=>st.get(id)),readTimeout);return valid(s)&&value instanceof Blob?value:null},
  async saveMedia(path,blob){const s=owner(),id=s.uid+'|'+path;if(!valid(s)||!(blob instanceof Blob)||!blob.size||blob.size>MEDIA_MAX)return;await run(s,'media','readwrite',st=>st.put(blob,id));await touch(s,s.uid+'|media',id,MEDIA,'media',blob.size)},
  async wipe(){if(disposed)return deletion;disposed=true;++epoch;for(const t of timers.values())clearTimeout(t);timers.clear();const pending=dbp;dbp=null;deletion=deletion.then(async()=>{for(const d of [...connections])closeDb(d);if(pending)pending.then(closeDb);await new Promise(resolve=>{const timer=setTimeout(resolve,1500);try{const r=indexedDB.deleteDatabase(NAME);r.onsuccess=r.onerror=()=>{clearTimeout(timer);resolve()};r.onblocked=()=>{for(const d of [...connections])closeDb(d)}}catch{clearTimeout(timer);resolve()}})});return deletion},
 };
}
