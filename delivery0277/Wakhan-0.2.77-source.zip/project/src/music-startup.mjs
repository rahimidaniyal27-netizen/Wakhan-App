import {musicSource} from './music-source.mjs';

// Catalogue audio URLs are already playable. Do not resolve the same public URL again.
export function readyCatalogueTrack(track,origin='https://music.kabulcafe.uk'){
 return !!track&&!track.embed&&['audius','archive','ccmixter'].includes(track.provider)&&!!musicSource(track.stream,origin);
}
export function startupTask(work,{signal,timeout=25000,code='audio_timeout'}={}){
 if(signal?.aborted)return Promise.reject(Error('cancelled'));
 return new Promise((resolve,reject)=>{
  let settled=false;
  const finish=(fn,value)=>{if(settled)return;settled=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);fn(value)};
  const abort=()=>finish(reject,Error('cancelled'));
  const timer=setTimeout(()=>finish(reject,Error(code)),timeout);
  signal?.addEventListener('abort',abort,{once:true});
  Promise.resolve().then(()=>{if(settled||signal?.aborted)throw Error('cancelled');return work()}).then(v=>finish(resolve,v),e=>finish(reject,e));
 });
}
export function startupProgress({loading,time,duration,position=0}){
 const length=Number.isFinite(Number(duration))&&Number(duration)>0?Number(duration):0;
 const raw=loading?position:time,elapsed=Number.isFinite(Number(raw))?Math.max(0,Number(raw)):0;
 return {time:length?Math.min(elapsed,length):elapsed,duration:length};
}
// Ask the browser to play as soon as a first buffer exists, rather than waiting
// for a separate metadata round-trip before even expressing playback intent.
export async function prepareBrowserAudio(audio,track,position=0,playing=true,{valid=()=>true,signal,timeout=15000}={}){
 let cleanup=()=>{};
 try{return await startupTask(()=>new Promise(resolve=>{
  let done=false,starting=false;
  const finish=value=>{if(done)return;done=true;cleanup();resolve(value)};
  const failed=()=>finish(false);
  const metadata=()=>{if(!valid())return finish(false);if(position>0){try{audio.currentTime=position}catch{}start()}};
  const start=()=>{if(starting||!valid())return;if(position>0&&audio.readyState<1)return;starting=true;
   if(!playing){finish(true);return}
   try{Promise.resolve(audio.play()).then(()=>finish(valid()),()=>finish(false))}catch{finish(false)}};
  const abort=()=>finish(false);
  cleanup=()=>{audio.removeEventListener('loadedmetadata',metadata);audio.removeEventListener('error',failed);signal?.removeEventListener('abort',abort)};
  audio.addEventListener('loadedmetadata',metadata);audio.addEventListener('error',failed);signal?.addEventListener('abort',abort,{once:true});
  audio.preload='auto';audio.src=track.stream;audio.load();start();
 }),{signal,timeout})}finally{cleanup()}
}

// Use catalogue identity/cover without another metadata lookup. Playback still
// goes through the authenticated server, which resolves and authorizes the ID.
export function readyExternalHint(track){
 try{const u=new URL(track.source_url);if(u.protocol!=='https:'||u.username||u.password||u.hash||u.search&&track.provider!=='youtube')return false;
  if(track.provider==='youtube')return /^yt\.[A-Za-z0-9_-]{11}$/.test(track.id)&&u.origin==='https://www.youtube.com'&&u.pathname==='/watch'&&u.searchParams.size===1&&u.searchParams.get('v')===track.id.slice(3);
  if(track.provider==='soundcloud'&&/^sc\.[A-Za-z0-9_-]+$/.test(track.id)&&u.origin==='https://soundcloud.com'&&/^\/[A-Za-z0-9_-]+\/[A-Za-z0-9_-]+$/.test(u.pathname)){
   const code=track.id.slice(3).replace(/-/g,'+').replace(/_/g,'/');return atob(code+'='.repeat((4-code.length%4)%4))===u.href;
  }
 }catch{}return false;
}
