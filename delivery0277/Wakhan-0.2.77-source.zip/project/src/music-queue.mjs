import {startupTask,startupProgress} from './music-startup.mjs';
/* One owner of queue advancement; catalogue refreshes never replace its snapshot. */
export function createMusicQueue({audio,resolve,local,prepare,onChange=()=>{},onError=()=>{},online=()=>navigator.onLine,random=Math.random,now=()=>performance.now(),startupTimeout=25000,localTimeout=120}){
 let queue=[],index=-1,current=null,serial=0,endedSerial=-1,busy=false,error='',repeat='all',shuffle=false,disposed=false,controller=null,requestedPosition=0,phase='idle',failedPhase='',started=0,startupMs=0;const history=[];
 const emit=()=>onChange(state());
 function state(){const timeline=startupProgress({loading:busy||!!error,time:audio.currentTime,duration:busy||error?current?.duration:Number(audio.duration)||current?.duration,position:requestedPosition});return {queue:queue.slice(),index,current,loading:busy,error,repeat,shuffle,paused:busy?false:audio.paused,...timeline,phase,failedPhase,startupMs:busy?Math.max(0,now()-started):startupMs}}
 async function start(i,position=0,playing=true){
  if(disposed||!queue[i])return false;
  const reused=current?.id===queue[i].id&&!error&&audio.readyState>=1;
  controller?.abort();controller=new AbortController();const signal=controller.signal;
  const seq=++serial;index=i;current=reused?current:queue[i];requestedPosition=Math.max(0,Number(position)||0);busy=true;error='';phase='local';failedPhase='';started=now();startupMs=0;
  // Stop the previous track before showing the new title/time. Its clock is never reused.
  audio.pause();if(!reused)audio.reset?.();emit();
  try{
   await startupTask(async()=>{
    if(reused){phase='prepare';audio.currentTime=requestedPosition;if(playing)await audio.play();return}
    const connected=online();
    const saved=await startupTask(()=>local(current.id),{signal,timeout:connected?localTimeout:1500,code:'storage'}).catch(e=>{if(e.message==='cancelled')throw e;return null});
    if(seq!==serial||disposed||signal.aborted)throw Error('cancelled');
    if(!saved&&!online())throw Error('offline');
    phase='resolve';
    const track=saved?{...current,...saved}:await resolve(current.id,()=>seq===serial&&!disposed&&!signal.aborted,{track:current,signal});
    if(seq!==serial||disposed||signal.aborted)throw Error('cancelled');
    if(!track||!track.stream)throw Error('unavailable');current={...track,local:!!saved};
    phase='prepare';
    const ok=await prepare(current,requestedPosition,playing,seq,signal);
    if(seq!==serial||disposed||signal.aborted)throw Error('cancelled');
    if(ok===false)throw Error('play');
   },{signal,timeout:startupTimeout});
   if(seq!==serial||disposed)return false;busy=false;phase='playing';startupMs=Math.max(0,now()-started);emit();return true;
  }catch(e){if(seq===serial&&!disposed){controller.abort();audio.pause();audio.reset?.();busy=false;failedPhase=phase;phase='error';startupMs=Math.max(0,now()-started);requestedPosition=0;error=['offline','subscription_required','audio_timeout','audio_unavailable'].includes(e.message)?e.message:'play';emit();onError(error)}return false}
 }

 async function play(items,i=0){if(!Array.isArray(items)||!items[i])return false;queue=items.slice();history.length=0;return start(i)}
 async function next(step=1,automatic=false){
  if(!queue.length||disposed)return false;
  if(automatic&&repeat==='one')return start(index);
  if(step<0&&(Number(audio.currentTime)||0)>3){audio.currentTime=0;emit();return true}
  if(step<0&&history.length)return start(history.pop());
  let candidates=queue.map((x,i)=>i).filter(i=>i!==index);
  if(!online()){
   const downloaded=await Promise.all(candidates.map(async i=>(await local(queue[i].id))?i:null));candidates=downloaded.filter(i=>i!==null);
  }
  if(!candidates.length){if((!automatic||repeat==='all')&&(online()||await local(queue[index].id)))return start(index);audio.pause();emit();return false}
  let i;
  if(shuffle&&step>0)i=candidates[Math.floor(random()*candidates.length)];
  else{
   i=step>0?candidates.find(i=>i>index):candidates.slice().reverse().find(i=>i<index);
   if(i===undefined){if(automatic&&repeat==='off'){audio.pause();emit();return false}i=step>0?candidates[0]:candidates[candidates.length-1]}
  }
  if(step>0)history.push(index);if(history.length>100)history.shift();return start(i);
 }
 function ended(){if(disposed||!current||busy||endedSerial===serial)return;endedSerial=serial;void next(1,true)}
 function toggle(){if(!current)return;if(busy){++serial;controller?.abort();audio.pause();audio.reset?.();busy=false;phase='paused';emit();return}if(phase==='paused'&&audio.readyState<1)return start(index,requestedPosition);if(audio.ended)return start(index);if(error){if(audio.readyState>=1){error='';void audio.play().catch(()=>{error='play';emit();onError('play')});emit();return}return start(index,audio.currentTime)}if(audio.paused){void audio.play().catch(()=>onError('play'))}else audio.pause();emit()}
 function seek(value){if(current){audio.currentTime=Math.max(0,Math.min(Number(value)||0,state().duration));emit()}}
 const failed=()=>{if(current&&!busy){error='play';emit();onError('play')}};audio.addEventListener('error',failed);
 const update=()=>{if(current)emit()};audio.addEventListener('ended',ended);for(const e of ['play','pause','timeupdate','durationchange','waiting','canplay'])audio.addEventListener(e,update);
 function stop(){++serial;controller?.abort();phase='idle';requestedPosition=0;audio.pause();audio.reset?.();current=null;queue=[];index=-1;busy=false;error='';emit()}
 return {state,play,next,toggle,seek,stop,retry:()=>start(index,audio.currentTime),setRepeat(v){repeat=['all','one','off'].includes(v)?v:'all';emit()},setShuffle(v){shuffle=!!v;emit()},append(track){if(!queue.some(x=>x.id===track.id))queue.push(track);emit()},remove(i){if(i===index||i<0||i>=queue.length)return;queue.splice(i,1);if(i<index)index--;emit()},dispose(){disposed=true;stop();audio.removeEventListener('ended',ended);audio.removeEventListener('error',failed);for(const e of ['play','pause','timeupdate','durationchange','waiting','canplay'])audio.removeEventListener(e,update)}};
}
