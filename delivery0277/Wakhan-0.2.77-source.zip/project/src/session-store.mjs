/* Native credentials live in Keychain / Android Keystore, never in web storage. */
import {AuthError} from './session.mjs';
const ALLOWED=new Set(['session','pair','server']);
function legacyValid(key,raw,origin){
 try{
  if(key==='server')return raw===origin;
  const v=JSON.parse(raw);
  if(v?.origin!==origin)return false;
  if(key==='session')return /^wka1\.[A-Za-z0-9_-]{24}\.[a-f0-9]{32}$/.test(v.key)&&Number.isSafeInteger(v.user?.id)&&v.user.id>0;
  return v.kind==='browser'&&['google','facebook'].includes(v.provider)&&Number.isFinite(v.expires)&&v.expires*1000>Date.now()&&typeof v.ticket==='string'&&typeof v.proof==='string';
 }catch{return false}
}

export function createSessionStore({native,available,plugin,legacyStorage,origin,memory=new Map()}){
 let tail=Promise.resolve();
 const serial=work=>{const result=tail.catch(()=>{}).then(work);tail=result;return result};
 const check=key=>{if(!ALLOWED.has(key))throw new AuthError('vault_unavailable');if(native&&!available)throw new AuthError('vault_unavailable')};
 const forget=key=>{try{legacyStorage?.removeItem('wkv_'+key)}catch{}};
 return {
  get:key=>serial(async()=>{
   check(key);if(!native)return memory.get(key)||null;
   try{
    const result=await plugin.get({key});
    if(result.value!=null){if(typeof result.value!=='string')throw Error();forget(key);return result.value}
    let old;try{old=legacyStorage?.getItem('wkv_'+key)}catch{}
    if(!old)return null;
    if(old.length>16384||!legacyValid(key,old,origin)){forget(key);return null}
    await plugin.set({key,value:old}); // Remove the old copy only after durable secure storage succeeds.
    forget(key);return old;
   }catch{throw new AuthError('vault_unavailable')}
  }),
  set:(key,value)=>serial(async()=>{
   check(key);if(typeof value!=='string'||value.length>16384)throw new AuthError('vault_unavailable');
   if(!native){memory.set(key,value);return}
   try{await plugin.set({key,value});forget(key)}catch{throw new AuthError('vault_unavailable')}
  }),
  remove:key=>serial(async()=>{
   check(key);forget(key);
   if(!native){memory.delete(key);return}
   try{await plugin.remove({key})}catch{throw new AuthError('vault_unavailable')}
  })
 };
}
