import test from 'node:test';import assert from 'node:assert/strict';import {externalAudio} from '../src/music-audio.mjs';
const legacy=fn=>async(url,options)=>url.includes('/api/app/music/audio-start?')?response({},404):fn(url,options);
const track={id:'yt.abcdefghijk',provider:'youtube',source_url:'https://www.youtube.com/watch?v=abcdefghijk',cover:'https://i.ytimg.com/vi/abcdefghijk/hqdefault.jpg',embed:true};const response=(data,status=200)=>({ok:status===200,status,json:async()=>data});
test('uses existing authenticated preparation and keeps original identity/cover; no video or download',async()=>{let n=0,clock=0;const t=await externalAudio({track,fetchBinary:legacy(async url=>{assert(url.startsWith('https://music.kabulcafe.uk/api/v60/audio?'));return ++n===1?response({ok:false,pending:true}):response({ok:true,src:'/a/wm60_audio_file.m4a?lease=private',dur:180})}),delay:async ms=>clock+=ms,now:()=>clock});assert.equal(n,2);assert.equal(t.embed,false);assert.equal(t.id,track.id);assert.equal(t.cover,track.cover);assert.equal(t.playback,'audio');assert.equal(t.stream,'https://music.kabulcafe.uk/api/app/music/media/wm60_audio_file.m4a?lease=private');assert.equal(t.downloadable,false)});
test('cancelled selection stops polling without creating a player',async()=>{let current=true,calls=0;await assert.rejects(externalAudio({track,valid:()=>current,fetchBinary:legacy(async()=>{calls++;return response({pending:true})}),delay:async()=>{current=false}}),/cancelled/);assert.equal(calls,1)});
test('subscription, unavailability and untrusted audio paths are preserved as errors',async()=>{for(const [r,err]of [[response({err:'subscription_required'},403),'subscription_required'],[response({err:'auth'},401),'auth'],[response({ok:true,src:'https://evil.test/file.mp3'}),'audio_unavailable'],[response({ok:true,src:'/a/no-lease.m4a'}),'audio_unavailable'],[response({ok:true,playback:'youtube',video_id:'abcdefghijk'}),'audio_unavailable']])await assert.rejects(externalAudio({track,fetchBinary:async()=>r}),new RegExp(err))});
test('only external music sources use preparation and pending jobs have a deadline',async()=>{const direct={provider:'archive'};assert.equal(await externalAudio({track:direct,fetchBinary:()=>{throw Error('unexpected')}}),direct);let time=0;await assert.rejects(externalAudio({track,fetchBinary:legacy(async()=>response({pending:true})),now:()=>time,delay:async()=>time+=3000,timeout:1000}),/audio_timeout/)});

test('a source that never answers cannot exceed its complete preparation deadline',async()=>{
 const started=performance.now();await assert.rejects(externalAudio({track,fetchBinary:()=>new Promise(()=>{}),timeout:15}),/audio_timeout/);assert(performance.now()-started<250);
});
test('a JSON body that stalls is bounded too, not only response headers',async()=>{
 await assert.rejects(externalAudio({track,fetchBinary:async()=>({status:200,ok:true,json:()=>new Promise(()=>{})}),timeout:15}),/audio_timeout/);
});
test('cancelling a selection passes the signal and prevents further polling',async()=>{
 const controller=new AbortController();let calls=0;
 const pending=externalAudio({track,signal:controller.signal,fetchBinary:async(url,options)=>{calls++;assert.equal(options.signal,controller.signal);return new Promise(()=>{})}});
 await new Promise(r=>setTimeout(r,0));controller.abort();await assert.rejects(pending,/cancelled/);assert.equal(calls,1);
});

test('fast endpoint returns private audio directly without polling v60 or changing identity',async()=>{
 const calls=[],src='/api/app/music/play/'+'a'.repeat(32)+'/audio.m4a?lease=private';
 const value=await externalAudio({track,fetchBinary:async url=>{calls.push(url);return response({ok:true,src,dur:180})}});
 assert.equal(calls.length,1);assert(calls[0].includes('/api/app/music/audio-start?id=yt.abcdefghijk'));assert.equal(value.id,track.id);assert.equal(value.cover,track.cover);assert.equal(value.embed,false);assert.equal(value.downloadable,false);assert.equal(value.stream,'https://music.kabulcafe.uk'+src);
});
test('SoundCloud HLS keeps the same audio queue and private gateway',async()=>{
 const song={...track,id:'sc.test',provider:'soundcloud',source_url:'https://soundcloud.com/artist/song'};
 const value=await externalAudio({track:song,fetchBinary:async()=>response({ok:true,src:'/api/app/music/play/'+'a'.repeat(32)+'/index.m3u8?lease=private',dur:90})});
 assert.equal(value.provider,'soundcloud');assert.equal(value.embed,false);assert(value.stream.includes('/index.m3u8?lease='));
});
test('a denied fast endpoint never falls back to the older preparation path',async()=>{
 const calls=[];await assert.rejects(externalAudio({track,fetchBinary:async url=>{calls.push(url);return response({err:'subscription_required'},403)}}),/subscription_required/);assert.equal(calls.length,1);
});
