import test from 'node:test';
import assert from 'node:assert/strict';
import {createSessionStore} from '../src/session-store.mjs';
import {SessionBroker} from '../src/session.mjs';
const origin='https://music.kabulcafe.uk',key='wka1.'+'A'.repeat(24)+'.'+'b'.repeat(32);
const session=JSON.stringify({origin,key,user:{id:42}});
function fixture(overrides={}){
 const old=new Map([['wkv_session',session]]),secure=new Map(),calls=[];
 const legacyStorage={getItem:k=>old.get(k)||null,removeItem:k=>old.delete(k)};
 const plugin={get:async({key})=>({value:secure.get(key)||null}),set:async({key,value})=>{calls.push('set');secure.set(key,value)},remove:async({key})=>secure.delete(key),...overrides};
 const store=createSessionStore({native:true,available:true,plugin,legacyStorage,origin});return {old,secure,calls,store};
}
test('first native read migrates a valid old session into the platform vault and deletes plaintext',async()=>{
 const f=fixture();assert.equal(await f.store.get('session'),session);assert.equal(f.secure.get('session'),session);assert(!f.old.has('wkv_session'));
});
test('a failed vault write retains the previous session for a safe retry and never pretends success',async()=>{
 const f=fixture({set:async()=>{throw Error('locked')}});await assert.rejects(()=>f.store.get('session'),e=>e.code==='vault_unavailable');assert.equal(f.old.get('wkv_session'),session);assert.equal(f.secure.size,0);
});
test('native vault read failure never falls back to a plaintext credential',async()=>{
 const f=fixture({get:async()=>{throw Error('locked')}});await assert.rejects(()=>f.store.get('session'),e=>e.code==='vault_unavailable');assert.equal(f.secure.size,0);
});
test('a native binary without the vault cannot save credentials in localStorage',async()=>{
 const f=fixture();const s=createSessionStore({native:true,available:false,origin,legacyStorage:{getItem:()=>session}});
 for(const op of [()=>s.get('session'),()=>s.set('session',session),()=>s.remove('session')])await assert.rejects(op,e=>e.code==='vault_unavailable');
});
test('invalid or other-server legacy sessions are discarded rather than migrated',async()=>{
 for(const value of ['invalid',JSON.stringify({origin:'https://other.test',key,user:{id:42}})]){
  const f=fixture();f.old.set('wkv_session',value);assert.equal(await f.store.get('session'),null);assert.equal(f.old.size,0);assert.equal(f.secure.size,0);
 }
});
test('a migration cannot overwrite a login saved concurrently afterwards',async()=>{
 let read;const f=fixture({get:()=>new Promise(r=>read=r)});
 const migrated=f.store.get('session');await Promise.resolve();await Promise.resolve();
 const newer=f.store.set('session','newer');read({value:null});
 await migrated;await newer;assert.equal(f.secure.get('session'),'newer');assert.equal(f.old.size,0);
});
test('secure data wins over old plaintext and logout clears both copies',async()=>{
 const f=fixture();f.secure.set('session','secured');assert.equal(await f.store.get('session'),'secured');assert.equal(f.old.size,0);await f.store.remove('session');assert.equal(f.secure.size,0);
});
test('browser previews retain credentials in memory only',async()=>{
 let read=false;const s=createSessionStore({native:false,available:false,origin,legacyStorage:{getItem:()=>{read=true;return session}}});
 assert.equal(await s.get('session'),null);await s.set('session',session);assert.equal(await s.get('session'),session);await s.remove('session');assert.equal(await s.get('session'),null);assert(!read);
});
test('server logout is still attempted when secure deletion fails',async()=>{
 const calls=[];const broker=new SessionBroker({origin,store:{get:async()=>session,set:async()=>{},remove:async()=>{throw Error('vault locked')}},fetch:async(url,init)=>{calls.push({url,init});return Response.json({ok:true})}});
 await broker.restore();await assert.rejects(()=>broker.logout(),e=>e.code==='vault_unavailable');
 assert.equal(broker.session,null);assert.equal(calls.length,1);assert.equal(calls[0].url,origin+'/api/app/logout');assert.equal(calls[0].init.headers['X-Init'],key);
});
