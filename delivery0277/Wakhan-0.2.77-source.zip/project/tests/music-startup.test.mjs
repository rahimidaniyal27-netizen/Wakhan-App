import test from 'node:test';import assert from 'node:assert/strict';
import {startupTask,readyCatalogueTrack,prepareBrowserAudio}from '../src/music-startup.mjs';
import {createMusicQueue}from '../src/music-queue.mjs';
const track={id:'ia.one',provider:'archive',stream:'https://archive.org/download/album/one.mp3',duration:100};
class Audio extends EventTarget{paused=false;currentTime=89;duration=100;readyState=0;src='';playCalls=0;resets=0;pause(){this.paused=true;this.dispatchEvent(new Event('pause'))}reset(){this.resets++;this.currentTime=0;this.duration=NaN;this.readyState=0}load(){}async play(){this.playCalls++;this.paused=false;this.dispatchEvent(new Event('play'))}}
const tick=()=>new Promise(r=>setTimeout(r,0));
test('selection reports zero immediately while a previous track was at 89 seconds',async()=>{
 const audio=new Audio();let release;const snapshots=[];
 const queue=createMusicQueue({audio,local:async()=>null,resolve:()=>new Promise(r=>release=r),prepare:async()=>true,onChange:s=>snapshots.push(s),online:()=>true});
 const pending=queue.play([track]);assert.equal(queue.state().time,0);assert.equal(queue.state().duration,100);assert(queue.state().loading);assert(audio.paused);
 audio.currentTime=89;audio.dispatchEvent(new Event('timeupdate'));assert.equal(queue.state().time,0,'late native timing cannot move the new scrubber');
 await tick();release(track);await pending;queue.dispose();
});
test('a stuck local database cannot block online playback',async()=>{
 const audio=new Audio();let prepared=0;
 const queue=createMusicQueue({audio,local:()=>new Promise(()=>{}),resolve:async()=>track,prepare:async()=>{prepared++;await audio.play();return true},online:()=>true,localTimeout:8});
 const started=performance.now();assert(await queue.play([track]));assert.equal(prepared,1);assert(performance.now()-started<250);queue.dispose();
});
test('public catalogue audio needs no second resolver; external URLs still need entitlement/lease',()=>{
 assert(readyCatalogueTrack(track));assert(readyCatalogueTrack({provider:'audius',stream:'https://api.audius.co/v1/tracks/abc/stream?app_name=Wakhan'}));
 assert(!readyCatalogueTrack({...track,provider:'youtube'}));assert(!readyCatalogueTrack({...track,embed:true}));assert(!readyCatalogueTrack({...track,stream:'https://evil.test/audio'}));
});
test('one deadline stops a permanently pending resolver; a late result never reaches playback',async()=>{
 const audio=new Audio();let done,prepared=0,error;
 const queue=createMusicQueue({audio,local:async()=>null,resolve:()=>new Promise(r=>done=r),prepare:async()=>{prepared++;return true},onError:e=>error=e,online:()=>true,startupTimeout:15});
 assert.equal(await queue.play([track]),false);assert.equal(error,'audio_timeout');assert.equal(queue.state().loading,false);assert.equal(queue.state().time,0);
 done(track);await tick();assert.equal(prepared,0);queue.dispose();
});
test('new selection aborts the previous request and never starts its audio',async()=>{
 const audio=new Audio(),signals=[],prepared=[];let release;
 const queue=createMusicQueue({audio,local:async()=>null,resolve:async(id,valid,{signal})=>{signals.push(signal);return id==='ia.one'?new Promise(r=>release=r):{...track,id}},prepare:async t=>{prepared.push(t.id);return true},online:()=>true});
 const first=queue.play([track]);await tick();await queue.play([{...track,id:'ia.two'}]);assert(signals[0].aborted);release(track);await first;assert.deepEqual(prepared,['ia.two']);queue.dispose();
});
test('repeat of an already buffered file seeks and plays without resolver or new source',async()=>{
 const audio=new Audio();let resolves=0,prepares=0;
 const queue=createMusicQueue({audio,local:async()=>null,resolve:async()=>{resolves++;return track},prepare:async()=>{prepares++;audio.readyState=4;await audio.play();return true},online:()=>true});
 await queue.play([track]);audio.currentTime=100;audio.dispatchEvent(new Event('ended'));await tick();
 assert.equal(resolves,1);assert.equal(prepares,1);assert.equal(audio.currentTime,0);assert.equal(audio.playCalls,2);queue.dispose();
});
test('browser playback intent starts before metadata and cancellation removes callbacks',async()=>{
 const audio=new Audio();await prepareBrowserAudio(audio,track,0,true);assert.equal(audio.playCalls,1);assert.equal(audio.preload,'auto');
 const aborted=new AbortController();aborted.abort();await assert.rejects(prepareBrowserAudio(audio,track,0,true,{signal:aborted.signal}),/cancelled/);assert.equal(audio.playCalls,1);
});
test('cancelled queued work never runs after its caller has moved on',async()=>{
 const controller=new AbortController();let ran=false;const work=startupTask(()=>{ran=true},{signal:controller.signal});controller.abort();await assert.rejects(work,/cancelled/);assert.equal(ran,false);
});


test('pause during preparation cancels its pending source and resumes on explicit play',async()=>{
 const audio=new Audio();let done,calls=0,prepared=0;
 const queue=createMusicQueue({audio,local:async()=>null,resolve:()=>++calls===1?new Promise(r=>done=r):Promise.resolve(track),prepare:async()=>{prepared++;return true},online:()=>true});
 const loading=queue.play([track]);await tick();queue.toggle();assert.equal(queue.state().loading,false);assert(audio.paused);
 done(track);await loading;assert.equal(prepared,0);await queue.toggle();assert.equal(prepared,1);queue.dispose();
});

test('external catalogue hints avoid duplicate metadata lookup but do not accept a mismatched identity',async()=>{
 const {readyExternalHint}=await import('../src/music-startup.mjs');
 const song={id:'yt.abcdefghijk',provider:'youtube',source_url:'https://www.youtube.com/watch?v=abcdefghijk'};
 assert(readyExternalHint(song));assert(!readyExternalHint({...song,id:'yt.otherotherx'}));assert(!readyExternalHint({...song,source_url:'https://evil.test/watch?v=abcdefghijk'}));
 const url='https://soundcloud.com/singer/song',id='sc.'+btoa(url).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
 assert(readyExternalHint({id,provider:'soundcloud',source_url:url}));assert(!readyExternalHint({id,provider:'soundcloud',source_url:url+'x'}));
});
test('native audio source accepts only leased, exact gateway routes',async()=>{
 const {musicSource}=await import('../src/music-source.mjs');const base='https://music.kabulcafe.uk/api/app/music/play/'+'a'.repeat(32);
 assert(musicSource(base+'/audio.m4a?lease=one'));assert(musicSource(base+'/index.m3u8?lease=one'));
 for(const s of ['/audio.m4a','/audio.m4a?lease=','/audio.m4a?lease=one&url=https://evil.test','/segment.bin?lease=one'])assert.equal(musicSource(base+s),null);
});
