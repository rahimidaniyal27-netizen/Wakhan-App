import test from 'node:test';import assert from 'node:assert/strict';import {installNativeMusic}from '../src/native-music.mjs';
class Audio extends EventTarget{paused=true;src='';pause(){this.paused=true}play(){this.paused=false;return Promise.resolve()}load(){}removeAttribute(){this.src=''}}
function fixture(){let consumer;const requests=[],commands=[];const native=installNativeMusic({enabled:true,origin:'https://music.kabulcafe.uk',player:{async addListener(_,fn){consumer=fn;return{remove(){}}},async loadTrack(value){requests.push(value);return {id:value.id,ready:true,playing:false,wanted:true,duration:90,position:0}},async control(c){commands.push(c)},async stopAll(){}}});const audio=native.wrap(new Audio());return{native,audio,requests,commands,send:v=>consumer(v)}}
const source={src:'https://archive.org/download/album/one.mp3',title:'Song'};
const tick=()=>new Promise(r=>setTimeout(r,0));
test('native preparation waits for real playback, not merely metadata-ready',async()=>{
 const f=fixture();let settled=false;const prepared=f.native.prepare(source,0,true).then(v=>{settled=true;return v});await tick();assert.equal(settled,false);assert.equal(f.requests.length,1);
 f.send({id:f.requests[0].id,ready:true,playing:true,wanted:true,position:0.1,duration:90});assert.equal(await prepared,true);await f.native.shutdown();
});
test('old native timing cannot overwrite a new request and stop releases preparation',async()=>{
 const f=fixture(),first=f.native.prepare(source,0,true);await tick();const old=f.requests[0].id;
 const second=f.native.prepare({...source,src:'https://archive.org/download/album/two.mp3'},0,true);await tick();assert.equal(await first,false);
 f.send({id:old,ready:true,playing:true,wanted:true,position:80,duration:90});assert.equal(f.audio.currentTime,0);
 await f.native.shutdown();assert.equal(await second,false);
});
test('a native buffering failure exits preparation instead of hanging',async()=>{
 const f=fixture(),prepared=f.native.prepare(source,0,true);await tick();f.send({id:f.requests[0].id,error:'NETWORK',ready:false,playing:false,wanted:true});assert.equal(await prepared,false);await f.native.shutdown();
});
