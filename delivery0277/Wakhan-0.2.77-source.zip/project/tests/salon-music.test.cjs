const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const shell=JSON.parse(fs.readFileSync(path.resolve(__dirname,'../public/wakhan-shell.json'),'utf8'));
const program=shell.programs.find(p=>p.id==='slr6.js').code;
const client=program.slice(program.indexOf('/* Shared salon music protocol.'));
assert(client.startsWith('/* Shared salon music protocol.'));
function fixture(){
 const calls=[],applied=[];let finish;
 const state={ok:true,_cid:'MUSIC1',vid:'aaaaaaaaaaa',mine:0,playing:true,ver:10,timeline_revision:5,music_generation:'cycle1'};
 const ctx={window:null,CID:'MUSIC1',CS:state,WMC:{},console,Map,Set,Number,Error,Promise,setTimeout,
  cinApply(){ctx.applies=(ctx.applies||0)+1},cinSet(j){applied.push(j);ctx.CS=j;ctx.cinApply()},
  async api(url,body){calls.push({url,body});return new Promise(resolve=>finish=resolve)},wmcFinishMedia(){}};
 ctx.window=ctx;vm.createContext(ctx);vm.runInContext(client,ctx);
 return {ctx,calls,applied,resolve:j=>finish(j),state};
}
const player={getDuration:()=>60,getCurrentTime:()=>60};
test('many ended callbacks send one transition and repeat using the same player',async()=>{
 const f=fixture();const tasks=Array.from({length:12},()=>f.ctx.wmcFinishMedia(player));
 assert.equal(f.calls.length,1);assert.equal(f.calls[0].url,'/api/media/salon/advance');
 f.ctx.cinApply();assert.equal(f.ctx.applies,undefined,'old timeline cannot seek/replay during completion');
 f.resolve({ok:true,repeat:true,state:{...f.state,ver:11,timeline_revision:6,music_generation:'cycle2',t:0}});
 await Promise.all(tasks);assert.equal(f.applied.length,1);assert.equal(f.ctx.CS.music_generation,'cycle2');
 assert(!f.calls.some(c=>c.body?.a==='load'),'repeat must not reload provider');
 assert.equal(f.ctx.applies,1);
});
test('late old polling response cannot undo the repeated cycle',async()=>{
 const f=fixture(),done=f.ctx.wmcFinishMedia(player);
 f.resolve({ok:true,state:{...f.state,ver:11,timeline_revision:6,music_generation:'cycle2',t:0}});await done;
 f.ctx.cinSet({...f.state,t:59});assert.equal(f.ctx.CS.music_generation,'cycle2');assert.equal(f.applied.length,1);
 f.ctx.cinSet({...f.state,ver:99,_cid:'OTHER'});assert.equal(f.applied.length,1);
});
test('a response for a salon left during the request cannot affect the new salon',async()=>{
 const f=fixture(),done=f.ctx.wmcFinishMedia(player);f.ctx.CID='OTHER';
 f.resolve({ok:true,state:{...f.state,ver:11,timeline_revision:6,music_generation:'cycle2'}});await done;
 assert.equal(f.applied.length,0);
});
test('search is one server request and SoundCloud enters the WAKHAN queue',async()=>{
 const f=fixture();const search=f.ctx.WakhanSalonMusic.search('شفیق مرید');
 assert(f.calls[0].url.startsWith('/api/media/salon/search?q='));f.resolve({ok:true,items:[],sources:{}});await search;
 const q=f.ctx.WakhanSalonMusic.add({src:'sc',url:'https://soundcloud.com/artist/song',title:'Song',dur:60,thumb:'https://cdn.example/cover'});
 assert.equal(f.calls.length,2);assert.equal(f.calls[1].url,'/api/media/salon/queue');assert.equal(f.calls[1].body.item.src,'soundcloud');
 assert.equal(f.calls[1].body.item.ref,'https://soundcloud.com/artist/song');assert.equal(f.calls[1].body.item.thumb,'https://cdn.example/cover');
 f.resolve({ok:true,next:[{src:'soundcloud'}]});await q;
});
test('manual next uses the same generation and simultaneous next taps coalesce',async()=>{
 const f=fixture(),a=f.ctx.WakhanSalonMusic.advance('next'),b=f.ctx.WakhanSalonMusic.advance('next');
 assert.equal(f.calls.length,1);assert.equal(f.calls[0].body.generation,'cycle1');assert.equal(f.calls[0].body.reason,'next');
 f.resolve({ok:true,repeat:true,state:{...f.state,ver:11,timeline_revision:6,music_generation:'cycle2'}});await Promise.all([a,b]);assert.equal(f.applied.length,1);
});
test('normal playback and early ended events do not call advance',async()=>{
 const f=fixture();await f.ctx.wmcFinishMedia({getDuration:()=>60,getCurrentTime:()=>1});assert.equal(f.calls.length,0);
 f.ctx.cinApply();assert.equal(f.ctx.applies,1);
});
test('failed transition may be retried, without replaying a successful cycle',async()=>{
 const f=fixture();let done=f.ctx.wmcFinishMedia(player);f.resolve({ok:false,err:'offline'});await done;
 done=f.ctx.wmcFinishMedia(player);assert.equal(f.calls.length,2);
 f.resolve({ok:true,stale:true,state:{...f.state,ver:11,timeline_revision:6,music_generation:'cycle2'}});await done;
 // A duplicated old callback cannot send the completed old cycle again.
 f.ctx.CS=f.state;await f.ctx.wmcFinishMedia(player);assert.equal(f.calls.length,2);
});

test('confirmed SoundCloud failure skips once; pending streams never skip',async()=>{
 const f=fixture();f.ctx.CS={...f.state,can:true,media:{kind:'soundcloud'}};
 let stream=f.ctx.api('/api/stream?u=https%3A%2F%2Fsoundcloud.com%2Fa%2Fb');
 f.resolve({ok:false,pending:1});await stream;await new Promise(r=>setTimeout(r,5));assert.equal(f.calls.length,1);
 stream=f.ctx.api('/api/stream?u=https%3A%2F%2Fsoundcloud.com%2Fa%2Fb');
 f.resolve({ok:false,err:'fail'});await stream;await new Promise(r=>setTimeout(r,5));
 assert.equal(f.calls.length,3);assert.equal(f.calls[2].body.reason,'unplayable');
 f.resolve({ok:true,state:{...f.state,ver:11,vid:'nextnextnext',music_generation:'two'}});await new Promise(r=>setTimeout(r,1));
 assert.equal(f.ctx.CS.vid,'nextnextnext');
});
