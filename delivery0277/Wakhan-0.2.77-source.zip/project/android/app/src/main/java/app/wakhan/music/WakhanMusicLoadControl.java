package app.wakhan.music;

import android.os.Bundle;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Timeline;
import androidx.media3.exoplayer.DefaultLoadControl;

/** Begin personal audio after 250 ms is buffered. Keep room and rebuffer rules. */
@androidx.media3.common.util.UnstableApi
public final class WakhanMusicLoadControl extends DefaultLoadControl {
    @Override public boolean shouldStartPlayback(Parameters parameters) {
        boolean normal = super.shouldStartPlayback(parameters);
        if (normal || parameters.rebuffering || parameters.timeline.isEmpty()) return normal;
        int index = parameters.timeline.getIndexOfPeriod(parameters.mediaPeriodId.periodUid);
        if (index == C.INDEX_UNSET) return normal;
        Timeline.Period period = parameters.timeline.getPeriod(index, new Timeline.Period());
        MediaItem item = parameters.timeline.getWindow(period.windowIndex, new Timeline.Window()).mediaItem;
        Bundle extras = item.mediaMetadata.extras;
        if (extras == null || !extras.getBoolean("wakhan.personal", false)) return normal;
        return startupReady(parameters.bufferedDurationUs, parameters.playbackSpeed);
    }
    static boolean startupReady(long bufferedUs, float speed) {
        return bufferedUs >= 250_000L * Math.max(1f, speed);
    }
}
