package app.wakhan.music;

import android.os.CancellationSignal;
import androidx.core.content.ContextCompat;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

/** Official account picker. No browser handoff, mail code or stored provider token. */
@CapacitorPlugin(name = "WakhanSignIn")
public class WakhanSignInPlugin extends Plugin {
    private CancellationSignal cancellation;

    @PluginMethod
    public void signIn(PluginCall call) {
        if (getActivity() == null) { call.reject("Sign-in unavailable", "provider_fail"); return; }
        if (!"google".equals(call.getString("provider"))) {
            call.reject("Provider unavailable on Android", "provider_bad");
            return;
        }
        String nonce = call.getString("nonce", "");
        String clientId = call.getString("serverClientId", "");
        if (!nonce.matches("[A-Za-z0-9_-]{32,128}") || !clientId.matches("[A-Za-z0-9_-]+\\.apps\\.googleusercontent\\.com")) {
            call.reject("Sign-in configuration unavailable", "provider_fail");
            return;
        }
        getActivity().runOnUiThread(() -> {
            if (cancellation != null) { call.reject("Sign-in already open", "wait"); return; }
            cancellation = new CancellationSignal();
            try {
                GetSignInWithGoogleOption option = new GetSignInWithGoogleOption.Builder(clientId).setNonce(nonce).build();
                GetCredentialRequest request = new GetCredentialRequest.Builder().addCredentialOption(option).build();
                CredentialManager.create(getActivity()).getCredentialAsync(getActivity(), request, cancellation,
                    ContextCompat.getMainExecutor(getActivity()), new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override public void onResult(GetCredentialResponse response) {
                            cancellation = null;
                            try {
                                if (!(response.getCredential() instanceof CustomCredential)) throw new IllegalArgumentException();
                                CustomCredential credential = (CustomCredential) response.getCredential();
                                if (!GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) throw new IllegalArgumentException();
                                String token = GoogleIdTokenCredential.createFrom(credential.getData()).getIdToken();
                                JSObject result = new JSObject(); result.put("idToken", token); call.resolve(result);
                            } catch (Exception ignored) { call.reject("Sign-in failed", "provider_fail"); }
                        }
                        @Override public void onError(GetCredentialException error) {
                            cancellation = null;
                            call.reject("Sign-in did not complete", error instanceof GetCredentialCancellationException ? "cancelled" : "provider_fail");
                        }
                    });
            } catch (Exception ignored) { cancellation = null; call.reject("Sign-in unavailable", "provider_fail"); }
        });
    }

    @Override protected void handleOnDestroy() {
        if (cancellation != null) { cancellation.cancel(); cancellation = null; }
        super.handleOnDestroy();
    }
}
