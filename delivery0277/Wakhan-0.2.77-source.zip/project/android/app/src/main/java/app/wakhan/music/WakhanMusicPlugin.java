package app.wakhan.music;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import org.json.JSONArray;
import androidx.core.content.ContextCompat;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.common.util.concurrent.ListenableFuture;

@CapacitorPlugin(name = "WakhanMusic")
public class WakhanMusicPlugin extends Plugin {
    private MediaController controller;
    private ListenableFuture<MediaController> connecting;
    private String requestId = "";
    private volatile String desiredId = "";
    private boolean visible = true;
    private boolean destroyed = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (destroyed || !visible || controller == null) return;
            publish();
            handler.postDelayed(this, 1000);
        }
    };

    private String roomCode="", roomToken="", roomVideo="", roomEpoch="", lastRoomEnd="";
    private int roomRevision=0;
    private boolean roomWanted=false,roomCanEnd=false,roomMuted=false,roomHTTP=false,roomApplying=false,roomProgramWanted=false;
    private double roomPosition=0;
    private long roomAt=0,lastRoomEndAt=0;
    private final ExecutorService roomNetwork=Executors.newSingleThreadExecutor();
    private final Runnable roomTick=new Runnable(){@Override public void run(){if(destroyed||roomCode.isEmpty())return;if(!visible)pollRoom();handler.postDelayed(this,3000);}};
    private void clearRoom(){handler.removeCallbacks(roomTick);roomCode="";roomToken="";roomVideo="";lastRoomEnd="";roomHTTP=false;}
    private double expectedRoomPosition(){return Math.max(0,roomPosition+(roomWanted?(android.os.SystemClock.elapsedRealtime()-roomAt)/1000.0:0));}
    private boolean allowedRemote(Uri uri){
        if(!"https".equals(uri.getScheme())||uri.getPort()!=-1||uri.getUserInfo()!=null||uri.getFragment()!=null||uri.getPath()==null)return false;
        String host=uri.getHost(),path=uri.getPath();
        return ("music.kabulcafe.uk".equals(host)&&(path.matches("/(a|api/app/music/media)/[A-Za-z0-9_-][A-Za-z0-9_.-]*")||(path.matches("/api/app/music/play/[a-f0-9]{32}/(audio\\.(m4a|mp3)|index\\.m3u8)")&&uri.getQueryParameter("lease")!=null&&!uri.getQueryParameter("lease").isEmpty())||(path.matches("/api/app/rooms/[A-Za-z0-9_-]{1,64}/video")&&uri.getQueryParameter("lease")!=null)))
            ||("api.audius.co".equals(host)&&path.matches("/v1/tracks/[A-Za-z0-9]{1,30}/stream")&&"app_name=Wakhan".equals(uri.getQuery()))
            ||("archive.org".equals(host)&&path.matches("/download/[A-Za-z0-9_.-]{1,180}/.+\\.mp3")&&uri.getQuery()==null)
            ||("ccmixter.org".equals(host)&&path.matches("/content/[^/]+/[^/]+\\.mp3")&&uri.getQuery()==null);
    }

    private interface Ready { void run(MediaController player); }
    private void ready(PluginCall call, Ready action) {
        getActivity().runOnUiThread(() -> {
            if (destroyed) { call.reject("PLAYER_UNAVAILABLE"); return; }
            if (controller != null) { action.run(controller); return; }
            if (connecting == null) {
                SessionToken token = new SessionToken(getContext(),
                    new ComponentName(getContext(), WakhanMusicService.class));
                connecting = new MediaController.Builder(getContext(), token).buildAsync();
            }
            ListenableFuture<MediaController> pending = connecting;
            pending.addListener(() -> {
                if (destroyed) { call.reject("PLAYER_UNAVAILABLE"); return; }
                if (pending != connecting) { call.reject("PLAYER_CANCELLED"); return; }
                try {
                    if (controller == null) {
                        controller = pending.get();
                        controller.addListener(new Player.Listener() {
                            @Override public void onEvents(Player player, Player.Events events) { publish();if(!visible&&!roomCode.isEmpty()&&player.getPlaybackState()==Player.STATE_ENDED)pollRoom(); }
                            @Override public void onPlayWhenReadyChanged(boolean playing,int reason){if(!roomCode.isEmpty()&&!roomApplying){if(reason==Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_BECOMING_NOISY)roomMuted=true;else if(!visible&&reason==Player.PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST&&playing!=roomProgramWanted){roomMuted=!playing;roomProgramWanted=playing;}}}
                            @Override public void onPlayerError(PlaybackException error) {
                                JSObject value = snapshot();
                                value.put("error", "PLAYBACK_FAILED");
                                value.put("errorCode", error.errorCode);
                                notifyListeners("state", value);
                            }
                        });
                        handler.removeCallbacks(tick); tick.run();
                    }
                    action.run(controller);
                } catch (Exception error) {
                    connecting = null; call.reject("PLAYER_UNAVAILABLE");
                }
            }, ContextCompat.getMainExecutor(getContext()));
        });
    }

    private JSObject snapshot() {
        JSObject value = new JSObject();
        value.put("backgroundOnly",!roomCode.isEmpty());
        value.put("id", controller != null && controller.getCurrentMediaItem() != null
            ? controller.getCurrentMediaItem().mediaId : requestId);
        if (controller == null) { value.put("active", false); return value; }
        long duration = controller.getDuration();
        int state = controller.getPlaybackState();
        value.put("active", controller.getMediaItemCount() > 0 && state != Player.STATE_IDLE && state != Player.STATE_ENDED);
        value.put("ready", state == Player.STATE_READY);
        value.put("buffering", state == Player.STATE_BUFFERING);
        value.put("ended", state == Player.STATE_ENDED);
        value.put("playing", controller.isPlaying());
        value.put("wanted", controller.getPlayWhenReady());
        value.put("position", Math.max(0, controller.getCurrentPosition()) / 1000.0);
        value.put("duration", duration == C.TIME_UNSET ? 0 : Math.max(0, duration) / 1000.0);
        return value;
    }

    private void publish() {
        if (!destroyed && controller != null) notifyListeners("state", snapshot());
    }

    @PluginMethod public void loadTrack(PluginCall call) {
        String source = call.getString("source", "");
        String id = call.getString("id", "");
        Uri uri = Uri.parse(source);
        boolean allowed=allowedRemote(uri);
        String path=uri.getPath();
        if ("file".equals(uri.getScheme()) && uri.getQuery() == null && uri.getFragment() == null && path != null) {
            try {
                java.io.File file = new java.io.File(path);
                java.io.File folder = new java.io.File(getContext().getFilesDir(), "wakhan-music");
                allowed = file.isFile() && file.getCanonicalFile().getParentFile().equals(folder.getCanonicalFile()) && file.getName().matches("u[0-9]{1,18}_[a-f0-9]{64}\\.mp3");
            } catch (java.io.IOException error) { allowed = false; }
        }
        if (!allowed || !id.matches("[A-Za-z0-9_-]{1,64}")) { call.reject("INVALID_AUDIO_SOURCE"); return; }
        final String code=call.getString("roomCode",""),token=call.getString("roomToken","");
        if(!code.isEmpty()&&(!code.matches("[A-Za-z0-9_-]{1,64}")||!token.matches("wka1\\.[A-Za-z0-9_-]{24}\\.[a-f0-9]{32}")||!"music.kabulcafe.uk".equals(uri.getHost())||!uri.getPath().equals("/api/app/rooms/"+code+"/video"))){call.reject("INVALID_ROOM_CONTEXT");return;}
        desiredId = id;
        ready(call, player -> {
            if (!id.equals(desiredId)) { call.resolve(); return; }
            clearRoom();roomCode=code;roomToken=token;roomVideo=call.getString("roomVideo","");roomRevision=call.getInt("roomRevision",0);roomCanEnd=Boolean.TRUE.equals(call.getBoolean("roomCanEnd",false));roomWanted=Boolean.TRUE.equals(call.getBoolean("playing",true));roomPosition=Math.max(0,call.getDouble("position",0.0));roomAt=android.os.SystemClock.elapsedRealtime();roomMuted=Boolean.TRUE.equals(call.getBoolean("muted",false));
            requestId = id;
            android.os.Bundle musicExtras = new android.os.Bundle();
            musicExtras.putBoolean("wakhan.personal", code.isEmpty());
            MediaMetadata metadata = new MediaMetadata.Builder().setExtras(musicExtras)
                .setTitle(call.getString("title", "Wakhan"))
                .setArtist(call.getString("artist", "")).build();
            player.setMediaItem(new MediaItem.Builder().setMediaId(id).setUri(uri).setMediaMetadata(metadata).build());
            player.seekTo((long)(Math.max(0, call.getDouble("position", 0.0)) * 1000));
            player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO,true).build());
            roomProgramWanted=roomWanted&&(roomCode.isEmpty()||!visible);roomApplying=true;player.setPlayWhenReady(roomProgramWanted);roomApplying=false;
            if(!roomCode.isEmpty()){handler.removeCallbacks(roomTick);roomTick.run();}
            player.prepare();
            publish(); call.resolve(snapshot());
        });
    }

    @PluginMethod public void control(PluginCall call) {
        String id = call.getString("id", "");
        String action = call.getString("action", "");
        if (action.equals("stop") && id.equals(desiredId)) desiredId = "";
        ready(call, player -> {
            if (!id.equals(requestId)) { call.resolve(); return; }
            switch (action) {
                case "room-sync":roomMuted=Boolean.TRUE.equals(call.getBoolean("muted",roomMuted));roomPosition=Math.max(0,call.getDouble("position",0.0));roomAt=android.os.SystemClock.elapsedRealtime();roomWanted=Boolean.TRUE.equals(call.getBoolean("playing",false));if(!visible){roomProgramWanted=roomWanted&&!roomMuted;roomApplying=true;player.setPlayWhenReady(roomProgramWanted);roomApplying=false;}break;
                case "play":roomMuted=false; if (player.getPlaybackState() == Player.STATE_IDLE) player.prepare(); player.play(); break;
                case "pause":roomMuted=true; player.pause(); break;
                case "seek": player.seekTo((long)(Math.max(0, call.getDouble("position", 0.0)) * 1000)); break;
                case "stop":clearRoom(); player.stop(); player.clearMediaItems(); requestId = ""; break;
                default: call.reject("INVALID_PLAYER_ACTION"); return;
            }
            publish(); call.resolve(snapshot());
        });
    }

    @PluginMethod public void state(PluginCall call) {
        getActivity().runOnUiThread(() -> call.resolve(snapshot()));
    }

    @PluginMethod public void stopAll(PluginCall call) {
        desiredId = "";clearRoom();
        getActivity().runOnUiThread(() -> {
            if (controller != null) { controller.stop(); controller.clearMediaItems(); }
            requestId = "";
            getContext().stopService(new Intent(getContext(), WakhanMusicService.class));
            handler.removeCallbacks(tick);
            if (connecting != null) MediaController.releaseFuture(connecting);
            connecting = null; controller = null;
            call.resolve();
        });
    }

    private void pollRoom(){
        if(roomCode.isEmpty()||visible||roomHTTP||controller==null)return;
        String endKey=roomVideo+"|"+roomRevision+"|"+roomEpoch;JSONObject action=null;
        if(controller.getPlaybackState()==Player.STATE_ENDED&&roomCanEnd&&roomWanted&&!roomVideo.isEmpty()&&(!endKey.equals(lastRoomEnd)||android.os.SystemClock.elapsedRealtime()-lastRoomEndAt>5000)){
            action=new JSONObject();try{action.put("a","end");action.put("vid",roomVideo);action.put("timeline_revision",roomRevision);}catch(Exception ignored){}lastRoomEnd=endKey;lastRoomEndAt=android.os.SystemClock.elapsedRealtime();
        }
        roomRequest(action);
    }
    private void roomRequest(JSONObject action){
        final String code=roomCode,key=roomToken,id=requestId;roomHTTP=true;
        roomNetwork.execute(()->{
            JSONObject value=null;int status=0;
            try{
                HttpURLConnection connection=(HttpURLConnection)new URL("https://music.kabulcafe.uk/api/c/"+code+"?v=-1").openConnection();connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(10000);connection.setReadTimeout(12000);connection.setRequestProperty("X-Init",key);
                try{
                    if(action!=null){connection.setRequestMethod("POST");connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json");try(java.io.OutputStream output=connection.getOutputStream()){output.write(action.toString().getBytes(StandardCharsets.UTF_8));}}
                    status=connection.getResponseCode();if(status==200){try(InputStream input=connection.getInputStream();ByteArrayOutputStream output=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=input.read(b))!=-1){if(output.size()+n>7000000)throw new java.io.IOException("state size");output.write(b,0,n);}value=new JSONObject(output.toString("UTF-8"));}}
                }finally{connection.disconnect();}
            }catch(Exception ignored){}
            final JSONObject result=value;final int resultStatus=status;
            handler.post(()->{if(destroyed||!code.equals(roomCode)||!id.equals(requestId))return;roomHTTP=false;if(resultStatus==401||resultStatus==403||resultStatus==404){if(controller!=null){controller.pause();controller.clearMediaItems();}clearRoom();return;}if(result!=null&&result.optBoolean("ok"))applyRoom(result);});
        });
    }
    private void applyRoom(JSONObject state){
        if(controller==null||roomCode.isEmpty())return;
        if(state.optInt("mine",-1)<0){controller.pause();controller.clearMediaItems();clearRoom();return;}
        String vid=state.optString("vid","");JSONObject media=state.optJSONObject("media");JSONArray formats=media==null?null:media.optJSONArray("formats");JSONObject format=formats==null?null:formats.optJSONObject(0);
        Uri uri=null;try{uri=Uri.parse(new java.net.URI("https://music.kabulcafe.uk").resolve(format==null?"":format.optString("url","")).toString());}catch(Exception ignored){}
        if(!vid.matches("[A-Za-z0-9_-]{11}")||media==null||!"native".equals(media.optString("kind"))||uri==null||!allowedRemote(uri)||!uri.getPath().equals("/api/app/rooms/"+roomCode+"/video")||!vid.equals(uri.getQueryParameter("vid"))){roomProgramWanted=false;roomApplying=true;controller.pause();roomApplying=false;roomWanted=false;return;}
        double position=state.optDouble("t",0);if(!Double.isFinite(position)||position<0)return;
        int revision=state.optInt("timeline_revision",0);boolean changed=!vid.equals(roomVideo)||revision!=roomRevision;
        roomVideo=vid;roomRevision=revision;roomEpoch=state.optString("sync_epoch","");roomCanEnd=state.optBoolean("can");roomWanted=state.optBoolean("playing");roomPosition=position;roomAt=android.os.SystemClock.elapsedRealtime();roomApplying=true;
        if(changed||controller.getCurrentMediaItem()==null){controller.setMediaItem(new MediaItem.Builder().setMediaId(requestId).setUri(uri).setMediaMetadata(new MediaMetadata.Builder().setTitle(state.optString("title","Wakhan")).build()).build());controller.seekTo((long)(position*1000));controller.prepare();}
        else if(Math.abs(controller.getCurrentPosition()/1000.0-position)>3)controller.seekTo((long)(position*1000));
        roomProgramWanted=!visible&&roomWanted&&!roomMuted;controller.setPlayWhenReady(roomProgramWanted);roomApplying=false;publish();
    }
    @Override protected void handleOnPause() {visible=false;handler.removeCallbacks(tick);if(!roomCode.isEmpty()&&controller!=null){roomProgramWanted=roomWanted&&!roomMuted;roomApplying=true;controller.seekTo((long)(expectedRoomPosition()*1000));controller.setPlayWhenReady(roomProgramWanted);roomApplying=false;pollRoom();}}
    @Override protected void handleOnResume() {visible=true;if(!roomCode.isEmpty()&&controller!=null){roomProgramWanted=false;roomApplying=true;controller.pause();roomApplying=false;}handler.removeCallbacks(tick);tick.run();}
    @Override protected void handleOnDestroy() {
        destroyed=true;clearRoom();roomNetwork.shutdownNow();handler.removeCallbacksAndMessages(null);
        if(connecting!=null)MediaController.releaseFuture(connecting);controller=null;
    }
}
