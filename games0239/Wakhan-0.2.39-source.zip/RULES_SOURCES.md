# Rule references and limits of observation — 2026-11-17 UTC

The user's GAMES_REQUIREMENTS_DARI.md controls the implementation. Existing canonical IDs (patpal, bazaar, fiskot, ludo, chess, ono) and approved Home artwork were retained. No earlier repository files with the two named Home prompt filenames were found. Old Home prototype game engines were removed; live games have one authenticated parent transport.

| Reference | Inspected evidence | How it is used |
|---|---|---|
| https://www.pagat.com/national/afghanistan.html | Official page text, retrieved 2026-11-17 | Fis Kut: 52-card pack, four players in fixed partnerships, non-dealer's team selects trump. Dealing 5+8, score to 5 and timers are explicit Wakhan defaults. |
| https://handbook.fide.com/chapter/E012023 | FIDE Laws page, retrieved 2026-11-17; articles 5.2.2, 6.9 and 9 inspected | Legal chess, clock, mate/draw conditions. Vendored python-chess 1.11.2 replays complete history. Material dead-position tests are covered; arbitrary locked fortress reachability is not completely solved by this library. This is an explicit remaining rules limitation, not a claim of exhaustive FIDE adjudication. |
| https://handbook.fide.com/chapter/ChessEquipmentWithoutElectronicComponenets032026 | FIDE equipment text, retrieved 2026-11-17 | Distinct Staunton silhouettes, ivory/dark wood and contrasting squares. Original SVG assets; no FIDE artwork copied. |
| https://service.mattel.com/instruction_sheets/42001pr.pdf | Original PDF retrieved and extracted | Reference for the card-game family and +4 challenge. Ono follows the user's named Wakhan variant, including 2-second declaration priority and private evidence, and uses original artwork. |
| https://moonfroglabs.com/our-games/ | Official Moonfrog page retrieved | Identifies Ludo Club. Marketing description does not establish granular Classic rules. |
| https://play.google.com/store/apps/details?id=com.moonfrog.ludo.club&hl=en-GB | Official listing and first four screenshot images inspected, retrieved 2026-11-17 | Cross board, four yards, dice, pawn and player presentation are visible. Images are promotional and mix modes; they do not establish the detailed behavior of a Classic match. Reference images are review material only, never bundled in the app. |

## Ludo Club Classic observation ledger

No accessible live Classic session or clearly identified Classic gameplay video was available in this environment. Therefore no granular Classic rule is labelled as observed. The user explicitly permits the following Wakhan defaults where public evidence is inconclusive. The installed Ludo guide explains this.

| Scenario | Classic status | Implemented Wakhan default |
|---|---|---|
| Roll 6 / 6 with no legal move | Not established by public reference | Another subturn |
| Third consecutive 6 | Not established | Only third roll loses its move; earlier moves stay |
| Capture or final-home bonus | Not established | No bonus, except ordinary 6 bonus |
| Safe cells | Not established | Starts 0,13,26,39 plus 8,21,34,47 |
| Own overlap on ordinary cell / blockade | Not established | Own landing disallowed, pass-through permitted, no blockade |
| Entry / home path / exact finish | Not established in Classic | Entry consumes 6; shared relative 0..50, own final 51..56; exact finish |
| Single available token | Not established | User confirms the one legal choice |
| Timeout | Not established | 30 seconds for roll+selection; server rolls if needed and picks first legal ID |
| Three players | Not established | Three seats, no empty-colour turn |

Deterministic server tests cover each of these defaults; the renderer loads the path/finish/safe-cell JSON generated from the same Python geometry. No competitor assets or reward system were imported.

## Assets / licenses

- `project/public/games-ui/assets`: 52 original physical-card faces and back; original Ono faces/back; 12 original Staunton SVGs; authoritative Ludo coordinate JSON. Generator: `generate-game-art.py`, provenance file in assets.
- `project/public/games-ui/renderers/world.js`: original procedural house/market, identical instanced human/NPC models, copper teapot, folded cloth, fruit basket and generated materials. Map/collision dimensions come from the server's `maps.py`.
- `project/public/games-ui/vendor`: Three.js 0.160.1 and MIT license/provenance. Loaded only for a 3D match.
- `server/wakhan_games/vendor`: python-chess 1.11.2, upstream GPL-3.0-or-later license and source provenance. Included source is retained in the delivery archive; review license compatibility before distributing a differently licensed derivative.

No native iPhone/Android device, 2–3 GB phone, real microphone, public TURN path or real Classic session was tested. Chromium software-renderer measurements are labelled as such and are not a device performance claim.
