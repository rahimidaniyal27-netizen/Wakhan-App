from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).parent/'server'))
from wakhan_games import ludo
OUT=Path(__file__).parent/'project/public/games-ui/assets'
PIPS={'H':'M50 90C-12 53 0 5 29 12C42 13 50 23 50 28C58 11 75 7 87 14C115 38 87 65 50 90Z','D':'M50 2L93 50L50 98L7 50Z','C':'M50 12C28-2 14 31 34 45C0 29-5 67 20 70C32 72 42 63 46 57C44 78 38 83 30 90H70C61 81 56 74 54 57C70 84 102 62 86 42C80 34 65 36 58 42C77 27 68 0 50 12Z','S':'M50 2C35 22-1 45 10 65C21 85 42 70 46 58C44 78 37 84 30 94H70C60 83 56 74 54 58C63 80 92 76 94 58C98 38 64 19 50 2Z'}
def svg(body,w=630,h=880):return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}">{body}</svg>'
def pip(s,x,y,size,flip=False):return f'<g transform="translate({x} {y}) rotate({180 if flip else 0})"><use href="#pip" x="{-size/2}" y="{-size/2}" width="{size}" height="{size}"/></g>'
placements={2:[(315,245),(315,635)],3:[(315,230),(315,440),(315,650)],4:[(190,245),(440,245),(190,635),(440,635)],5:[(190,245),(440,245),(315,440),(190,635),(440,635)],6:[(190,y) for y in (235,440,645)]+[(440,y) for y in (235,440,645)],7:[(190,y) for y in (230,440,650)]+[(440,y) for y in (230,440,650)]+[(315,335)],8:[(190,y) for y in (230,440,650)]+[(440,y) for y in (230,440,650)]+[(315,335),(315,545)],9:[(190,y) for y in (205,360,520,675)]+[(440,y) for y in (205,360,520,675)]+[(315,440)],10:[(190,y) for y in (205,360,520,675)]+[(440,y) for y in (205,360,520,675)]+[(315,285),(315,595)]}
for suit,path in PIPS.items():
 color='#b7263a' if suit in 'HD' else '#192637'
 for value in range(2,15):
  rank={11:'J',12:'Q',13:'K',14:'A'}.get(value,str(value));defs=f'<defs><symbol id="pip" viewBox="0 0 100 100"><path fill="{color}" d="{path}"/></symbol><linearGradient id="paper" x2=".8" y2="1"><stop stop-color="#fffdf3"/><stop offset="1" stop-color="#eee8d9"/></linearGradient></defs>'
  corner=f'<g fill="{color}" font-family="Georgia,serif" font-size="88" font-weight="bold"><text x="28" y="94">{rank}</text><use href="#pip" x="28" y="112" width="64" height="64"/></g>'
  body=defs+'<rect x="4" y="4" width="622" height="872" rx="32" fill="url(#paper)" stroke="#d4ccba" stroke-width="8"/>'+corner+'<g transform="translate(630 880) rotate(180)">'+corner+'</g>'
  if value==14:body+=pip(suit,315,420,260)+f'<text x="315" y="670" text-anchor="middle" font-size="25" letter-spacing="8" fill="{color}" font-family="Georgia,serif">WAKHAN</text>'
  elif value<=10:
   for x,y in placements[value]:body+=pip(suit,x,y,100 if value<8 else 88,y>440)
  else:
   # Original two-way court illustrations; no third-party card art.
   crown={'J':'M-64-68L-70-90L60-90L72-55L35-68Z','Q':'M-65-66L-82-112L-32-88L0-125L32-88L82-112L65-66Z','K':'M-65-65L-80-115L-28-92L0-130L28-92L80-115L65-65Z'}[rank]
   face=f'<g id="court"><path d="M-125 240L-112 75Q0 5 112 75L125 240Z" fill="{color}" stroke="#c6a24c" stroke-width="15"/><path d="M-100 100L80 240M-70 74L110 210M-120 165L12 240" stroke="#e3c569" stroke-width="19"/><ellipse cy="-2" rx="64" ry="87" fill="#e3ba8c" stroke="#243852" stroke-width="6"/><path d="M-66-22L-62-78Q0-110 62-76L65-22L44-48L33-66Q-10-40-40-66L-42-36Z" fill="#28354d"/><path d="{crown}" fill="#e0b451" stroke="#805a30" stroke-width="5"/><path d="M-36-11H-18M20-11H38M-7 23Q3 28 10 22M-23 43Q0 53 23 42" fill="none" stroke="#43372e" stroke-width="7" stroke-linecap="round"/>'
   if rank=='K':face+='<path d="M-45 50L-20 103L0 84L22 104L46 48L21 66H-21Z" fill="#3b3a43"/><path d="M-105 200L-105 14M-131 58H-79" stroke="#e8d8a3" stroke-width="18"/>'
   elif rank=='Q':face+='<path d="M-69-15Q-102 30-79 126L-42 76M69-15Q102 30 79 126L42 76" fill="#4f3650"/><path d="M91 194L91 39" stroke="#c6a24c" stroke-width="9"/><g fill="#e9c5d9"><circle cx="91" cy="35" r="21"/><circle cx="70" cy="27" r="18"/><circle cx="109" cy="20" r="18"/></g>'
   else:face+='<path d="M-40 63Q0 78 44 60" fill="none" stroke="#7a4936" stroke-width="7"/><path d="M105 194L105-6M85 4L125 4" stroke="#e3c569" stroke-width="11"/>'
   face+='</g>';body+=f'<rect x="119" y="177" width="392" height="530" rx="6" fill="#e9d9ad" stroke="{color}" stroke-width="9"/><defs>{face}</defs><g transform="translate(315 325) scale(.91)"><use href="#court"/></g><g transform="translate(315 555) rotate(180) scale(.91)"><use href="#court"/></g>'+pip(suit,144,203,33)+pip(suit,486,677,33,True)
  (OUT/f'card-{suit}{value}.svg').write_text(svg(body))
back='<defs><pattern id="p" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M20 0L40 20L20 40L0 20Z" fill="none" stroke="#a9894d" stroke-width="2"/></pattern><linearGradient id="b"><stop stop-color="#20384d"/><stop offset="1" stop-color="#0a1526"/></linearGradient></defs><rect x="4" y="4" width="622" height="872" rx="32" fill="#eee7d8"/><rect x="22" y="22" width="586" height="836" rx="24" fill="url(#b)" stroke="#c6a24c" stroke-width="8"/><rect x="40" y="40" width="550" height="800" rx="16" fill="url(#p)"/><ellipse cx="315" cy="440" rx="185" ry="225" fill="#10243a" stroke="#d8b86c" stroke-width="10"/><path d="M185 355L242 534L315 417L389 534L445 355" fill="none" stroke="#d8b86c" stroke-width="26" stroke-linejoin="round"/><text x="315" y="630" fill="#e2c58a" text-anchor="middle" font-size="32" font-family="Georgia,serif" letter-spacing="8">WAKHAN</text>'
(OUT/'card-back.svg').write_text(svg(back))
colors={'r':'#c84250','y':'#dfa831','g':'#398475','b':'#3d6db5'}
values=[*map(str,range(10)),'skip','reverse','draw2','wild','wild4']
for color,fill in [*colors.items(),('w','#25354c')]:
 for value in values:
  if (color=='w')!=(value in ('wild','wild4')):continue
  label={'skip':'⊘','reverse':'⇄','draw2':'+2','wild':'✦','wild4':'+4'}.get(value,value)
  defs='<defs><linearGradient id="p" x2="1" y2="1"><stop stop-color="#fffced"/><stop offset="1" stop-color="#e4dfd1"/></linearGradient></defs>'
  b=defs+f'<rect x="3" y="3" width="624" height="874" rx="42" fill="url(#p)" stroke="#bfb5a1" stroke-width="6"/><rect x="30" y="30" width="570" height="820" rx="32" fill="{fill}"/><ellipse cx="315" cy="440" rx="205" ry="278" transform="rotate(24 315 440)" fill="#fff4db" opacity=".94"/>'
  if color=='w':
   for x,y,c in [(205,310,'r'),(320,310,'y'),(205,430,'b'),(320,430,'g')]:b+=f'<rect x="{x}" y="{y}" width="110" height="120" rx="16" fill="{colors[c]}" stroke="#fff4db" stroke-width="6"/>'
  b+=f'<text x="315" y="510" text-anchor="middle" font-size="{180 if len(label)>1 else 260}" font-weight="900" font-family="Arial,sans-serif" fill="{fill if color!="w" else "#fff7df"}" stroke="{fill}" stroke-width="5">{label}</text>'
  if value in ('6','9'):b+=f'<path d="M235 560H395" stroke="{fill}" stroke-width="15" stroke-linecap="round"/>'
  corner=f'<text x="65" y="135" font-size="86" font-weight="900" font-family="Arial,sans-serif" fill="#fff7e7">{label}</text>'
  b+=corner+'<g transform="translate(630 880) rotate(180)">'+corner+'</g>'
  b+='<text x="315" y="735" text-anchor="middle" font-size="39" font-family="Arial,sans-serif" font-weight="bold" fill="#fff9e8" letter-spacing="12">ONO</text>'
  (OUT/f'ono-{color}-{value}.svg').write_text(svg(b))
(OUT/'ono-back.svg').write_text(svg(back.replace('WAKHAN</text>','ONO</text>')))
# Original Staunton silhouettes, with independent ivory and dark-wood materials.
pieces={
 'p':'M35 79L40 55Q29 52 30 40A20 20 0 1 1 70 40Q71 52 60 55L65 79L76 89H24Z',
 'r':'M27 80L32 45L20 37V12H32V24H43V12H57V24H68V12H80V37L68 45L73 80L82 91H18Z',
 'n':'M24 81L31 62Q31 48 58 39L43 33L27 42L16 33L31 15L44 10L51 2L56 12Q77 18 78 43L72 80L83 91H17Z',
 'b':'M27 82L39 62Q26 51 33 32Q39 16 50 4Q62 18 68 33Q75 52 61 62L73 82L82 92H18Z',
 'q':'M25 81L35 51L16 20L36 31L50 12L64 31L84 20L65 51L75 81L84 93H16Z',
 'k':'M25 82L35 52Q22 41 31 30L42 24V18H32V8H43V0H57V8H68V18H58V24L69 30Q78 41 65 52L75 82L84 93H16Z'}
for side in 'wb':
 for name,path in pieces.items():
  light,mid,dark=('#fff8dc','#dfc99c','#b89462') if side=='w' else ('#876244','#3e2a20','#1b1514')
  defs=f'<defs><linearGradient id="wood"><stop stop-color="{light}"/><stop offset=".45" stop-color="{mid}"/><stop offset="1" stop-color="{dark}"/></linearGradient></defs>'
  b=defs+f'<ellipse cx="50" cy="108" rx="39" ry="8" fill="#000" opacity=".18"/><path d="{path}" fill="url(#wood)" stroke="{dark if side=="w" else light}" stroke-width="2.2" stroke-linejoin="round"/><path d="M22 92Q50 84 78 92L88 101Q50 112 12 101Z" fill="url(#wood)" stroke="{dark}" stroke-width="2"/><path d="M28 81H72M35 55H65" stroke="{light}" opacity=".5" stroke-width="3"/>'
  if name=='n':b+=f'<circle cx="43" cy="23" r="3.8" fill="{dark if side=="w" else "#e3c89b"}"/><path d="M60 19Q75 39 63 65" fill="none" stroke="{light}" stroke-width="4"/>'
  if name=='b':b+=f'<path d="M58 21L43 43" stroke="{dark if side=="w" else "#c5a67a"}" stroke-width="5"/>'
  if name=='q':
   for x,y in [(16,18),(36,28),(50,10),(64,28),(84,18)]:b+=f'<circle cx="{x}" cy="{y}" r="5" fill="url(#wood)" stroke="{dark}"/>'
  (OUT/f'chess-{side}{name}.svg').write_text(svg(b,100,120))
(OUT/'ludo-geometry.json').write_text(json.dumps(dict(path=ludo.PATH,finals=ludo.FINALS,starts=ludo.STARTS,safe=sorted(ludo.SAFE)),separators=(',',':')))
(OUT/'ART_PROVENANCE.md').write_text('Original Wakhan vector game artwork generated from project-owned geometry: 52 physical card faces with pip/court mapping, card backs, Ono color/action faces, 12 Staunton silhouettes, shared authoritative Ludo path JSON. No competitor card art or brand assets copied. Three.js MIT and chess engine GPL license texts kept with respective source dependencies.\n')
print(len(list(OUT.iterdir())),'artwork/model files generated.')
