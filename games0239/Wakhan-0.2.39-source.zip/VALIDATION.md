# Combined games + full canvas candidate

Not yet deployed to the production server. Native packages require a new build. The current production baseline remains 0.2.38-beta/build53.

Completed local checks are recorded in `game-tests/all.log`, `game-tests/ui-results.json`, `game-tests/voice-results.json`, and `project/review/edge-*-results.json`. The synthetic test server and all authentication bypasses are confined to game-tests; they are never installed on production.

| Area | Expected | Observed locally |
|---|---|---|
| All six lobbies | Canonical cover -> real match ID, capacities, manual host start | Authenticated HTTP tests and actual Home/iframe UI |
| Fiscut | Private 5+8 cards, fixed teams, follow suit, full hands to >=5 | Server complete match; UI full/mid-hand screenshots and corner selection |
| Ono | 108 cards, private hand, challenge/declaration windows and full result | Complete 2/6-player HTTP matches, penalty rule tests, full/mid UI |
| Ludo | Exact server die/geometry, four-token finish, 2/4 seats | Complete HTTP matches, deterministic rule scenarios, actual SVG/token UI; see Classic ledger |
| Chess | Full history/legal moves, 300+3, draws/mate/promotion | Rule tests, actual UI Fool's Mate and promotion dialog; general fortress limitation in RULES_SOURCES.md |
| Petpal | 4/9/13/16 players, role count, private preparation, camouflage/pose and catch | Rule/service tests, minimum/maximum timed complete matches, real WebGL view; touch/camera follow-up in progress |
| Bazaar | 4/10 players, private mission, take/deliver/threshold/three errors | Rule/service tests and timed complete matches; separate runner/guard WebGL views |
| Shared match lifecycle | Last seat once, start once, 20s invitations, 45s return, host migration, result once | HTTP/WS tests incl. transaction failure rollback |
| Voice | Membership-only relay, local tracks stop on exit, no auto microphone on return | WS scope test and two-browser fake-microphone live peer track; physical/TURN not tested |
| Full canvas | Art under clock on initial Me and Home scrolling; controls below measured insets | Four viewport sizes and nine inset variants in Chromium |
| Existing app | Me/Salon/Chat preserved except declared games tool route | Existing 73 tests pass; bundle patch manifest verifies all other program bytes |

Known limitations to disclose: exhaustive dead-fortress chess adjudication; no real phone/physical microphone/TURN validation; no granular observed Classic behavior. Games produce verified match statistics only. Wallets and XP ledgers are untouched. Overall game-ranking weighting remains at the prior policy until the user's pending weight choice is answered.
