def install(app,namespace):
    from .service import Games
    games=Games(namespace);games.routes(app);namespace['WKG_GAMES']=games
    from .rankings import install as install_rankings
    install_rankings(games,namespace)
    return games
