from .common import base,require,integer,finish,public,timeout,next_active
VERSION='ludo-wakhan-classic-fallback-1'
STARTS=(0,13,26,39);SAFE={0,8,13,21,26,34,39,47}
# Canonical clockwise physical path; renderer consumes this same model.
PATH=[(6,1),(6,2),(6,3),(6,4),(6,5),(5,6),(4,6),(3,6),(2,6),(1,6),(0,6),(0,7),(0,8),(1,8),(2,8),(3,8),(4,8),(5,8),(6,9),(6,10),(6,11),(6,12),(6,13),(6,14),(7,14),(8,14),(8,13),(8,12),(8,11),(8,10),(8,9),(9,8),(10,8),(11,8),(12,8),(13,8),(14,8),(14,7),(14,6),(13,6),(12,6),(11,6),(10,6),(9,6),(8,5),(8,4),(8,3),(8,2),(8,1),(8,0),(7,0),(6,0)]
FINALS=[[(7,i) for i in range(1,7)],[(i,7) for i in range(1,7)],[(7,i) for i in range(13,7,-1)],[(i,7) for i in range(13,7,-1)]]

def create(players,rng,now,options=None):
    require(2<=len(players)<=4,'capacity');s=base(players);colors=[0,2] if len(players)==2 else list(range(len(players)));s.update(colors=colors,tokens=[[-1]*4 for _ in players],turn=rng.randrange(len(players)),phase='roll',die=None,roll_id=0,sixes=0,deadline=now+30,last_move=None,turn_timed=False);return s

def location(s,seat,step):
    if step<0:return None
    color=s['colors'][seat]
    return ('track',(STARTS[color]+step)%52) if step<=50 else ('home',color,step)

def legal(s,seat,die=None):
    die=s['die'] if die is None else die;out=[]
    for i,pos in enumerate(s['tokens'][seat]):
        dest=0 if pos<0 and die==6 else pos+die if pos>=0 else -1
        if dest<0 or pos==56 or dest>56:continue
        loc=location(s,seat,dest)
        if loc[0]=='track' and loc[1] not in SAFE:
            if any(j!=i and location(s,seat,p)==loc for j,p in enumerate(s['tokens'][seat]) if p>=0):continue
        out.append(i)
    return out

def next_roll(s,now,extra=False):
    seat=s['turn']
    if not extra:
        if s['turn_timed'] and timeout(s,seat):leave(s,seat,now,None);return
        s['turn']=next_active(s,seat);s['sixes']=0;s['turn_timed']=False
    s.update(phase='roll',die=None,deadline=now+30)

def move(s,seat,token,now):
    require(token in legal(s,seat),'illegal_token');old=s['tokens'][seat][token];dest=0 if old<0 else old+s['die'];s['tokens'][seat][token]=dest;loc=location(s,seat,dest);taken=[]
    if loc[0]=='track' and loc[1] not in SAFE:
        for other in s['active']:
            if other==seat:continue
            for i,pos in enumerate(s['tokens'][other]):
                if location(s,other,pos)==loc:s['tokens'][other][i]=-1;taken.append([other,i])
    s['last_move']=dict(seat=seat,token=token,start=old,end=dest,captured=taken,roll_id=s['roll_id'],die=s['die'])
    if all(p==56 for p in s['tokens'][seat]):finish(s,[seat],tokens=s['tokens']);return
    next_roll(s,now,extra=s['die']==6)

def roll(s,now,rng):
    require(s['phase']=='roll','already_rolled');die=rng.randrange(1,7);s['die']=die;s['roll_id']+=1;s['sixes']=s['sixes']+1 if die==6 else 0
    if s['sixes']==3:s['last_move']=dict(seat=s['turn'],roll_id=s['roll_id'],die=6,reason='third_six');next_roll(s,now);return
    s['phase']='move'
    if not legal(s,s['turn']):s['last_move']=dict(seat=s['turn'],roll_id=s['roll_id'],die=die,reason='no_move');next_roll(s,now,extra=die==6)

def apply(s,seat,a,now,rng):
    require(not s['result'],'finished');require(seat==s['turn'] and seat in s['active'],'not_your_turn')
    if a.get('type')=='roll':require(s['phase']=='roll','already_rolled');roll(s,now,rng)
    elif a.get('type')=='move':require(s['phase']=='move','roll_first');move(s,seat,integer(a.get('token'),0,3),now)
    else:require(False,'invalid_action')
    s['timeouts'][seat]=0;s['turn_timed']=False

def leave(s,seat,now,rng):
    if s['result'] or seat not in s['active']:return
    s['active'].remove(seat);s['tokens'][seat]=[-2]*4
    if len(s['active'])==1:finish(s,s['active'],reason='opponent_left')
    elif not s['active']:finish(s,reason='incomplete')
    elif seat==s['turn']:s['turn']=next_active(s,seat);s.update(phase='roll',die=None,sixes=0,deadline=now+30,turn_timed=False)

def tick(s,now,rng):
    if s['result'] or now<s['deadline']:return False
    s['turn_timed']=True;seat=s['turn']
    if s['phase']=='roll':roll(s,now,rng)
    if not s['result'] and s['turn']==seat and s['phase']=='move':move(s,seat,legal(s,seat)[0],now)
    return True

def view(s,seat,now):
    v=public(s);v['legal']=legal(s,seat) if seat==s['turn'] and s['phase']=='move' and not s['result'] else [];return v
