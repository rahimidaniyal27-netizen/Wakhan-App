import math,secrets,copy
from .common import base,require,integer,finish
from . import maps
VERSION='action-world-wakhan-1'
POSES={'stand':(.27,1.7),'sit':(.36,1.05),'lie':(.65,.38),'lean':(.46,1.6)}
PALETTES=[['#bd8c65','#537d78','#4c5774','#453c35'],['#c29a76','#975962','#6d6c47','#4b4238'],['#a47c5a','#82719b','#526b75','#463d38'],['#d0ad84','#a47e45','#66754f','#514737']]
MISSIONS=[dict(item='teapot',source='copper',target='tea',text='چاینک را از مسگر بگیر و به چای‌فروش برسان.'),dict(item='cloth',source='cloth',target='tailor',text='پارچه را از پارچه‌فروش بگیر و به خیاط برسان.'),dict(item='basket',source='fruit',target='porter',text='سبد را از میوه‌فروش بگیر و به باربر برسان.')]

def dist(a,b):return math.hypot(a[0]-b[0],a[1]-b[1])
def finite(value,limit=1000):return type(value) in (int,float) and math.isfinite(value) and abs(value)<=limit

def clear_position(m,x,z,pose='stand'):
    radius,height=POSES[pose];xmin,xmax,zmin,zmax=m['bounds']
    if not xmin+radius<=x<=xmax-radius or not zmin+radius<=z<=zmax-radius:return False
    for o in m['objects']:
        if not o['solid'] or o['h']+o['y']<=.15 or o['y']>=height:continue
        # Circle/AABB collision avoids fictitious traps at box corners.
        dx=max(abs(x-o['x'])-o['w']/2,0);dz=max(abs(z-o['z'])-o['d']/2,0)
        if dx*dx+dz*dz<radius*radius:return False
    return True

def line_clear(m,a,b,ignore=None):
    # Segment slab intersection in x/y/z. It uses the same visible solid bounds.
    for o in m['objects']:
        if not o['solid'] or o['id']==ignore:continue
        low=(o['x']-o['w']/2,o['y'],o['z']-o['d']/2);high=(o['x']+o['w']/2,o['y']+o['h'],o['z']+o['d']/2);lo,hi=0.,1.
        for i in range(3):
            delta=b[i]-a[i]
            if abs(delta)<1e-9:
                if not low[i]<=a[i]<=high[i]:lo=2;break
            else:
                u,v=(low[i]-a[i])/delta,(high[i]-a[i])/delta;lo=max(lo,min(u,v));hi=min(hi,max(u,v))
        if lo<=hi and hi>.001 and lo<.999:return False
    return True

def eye(p):return (p['x'],max(.3,POSES[p['pose']][1]*.9),p['z'])
def in_view(s,p,target,reach=30,cone=math.pi*.42):
    dx,dz=target['x']-p['x'],target['z']-p['z'];d=math.hypot(dx,dz)
    if d>reach:return False
    if d>.15:
        angle=math.atan2(dx,dz)-p['yaw'];angle=(angle+math.pi)%(2*math.pi)-math.pi
        if abs(angle)>cone:return False
    return line_clear(s['map'],eye(p),(target['x'],max(.2,POSES[target.get('pose','stand')][1]*.55),target['z']))

def zone(m,x,z):
    return next((n['name'] for n in m['zones'] if n['rect'][0]<=x<=n['rect'][1] and n['rect'][2]<=z<=n['rect'][3]),'گذر')

def create(players,rng,now,options=None):
    options=options or {};game=options.get('game','patpal');n=len(players);require(4<=n<=(16 if game=='patpal' else 10),'capacity')
    s=base(players);seed=secrets.token_hex(8);m=maps.build(game,seed);order=[u for u in options.get('role_queue',[]) if u in players];fresh=[u for u in players if u not in order];rng.shuffle(fresh);order.extend(fresh)
    count=(1 if n<=8 else 2 if n<=12 else 3) if game=='patpal' else 1;hunters=[players.index(u) for u in order[:count]];role_queue=order[count:]+order[:count]
    people=[]
    for seat,uid in enumerate(players):
        x,z=m['spawns'][seat];paint=list(PALETTES[seat%len(PALETTES)]);role=('seeker' if seat in hunters else 'hider') if game=='patpal' else ('guard' if seat in hunters else 'runner')
        if role=='seeker':x,z=-1+2*hunters.index(seat),17
        people.append(dict(entity=secrets.token_hex(5),seat=seat,role=role,x=x,z=z,yaw=math.pi if role in ('guard','seeker') else 0.,pose='stand',paint=paint,original=paint[:],samples=[],status='active',motion_at=now,input_seq=0,last_valid=[x,z],cooldown=0,found=0,torch=False,mission=None,carry=None,gesture_until=0))
        if role=='runner':mission=copy.deepcopy(MISSIONS[(seat+int(seed[:4],16))%3]);mission['stage']='not_taken';people[-1]['mission']=mission
    npcs=[]
    if game=='bazaar':
        for i in range(18):
            x,z=m['npc_path'][i%len(m['npc_path'])];npcs.append(dict(entity=secrets.token_hex(5),x=x,z=z,yaw=0.,pose='stand',paint=list(PALETTES[i%4]),waypoint=(i+1)%len(m['npc_path']),speed=.9+(i%5)*.15,pause_until=now+(i%4),motion_at=now,carry=['teapot','cloth','basket',None][i%4],gesture_until=0))
    s.update(game=game,map=m,people=people,npcs=npcs,phase='intro',started=now,hide_until=now+5+(35 if game=='patpal' else 10),ends=now+5+(35 if game=='patpal' else 10)+120,deadline=now+5,role_queue=role_queue,errors=0,delivered=0,total=n-count,threshold=math.ceil((n-count)/2),hint=None,last_event=None,world_seq=0)
    for p in people:require(clear_position(m,p['x'],p['z'],p['pose']),'invalid_spawn')
    return s

def advance_motion(s,now):
    if s['result']:return False
    changed=False
    for npc in s['npcs']:
        dt=min(.2,max(0,now-npc['motion_at']));npc['motion_at']=now
        if now<npc['pause_until']:continue
        goal=s['map']['npc_path'][npc['waypoint']];d=dist((npc['x'],npc['z']),goal)
        if d<.1:
            npc['waypoint']=(npc['waypoint']+1)%len(s['map']['npc_path']);npc['pause_until']=now+.5+(npc['waypoint']%3)*.6;npc['gesture_until']=now+.6;continue
        vx=(goal[0]-npc['x'])/d;vz=(goal[1]-npc['z'])/d;npc['yaw']=math.atan2(vx,vz);x=npc['x']+vx*min(d,dt*npc['speed']);z=npc['z']+vz*min(d,dt*npc['speed'])
        if clear_position(s['map'],x,z):npc['x'],npc['z']=x,z;changed=True
        else:npc['waypoint']=(npc['waypoint']+1)%len(s['map']['npc_path']);npc['pause_until']=now+.2
    if changed:s['world_seq']+=1
    return changed

def _evaluate(s,now):
    hunters=[p for p in s['people'] if p['role'] in ('guard','seeker') and p['status']=='active'];runners=[p for p in s['people'] if p['role'] in ('runner','hider')];active=[p for p in runners if p['status']=='active'];found=[p for p in runners if p['status']=='caught'];left=[p for p in runners if p['status']=='left']
    def wins(roles,reason):
        seats=[p['seat'] for p in s['people'] if p['role'] in roles and p['status']!='left'];finish(s,seats,reason,found=len(found),survived=len(active),left=len(left),delivered=s['delivered'],total=s['total'],threshold=s['threshold'],errors=s['errors'])
    if not hunters and not active:finish(s,reason='incomplete');return
    if not hunters:wins(('hider','runner'),'opponent_left');return
    if s['game']=='patpal':
        if not active:wins(('seeker',),'opponent_left' if len(left)==len(runners) else 'all_found' if not left else 'found_and_left')
        elif now>=s['ends']:wins(('hider',),'survived')
    else:
        if s['delivered']>=s['threshold']:wins(('runner',),'missions_complete')
        elif not active:wins(('guard',),'opponent_left' if len(left)==len(runners) else 'captured')
        elif s['delivered']+sum(p['mission']['stage']!='delivered' for p in active)<s['threshold']:wins(('guard',),'threshold_unreachable')
        elif now>=s['ends']:wins(('guard',),'time')

def tick(s,now,rng):
    if s['result']:return False
    changed=False;phase='intro' if now<s['started']+5 else 'hide' if now<s['hide_until'] else 'search'
    if s['phase']!=phase:s['phase']=phase;s['deadline']=s['started']+5 if phase=='intro' else s['hide_until'] if phase=='hide' else s['ends'];changed=True
    if phase=='search' and s['game']=='patpal' and now>=s['ends']-25 and not s['hint']:
        remaining=[p for p in s['people'] if p['role']=='hider' and p['status']=='active']
        if remaining:p=rng.choice(remaining);s['hint']=zone(s['map'],p['x'],p['z']);changed=True
    _evaluate(s,now)
    return changed or s['result'] is not None

def _move(s,p,a,now):
    seq=integer(a.get('input_seq'),1,2**53-1);require(seq>p['input_seq'],'stale_input');vx,vz,yaw=a.get('x'),a.get('z'),a.get('yaw');require(all(finite(v) for v in (vx,vz,yaw)),'bad_input');p['input_seq']=seq;p['yaw']=yaw%(math.pi*2)
    require(s['phase']!='intro','controls_locked');require(not (s['phase']=='hide' and p['role'] in ('seeker','guard')),'controls_locked')
    dt=min(.2,max(0,now-p['motion_at']));p['motion_at']=now;length=math.hypot(vx,vz)
    if length>1:vx/=length;vz/=length
    speed=1.1 if s['phase']=='search' and p['role']=='hider' else 2.2 if p['role']=='runner' else 3.2;speed*=.45 if p['pose']=='lie' else .65 if p['pose']=='sit' else 1
    if not clear_position(s['map'],p['x'],p['z'],p['pose']):p['x'],p['z']=p['last_valid']
    steps=max(1,math.ceil(dt*speed/.08))
    for _ in range(steps):
        x=p['x']+vx*speed*dt/steps;z=p['z']+vz*speed*dt/steps
        if clear_position(s['map'],x,p['z'],p['pose']):p['x']=x
        if clear_position(s['map'],p['x'],z,p['pose']):p['z']=z
    if clear_position(s['map'],p['x'],p['z'],p['pose']):p['last_valid']=[p['x'],p['z']]
    s['world_seq']+=1
    return {'motion':True}

def apply(s,seat,a,now,rng):
    require(not s['result'],'finished');p=s['people'][seat];require(seat in s['active'] and p['status']=='active','not_active');kind=a.get('type')
    if kind=='move':return _move(s,p,a,now)
    require(s['phase']!='intro','controls_locked')
    if kind=='torch':require(p['role']=='seeker' and s['phase']=='search','not_allowed');p['torch']=a.get('on') is True;return
    if kind in ('sample','paint','erase','pose'):
        require(s['game']=='patpal' and p['role']=='hider' and s['phase']=='hide','camouflage_locked')
        if kind=='sample':
            o=next((o for o in s['map']['objects'] if o['id']==a.get('surface')),None);point=a.get('point');require(o and isinstance(point,list) and len(point)==3 and all(finite(v) for v in point),'bad_surface')
            require(abs(point[0]-o['x'])<=o['w']/2+.1 and abs(point[2]-o['z'])<=o['d']/2+.1 and o['y']-.1<=point[1]<=o['y']+o['h']+.1,'bad_surface');require(min(abs(point[0]-(o['x']-o['w']/2)),abs(point[0]-(o['x']+o['w']/2)),abs(point[1]-o['y']),abs(point[1]-(o['y']+o['h'])),abs(point[2]-(o['z']-o['d']/2)),abs(point[2]-(o['z']+o['d']/2)))<=.1,'bad_surface');require(math.dist(eye(p),point)<=2.2,'out_of_range');require(line_clear(s['map'],eye(p),point,o['id']),'occluded')
            if o['color'] not in p['samples']:require(len(p['samples'])<8,'sample_limit');p['samples'].append(o['color'])
        elif kind in ('paint','erase'):
            region=integer(a.get('region'),0,3)
            if kind=='erase':p['paint'][region]=p['original'][region]
            else:sample=integer(a.get('sample'),0,len(p['samples'])-1);p['paint'][region]=p['samples'][sample]
        else:
            pose=a.get('pose');require(pose in POSES,'bad_pose');require(clear_position(s['map'],p['x'],p['z'],pose),'no_space')
            if pose=='lean':require(any(o['solid'] and o['h']>=.6 and max(abs(p['x']-o['x'])-o['w']/2,0)**2+max(abs(p['z']-o['z'])-o['d']/2,0)**2<.6**2 for o in s['map']['objects']),'no_support')
            p['pose']=pose
        return
    if kind=='check':
        require(s['phase']=='search' and p['role'] in ('guard','seeker'),'not_allowed');require(now>=p['cooldown'],'cooldown');require(not (p['role']=='guard' and s['errors']>=3),'no_checks_left');target=next((v for v in s['people']+s['npcs'] if v['entity']==a.get('entity')),None)
        if target is None and p['role']=='seeker':
            point=a.get('point');require(isinstance(point,list) and len(point)==3 and all(finite(v) for v in point),'bad_target');require(math.dist(eye(p),point)<=3 and line_clear(s['map'],eye(p),point),'out_of_range_or_hidden');p['cooldown']=now+3;s['last_event']=dict(type='wrong_check');return
        require(target is not None and target is not p,'bad_target');require(target.get('status','active')=='active','already_caught');require(target.get('role') not in ('seeker','guard'),'bad_target');require(in_view(s,p,target,3),'out_of_range_or_hidden')
        if 'seat' in target:target['status']='caught';target['carry']=None;p['found']+=1;p['cooldown']=now+2;s['last_event']=dict(type='caught',entity=target['entity'])
        elif p['role']=='guard':s['errors']+=1;p['cooldown']=now+2;s['last_event']=dict(type='wrong_check',errors=s['errors'])
        else:p['cooldown']=now+3;s['last_event']=dict(type='wrong_check')
        _evaluate(s,now);return
    if kind in ('take','deliver'):
        require(s['game']=='bazaar' and p['role']=='runner' and s['phase']=='search','not_allowed');mission=p['mission'];require(mission['stage']==('not_taken' if kind=='take' else 'carrying'),'mission_order');key=mission['source'] if kind=='take' else mission['target'];shop=next(v for v in s['map']['shops'] if v['id']==key);require(dist((p['x'],p['z']),(shop['x'],shop['z']))<=1.8,'out_of_range');require(line_clear(s['map'],eye(p),(shop['x'],.8,shop['z'])),'occluded');mission['stage']='carrying' if kind=='take' else 'delivered';p['carry']=mission['item'] if kind=='take' else None;p['gesture_until']=now+.7
        if kind=='deliver':s['delivered']+=1
        _evaluate(s,now);return
    require(False,'invalid_action')

def leave(s,seat,now,rng):
    if s['result'] or seat not in s['active']:return
    s['active'].remove(seat);s['people'][seat]['status']='left';s['people'][seat]['carry']=None;_evaluate(s,now)

def view(s,seat,now,include_map=True):
    p=s['people'][seat];v=dict(game=s['game'],phase=s['phase'],deadline=s['deadline'],ends=s['ends'],result=copy.deepcopy(s['result']),role=p['role'],self=dict(entity=p['entity'],x=p['x'],z=p['z'],yaw=p['yaw'],pose=p['pose'],status=p['status'],paint=list(p['paint']),cooldown=p['cooldown'],torch=p['torch'],carry=p.get('carry'),gesture_until=p.get('gesture_until',0),input_seq=p['input_seq']),entities=[],world_seq=s['world_seq'],found=sum(q['status']=='caught' for q in s['people']),remaining=sum(q['role'] in ('hider','runner') and q['status']=='active' for q in s['people']))
    if include_map:v['map']=s['map']
    if p['role']=='hider':v.update(samples=list(p['samples']),original=list(p['original']))
    if p['role']=='runner':v['mission']=copy.deepcopy(p['mission'])
    if p['role']=='seeker':v['hint']=s['hint']
    if s['game']=='bazaar':v.update(errors=s['errors'],delivered=s['delivered'],total=s['total'],threshold=s['threshold'])
    if p['status']!='active' or s['phase']=='intro' or s['phase']=='hide' and p['role'] in ('seeker','guard'):return v
    for other in s['people']+s['npcs']:
        if other is p or other.get('status','active')!='active':continue
        if not in_view(s,p,other,30):continue
        v['entities'].append({k:copy.deepcopy(other.get(k)) for k in ('entity','x','z','yaw','pose','paint','carry','gesture_until')})
    return v
