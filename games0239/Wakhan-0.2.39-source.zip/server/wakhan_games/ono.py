from .common import base,require,integer,finish,public,timeout,next_active
VERSION='ono-wakhan-1'
COLORS=('r','y','g','b')
CARDS=[]
def _card(c,v):CARDS.append(dict(id=len(CARDS),color=c,value=str(v)))
for color in COLORS:
    _card(color,0)
    for value in [*range(1,10),'skip','reverse','draw2']:
        _card(color,value);_card(color,value)
for value in ('wild','wild4'):
    for _ in range(4):_card(None,value)
assert len(CARDS)==108

def create(players,rng,now,options=None):
    require(2<=len(players)<=6,'capacity');s=base(players);pile=list(range(108));rng.shuffle(pile);hands=[[] for _ in players]
    for _ in range(7):
        for h in hands:h.append(pile.pop())
    rejected=[]
    while not CARDS[pile[-1]]['value'].isdigit():rejected.append(pile.pop())
    first=pile.pop();pile.extend(rejected);rng.shuffle(pile)
    s.update(pile=pile,discard=[first],recycle=[],hands=hands,color=CARDS[first]['color'],direction=1,turn=rng.randrange(len(players)),phase='turn',deadline=now+25,drawn_id=None,effect=None,ono_window=None,challenge=None,last_effect=None,event_id=0,stall_turns=0,turn_progress=False)
    return s

def playable(s,card):
    c=CARDS[card];top=CARDS[s['discard'][-1]]
    return c['color'] is None or c['color']==s['color'] or c['value']==top['value']

def legal(s,seat):
    cards=[s['drawn_id']] if s['phase']=='drawn' and seat==s['turn'] else s['hands'][seat]
    return [c for c in cards if c is not None and c in s['hands'][seat] and playable(s,c)]

def draw(s,seat,count,rng):
    added=[]
    for _ in range(count):
        if not s['pile']:
            fresh=s['discard'][:-1]+s['recycle'];s['discard']=s['discard'][-1:];s['recycle']=[];rng.shuffle(fresh);s['pile']=fresh
        if not s['pile']:break
        c=s['pile'].pop();s['hands'][seat].append(c);added.append(c);s['turn_progress']=True
    return added

def note(s,kind,**fields):
    s['event_id']+=1;s['last_effect']=dict(id=s['event_id'],type=kind,**fields)

def check_win(s,actor):
    if actor in s['active'] and not s['hands'][actor]:finish(s,[actor],reason='normal')

def begin_turn(s,seat,now):
    if seat not in s['active']:seat=next_active(s,seat,direction=s['direction'])
    s.update(turn=seat,phase='turn',deadline=now+25,drawn_id=None,effect=None,ono_window=None,challenge=None)
    # With no source to draw from, a whole futile cycle is unnecessary: no
    # active player can legally make progress from this exact public top card.
    blocked=not s['pile'] and len(s['discard'])==1 and not s['recycle'] and not any(playable(s,c) for n in s['active'] for c in s['hands'][n])
    s['stall_turns']=s.get('stall_turns',0)+1 if blocked and not s.get('turn_progress') else 0;s['turn_progress']=False
    if s['stall_turns']>=len(s['active']):finish(s,reason='no_cards',draw=True)

def resolve_effect(s,now,rng):
    e=s['effect'];s['ono_window']=None
    if not e:return
    actor=e['actor'];value=CARDS[e['card']]['value'];target=e['target']
    if value=='wild4' and target in s['active']:
        s.update(phase='challenge4',turn=target,deadline=now+5,challenge=dict(actor=actor,target=target,had_color=e['had_color'],deadline=now+5));return
    next_seat=target
    if value=='reverse':
        s['direction']*=-1;next_seat=next_active(s,actor,direction=s['direction'])
        if len(s['active'])==2:next_seat=actor if actor in s['active'] else next_seat
    elif value=='skip':next_seat=next_active(s,target,direction=s['direction'])
    elif value=='draw2':
        count=len(draw(s,target,2,rng)) if target in s['active'] else 0;note(s,'draw2',seat=target,count=count);next_seat=next_active(s,target,direction=s['direction'])
    elif target not in s['active']:next_seat=next_active(s,target,direction=s['direction'])
    check_win(s,actor)
    if not s['result']:begin_turn(s,next_seat,now)

def resolve_challenge(s,now,rng,challenged=False):
    c=s['challenge'];actor,target=c['actor'],c['target'];correct=challenged and c['had_color']
    penalized=actor if correct else target;requested=4 if correct or not challenged else 6
    count=len(draw(s,penalized,requested,rng)) if penalized in s['active'] else 0
    note(s,'wild4',seat=penalized,count=count,challenged=bool(challenged),challenge_correct=bool(correct))
    next_seat=target if correct else next_active(s,target,direction=s['direction']);check_win(s,actor)
    if not s['result']:begin_turn(s,next_seat,now)

def play(s,seat,card,chosen,said,now,rng):
    require(card in legal(s,seat),'illegal_card');c=CARDS[card];previous=s['color']
    if c['color'] is None:require(chosen in COLORS,'choose_color')
    had=any(CARDS[x]['color']==previous for x in s['hands'][seat] if x!=card)
    s['hands'][seat].remove(card);s['turn_progress']=True;s['discard'].append(card);s['color']=chosen if c['color'] is None else c['color'];s['drawn_id']=None;s['effect']=dict(actor=seat,card=card,target=next_active(s,seat,direction=s['direction']),had_color=had);note(s,'play',seat=seat,card=card)
    if len(s['hands'][seat])==1:
        s.update(phase='ono',deadline=now+2,ono_window=dict(seat=seat,until=now+2,declared=bool(said),claims=[]));return
    resolve_effect(s,now,rng)

def apply(s,seat,a,now,rng):
    require(not s['result'],'finished');require(seat in s['active'],'not_active');kind=a.get('type')
    if s['phase']=='ono':
        w=s['ono_window'];require(now<=w['until'],'ono_expired')
        if kind=='declare_ono':require(seat==w['seat'],'not_your_ono');w['declared']=True;note(s,'ono',seat=seat)
        elif kind=='catch_ono':require(seat!=w['seat'],'not_your_ono');w['claims']=list(set(w['claims']+[seat]))
        else:require(False,'ono_pending')
        s['timeouts'][seat]=0;return
    require(seat==s['turn'],'not_your_turn')
    if s['phase']=='challenge4':
        require(kind in ('challenge4','accept4'),'challenge_pending');resolve_challenge(s,now,rng,kind=='challenge4');s['timeouts'][seat]=0;return
    if kind=='play':play(s,seat,integer(a.get('card'),0,107),a.get('color'),a.get('ono') is True,now,rng)
    elif kind=='draw':
        require(s['phase']=='turn','already_drawn');added=draw(s,seat,1,rng);note(s,'draw',seat=seat,count=len(added));s['drawn_id']=added[0] if added else None
        if added and playable(s,added[0]):s['phase']='drawn'
        else:begin_turn(s,next_active(s,seat,direction=s['direction']),now)
    elif kind=='pass':require(s['phase']=='drawn','draw_first');begin_turn(s,next_active(s,seat,direction=s['direction']),now)
    else:require(False,'invalid_action')
    s['timeouts'][seat]=0

def leave(s,seat,now,rng):
    if s['result'] or seat not in s['active']:return
    s['active'].remove(seat);s['recycle'].extend(s['hands'][seat]);s['hands'][seat]=[]
    if not s['active']:finish(s,reason='incomplete');return
    if len(s['active'])==1:finish(s,s['active'],reason='opponent_left');return
    if s['phase']=='challenge4' and s['challenge']['target']==seat:
        actor=s['challenge']['actor'];note(s,'penalty_closed',seat=seat);check_win(s,actor)
        if not s['result']:begin_turn(s,next_active(s,seat,direction=s['direction']),now)
    elif s['phase']=='ono' and s['ono_window']['seat']==seat:resolve_effect(s,now,rng)
    elif s['turn']==seat and s['phase'] in ('turn','drawn'):begin_turn(s,next_active(s,seat,direction=s['direction']),now)

def tick(s,now,rng):
    if s['result'] or now<s['deadline']:return False
    if s['phase']=='ono':
        w=s['ono_window']
        if not w['declared'] and w['claims'] and w['seat'] in s['active']:n=len(draw(s,w['seat'],2,rng));note(s,'missed_ono',seat=w['seat'],count=n)
        resolve_effect(s,now,rng);return True
    if s['phase']=='challenge4':resolve_challenge(s,now,rng,False);return True
    seat=s['turn']
    if timeout(s,seat):leave(s,seat,now,rng);return True
    if s['phase']=='turn':n=len(draw(s,seat,1,rng));note(s,'timeout_draw',seat=seat,count=n)
    begin_turn(s,next_active(s,seat,direction=s['direction']),now);return True

def view(s,seat,now):
    v=public(s,('pile','hands','recycle','effect','drawn_id','discard','challenge','ono_window'));v['top']=dict(CARDS[s['discard'][-1]]);v['hand_cards']=[dict(CARDS[c]) for c in s['hands'][seat]];v['counts']=[len(x) for x in s['hands']];v['pile_count']=len(s['pile']);v['legal']=legal(s,seat) if seat==s['turn'] and s['phase'] in ('turn','drawn') and not s['result'] else []
    if s['phase']=='drawn' and seat==s['turn']:v['drawn_id']=s['drawn_id']
    if s['challenge']:v['challenge']={k:s['challenge'][k] for k in ('actor','target','deadline')}
    if s['ono_window']:v['ono_window']={k:s['ono_window'][k] for k in ('seat','until','declared')}
    return v
