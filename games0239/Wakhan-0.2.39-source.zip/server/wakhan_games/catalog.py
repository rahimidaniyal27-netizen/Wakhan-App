from . import fiskot,ludo,ono,chess_game,world
GAMES={
 'patpal':dict(name='پت‌پال',minimum=4,maximum=16,module=world,kind='world'),
 'bazaar':dict(name='گم در بازار',minimum=4,maximum=10,module=world,kind='world'),
 'fiskot':dict(name='فیس‌کوت',minimum=4,maximum=4,module=fiskot,kind='cards'),
 'ludo':dict(name='لدو',minimum=2,maximum=4,module=ludo,kind='board'),
 'chess':dict(name='شطرنج',minimum=2,maximum=2,module=chess_game,kind='board'),
 'ono':dict(name='Ono',minimum=2,maximum=6,module=ono,kind='cards')}
ALIASES={'hide':'patpal','petpal':'patpal','hide-and-seek':'patpal','market':'bazaar','fiscut':'fiskot','cards':'fiskot'}
def canonical(value):return ALIASES.get(value,value)
def public_catalog():return [dict(id=k,name=g['name'],minimum=g['minimum'],maximum=g['maximum'],kind=g['kind'],rules_version=g['module'].VERSION) for k,g in GAMES.items()]
