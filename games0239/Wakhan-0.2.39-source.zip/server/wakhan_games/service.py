"""Authenticated shared match service. Every private projection is made on server.
All SQLite writes are additive wkg_ tables. Wallet and account balances are never edited.
"""
import asyncio,collections,copy,hashlib,json,math,re,secrets,time
from contextlib import contextmanager
from aiohttp import web
from .common import GameError,require,finish
from .catalog import GAMES,canonical,public_catalog
from . import world
HEX=re.compile(r'^[a-f0-9]{32}$')
LIVE={'waiting','starting','active'}

class Games:
    def __init__(self,ns,clock=time.time,rng=None,testing=False):
        self.n=ns;self.db=ns['DB'];self.me=ns['WME'];self.salon=ns.get('WKS_SALON');self.clock=clock;self.rng=rng or secrets.SystemRandom();self.testing=testing;self.lock=asyncio.Lock();self.cache=collections.OrderedDict();self.connections={};self.tickets={};self.rates={};self.last_persist={};self.seq=0;self.task=None;self.stopped=False;self.profiles={}
        self.db.executescript('''
CREATE TABLE IF NOT EXISTS wkg_matches(id TEXT PRIMARY KEY,game TEXT NOT NULL,status TEXT NOT NULL,public INTEGER NOT NULL,host INTEGER NOT NULL,created REAL NOT NULL,updated REAL NOT NULL,version INTEGER NOT NULL,payload TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS wkg_open_matches ON wkg_matches(status,public,created);
CREATE TABLE IF NOT EXISTS wkg_members(match_id TEXT NOT NULL,uid INTEGER NOT NULL,seat INTEGER NOT NULL,left_match INTEGER NOT NULL,seen REAL NOT NULL,PRIMARY KEY(match_id,uid),UNIQUE(match_id,seat));
CREATE INDEX IF NOT EXISTS wkg_user_matches ON wkg_members(uid,left_match,seen);
CREATE TABLE IF NOT EXISTS wkg_invites(id TEXT PRIMARY KEY,match_id TEXT NOT NULL,sender INTEGER NOT NULL,target INTEGER NOT NULL,created REAL NOT NULL,expires REAL NOT NULL,state TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS wkg_pending_invites ON wkg_invites(target,state,expires);
CREATE TABLE IF NOT EXISTS wkg_actions(uid INTEGER NOT NULL,action_id TEXT NOT NULL,operation TEXT NOT NULL,fingerprint TEXT NOT NULL,match_id TEXT,version INTEGER NOT NULL,created REAL NOT NULL,PRIMARY KEY(uid,action_id));
CREATE TABLE IF NOT EXISTS wkg_results(match_id TEXT PRIMARY KEY,game TEXT NOT NULL,rules_version TEXT NOT NULL,created REAL NOT NULL,test INTEGER NOT NULL,payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS wkg_result_people(match_id TEXT NOT NULL,uid INTEGER NOT NULL,game TEXT NOT NULL,outcome TEXT NOT NULL,position INTEGER,created REAL NOT NULL,test INTEGER NOT NULL,PRIMARY KEY(match_id,uid));
CREATE INDEX IF NOT EXISTS wkg_rank_games ON wkg_result_people(created,game,outcome,test);
''');self.db.commit()
    @contextmanager
    def atomic(self):
        before=self.cache.copy();persisted=self.last_persist.copy()
        try:
            with self.db:yield
        except BaseException:
            self.cache=before;self.last_persist=persisted
            raise
    def limited(self,uid,kind,limit,seconds=10):
        now=self.clock();key=(uid,kind);q=self.rates.setdefault(key,collections.deque())
        while q and q[0]<now-seconds:q.popleft()
        require(len(q)<limit,'slow_down');q.append(now)
        if len(self.rates)>5000:
            for key in list(self.rates):
                if not self.rates[key] or self.rates[key][-1]<now-120:self.rates.pop(key,None)
    def account(self,uid):
        r=self.db.execute('SELECT done,blocked FROM wka_accounts WHERE uid=?',(uid,)).fetchone();require(r and r[0] and not r[1],'account_unavailable')
    def instance(self,b):
        instance=b.get('instance');require(isinstance(instance,str) and HEX.fullmatch(instance),'bad_instance');return instance
    def blocked(self,a,b):return bool(self.db.execute('SELECT 1 FROM wm70_blocks WHERE (actor=? AND target=?) OR (actor=? AND target=?)',(a,b,b,a)).fetchone())
    def friend(self,a,b):
        x,y=sorted((a,b));return bool(self.db.execute("SELECT 1 FROM wm70_friends WHERE a=? AND b=? AND state='accepted'",(x,y)).fetchone())
    def profile(self,uid,viewer):
        key=(uid,viewer);cached=self.profiles.get(key)
        if cached and self.clock()-cached[0]<2:return dict(cached[1])
        row=self.me.com.row(uid);name=str(row.get('name') or '')
        if not name:
            r=self.db.execute('SELECT name FROM users WHERE uid=?',(uid,)).fetchone();name=str(r[0] if r else 'کاربر')
        photo='/api/app/chat/avatar/'+str(uid)+'?rev='+str(row.get('rev',0)) if self.me.more.can_see(uid,viewer,'profile') else None
        value=dict(id=uid,name=name[:80],avatar=photo);self.profiles[key]=(self.clock(),value)
        if len(self.profiles)>2048:self.profiles={k:v for k,v in self.profiles.items() if self.clock()-v[0]<2}
        return dict(value)
    def origin(self,code,uid,required=False):
        if not code:return None
        valid=False;info=None
        if self.salon:
            info=self.salon.hall.info(code,uid);valid=bool(info and self.salon.visible(code,uid,info))
        if required:require(valid,'salon_forbidden')
        return dict(code=code,name=str(info.get('name') or 'سالون')[:80]) if valid else None
    def load(self,mid):
        require(isinstance(mid,str) and HEX.fullmatch(mid),'match_missing')
        if mid in self.cache:self.cache.move_to_end(mid);return copy.deepcopy(self.cache[mid])
        row=self.db.execute('SELECT payload FROM wkg_matches WHERE id=?',(mid,)).fetchone();require(row,'match_missing');l=json.loads(row[0]);self.cache[mid]=copy.deepcopy(l);return l
    def members(self,l):return [m for m in l['members'] if not m['left']]
    def member(self,l,uid):return next((m for m in l['members'] if m['uid']==uid and not m['left']),None)
    def connected(self,m,now):
        c=self.connections.get(m['uid']);return bool(c and c['instance']==m['instance'] and not c['ws'].closed) or m.get('offline_since') is None and now-m['seen']<6
    def allowed(self,l,uid,member_only=False):
        if self.member(l,uid) or l['status']=='finished' and any(m['uid']==uid for m in l['members']):return
        require(not member_only,'not_member')
        if l['status']=='waiting' and l['public']:return
        r=self.db.execute("SELECT 1 FROM wkg_invites WHERE target=? AND match_id=? AND state='pending' AND expires>?",(uid,l['id'],self.clock())).fetchone();require(r and l['status']=='waiting','not_member')
    def lease(self,l,uid,b,touch=True):
        m=self.member(l,uid);require(m,'not_member');instance=self.instance(b);require(m['instance']==instance,'another_device')
        if touch:m['seen']=self.clock();m['offline_since']=None
        return m
    def receipt(self,uid,b,op,mid=None):
        aid=b.get('action_id');require(isinstance(aid,str) and HEX.fullmatch(aid),'bad_action_id');payload={k:v for k,v in b.items() if k not in ('action_id','expected_version')};fp=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest();r=self.db.execute('SELECT operation,fingerprint,match_id,version FROM wkg_actions WHERE uid=? AND action_id=?',(uid,aid)).fetchone()
        if r:require(r[0]==op and r[1]==fp and (mid is None or mid==r[2]),'intent_mismatch')
        return aid,fp,r
    def record(self,uid,aid,fp,op,l):self.db.execute('INSERT INTO wkg_actions VALUES(?,?,?,?,?,?,?)',(uid,aid,op,fp,l['id'],l['version'],self.clock()))
    def persist(self,l):
        now=self.clock();l['updated']=now;encoded=json.dumps(l,separators=(',',':'),ensure_ascii=False)
        self.db.execute('INSERT INTO wkg_matches VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,public=excluded.public,host=excluded.host,updated=excluded.updated,version=excluded.version,payload=excluded.payload',(l['id'],l['game'],l['status'],int(l['public']),l['host'],l['created'],now,l['version'],encoded))
        stored=self.db.execute('SELECT uid,seat FROM wkg_members WHERE match_id=? ORDER BY seat',(l['id'],)).fetchall()
        wanted=[(m['uid'],m['seat']) for m in sorted(l['members'],key=lambda q:q['seat'])]
        if stored!=wanted:self.db.execute('DELETE FROM wkg_members WHERE match_id=?',(l['id'],))
        for m in l['members']:self.db.execute('INSERT INTO wkg_members VALUES(?,?,?,?,?) ON CONFLICT(match_id,uid) DO UPDATE SET left_match=excluded.left_match,seen=excluded.seen',(l['id'],m['uid'],m['seat'],int(m['left']),m['seen']))
        self.cache[l['id']]=copy.deepcopy(l);self.cache.move_to_end(l['id']);self.last_persist[l['id']]=now
        while len(self.cache)>128:
            removable=next((k for k,v in self.cache.items() if v['status'] not in LIVE),None)
            if removable is None:break
            self.cache.pop(removable,None)
    def finish_if_needed(self,l):
        s=l.get('state')
        if not s or not s.get('result') or l['status']=='finished':return
        l['status']='finished';l['public']=False
        remaining=self.members(l)
        if remaining and not any(m['uid']==l['host'] for m in remaining):l['host']=min(remaining,key=lambda m:(not self.connected(m,self.clock()),m['joined']))['uid']
        now=self.clock();r=s['result'];players=[m['uid'] for m in l['members']];result=dict(match_id=l['id'],game=l['game'],rules_version=l['rules_version'],players=players,result=copy.deepcopy(r),created=now)
        self.db.execute('INSERT OR IGNORE INTO wkg_results VALUES(?,?,?,?,?,?)',(l['id'],l['game'],l['rules_version'],now,int(self.testing),json.dumps(result,ensure_ascii=False,separators=(',',':'))))
        for m in l['members']:
            won=m['seat'] in r['winners'];outcome='incomplete' if r['reason']=='incomplete' else 'draw' if r['draw'] else 'win' if won else 'loss';self.db.execute('INSERT OR IGNORE INTO wkg_result_people VALUES(?,?,?,?,?,?,?)',(l['id'],m['uid'],l['game'],outcome,1 if won else None,now,int(self.testing)))
        self.db.execute("UPDATE wkg_invites SET state='closed' WHERE match_id=? AND state='pending'",(l['id'],))
    def summary(self,l,uid):
        g=GAMES[l['game']];n=len(self.members(l));return dict(id=l['id'],game=l['game'],name=g['name'],status=l['status'],count=n,minimum=g['minimum'],maximum=g['maximum'],public=l['public'],host=l['host'],version=l['version'],origin=self.origin(l.get('origin'),uid),can_start=l['host']==uid and l['status']=='waiting' and n>=g['minimum'],one_needed=l['status']=='waiting' and l['public'] and n==g['minimum']-1,starts_at=l.get('starts_at'),round=l['round'])
    def snapshot(self,l,uid,instance=None,include_map=True):
        self.allowed(l,uid);now=self.clock();m=self.member(l,uid) or (next((m for m in l['members'] if m['uid']==uid),None) if l['status']=='finished' else None);v=self.summary(l,uid);v.update(ok=True,server_time=now,seq=self.seq,members=[dict(**self.profile(x['uid'],uid),seat=x['seat'],host=x['uid']==l['host'],left=x['left'],online=self.connected(x,now),return_seconds=max(0,45-(now-(x.get('offline_since') or x['seen']+6))) if not self.connected(x,now) else None) for x in l['members']],seat=m['seat'] if m else None,lease_owned=bool(m and instance==m['instance']),rules_version=l['rules_version'])
        if l.get('state') is not None and m:
            require(instance==m['instance'],'another_device');mod=GAMES[l['game']]['module'];v['state']=mod.view(l['state'],m['seat'],now,include_map) if mod is world else mod.view(l['state'],m['seat'],now)
        return v
    def active_for(self,uid):
        row=self.db.execute("SELECT a.match_id FROM wkg_members a JOIN wkg_matches b ON a.match_id=b.id WHERE a.uid=? AND a.left_match=0 AND b.status IN ('waiting','starting','active') ORDER BY b.updated DESC LIMIT 1",(uid,)).fetchone();return self.load(row[0]) if row else None
    def _new(self,game,uid,instance,public,origin=None,group=None,round=1,options=None):
        now=self.clock();return dict(id=secrets.token_hex(16),game=game,status='waiting',public=public,host=uid,origin=origin,created=now,updated=now,version=1,round=round,group=group or secrets.token_hex(16),rules_version=GAMES[game]['module'].VERSION,members=[dict(uid=uid,seat=0,instance=instance,seen=now,joined=now,offline_since=None,left=False)],state=None,options=options or {},starts_at=None)
    def expected(self,l,b):require(type(b.get('expected_version')) is int and b['expected_version']==l['version'],'stale_version')
    def _join(self,l,uid,instance):
        require(l['status']=='waiting','match_started');existing=self.member(l,uid)
        if existing:
            require(existing['instance']==instance or not self.connected(existing,self.clock()),'another_device');existing.update(instance=instance,seen=self.clock(),offline_since=None);return
        self.allowed(l,uid);require(len(self.members(l))<GAMES[l['game']]['maximum'],'match_full');require(not any(self.blocked(uid,m['uid']) for m in self.members(l)),'match_forbidden');other=self.active_for(uid);require(other is None or other['id']==l['id'],'already_in_match')
        # Before start seats can be compacted; no running match ever changes them.
        old=next((m for m in l['members'] if m['uid']==uid),None)
        if old:old.update(left=False,instance=instance,seen=self.clock(),joined=self.clock(),offline_since=None)
        else:
            l['members']=self.members(l)
            for seat,member in enumerate(l['members']):member['seat']=seat
            l['members'].append(dict(uid=uid,seat=len(l['members']),instance=instance,seen=self.clock(),joined=self.clock(),offline_since=None,left=False))
        l['version']+=1
    async def create(self,uid,b):
        self.account(uid);self.limited(uid,'create',6,60);instance=self.instance(b);game=canonical(b.get('game'));require(game in GAMES,'unknown_game');aid,fp,prior=self.receipt(uid,b,'create')
        if prior:return self.snapshot(self.load(prior[2]),uid,instance)
        require(self.active_for(uid) is None,'already_in_match');origin=b.get('origin');require(origin is None or isinstance(origin,str) and len(origin)<=80,'bad_origin');self.origin(origin,uid,True)
        l=self._new(game,uid,instance,b.get('public') is True,origin)
        with self.atomic():self.persist(l);self.record(uid,aid,fp,'create',l)
        return self.snapshot(l,uid,instance)
    async def join(self,uid,mid,b):
        self.account(uid);self.limited(uid,'join',20);instance=self.instance(b);l=self.load(mid);aid,fp,prior=self.receipt(uid,b,'join',mid)
        if prior:return self.snapshot(l,uid,instance)
        self._join(l,uid,instance)
        with self.atomic():self.persist(l);self.record(uid,aid,fp,'join',l);self.db.execute("UPDATE wkg_invites SET state='accepted' WHERE target=? AND match_id=? AND state='pending'",(uid,mid))
        return self.snapshot(l,uid,instance)
    def _leave(self,l,m,now):
        if m['left']:return
        m['left']=True
        if l['status']=='waiting':
            remaining=self.members(l)
            if not remaining:l['status']='cancelled';l['public']=False
            elif m['uid']==l['host']:l['host']=min(remaining,key=lambda x:(not self.connected(x,now),x['joined']))['uid']
        elif l['status']=='starting':
            # The roster locked at start; this is a real forfeit, not a late join.
            self._begin(l)
            GAMES[l['game']]['module'].leave(l['state'],m['seat'],now,self.rng)
        elif l['status']=='active':GAMES[l['game']]['module'].leave(l['state'],m['seat'],now,self.rng)
        l['version']+=1;self.finish_if_needed(l)
    def _begin(self,l):
        require(l['status']=='starting','not_starting');opts=copy.deepcopy(l['options']);opts['game']=l['game'];l['state']=GAMES[l['game']]['module'].create([m['uid'] for m in l['members']],self.rng,l['starts_at'],opts);l['status']='active';l['version']+=1
    async def action(self,uid,mid,b):
        self.account(uid);instance=self.instance(b);a=b.get('action');require(isinstance(a,dict) and isinstance(a.get('type'),str),'bad_action');motion=a['type']=='move' and canonical(self.load(mid)['game']) in ('patpal','bazaar');self.limited(uid,'motion' if motion else 'action',180 if motion else 80);l=self.load(mid)
        if not motion:
            aid,fp,prior=self.receipt(uid,b,'action',mid)
            if prior:
                if a['type']=='leave':return dict(ok=True,left=True,match_id=mid,status=l['status'],result=l.get('state',{}).get('result') if l.get('state') else None,duplicate=True)
                v=self.snapshot(l,uid,instance);v['duplicate']=True;return v
        if a['type']=='resume':
            member=self.member(l,uid);require(member,'not_member');require(member['instance']==instance or not self.connected(member,self.clock()),'another_device');member['instance']=instance
        m=self.lease(l,uid,b)
        if motion:
            require(l['status']=='active','not_started');GAMES[l['game']]['module'].apply(l['state'],m['seat'],a,self.clock(),self.rng);self.cache[mid]=copy.deepcopy(l)
            if self.clock()-self.last_persist.get(mid,0)>=1:
                with self.atomic():self.persist(l)
            return dict(ok=True,motion=True,version=l['version'],world_seq=l['state']['world_seq'])
        aid,fp,prior=self.receipt(uid,b,'action',mid)
        if prior:
            v=self.snapshot(l,uid,instance);v['duplicate']=True;return v
        self.expected(l,b);kind=a['type'];now=self.clock()
        if kind=='start':
            require(l['status']=='waiting','match_started');require(l['host']==uid,'host_only');members=self.members(l);require(len(members)>=GAMES[l['game']]['minimum'],'need_players')
            # Compact lobby seats once, then freeze roster/rules for this match.
            l['members']=sorted(members,key=lambda m:m['seat'])
            for seat,member in enumerate(l['members']):member['seat']=seat
            l.update(status='starting',public=False,starts_at=now+2);l['version']+=1
        elif kind=='recruit':require(l['status']=='waiting' and l['host']==uid,'host_only');l['public']=a.get('on') is True;l['version']+=1
        elif kind=='leave':self._leave(l,m,now)
        elif kind=='resume':m.update(seen=now,offline_since=None);l['version']+=1
        else:
            require(l['status']=='active','not_started');GAMES[l['game']]['module'].apply(l['state'],m['seat'],a,now,self.rng);l['version']+=1;self.finish_if_needed(l)
        with self.atomic():
            if kind=='start':self.db.execute('DELETE FROM wkg_members WHERE match_id=?',(mid,))
            self.persist(l);self.record(uid,aid,fp,'action',l)
        if kind=='leave':return dict(ok=True,left=True,match_id=mid,status=l['status'],result=l['state']['result'] if l.get('state') else None)
        return self.snapshot(l,uid,instance)
    async def invite(self,uid,mid,b):
        self.account(uid);self.limited(uid,'invite',12);l=self.load(mid);self.lease(l,uid,b);aid,fp,prior=self.receipt(uid,b,'invite',mid)
        if prior:return dict(ok=True,home=self.home(uid))
        self.expected(l,b);require(l['status']=='waiting' and l['host']==uid,'host_only');require(len(self.members(l))<GAMES[l['game']]['maximum'],'match_full');targets=b.get('targets');require(isinstance(targets,list) and 1<=len(targets)<=16 and all(type(v) is int and v>0 for v in targets),'bad_targets');now=self.clock()
        for target in set(targets):
            self.account(target);require(target!=uid and not self.member(l,target) and not self.blocked(uid,target),'invite_forbidden');same=self.salon and l.get('origin') and self.salon.member(l['origin'],uid) and self.salon.member(l['origin'],target);require(self.friend(uid,target) or same,'invite_friends_only')
        with self.atomic():
            for target in set(targets):
                pending=self.db.execute("SELECT 1 FROM wkg_invites WHERE match_id=? AND target=? AND state='pending' AND expires>?",(mid,target,now)).fetchone()
                if pending:continue
                self.db.execute('INSERT INTO wkg_invites VALUES(?,?,?,?,?,?,?)',(secrets.token_hex(16),mid,uid,target,now,now+20,'pending'))
            self.record(uid,aid,fp,'invite',l)
        return dict(ok=True,home=self.home(uid))
    async def reply(self,uid,invite_id,b):
        self.account(uid);instance=self.instance(b);r=self.db.execute('SELECT match_id,target,expires,state FROM wkg_invites WHERE id=?',(invite_id,)).fetchone();require(r and r[1]==uid,'invite_missing');mid=r[0];aid,fp,prior=self.receipt(uid,b,'reply:'+invite_id,mid);l=self.load(mid)
        if prior:return self.snapshot(l,uid,instance) if b.get('accept') is True else dict(ok=True,declined=True)
        require(r[3]=='pending' and r[2]>self.clock(),'invite_expired');require(l['status']=='waiting','match_started')
        if b.get('accept') is True:self._join(l,uid,instance)
        with self.atomic():
            self.db.execute('UPDATE wkg_invites SET state=? WHERE id=?',('accepted' if b.get('accept') is True else 'declined',invite_id));self.persist(l);self.record(uid,aid,fp,'reply:'+invite_id,l)
        return self.snapshot(l,uid,instance) if b.get('accept') is True else dict(ok=True,declined=True)
    async def next_match(self,uid,mid,b):
        self.account(uid);instance=self.instance(b);old=self.load(mid);self.lease(old,uid,b);aid,fp,prior=self.receipt(uid,b,'next:'+mid)
        if prior:return self.snapshot(self.load(prior[2]),uid,instance)
        require(old['status']=='finished' and old['host']==uid,'host_only')
        if old.get('next_match'):return self.snapshot(self.load(old['next_match']),uid,instance)
        require(self.active_for(uid) is None,'already_in_match');opts={}
        if old['game'] in ('patpal','bazaar'):opts['role_queue']=old['state']['role_queue']
        members=[m for m in old['members'] if not m['left'] and self.connected(m,self.clock()) and self.active_for(m['uid']) is None]
        require(any(m['uid']==uid for m in members),'not_member');l=self._new(old['game'],uid,instance,False,old.get('origin'),old['group'],old['round']+1,opts);l['members']=[]
        for seat,m in enumerate(members):q=copy.deepcopy(m);q.update(seat=seat,joined=self.clock(),seen=self.clock(),offline_since=None);l['members'].append(q)
        if old['game']=='chess' and len(members)==2:
            former_white=old['members'][old['state']['white']]['uid'];opts['white_seat']=next((m['seat'] for m in l['members'] if m['uid']!=former_white),0);l['options']=opts
        with self.atomic():
            old['next_match']=l['id'];self.persist(old);self.persist(l);self.record(uid,aid,fp,'next:'+mid,l)
        return self.snapshot(l,uid,instance)
    def lobbies(self,uid,game=None):
        if game is not None:game=canonical(game);require(game in GAMES,'unknown_game')
        rows=self.db.execute("SELECT id FROM wkg_matches WHERE status='waiting' AND public=1 ORDER BY created DESC LIMIT 100").fetchall();out=[]
        for row in rows:
            l=self.load(row[0])
            if game and game!=l['game'] or len(self.members(l))>=GAMES[l['game']]['maximum'] or any(self.blocked(uid,m['uid']) for m in self.members(l)):continue
            out.append(self.summary(l,uid))
            if len(out)==30:break
        return out
    def home(self,uid):
        now=self.clock();active=self.active_for(uid);invites=[]
        for iid,mid,sender,expires in self.db.execute("SELECT id,match_id,sender,expires FROM wkg_invites WHERE target=? AND state='pending' AND expires>? ORDER BY created DESC LIMIT 20",(uid,now)):
            l=self.load(mid)
            if l['status']!='waiting' or len(self.members(l))>=GAMES[l['game']]['maximum'] or self.blocked(uid,sender):continue
            invites.append(dict(id=iid,match=self.summary(l,uid),sender=self.profile(sender,uid),expires=expires))
        return dict(ok=True,server_time=now,resume=self.summary(active,uid) if active else None,invites=invites,one_needed=[l for l in self.lobbies(uid) if l['one_needed']])
    def _tick_lobby(self,l,now):
        if l['status'] not in LIVE:return False
        expired=[];changed=False
        for m in self.members(l):
            if self.connected(m,now):continue
            if m.get('offline_since') is None:m['offline_since']=m['seen']+6;changed=True
            if now-m['offline_since']>=45:expired.append(m)
        if expired and len(expired)==len(self.members(l)):
            for m in expired:m['left']=True
            if l.get('state') is not None:finish(l['state'],reason='incomplete');self.finish_if_needed(l)
            elif l['status']=='starting':self._begin(l);finish(l['state'],reason='incomplete');self.finish_if_needed(l)
            else:l['status']='cancelled';l['public']=False
            l['version']+=1;return True
        for m in expired:self._leave(l,m,now);changed=True
        if l['status']=='starting' and now>=l['starts_at']:self._begin(l);changed=True
        if l['status']=='active':
            mod=GAMES[l['game']]['module'];s=l['state'];s['connected']=[self.connected(m,now) and not m['left'] for m in l['members']]
            if mod.tick(s,now,self.rng):l['version']+=1;changed=True;self.finish_if_needed(l)
            if mod is world:mod.advance_motion(s,now)
        return changed
    async def tick(self):
        now=self.clock();ids=[r[0] for r in self.db.execute("SELECT id FROM wkg_matches WHERE status IN ('waiting','starting','active')").fetchall()]
        async with self.lock:
            for mid in ids:
                l=self.load(mid)
                with self.atomic():
                    changed=self._tick_lobby(l,now)
                    if changed or now-self.last_persist.get(mid,0)>=1:self.persist(l)
                    else:self.cache[mid]=copy.deepcopy(l)
            self.db.execute("UPDATE wkg_invites SET state='expired' WHERE state='pending' AND expires<=?",(now,));self.db.commit()
            for ticket in list(self.tickets):
                if self.tickets[ticket]['expires']<=now:self.tickets.pop(ticket,None)
        self.seq+=1;await self.broadcast()
    async def broadcast(self):
        for uid,c in list(self.connections.items()):
            if c['ws'].closed:continue
            try:
                self.account(uid)
                check=self.n.get('check_init')
                if check and not check(c.get('auth') or ''):await c['ws'].close(code=4003,message=b'auth');continue
                if c.get('match'):
                    l=self.load(c['match']);m=self.member(l,uid)
                    if not m or m['instance']!=c['instance']:await c['ws'].send_json(dict(type='lease_lost'));c['match']=None
                    else:
                        include_map=c.get('map_match')!=l['id'];key=(l['id'],l['version'],l.get('state',{}).get('world_seq',0) if l.get('state') else 0,int(self.clock()*4) if l['game']=='chess' else int(self.clock()))
                        changed_key=key!=c.get('snapshot_key') or include_map
                        c['snapshot_key']=key
                        if changed_key:
                            value=self.snapshot(l,uid,c['instance'],include_map);signature=json.dumps({k:v for k,v in value.items() if k not in ('server_time','seq')},sort_keys=True,separators=(',',':'))
                            if signature!=c.get('state_signature'):
                                await c['ws'].send_json(dict(type='snapshot',data=value));c['state_signature']=signature
                                if value.get('state',{}).get('map'):c['map_match']=l['id']
                if self.clock()<c.get('next_home_at',0):continue
                c['next_home_at']=self.clock()+1
                home=self.home(uid);signature=json.dumps({k:v for k,v in home.items() if k!='server_time'},sort_keys=True,separators=(',',':'))
                if signature!=c.get('home_signature'):await c['ws'].send_json(dict(type='home',data=home));c['home_signature']=signature
            except GameError:
                if not c['ws'].closed:await c['ws'].close(code=4003,message=b'auth')
            except (ConnectionError,RuntimeError):pass
    async def stop_voice(self,uid,connection):
        mid=connection.get('match')
        if not mid:return
        for target,c in list(self.connections.items()):
            if target!=uid and c.get('match')==mid and not c['ws'].closed:
                try:await c['ws'].send_json(dict(type='voice',source=uid,match=mid,payload=dict(type='stop')))
                except (ConnectionError,RuntimeError):pass
    async def websocket(self,request):
        token=request.query.get('ticket','');ticket=self.tickets.pop(token,None)
        if not ticket or ticket['expires']<=self.clock():return web.json_response(dict(ok=False,err='auth'),status=401)
        uid=ticket['uid'];instance=ticket['instance']
        try:self.account(uid)
        except GameError:return web.json_response(dict(ok=False,err='auth'),status=401)
        old=self.connections.get(uid)
        if old and not old['ws'].closed and old['instance']!=instance and self.active_for(uid):return web.json_response(dict(ok=False,err='another_device'),status=409)
        if old and not old['ws'].closed:await old['ws'].close(code=4001,message=b'new_connection')
        ws=web.WebSocketResponse(heartbeat=10,max_msg_size=70000);await ws.prepare(request);c=dict(ws=ws,instance=instance,match=None,map_match=None,auth=ticket.get('auth'));self.connections[uid]=c
        await ws.send_json(dict(type='ready',server_time=self.clock(),seq=self.seq))
        try:
            async for message in ws:
                if message.type!=web.WSMsgType.TEXT:continue
                try:
                    data=json.loads(message.data);require(isinstance(data,dict),'bad_message');kind=data.get('type');self.account(uid)
                    if kind=='watch':
                        if c.get('match') and c['match']!=data.get('match'):await self.stop_voice(uid,c)
                        async with self.lock:
                            l=self.load(data.get('match'));m=self.lease(l,uid,dict(instance=instance));c.update(match=l['id'],map_match=None,state_signature=None)
                            with self.atomic():self.persist(l)
                        await self.broadcast()
                    elif kind=='unwatch':
                        await self.stop_voice(uid,c);c.update(match=None,map_match=None,state_signature=None,snapshot_key=None)
                    elif kind=='heartbeat':
                        async with self.lock:
                            active=self.active_for(uid)
                            if active:
                                m=self.member(active,uid)
                                if m['instance']==instance:m.update(seen=self.clock(),offline_since=None);self.cache[active['id']]=copy.deepcopy(active)
                        await ws.send_json(dict(type='pong',server_time=self.clock(),seq=self.seq))
                    elif kind=='voice':
                        self.limited(uid,'voice',300);mid=c.get('match');require(mid and isinstance(data.get('payload'),dict),'voice_forbidden');l=self.load(mid);self.lease(l,uid,dict(instance=instance),False);target=data.get('target');recipient=self.connections.get(target);require(type(target) is int and target!=uid and recipient and recipient.get('match')==mid,'voice_forbidden');member=self.member(l,target);require(member and member['instance']==recipient['instance'] and l['status'] in LIVE,'voice_forbidden');payload=data['payload'];require(payload.get('type') in ('offer','answer','candidate','mute','stop'),'bad_signal');await recipient['ws'].send_json(dict(type='voice',source=uid,payload=payload,match=mid))
                    else:require(False,'bad_message')
                except (GameError,ValueError,TypeError) as e:await ws.send_json(dict(type='error',err=getattr(e,'code','bad_message')))
        finally:
            if self.connections.get(uid) is c:
                await self.stop_voice(uid,c)
                self.connections.pop(uid,None)
                async with self.lock:
                    l=self.active_for(uid)
                    if l:
                        m=self.member(l,uid)
                        if m and m['instance']==instance:m['offline_since']=self.clock();m['seen']=self.clock();self.cache[l['id']]=copy.deepcopy(l)
                        with self.atomic():self.persist(l)
        return ws
    def invitees(self,l,uid):
        require(l['status']=='waiting' and l['host']==uid and self.member(l,uid),'host_only')
        ids=set()
        for a,b in self.db.execute("SELECT a,b FROM wm70_friends WHERE state='accepted' AND (a=? OR b=?)",(uid,uid)):ids.add(b if a==uid else a)
        if l.get('origin') and self.salon and self.origin(l['origin'],uid) and self.salon.member(l['origin'],uid):ids.update(self.salon.present(l['origin']))
        out=[]
        for target in ids:
            if target==uid or self.member(l,target) or self.blocked(uid,target):continue
            try:self.account(target)
            except GameError:continue
            chat=self.n.get('WM_CHAT2');p=chat.person(target,uid) if chat else self.profile(target,uid)
            out.append(dict(id=p['id'],name=p['name'],avatar=p.get('avatar'),online=p.get('online') is True))
        return dict(ok=True,items=sorted(out,key=lambda p:(not p['online'],p['name']))[:100])
    async def dispatch(self,request):
        uid=int(request['u']['id']);op=request.match_info.get('op');mid=request.match_info.get('mid');b={}
        try:
            self.account(uid)
            if request.method=='POST':
                require(request.content_length is None or request.content_length<=16000,'request_too_large');b=await request.clone(client_max_size=16000).json();require(isinstance(b,dict),'bad_request')
            async with self.lock:
                # Apply deadlines before accepting a late move or reopening a seat.
                if mid:
                    l=self.load(mid)
                    with self.atomic():
                        if self._tick_lobby(l,self.clock()):self.persist(l)
                if op=='catalog':value=dict(ok=True,games=public_catalog(),reconnect_seconds=45,invite_seconds=20)
                elif op=='rankings':
                    ranks=self.n.get('WKG_RANKINGS');require(ranks is not None,'rankings_unavailable');value=ranks.leaderboard(uid,'games',str(request.query.get('period') or 'month'),game=request.query.get('game'))
                elif op=='home':
                    active=self.active_for(uid)
                    if active:
                        m=self.member(active,uid)
                        if m and m['instance']==request.query.get('instance'):m.update(seen=self.clock(),offline_since=None);self.cache[active['id']]=copy.deepcopy(active)
                    value=self.home(uid)
                elif op=='history':
                    game=canonical(request.query.get('game')) if request.query.get('game') else None
                    if game:require(game in GAMES,'unknown_game')
                    rows=self.db.execute('SELECT r.payload FROM wkg_results r JOIN wkg_result_people p ON p.match_id=r.match_id WHERE p.uid=?'+(' AND r.game=?' if game else '')+' ORDER BY r.created DESC LIMIT 30',([uid,game] if game else [uid])).fetchall();value=dict(ok=True,items=[json.loads(r[0]) for r in rows])
                elif op=='lobbies':value=dict(ok=True,items=self.lobbies(uid,request.query.get('game')))
                elif op=='create':value=await self.create(uid,b)
                elif op=='get':
                    active=self.load(mid);m=self.member(active,uid)
                    if m and m['instance']==request.query.get('instance'):m.update(seen=self.clock(),offline_since=None);self.cache[mid]=copy.deepcopy(active)
                    value=self.snapshot(active,uid,request.query.get('instance'))
                elif op=='invitees':value=self.invitees(self.load(mid),uid)
                elif op=='join':value=await self.join(uid,mid,b)
                elif op=='action':value=await self.action(uid,mid,b)
                elif op=='invite':value=await self.invite(uid,mid,b)
                elif op=='reply':value=await self.reply(uid,request.match_info['invite_id'],b)
                elif op=='next':value=await self.next_match(uid,mid,b)
                elif op=='socket':
                    self.limited(uid,'socket',20,60);instance=self.instance(b);token=secrets.token_hex(24);self.tickets[token]=dict(uid=uid,instance=instance,expires=self.clock()+30,auth=request.headers.get('X-Init',''));value=dict(ok=True,ticket=token,expires=self.clock()+30)
                else:raise GameError('not_found',404)
            self.seq+=1
            if request.method=='POST' and not value.get('motion'):
                for c in self.connections.values():c['next_home_at']=0
            await self.broadcast();return self.n['J'](value)
        except GameError as e:return self.n['J'](dict(ok=False,err=e.code),e.status)
        except (ValueError,TypeError,json.JSONDecodeError):return self.n['J'](dict(ok=False,err='bad_request'),400)
    def routes(self,app):
        def add(method,path,op):
            async def endpoint(req):req.match_info['op']=op;return await self.dispatch(req)
            app.router.add_route(method,'/api/app/games'+path,self.n['auth'](endpoint))
        app.router.add_get('/api/app/games/ws',self.websocket)
        for method,path,op in [('GET','/catalog','catalog'),('GET','/rankings','rankings'),('GET','/history','history'),('GET','/home','home'),('GET','/lobbies','lobbies'),('POST','/create','create'),('POST','/socket','socket'),('POST','/invites/{invite_id}','reply'),('GET','/{mid}','get'),('POST','/{mid}/join','join'),('POST','/{mid}/action','action'),('POST','/{mid}/invite','invite'),('GET','/{mid}/invitees','invitees'),('POST','/{mid}/next','next')]:add(method,path,op)
        async def start(app):self.task=asyncio.create_task(self.loop())
        async def stop(app):
            self.stopped=True
            if self.task:self.task.cancel()
            for c in list(self.connections.values()):await c['ws'].close()
            if self.task:
                try:await self.task
                except asyncio.CancelledError:pass
        app.on_startup.append(start);app.on_cleanup.append(stop)
    async def loop(self):
        while not self.stopped:
            try:await self.tick()
            except asyncio.CancelledError:raise
            except Exception:
                log=self.n.get('log')
                if log:log.exception('Wakhan games tick failed')
            await asyncio.sleep(.1)
