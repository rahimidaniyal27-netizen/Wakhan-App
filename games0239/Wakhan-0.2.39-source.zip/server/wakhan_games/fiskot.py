from .common import base,require,integer,finish,public,timeout
SUITS=('H','D','C','S')
VERSION='fiskot-wakhan-1'

def deck():return [s+str(v) for s in SUITS for v in range(2,15)]
def rank(card):return int(card[1:])
def new_hand(s,rng,now):
    cards=deck();rng.shuffle(cards);s.update(deck=cards,hands=[[] for _ in range(4)],trick=[],last_trick=None,trump=None,tricks=[0,0],phase='trump',turn=(s['dealer']+1)%4,deadline=now+20,collect_until=0)
    for _ in range(5):
        for i in range(1,5):s['hands'][(s['dealer']+i)%4].append(s['deck'].pop())

def create(players,rng,now,options=None):
    require(len(players)==4,'capacity');s=base(players);s.update(dealer=rng.randrange(4),scores=[0,0],hand=1,history=[]);new_hand(s,rng,now);return s

def legal(s,seat):
    hand=s['hands'][seat]
    if s['trick']:
        suit=s['trick'][0]['card'][0];following=[c for c in hand if c[0]==suit]
        if following:return following
    return list(hand)

def trump(s,suit,now):
    require(suit in SUITS,'bad_suit');s['trump']=suit
    for _ in range(8):
        for i in range(1,5):s['hands'][(s['dealer']+i)%4].append(s['deck'].pop())
    s.update(phase='play',deadline=now+20)

def play(s,seat,card,now):
    require(card in legal(s,seat),'follow_suit');s['hands'][seat].remove(card);s['trick'].append(dict(seat=seat,card=card));s['turn']=(seat+1)%4;s['deadline']=now+20
    if len(s['trick'])==4:
        lead=s['trick'][0]['card'][0]
        def power(x):return (2 if x['card'][0]==s['trump'] else 1 if x['card'][0]==lead else 0,rank(x['card']))
        win=max(s['trick'],key=power)['seat'];s['tricks'][win%2]+=1;s['last_trick']=dict(cards=s['trick'],winner=win);s['trick']=[];s['turn']=win;s['collect_until']=now+.8;s['deadline']=now+20.8
        if sum(s['tricks'])==13:
            team=0 if s['tricks'][0]>s['tricks'][1] else 1;points=2 if s['tricks'][team]==13 else 1;s['scores'][team]+=points;s['history'].append(dict(hand=s['hand'],dealer=s['dealer'],trump=s['trump'],tricks=list(s['tricks']),winner=team,points=points))
            if s['scores'][team]>=5:finish(s,[team,team+2],scores=s['scores'],hands=s['history'])
            else:s.update(phase='hand_end',deadline=now+3)

def apply(s,seat,a,now,rng):
    require(not s['result'],'finished');require(seat in s['active'],'not_active');require(seat==s['turn'],'not_your_turn');require(now>=s.get('collect_until',0),'collecting')
    if s['phase']=='trump':require(a.get('type')=='trump','choose_trump');trump(s,a.get('suit'),now)
    else:require(s['phase']=='play' and a.get('type')=='play','invalid_action');play(s,seat,a.get('card'),now)
    s['timeouts'][seat]=0

def leave(s,seat,now,rng):
    if s['result'] or seat not in s['active']:return
    s['active'].remove(seat)
    if not s['active']:finish(s,reason='incomplete')
    else:finish(s,[n for n in s['active'] if n%2!=seat%2],reason='opponent_left',scores=list(s['scores']),tricks=list(s['tricks']))

def tick(s,now,rng):
    if s['result'] or now<s['deadline']:return False
    if s['phase']=='hand_end':s['dealer']=(s['dealer']+1)%4;s['hand']+=1;new_hand(s,rng,now);return True
    seat=s['turn']
    if timeout(s,seat):leave(s,seat,now,rng);return True
    if s['phase']=='trump':
        hand=s['hands'][seat];suit=max(SUITS,key=lambda t:(sum(c[0]==t for c in hand),max([rank(c) for c in hand if c[0]==t] or [0]),-SUITS.index(t)));trump(s,suit,now)
    else:play(s,seat,min(legal(s,seat),key=lambda c:(rank(c),SUITS.index(c[0]))),now)
    return True

def view(s,seat,now):
    v=public(s,('deck','hands','history'));v['hand_cards']=list(s['hands'][seat]);v['counts']=[len(h) for h in s['hands']];v['team']=seat%2;v['legal']=legal(s,seat) if s['phase']=='play' and seat==s['turn'] and not s['result'] else [];return v
