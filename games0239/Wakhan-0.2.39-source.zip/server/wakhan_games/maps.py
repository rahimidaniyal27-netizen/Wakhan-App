"""World geometry shared with the renderer, in metres; all blockers are explicit."""
import random
VERSION='wakhan-worlds-1'

def box(key,x,z,w,d,h=2.6,color='#d9bd89',kind='wall',y=0,solid=True,**extra):
    return dict(id=key,x=x,z=z,w=w,d=d,h=h,y=y,color=color,kind=kind,solid=solid,**extra)

def build(game,seed):
    rng=random.Random(seed);objects=[]
    def add(*a,**kw):objects.append(box(*a,**kw))
    if game=='patpal':
        bounds=[-14,14,-12,20]
        add('west',-14,4,.25,32);add('east',14,4,.25,32);add('back',0,-12,28,.25);add('front',0,20,28,.25,h=1.5)
        for x in (-2,2):
            for a,b in [(-12,-7),(-5,-1),(1,6),(8,10)]:add('wall-'+str(x)+'-'+str(a),x,(a+b)/2,.2,b-a)
        for a,b in [(-14,-9),(-7,-2),(2,5),(7,14)]:add('divider-'+str(a),(a+b)/2,0,b-a,.2)
        for a,b in [(-14,-8),(-6,-2),(2,6),(8,14)]:add('courtyard-'+str(a),(a+b)/2,10,b-a,.2)
        add('bath-wall-a',8,3.5,.18,3);add('bath-wall-b',8,8.5,.18,3)
        add('sofa',-12,-5,1.6,4,1.0,'#8b3949','sofa');add('salon-rug',-8,-5,7,6,.015,'#98384a','rug',solid=False)
        dx=rng.choice([-.3,0,.3]);add('tea-table',-8+dx,-5,2,1.4,.12,'#774c2a','table',y=.65)
        for i,(x,z) in enumerate([(-.8,-.5),(.8,-.5),(-.8,.5),(.8,.5)]):add('table-leg-'+str(i),-8+dx+x,-5+z,.15,.15,.65,'#774c2a','leg')
        add('cabinet',-9,-10.6,4,.8,1.7,'#77543a','cabinet');add('lamp',-12,-9,.5,.5,1.8,'#b88d39','lamp')
        add('bed',-9,5,4,2.6,.55,'#416c91','bed');add('bed-rug',-8,7.5,4,2,.015,'#ae7846','rug',solid=False)
        add('kitchen',10,-10.5,6,.9,1.0,'#aa8260','counter');add('kitchen-island',8,-5,3,1.3,1,'#bd9a69','counter');add('sink',12.7,-8,.8,2,.9,'#cbd3cf','sink')
        add('couch-east',5,6,2.8,1.3,.9,'#59795c','sofa');add('bath',11,4,2.2,1.2,.7,'#d1dad6','bath');add('basin',12.8,8,.8,1,.85,'#d1dad6','sink')
        for i,(x,z) in enumerate([(-11,16),(11,16),(-11,12),(11,12)]):add('tree-'+str(i),x,z,.7,.7,2.6,'#466c42','tree')
        add('courtyard-rug',0,15,8,5,.015,'#3d6b81','rug',solid=False);add('bench',-6,17,3,1,.55,'#7c5836','bench');add('low-step',4,13,2,1,.12,'#b2926b','step')
        zones=[dict(name='سالون',rect=[-14,-2,-12,0]),dict(name='اتاق',rect=[-14,-2,0,10]),dict(name='آشپزخانه',rect=[2,14,-12,0]),dict(name='اتاق مهمان',rect=[2,8,0,10]),dict(name='دست‌شویی',rect=[8,14,0,10]),dict(name='راهرو',rect=[-2,2,-12,10]),dict(name='حویلی',rect=[-14,14,10,20])]
        for i,zone in enumerate(zones):
            a,b,c,d=zone['rect'];add('floor-'+str(i),(a+b)/2,(c+d)/2,b-a,d-c,.012,'#ccd3c3' if zone['name']=='دست‌شویی' else '#b79c72' if zone['name']=='حویلی' else '#c5ae86','floor',y=-.012,solid=False)
        spawns=[[-.7,-10+i*1.15] for i in range(8)]+[[.7,-10+i*1.15] for i in range(8)]
        return dict(version=VERSION,seed=seed,bounds=bounds,objects=objects,zones=zones,spawns=spawns,light=dict(color='#fff0ce',ground='#c9ab79'),shops=[])
    bounds=[-18,18,-16,16]
    add('west',-18,0,.3,32,3,'#bb9169');add('east',18,0,.3,32,3,'#bb9169');add('north',0,-16,36,.3,3,'#bb9169');add('south',0,16,36,.3,3,'#bb9169')
    shops=[]
    names=[('copper','مسگر',-15,-10,'#b46d38'),('tea','چای‌فروش',-15,10,'#447d73'),('cloth','پارچه‌فروش',15,-10,'#63538b'),('tailor','خیاط',15,10,'#9c5362'),('fruit','میوه‌فروش',0,-14,'#748044'),('porter','دروازه',0,14,'#98713b')]
    for key,name,x,z,color in names:
        w,d=(3.4,5) if x else (6,2.2);add('shop-'+key,x,z,w,d,2.8,color,'shop',label=name)
        px,pz=(x+3 if x<0 else x-3,z) if x else (x,z+3 if z<0 else z-3)
        shops.append(dict(id=key,name=name,x=px,z=pz,item={'copper':'teapot','cloth':'cloth','fruit':'basket'}.get(key)))
        add('rug-'+key,px,pz,2.2,2,.015,color,'rug',solid=False)
    for i,(x,z,c) in enumerate([(-6,0,'#a96e48'),(6,0,'#507b79')]):add('island-'+str(i),x,z,3,4,1.1,c,'stall');add('awning-'+str(i),x,z,3.5,4.5,.2,c,'awning',y=2.4)
    add('market-floor',0,0,36,32,.012,'#b99b73','floor',y=-.012,solid=False)
    zones=[dict(name='گذر مسگر',rect=[-18,-8,-16,0]),dict(name='گذر چای‌فروش',rect=[-18,-8,0,16]),dict(name='گذر پارچه',rect=[8,18,-16,0]),dict(name='گذر خیاط',rect=[8,18,0,16]),dict(name='بازار مرکزی',rect=[-8,8,-16,16])]
    spawns=[[-2+(i%5),-4+2*(i//5)] for i in range(10)]
    return dict(version=VERSION,seed=seed,bounds=bounds,objects=objects,zones=zones,spawns=spawns,light=dict(color='#ffe6bc',ground='#b99b73'),shops=shops,npc_path=[[-11,-8],[-4,-8],[4,-8],[11,-8],[11,8],[4,8],[-4,8],[-11,8]])
