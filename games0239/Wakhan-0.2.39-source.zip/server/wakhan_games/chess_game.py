from .common import base,require,finish,public
from .vendor import chess
VERSION='chess-fide-300+3-wakhan-1'

def board(s):
    b=chess.Board(s['initial_fen'])
    for uci in s['moves']:b.push_uci(uci)
    return b

def create(players,rng,now,options=None):
    require(len(players)==2,'capacity');s=base(players);white=(options or {}).get('white_seat',rng.randrange(2));s.update(white=white,initial_fen=chess.STARTING_FEN,moves=[],san=[],clocks=[300.,300.],clock_at=now,turn=white,deadline=now+300,draw_offer=None,last_move=None);return s

def color(s,seat):return chess.WHITE if seat==s['white'] else chess.BLACK
def seat_for(s,c):return s['white'] if c==chess.WHITE else 1-s['white']
def can_mate(b,c):return not b.has_insufficient_material(c)
def charge(s,now):
    who=s['turn'];s['clocks'][who]=max(0,s['clocks'][who]-max(0,now-s['clock_at']));s['clock_at']=now;s['deadline']=now+s['clocks'][who]

def terminal(s,b):
    o=b.outcome(claim_draw=False)
    if o is None:return False
    reason={chess.Termination.CHECKMATE:'checkmate',chess.Termination.STALEMATE:'stalemate',chess.Termination.INSUFFICIENT_MATERIAL:'dead_position',chess.Termination.SEVENTYFIVE_MOVES:'75_moves',chess.Termination.FIVEFOLD_REPETITION:'fivefold'}.get(o.termination,'draw')
    finish(s,[] if o.winner is None else [seat_for(s,o.winner)],reason,draw=o.winner is None);return True

def flag(s,now):
    charge(s,now)
    if s['clocks'][s['turn']]>0:return False
    b=board(s);winner=1-s['turn']
    if can_mate(b,color(s,winner)):finish(s,[winner],'time')
    else:finish(s,reason='time_no_mate',draw=True)
    return True

def apply(s,seat,a,now,rng):
    require(not s['result'],'finished');require(seat in s['active'],'not_active')
    if flag(s,now):return
    b=board(s);kind=a.get('type')
    if kind=='resign':leave(s,seat,now,rng);return
    if kind=='offer_draw':require(len(s['moves'])>=2,'draw_too_early');require(s['draw_offer'] is None,'offer_pending');s['draw_offer']=seat;return
    if kind in ('accept_draw','decline_draw'):
        require(s['draw_offer'] is not None and s['draw_offer']!=seat,'no_draw_offer')
        if kind=='accept_draw':finish(s,reason='agreement',draw=True)
        s['draw_offer']=None;return
    require(seat==s['turn'],'not_your_turn')
    if kind=='claim_draw':
        rule=a.get('rule');require(rule in ('threefold','50_moves'),'bad_claim');intended=a.get('move');claim_board=b.copy(stack=True)
        if intended:
            try:m=chess.Move.from_uci(intended)
            except (ValueError,TypeError):require(False,'illegal_move')
            require(m in b.legal_moves,'illegal_move');claim_board.push(m)
        valid=claim_board.is_repetition(3) if rule=='threefold' else claim_board.halfmove_clock>=100 and any(claim_board.legal_moves)
        require(valid,'draw_claim_invalid');finish(s,reason=rule,draw=True,intended_move=intended or None);return
    require(kind=='move','invalid_action')
    try:m=chess.Move.from_uci(a.get('move',''))
    except (ValueError,TypeError):require(False,'illegal_move')
    require(m in b.legal_moves,'illegal_move');s['san'].append(b.san(m));s['moves'].append(m.uci());s['last_move']=m.uci();s['draw_offer']=None;s['clocks'][seat]+=3;b.push(m);s['turn']=seat_for(s,b.turn);s['clock_at']=now;s['deadline']=now+s['clocks'][s['turn']];terminal(s,b)

def leave(s,seat,now,rng):
    if s['result'] or seat not in s['active']:return
    s['active'].remove(seat)
    if not s['active']:finish(s,reason='incomplete');return
    winner=1-seat;b=board(s)
    if can_mate(b,color(s,winner)):finish(s,[winner],'resigned')
    else:finish(s,reason='resigned_no_mate',draw=True)

def tick(s,now,rng):
    if s['result'] or now<s['deadline']:return False
    return flag(s,now)

def view(s,seat,now):
    b=board(s);v=public(s,('initial_fen',));v['fen']=b.fen();v['color']='w' if color(s,seat) else 'b';v['check']=chess.square_name(b.king(b.turn)) if b.is_check() else None;v['legal']=[m.uci() for m in b.legal_moves] if seat==s['turn'] and not s['result'] else [];v['pieces']=[dict(square=chess.square_name(q),piece=p.symbol()) for q,p in b.piece_map().items()];v['clocks']=list(s['clocks']);
    if not s['result']:v['clocks'][s['turn']]=max(0,v['clocks'][s['turn']]-max(0,now-s['clock_at']))
    return v
