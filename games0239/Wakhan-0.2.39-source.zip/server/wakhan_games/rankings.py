"""Read-only integration: verified wins are statistics, never coins or XP awards."""
import json
from fractions import Fraction
from pathlib import Path
from .catalog import canonical,GAMES
from .common import require

def weights(namespace):
    value=namespace.get('ENV',{}).get('WKG_RANK_WEIGHTS')
    if not value:
        p=Path(__file__).with_name('ranking-policy.json')
        value=p.read_text() if p.is_file() else '{"activity":50,"purchase":50,"games":0}'
    try:
        data=json.loads(value) if isinstance(value,str) else value
        require(isinstance(data,dict) and set(data)=={'activity','purchase','games'},'bad_rank_policy')
        require(all(type(x) is int and 0<=x<=100 for x in data.values()) and sum(data.values())>0,'bad_rank_policy')
        return data
    except (ValueError,TypeError):return dict(activity=50,purchase=50,games=0)

class Rankings:
    def __init__(self,games,existing):self.g=games;self.old=existing;self.original=existing.leaderboard;self.weights=weights(games.n)
    def wins(self,viewer,start,end,game=None):
        where=' AND p.game=?' if game else '';args=[start,end,viewer,viewer]
        if game:args.append(canonical(game))
        rows=self.g.db.execute("""SELECT p.uid,count(*) FROM wkg_result_people p
JOIN wka_accounts a ON a.uid=p.uid
WHERE p.outcome='win' AND p.test=0 AND p.created>=? AND p.created<=?
AND a.done=1 AND coalesce(a.blocked,0)=0
AND NOT EXISTS(SELECT 1 FROM wm70_blocks b WHERE (b.actor=? AND b.target=p.uid) OR (b.target=? AND b.actor=p.uid))"""+where+' GROUP BY p.uid',args).fetchall()
        return dict(rows)
    def leaderboard(self,viewer,category='overall',period='month',now=None,game=None):
        require(category in {'overall','activity','purchase','games'} and period in {'week','month'},'bad_input')
        if game:game=canonical(game);require(game in GAMES,'unknown_game')
        if category not in ('games','overall') or category=='overall' and self.weights['games']==0:return self.original(viewer,category,period,now)
        start,end=self.old.window(period,now);wins=self.wins(int(viewer),start,end,game)
        if category=='games':scored=[(uid,Fraction(n)) for uid,n in wins.items() if n>0];rule='شمار بردهای معتبر همین دوره؛ مچ ناتمام و آزمایشی حساب نمی‌شود.'
        else:
            rows=self.old.rows(int(viewer),start,end);top_xp=max((r[1] for r in rows),default=0) or 1;top_purchase=max((r[2] for r in rows),default=0) or 1;top_wins=max(wins.values(),default=0) or 1;w=self.weights;total=sum(w.values());scored=[]
            for uid,xp,purchase in rows:
                score=Fraction(10000,total)*(Fraction(w['activity']*xp,top_xp)+Fraction(w['purchase']*purchase,top_purchase)+Fraction(w['games']*wins.get(uid,0),top_wins))
                if score>0:scored.append((uid,score))
            rule=f"بازی {w['games']}٪، فعالیت {w['activity']}٪ و خرید سکهٔ تأییدشده {w['purchase']}٪؛ هر بخش نسبت به بیشترین مقدار همین دوره."
        scored.sort(key=lambda r:(-r[1],r[0]));items=[];me=None
        for position,(uid,score) in enumerate(scored,1):
            if position<=50 or uid==int(viewer):
                p=self.g.profile(uid,int(viewer));item=dict(id=p['id'],name=p['name'],avatar=p['avatar'],position=position,score=round(float(score),2),own=uid==int(viewer))
                if position<=50:items.append(item)
                if uid==int(viewer):me=item
        return dict(ok=True,category=category,period=period,start=start,end=end,timezone='Asia/Kabul',available=True,rule=rule,items=items,me=me or dict(id=int(viewer),position=None,score=0,own=True),game=game)

def install(games,namespace):
    existing=namespace.get('WKH_RANKINGS')
    if existing is None:return None
    integration=Rankings(games,existing);existing.leaderboard=integration.leaderboard;namespace['WKG_RANKINGS']=integration;return integration
