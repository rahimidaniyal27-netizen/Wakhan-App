"""Shared rules primitives. No wallet mutations or client supplied randomness."""
import copy, math

class GameError(Exception):
    def __init__(self, code, status=400):
        super().__init__(code)
        self.code, self.status = code, status

def require(test, code='invalid_action'):
    if not test:
        raise GameError(code)

def integer(value, low, high):
    require(type(value) is int and low <= value <= high, 'bad_input')
    return value

def finish(state, winners=(), reason='normal', draw=False, **details):
    if state.get('result') is None:
        state['result'] = dict(winners=list(winners), reason=reason, draw=bool(draw), details=details)
    return state['result']

def next_active(state, seat, steps=1, direction=1):
    active=state['active'];n=len(state['players'])
    require(bool(active), 'no_players')
    for _ in range(steps):
        for _ in range(n):
            seat=(seat+direction)%n
            if seat in active:break
    return seat

def timeout(state, seat):
    if not state.get('connected',[True]*len(state['players']))[seat]:
        state['timeouts'][seat]=0
        return False
    state['timeouts'][seat]+=1
    return state['timeouts'][seat]>=2

def base(players):
    return dict(players=list(players),active=list(range(len(players))),timeouts=[0]*len(players),connected=[True]*len(players),result=None)

def public(state, exclude=()):
    return copy.deepcopy({k:v for k,v in state.items() if k not in {'players','connected','timeouts',*exclude}})
