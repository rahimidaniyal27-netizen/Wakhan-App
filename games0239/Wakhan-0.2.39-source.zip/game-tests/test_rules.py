import unittest,random,copy,json,math
from wakhan_games import fiskot,ludo,ono,chess_game,world
from wakhan_games.common import GameError

class FixedDice:
 def __init__(self,*dice):self.dice=iter(dice)
 def randrange(self,*a):return next(self.dice)
class FiscutTests(unittest.TestCase):
 def setUp(self):self.r=random.Random(4);self.s=fiskot.create([10,20,30,40],self.r,0)
 def test_deal_private_trump_and_52_distinct(self):
  s=self.s;self.assertEqual(s['turn'],(s['dealer']+1)%4);self.assertNotEqual(s['turn']%2,s['dealer']%2);self.assertEqual(list(map(len,s['hands'])),[5]*4);self.assertEqual(len(set(sum(s['hands'],[])+s['deck'])),52);v=fiskot.view(s,0,0);self.assertNotIn('hands',v);self.assertNotIn('deck',v);fiskot.apply(s,s['turn'],dict(type='trump',suit='S'),1,self.r);self.assertEqual(list(map(len,s['hands'])),[13]*4)
 def test_follow_suit_and_trump_winner(self):
  s=self.s;s.update(phase='play',turn=0,trump='S',hands=[['H2','C14'],['H14'],['S2'],['H13']],trick=[])
  fiskot.apply(s,0,dict(type='play',card='H2'),1,self.r)
  with self.assertRaises(GameError):fiskot.apply(s,1,dict(type='play',card='C14'),2,self.r)
  for seat,c in [(1,'H14'),(2,'S2'),(3,'H13')]:fiskot.apply(s,seat,dict(type='play',card=c),2+seat,self.r)
  self.assertEqual(s['turn'],2);self.assertEqual(s['tricks'],[1,0])
 def test_complete_real_match_has_13_tricks_per_hand(self):
  s=self.s;t=0
  for _ in range(2000):
   if s['result']:break
   t+=2
   if s['phase']=='hand_end':fiskot.tick(s,t+4,self.r);t+=4;continue
   action=dict(type='trump',suit='H') if s['phase']=='trump' else dict(type='play',card=fiskot.legal(s,s['turn'])[0]);fiskot.apply(s,s['turn'],action,t,self.r)
  self.assertIsNotNone(s['result']);self.assertTrue(all(sum(h['tricks'])==13 for h in s['history']));self.assertGreaterEqual(max(s['scores']),5)
 def test_thirteen_tricks_awards_two_and_forfeit_does_not_fake_score(self):
  s=self.s;s.update(phase='play',turn=0,trump='S',hands=[['S14'],['S13'],['S12'],['S11']],trick=[],tricks=[12,0]);
  for n in range(4):fiskot.apply(s,n,dict(type='play',card='S'+str(14-n)),n+1,self.r)
  self.assertEqual(s['scores'],[2,0]);fiskot.leave(s,1,10,self.r);self.assertEqual(s['scores'],[2,0]);self.assertEqual(s['result']['reason'],'opponent_left')

class LudoTests(unittest.TestCase):
 def setUp(self):self.r=random.Random(1);self.s=ludo.create([1,2,3,4],self.r,0);self.s['turn']=0
 def test_geometry_and_two_player_opposites(self):
  self.assertEqual(len(set(ludo.PATH)),52);self.assertTrue(all(len(p)==6 for p in ludo.FINALS));self.assertEqual(ludo.create([1,2],self.r,0)['colors'],[0,2])
 def test_six_third_six_preserves_prior_moves(self):
  s=self.s;r=FixedDice(6,6,6);ludo.apply(s,0,dict(type='roll'),1,r);ludo.apply(s,0,dict(type='move',token=0),2,r);self.assertEqual(s['tokens'][0][0],0);ludo.apply(s,0,dict(type='roll'),3,r);ludo.apply(s,0,dict(type='move',token=0),4,r);self.assertEqual(s['tokens'][0][0],6);ludo.apply(s,0,dict(type='roll'),5,r);self.assertEqual(s['turn'],1);self.assertEqual(s['tokens'][0][0],6)
 def test_capture_safe_and_exact_finish(self):
  s=self.s;s.update(phase='move',die=1);s['tokens'][0][0]=0;s['tokens'][1][0]=40;ludo.move(s,0,0,1);self.assertEqual(s['tokens'][1][0],-1)
  s.update(turn=0,phase='move',die=1);s['tokens'][0][0]=7;s['tokens'][1][0]=47;ludo.move(s,0,0,2);self.assertEqual(s['tokens'][1][0],47)
  s.update(turn=0,phase='move',die=2);s['tokens'][0][0]=55;self.assertNotIn(0,ludo.legal(s,0));s['die']=1;self.assertIn(0,ludo.legal(s,0));s['tokens'][0][1:]=[56]*3;ludo.move(s,0,0,3);self.assertEqual(s['result']['winners'],[0])
 def test_duplicate_roll_and_no_legal_move(self):
  s=self.s;ludo.apply(s,0,dict(type='roll'),1,FixedDice(6))
  with self.assertRaises(GameError):ludo.apply(s,0,dict(type='roll'),1,FixedDice(5))
  s=self.s=ludo.create([1,2,3],self.r,0);s['turn']=0;ludo.apply(s,0,dict(type='roll'),2,FixedDice(1));self.assertEqual(s['turn'],1);self.assertEqual(s['last_move']['reason'],'no_move')
 def test_own_landing_and_removed_player(self):
  s=self.s;s.update(phase='move',die=1);s['tokens'][0][:2]=[0,1];self.assertNotIn(0,ludo.legal(s,0));ludo.leave(s,1,2,self.r);self.assertEqual(s['tokens'][1],[-2]*4)

class OnoTests(unittest.TestCase):
 def setUp(self):self.r=random.Random(3);self.s=ono.create([1,2,3],self.r,0);self.s['turn']=0
 def card(self,c,v):return next(x['id'] for x in ono.CARDS if x['color']==c and x['value']==str(v))
 def setup_hand(self,hand,top=('r',5),n=3):
  s=ono.create(list(range(n)),self.r,0);s.update(turn=0,color=top[0],phase='turn',discard=[self.card(*top)]);s['hands'][0]=hand;s['hands'][1]=[self.card('g',2)];return s
 def test_108_unique_inventory_and_private_view(self):
  s=self.s;all_cards=sum(s['hands'],[])+s['pile']+s['discard'];self.assertEqual(len(all_cards),108);self.assertEqual(len(set(all_cards)),108);v=ono.view(s,0,0);self.assertNotIn('hands',v);self.assertNotIn('pile',v);self.assertNotIn('effect',v)
 def test_draw2_no_stacking_reverse_two(self):
  c=self.card('r','draw2');s=self.setup_hand([c,self.card('b',1),self.card('g',1)]);n=len(s['hands'][1]);ono.apply(s,0,dict(type='play',card=c),1,self.r);self.assertEqual(len(s['hands'][1]),n+2);self.assertEqual(s['turn'],2)
  c=self.card('r','reverse');s=self.setup_hand([c,self.card('b',1),self.card('g',1)],n=2);ono.apply(s,0,dict(type='play',card=c),1,self.r);self.assertEqual(s['turn'],0);self.assertEqual(s['direction'],-1)
 def test_correct_and_incorrect_wild4_challenge(self):
  c=self.card(None,'wild4')
  for illegal in (True,False):
   s=self.setup_hand([c,self.card('r' if illegal else 'b',2),self.card('g',1)]);a,b=len(s['hands'][0]),len(s['hands'][1]);ono.apply(s,0,dict(type='play',card=c,color='b'),1,self.r);v=ono.view(s,1,1);self.assertNotIn('had_color',v['challenge']);ono.apply(s,1,dict(type='challenge4'),2,self.r)
   if illegal:self.assertEqual(len(s['hands'][0]),a-1+4);self.assertEqual(s['turn'],1)
   else:self.assertEqual(len(s['hands'][1]),b+6);self.assertEqual(s['turn'],2)
 def test_ono_declaration_priority_and_no_automatic_penalty(self):
  c=self.card('r',1)
  for declare,claim,expected in [(True,True,1),(False,True,3),(False,False,1)]:
   s=self.setup_hand([c,self.card('g',1)]);ono.apply(s,0,dict(type='play',card=c),1,self.r)
   if claim:ono.apply(s,1,dict(type='catch_ono'),1.1,self.r)
   if declare:ono.apply(s,0,dict(type='declare_ono'),2.99,self.r)
   ono.tick(s,3.001,self.r);self.assertEqual(len(s['hands'][0]),expected)
 def test_last_wild4_waits_for_penalty_and_can_cancel_win(self):
  c=self.card(None,'wild4');s=self.setup_hand([c]);ono.apply(s,0,dict(type='play',card=c,color='b'),1,self.r);self.assertIsNone(s['result']);s['challenge']['had_color']=True;ono.apply(s,1,dict(type='challenge4'),2,self.r);self.assertIsNone(s['result']);self.assertEqual(len(s['hands'][0]),4)
  s=self.setup_hand([c]);ono.apply(s,0,dict(type='play',card=c,color='b'),1,self.r);ono.apply(s,1,dict(type='accept4'),2,self.r);self.assertEqual(s['result']['winners'],[0]);self.assertEqual(len(s['hands'][1]),5)
 def test_reshuffle_preserves_top_and_target_leaving_closes_penalty(self):
  s=self.s;top=s['discard'][-1];s['pile']=[];s['discard']=[0,1,top];added=ono.draw(s,0,9,self.r);self.assertEqual(len(added),2);self.assertEqual(s['discard'],[top])
  c=self.card(None,'wild4');s=self.setup_hand([c,self.card('b',1),self.card('g',1)]);ono.apply(s,0,dict(type='play',card=c,color='b'),1,self.r);n=len(s['hands'][2]);ono.leave(s,1,2,self.r);self.assertIsNone(s['challenge']);self.assertEqual(len(s['hands'][2]),n)

class ChessTests(unittest.TestCase):
 def setUp(self):self.r=random.Random(1);self.s=chess_game.create([1,2],self.r,0,{'white_seat':0})
 def move(self,m,t):chess_game.apply(self.s,self.s['turn'],dict(type='move',move=m),t,self.r)
 def fen(self,fen):self.s['initial_fen']=fen;self.s['moves']=[];self.s['san']=[];self.s['turn']=0 if ' w ' in fen else 1
 def test_mate_and_clock_increment(self):
  for i,m in enumerate(['f2f3','e7e5','g2g4','d8h4']):self.move(m,i+1)
  self.assertEqual(self.s['result']['reason'],'checkmate');self.assertEqual(self.s['result']['winners'],[1]);self.assertGreater(self.s['clocks'][0],300)
 def test_castling_ep_promotion_and_illegal_move(self):
  self.fen('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1');self.move('e1g1',1);self.assertEqual(chess_game.board(self.s).piece_at(chess_game.chess.F1).symbol(),'R')
  self.fen('4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1');self.move('e5d6',2);self.assertIsNone(chess_game.board(self.s).piece_at(chess_game.chess.D5))
  self.fen('4k3/P7/8/8/8/8/8/4K3 w - - 0 1');v=chess_game.view(self.s,0,2);self.assertEqual(len([m for m in v['legal'] if m.startswith('a7a8')]),4)
  with self.assertRaises(GameError):self.move('a7a8',3)
  self.move('a7a8n',3);self.assertEqual(chess_game.board(self.s).piece_at(chess_game.chess.A8).symbol(),'N')
 def test_stalemate_dead_position_and_time_without_mate_material(self):
  self.fen('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1');self.assertTrue(chess_game.terminal(self.s,chess_game.board(self.s)));self.assertEqual(self.s['result']['reason'],'stalemate')
  self.setUp();self.fen('4k3/8/8/8/8/8/8/4K3 w - - 0 1');chess_game.tick(self.s,301,self.r);self.assertEqual(self.s['result']['reason'],'time_no_mate');self.assertTrue(self.s['result']['draw'])
 def test_threefold_claim_and_fivefold_automatic(self):
  seq=['g1f3','g8f6','f3g1','f6g8']
  for i,m in enumerate(seq*2):self.move(m,i+1)
  chess_game.apply(self.s,self.s['turn'],dict(type='claim_draw',rule='threefold'),9,self.r);self.assertEqual(self.s['result']['reason'],'threefold')
  self.setUp()
  for i,m in enumerate(seq*4):
   if self.s['result']:break
   self.move(m,i+1)
  self.assertEqual(self.s['result']['reason'],'fivefold')
 def test_75_moves_and_bad_draw_claim(self):
  with self.assertRaises(GameError):chess_game.apply(self.s,0,dict(type='claim_draw',rule='threefold'),1,self.r)
  self.fen('7k/8/8/8/8/8/R7/K7 w - - 149 80');self.move('a2a3',2);self.assertEqual(self.s['result']['reason'],'75_moves')

class WorldTests(unittest.TestCase):
 def setUp(self):self.r=random.Random(2)
 def make(self,g='patpal',n=4):return world.create(list(range(1,n+1)),self.r,0,{'game':g})
 def test_role_counts_rotation_and_private_preparation(self):
  for n,count in [(4,1),(9,2),(13,3),(16,3)]:
   s=self.make(n=n);hunters=[p for p in s['people'] if p['role']=='seeker'];self.assertEqual(len(hunters),count);v=world.view(s,hunters[0]['seat'],6);self.assertEqual(v['entities'],[]);self.assertNotIn('people',v);self.assertNotIn('role_queue',v)
  s=self.make('bazaar',10);guard=next(p for p in s['people'] if p['role']=='guard');again=world.create(s['players'],self.r,0,{'game':'bazaar','role_queue':s['role_queue']});self.assertNotEqual(guard['seat'],next(p for p in again['people'] if p['role']=='guard')['seat']);self.assertEqual(s['threshold'],5);self.assertNotIn('mission',world.view(s,guard['seat'],16))
 def test_sample_paint_pose_lock_and_wall_visibility(self):
  s=self.make();world.tick(s,6,self.r);p=next(p for p in s['people'] if p['role']=='hider');p.update(x=-13.3,z=-5,yaw=-math.pi/2);seat=p['seat'];world.apply(s,seat,dict(type='sample',surface='west',point=[-13.875,1,-5]),6,self.r);world.apply(s,seat,dict(type='paint',region=1,sample=0),6,self.r);self.assertEqual(p['paint'][1],s['map']['objects'][0]['color']);world.apply(s,seat,dict(type='erase',region=1),6,self.r);self.assertEqual(p['paint'][1],p['original'][1]);world.apply(s,seat,dict(type='pose',pose='lean'),6,self.r);world.tick(s,41,self.r)
  with self.assertRaises(GameError):world.apply(s,seat,dict(type='pose',pose='stand'),41,self.r)
  hunter=next(p for p in s['people'] if p['role']=='seeker');hunter.update(x=-3,z=-3,yaw=math.pi/2);p.update(x=0,z=-3);self.assertFalse(world.in_view(s,hunter,p,3))
 def test_catch_once_and_hint_has_only_section(self):
  s=self.make();world.tick(s,41,self.r);hunter=next(p for p in s['people'] if p['role']=='seeker');p=next(p for p in s['people'] if p['role']=='hider');hunter.update(x=0,z=4,yaw=0);p.update(x=0,z=6);world.apply(s,hunter['seat'],dict(type='check',entity=p['entity']),42,self.r);self.assertEqual(p['status'],'caught')
  with self.assertRaises(GameError):world.apply(s,hunter['seat'],dict(type='check',entity=p['entity']),46,self.r)
  self.assertEqual(hunter['found'],1);world.tick(s,136,self.r);v=world.view(s,hunter['seat'],136);self.assertIsInstance(v['hint'],str);self.assertNotIn('samples',v)
 def test_market_delivery_threshold_and_three_guard_errors(self):
  s=self.make('bazaar');world.tick(s,16,self.r);runners=[p for p in s['people'] if p['role']=='runner'];guard=next(p for p in s['people'] if p['role']=='guard')
  for p in runners[:2]:
   m=p['mission']
   for kind,key in [('take',m['source']),('deliver',m['target'])]:
    q=next(q for q in s['map']['shops'] if q['id']==key);p.update(x=q['x'],z=q['z']);world.apply(s,p['seat'],dict(type=kind),17,self.r)
  self.assertEqual(s['result']['reason'],'missions_complete')
  s=self.make('bazaar');world.tick(s,16,self.r);guard=next(p for p in s['people'] if p['role']=='guard');npc=s['npcs'][0];guard.update(x=-11,z=-6,yaw=math.pi);npc.update(x=-11,z=-8)
  for n in range(3):world.apply(s,guard['seat'],dict(type='check',entity=npc['entity']),20+n*3,self.r)
  self.assertEqual(s['errors'],3)
  with self.assertRaises(GameError):world.apply(s,guard['seat'],dict(type='check',entity=npc['entity']),30,self.r)
 def test_motion_speed_collision_and_npc_paths(self):
  s=self.make('bazaar');world.tick(s,16,self.r);p=next(p for p in s['people'] if p['role']=='runner');p.update(x=0,z=-6,motion_at=16);start=(p['x'],p['z']);world.apply(s,p['seat'],dict(type='move',x=0,z=-1000,yaw=math.pi,input_seq=1),16.1,self.r);self.assertLessEqual(world.dist(start,(p['x'],p['z'])),.221)
  positions=[(p['x'],p['z']) for p in s['npcs']]
  for step in range(1,301):
   world.advance_motion(s,16+step*.1)
   self.assertTrue(all(world.clear_position(s['map'],p['x'],p['z']) for p in s['npcs']))
  self.assertTrue(all(world.dist(a,(p['x'],p['z']))>.1 for a,p in zip(positions,s['npcs'])))

if __name__=='__main__':unittest.main()

class PresenceTimeoutTests(unittest.TestCase):
 def test_offline_auto_moves_do_not_count_as_connected_inactivity(self):
  from wakhan_games.common import base,timeout
  s=base([1,2]);s['connected'][0]=False
  for i in range(4):self.assertFalse(timeout(s,0))
  s['connected'][0]=True;self.assertFalse(timeout(s,0));self.assertTrue(timeout(s,0))
