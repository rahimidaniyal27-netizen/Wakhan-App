"""Local synthetic harness only. NEVER package or mount these routes in production."""
import asyncio,copy,json,random,sqlite3,time,types,sys
from pathlib import Path
from aiohttp import web
sys.path.insert(0,str(Path(__file__).parents[1]/'server'))
from wakhan_games.service import Games
ROOT=Path(__file__).parents[1];PROJECT=ROOT/'project'
class TestClock:
 def __init__(self):self.offset=0
 def __call__(self):return time.time()+self.offset
class Salon:
 def __init__(self):self.hall=self
 def info(self,code,uid):return dict(name='سالون آزمایشی',owner_id=1) if code=='TEST' else None
 def visible(self,code,uid,info=None):return uid<=16
 def member(self,code,uid):return code=='TEST' and uid<=16
 def present(self,code):return list(range(1,17))
async def main():
 db=sqlite3.connect(':memory:');db.executescript('CREATE TABLE users(uid INTEGER PRIMARY KEY,name TEXT);CREATE TABLE wka_accounts(uid INTEGER PRIMARY KEY,done INTEGER,blocked INTEGER);CREATE TABLE wm70_blocks(actor INTEGER,target INTEGER);CREATE TABLE wm70_friends(a INTEGER,b INTEGER,state TEXT);CREATE TABLE wm_coin_accounts(uid INTEGER PRIMARY KEY,balance INTEGER);')
 for uid in range(1,65):db.execute('INSERT INTO users VALUES(?,?)',(uid,['آریا','مینا','فرهاد','سارا','شکیب','بلال','صدف','رامین'][(uid-1)%8]+str(uid)));db.execute('INSERT INTO wka_accounts VALUES(?,1,0)',(uid,));db.execute('INSERT INTO wm_coin_accounts VALUES(?,12345)',(uid,))
 for a in range(1,65):
  for b in range(a+1,65):db.execute("INSERT INTO wm70_friends VALUES(?,?,'accepted')",(a,b))
 db.commit();clock=TestClock();me=types.SimpleNamespace(com=types.SimpleNamespace(row=lambda uid:dict(name=db.execute('SELECT name FROM users WHERE uid=?',(uid,)).fetchone()[0])),more=types.SimpleNamespace(can_see=lambda *a:False))
 def auth(fn):
  async def wrapped(req):
   uid=int(req.headers.get('X-Test-Uid','0'))
   if not 1<=uid<=64:return web.json_response(dict(ok=False,err='auth'),status=401)
   req['u']=dict(id=uid);return await fn(req)
  return wrapped
 ns=dict(DB=db,WME=me,WKS_SALON=Salon(),auth=auth,J=lambda v,status=200:web.json_response(v,status=status));g=Games(ns,clock=clock,rng=random.Random(17),testing=True);app=web.Application();g.routes(app)
 async def control(req):
  b=await req.json();op=b.get('op')
  async with g.lock:
   if op=='reset':
    for c in list(g.connections.values()):await c['ws'].close()
    for table in ('matches','members','actions','results','result_people','invites'):db.execute('DELETE FROM wkg_'+table)
    db.commit();g.cache.clear();g.rates.clear();g.profiles.clear();g.last_persist.clear();clock.offset=0
   if op=='advance':clock.offset+=b['seconds']
   if op=='pulse':
    for mid in list(g.cache):
     l=g.load(mid)
     for m in l['members']:m.update(seen=clock(),offline_since=None)
     with g.atomic():g.persist(l)
   if op=='patch':
    l=g.load(b['match']);l['state'].update(b['state']);l['version']+=1
    with g.atomic():g.persist(l)
  await g.tick();return web.json_response(dict(ok=True,time=clock()))
 app.router.add_post('/_test/control',control)
 async def fixture(req):return web.FileResponse(ROOT/'game-tests/parent.html')
 app.router.add_get('/',fixture)
 async def static(req):
  path=req.match_info['path'];base=PROJECT/'public' if path.startswith(('games-ui/','home-ui/')) or (PROJECT/'public'/path).is_file() else PROJECT
  p=(base/path).resolve()
  if not p.is_relative_to(base.resolve()) or not p.is_file():raise web.HTTPNotFound()
  return web.FileResponse(p,headers={'Cache-Control':'no-store'})
 app.router.add_get('/{path:.*}',static)
 runner=web.AppRunner(app);await runner.setup();await web.TCPSite(runner,'127.0.0.1',8773).start();print('Synthetic games harness http://127.0.0.1:8773',flush=True);await asyncio.Event().wait()
asyncio.run(main())
