import asyncio,copy,json,uuid,math
from pathlib import Path
from playwright.async_api import async_playwright
BASE='http://127.0.0.1:8773';OUT=Path(__file__).parent/'screenshots'
async def main():
 errors=[];results=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']);api=await p.request.new_context(base_url=BASE)
  async def ctl(**kw):return await (await api.post('/_test/control',data=kw)).json()
  async def post(path,uid,**kw):
   r=await api.post('/api/app/games'+path,data={'instance':f'{uid:032x}','action_id':uuid.uuid4().hex,**kw},headers={'X-Test-Uid':str(uid)});v=await r.json();assert v.get('ok'),v;return v
  async def state(mid,uid):return await (await api.get('/api/app/games/'+mid+'?instance='+f'{uid:032x}',headers={'X-Test-Uid':str(uid)})).json()
  for game in ['patpal','bazaar']:
   await ctl(op='reset');v=await post('/create',1,game=game,public=True);mid=v['id']
   for uid in [2,3,4]:await post('/'+mid+'/join',uid)
   v=await state(mid,1);await post('/'+mid+'/action',1,expected_version=v['version'],action={'type':'start'});await ctl(op='advance',seconds=2.1);await ctl(op='pulse');await ctl(op='advance',seconds=5.1);await ctl(op='pulse')
   uid=next(uid for uid in [1,2,3,4] if (await state(mid,uid))['state']['role']==('hider' if game=='patpal' else 'runner')) if False else None
   for u in [1,2,3,4]:
    if (await state(mid,u))['state']['role']==('hider' if game=='patpal' else 'runner'):uid=u;break
   context=await b.new_context(viewport={'width':393,'height':852},has_touch=True,is_mobile=True);await context.add_init_script('sessionStorage.setItem("wk_game_instance","'+f'{uid:032x}'+'")');pg=await context.new_page();pg.on('pageerror',lambda e:errors.append(str(e)));pg.set_default_timeout(15000);await pg.goto(BASE+'/?uid='+str(uid));await pg.wait_for_function('window.fixtureReady');await pg.evaluate('(id)=>WakhanGames.openMatch(id)',mid);f=pg.frame_locator('.wk-games-frame');await f.locator('canvas').wait_for();await pg.wait_for_timeout(500)
   if game=='patpal':
    # Turn the actual camera toward the nearest side wall before sampling it.
    current=(await state(mid,uid))['state']['self'];desired=math.pi/2 if current['x']>0 else -math.pi/2;delta=(desired-current['yaw']+math.pi)%(2*math.pi)-math.pi
    remaining=delta
    while abs(remaining)>.01:
     turn=max(-.65,min(.65,remaining));await pg.mouse.move(196,410);await pg.mouse.down();await pg.mouse.move(196-turn/.006,410,steps=5);await pg.mouse.up();remaining-=turn
    await pg.wait_for_timeout(220);await f.get_by_role('button',name='قطره‌چکان',exact=True).tap();await f.locator('canvas').tap(position={'x':196,'y':426});await pg.wait_for_timeout(250)
    assert (await state(mid,uid))['state']['samples'],await f.locator('body').inner_text();await f.locator('.swatches button').first.tap();await pg.wait_for_timeout(180);s=(await state(mid,uid))['state'];assert s['self']['paint'][1]==s['samples'][0]
    await f.get_by_role('button',name='نشستن',exact=True).tap();await pg.wait_for_timeout(180);assert (await state(mid,uid))['state']['self']['pose']=='sit';await pg.screenshot(path=str(OUT/'patpal-camouflage.png'));await f.get_by_role('button',name='پاک‌کن',exact=True).tap();await pg.wait_for_timeout(180);s=(await state(mid,uid))['state'];assert s['self']['paint'][1]==s['original'][1];await f.get_by_role('button',name='ایستادن',exact=True).tap()
   # Pointer capture/cancel and closing a menu must stop old motion.
   box=await f.locator('.joystick').bounding_box();cdp=await context.new_cdp_session(pg);await cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':box['x']+54,'y':box['y']+18}]});await cdp.send('Input.dispatchTouchEvent',{'type':'touchCancel','touchPoints':[]})
   await pg.wait_for_timeout(300)
   before=(await state(mid,uid))['state']['self'];await pg.wait_for_timeout(400);after=(await state(mid,uid))['state']['self'];assert math.hypot(before['x']-after['x'],before['z']-after['z'])<.08
   # Move with real held mouse on virtual joystick; camera can be dragged independently.
   box=await f.locator('.joystick').bounding_box();start=(await state(mid,uid))['state']['self'];await pg.mouse.move(box['x']+54,box['y']+24);await pg.mouse.down();await pg.wait_for_timeout(550);await pg.mouse.up();await pg.wait_for_timeout(150);end=(await state(mid,uid))['state']['self'];distance=math.hypot(end['x']-start['x'],end['z']-start['z']);assert .03<distance<2.6,distance
   await pg.evaluate('routeTo("m")');await pg.wait_for_timeout(150);stopped=(await state(mid,uid))['state']['self'];await pg.wait_for_timeout(350);again=(await state(mid,uid))['state']['self'];assert stopped['x']==again['x'] and stopped['z']==again['z']
   await pg.evaluate('(id)=>WakhanGames.openMatch(id)',mid);await f.locator('canvas').wait_for();await pg.wait_for_timeout(200);stats=await f.locator('.world-shell').evaluate('n=>({...n.dataset})');results.append({'game':game,'sample_paint_erase_pose':game=='patpal','movement_metres':round(distance,3),'cancel_stops':True,'route_exit_stops':True,'software_renderer':stats});print('PASS',game,results[-1],flush=True);await context.close()
  assert not errors,errors;Path(__file__).with_name('world-control-results.json').write_text(json.dumps(dict(results=results,errors=errors,physical_device_verified=False),indent=2));await b.close()
asyncio.run(main())
