import asyncio,json,uuid,time
from pathlib import Path
from playwright.async_api import async_playwright
BASE='http://127.0.0.1:8773';OUT=Path(__file__).parent/'screenshots';OUT.mkdir(exist_ok=True)
async def main():
 errors=[];results=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
  api=await p.request.new_context(base_url=BASE)
  async def control(**kw):return await (await api.post('/_test/control',data=kw)).json()
  async def post(path,uid,**kw):
   body={'instance':f'{uid:032x}','action_id':uuid.uuid4().hex,**kw};r=await api.post('/api/app/games'+path,data=body,headers={'X-Test-Uid':str(uid)});v=await r.json();assert v.get('ok'),v;return v
  async def get(path,uid):return await (await api.get('/api/app/games'+path,headers={'X-Test-Uid':str(uid)})).json()
  for game,n in [('fiskot',4),('ono',6),('chess',2),('ludo',4),('patpal',4),('bazaar',4)]:
   await control(op='reset');context=await b.new_context(viewport={'width':393,'height':852},has_touch=True,is_mobile=True);page=await context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.set_default_timeout(15000);await page.goto(BASE+'/?uid=1');await page.wait_for_function('window.fixtureReady');h=page.frame_locator('.wk-approved-home-frame');await h.locator('[data-open-game='+game+']').tap();f=page.frame_locator('.wk-games-frame');await f.locator('[data-create]').tap();await f.locator('.dialog').get_by_role('button',name='ساخت لابی',exact=True).tap();await f.locator('[data-start]').wait_for();mid=await page.evaluate('WakhanGames.snapshot.id');inst=await page.evaluate('sessionStorage.wk_game_instance')
   for uid in range(2,n+1):await post('/'+mid+'/join',uid)
   await page.wait_for_function('WakhanGames.snapshot.count=='+str(n));await f.locator('[data-start]').tap();await page.wait_for_function('WakhanGames.snapshot.status==="active"');await page.wait_for_timeout(250)
   state=await page.evaluate('WakhanGames.snapshot.state')
   if game=='fiskot':
    seat=state['turn'];uid=seat+1;v=await get('/'+mid+'?instance='+(inst if uid==1 else f'{uid:032x}'),uid);await post('/'+mid+'/action',uid,instance=inst if uid==1 else f'{uid:032x}',expected_version=v['version'],action={'type':'trump','suit':'H'});await f.locator('[data-card]').nth(12).wait_for();await page.screenshot(path=str(OUT/'fiskot-full.png'))
    for i in range(8):
     v=await get('/'+mid+'?instance='+inst,1);s=v['state'];uid=s['turn']+1;v=await get('/'+mid+'?instance='+(inst if uid==1 else f'{uid:032x}'),uid)
     if uid==1:
      card=f.locator('[data-card="'+str(v['state']['legal'][0])+'"]');await card.scroll_into_view_if_needed();await card.tap(position={'x':8,'y':15});await f.locator('[data-play]').tap()
     else:await post('/'+mid+'/action',uid,expected_version=v['version'],action={'type':'play','card':v['state']['legal'][0]})
     await page.wait_for_timeout(200)
     if (i+1)%4==0:await page.wait_for_timeout(750)
    await page.screenshot(path=str(OUT/'fiskot-mid.png'))
   elif game=='ono':
    await f.locator('.hand-strip').wait_for();await page.screenshot(path=str(OUT/'ono-full.png'))
    for i in range(8):
     v=await get('/'+mid+'?instance='+inst,1);s=v['state'];uid=s['turn']+1;v=await get('/'+mid+'?instance='+(inst if uid==1 else f'{uid:032x}'),uid);s=v['state'];a={'type':'accept4'} if s['phase']=='challenge4' else {'type':'play','card':s['legal'][0],'color':'r','ono':True} if s['legal'] else {'type':'pass' if s['phase']=='drawn' else 'draw'};await post('/'+mid+'/action',uid,instance=inst if uid==1 else f'{uid:032x}',expected_version=v['version'],action=a);await page.wait_for_timeout(80)
    await page.screenshot(path=str(OUT/'ono-mid.png'))
   elif game=='chess':
    await f.locator('.chess-board').wait_for();await page.screenshot(path=str(OUT/'chess-start.png'))
    for move in ['f2f3','e7e5','g2g4','d8h4']:
     v=await get('/'+mid+'?instance='+inst,1);uid=v['state']['turn']+1
     if uid==1:
      await f.locator('[data-square='+move[:2]+']').tap();await f.locator('[data-square='+move[2:4]+']').tap()
     else:await post('/'+mid+'/action',uid,expected_version=v['version'],action={'type':'move','move':move})
     await page.wait_for_timeout(150)
    await f.locator('.result').wait_for();assert 'کیش' in await f.locator('.result').inner_text();results.append({'game':'chess','complete_actual_ui':True})
    # Test-only legal promotion position, server rules and actual promotion UI.
    v=await page.evaluate('WakhanGames.snapshot');s=v['state'];white=s['white'];uid=1;await context.close();await control(op='reset');context=await b.new_context(viewport={'width':393,'height':852},has_touch=True,is_mobile=True);page=await context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));await page.goto(BASE+'/?uid=1');await page.wait_for_function('window.fixtureReady');await page.evaluate('WakhanGames.open("chess")');f=page.frame_locator('.wk-games-frame');await f.locator('[data-create]').tap();await f.locator('.dialog .primary').tap();await f.locator('[data-start]').wait_for();mid=await page.evaluate('WakhanGames.snapshot.id');await post('/'+mid+'/join',2);await page.wait_for_function('WakhanGames.snapshot.count===2');await f.locator('[data-start]').tap();await f.locator('.chess-board').wait_for();v=await page.evaluate('WakhanGames.snapshot');s=v['state'];s.update(initial_fen='7k/P7/8/8/8/8/8/7K w - - 0 1',moves=[],san=[],turn=0,white=0,last_move=None);s.pop('fen',None);await control(op='patch',match=mid,state={'initial_fen':s['initial_fen'],'moves':[],'san':[],'turn':0,'white':0,'last_move':None});await page.wait_for_timeout(250);await f.locator('[data-square=a7]').tap();await f.locator('[data-square=a8]').tap();await f.locator('.promotion').wait_for();await page.screenshot(path=str(OUT/'chess-promotion.png'));await f.locator('.promotion button').first.tap();await page.wait_for_timeout(180)
   elif game=='ludo':
    await f.locator('.ludo-board').wait_for();v=await page.evaluate('WakhanGames.snapshot');s=v['state'];s.update(turn=0,phase='move',die=6,roll_id=s['roll_id']+1);await control(op='patch',match=mid,state={'turn':0,'phase':'move','die':6,'roll_id':s['roll_id']});await f.locator('.token-options button').first.tap();await f.locator('[data-move]').tap();await page.wait_for_timeout(100);await page.screenshot(path=str(OUT/'ludo-move.png'))
   else:
    await f.locator('canvas').wait_for();await control(op='advance',seconds=6);await control(op='pulse');await page.wait_for_timeout(500)
    s=await page.evaluate('WakhanGames.snapshot.state');role=s['role'];await page.screenshot(path=str(OUT/(game+'-'+role+'.png')))
    # Use another independent account to capture the opposing role, preserving its private projection.
    for uid in range(2,n+1):
     state=(await get('/'+mid+'?instance='+f'{uid:032x}',uid))['state']
     wanted='hider' if game=='patpal' else 'runner'
     if state['role']==wanted and role!=wanted:
      other=await b.new_context(viewport={'width':393,'height':852},has_touch=True,is_mobile=True);await other.add_init_script('sessionStorage.setItem("wk_game_instance","'+f'{uid:032x}'+'")');pg=await other.new_page();pg.on('pageerror',lambda e:errors.append(str(e)));await pg.goto(BASE+'/?uid='+str(uid));await pg.wait_for_function('window.fixtureReady');await pg.evaluate('(id)=>WakhanGames.openMatch(id)',mid);await pg.frame_locator('.wk-games-frame').locator('canvas').wait_for();await pg.wait_for_timeout(400);await pg.screenshot(path=str(OUT/(game+'-'+wanted+'.png')));await other.close();break
    f=page.frame_locator('.wk-games-frame');await control(op='advance',seconds=40 if game=='patpal' else 10);await control(op='pulse');await page.wait_for_timeout(300);shell=f.locator('.world-shell');stats=await shell.evaluate('n=>({fps:n.dataset.fps,calls:n.dataset.drawCalls,triangles:n.dataset.triangles})');results.append({'game':game,'software_renderer_stats':stats,'phone_verified':False});await page.screenshot(path=str(OUT/(game+'-search.png')))
   # Initial canvas is full viewport, safe controls never overlap status clock.
   box=await page.locator('.wk-games-frame').bounding_box();assert box['y']==0 and box['height']==852,box
   assert await f.locator('html').evaluate('n=>n.scrollWidth')<=393
   results.append({'game':game,'rendered':True});print('PASS',game,errors,flush=True);await context.close()
  assert not errors,errors;(OUT.parent/'ui-results.json').write_text(json.dumps({'results':results,'errors':errors,'real_devices_tested':False},ensure_ascii=False,indent=2));await b.close()
asyncio.run(main())
