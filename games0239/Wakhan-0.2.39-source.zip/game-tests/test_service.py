import asyncio,copy,json,random,sqlite3,types,unittest,uuid
from aiohttp import web
from aiohttp.test_utils import TestServer,TestClient
from wakhan_games.service import Games

class Clock:
 def __init__(self):self.now=1000.
 def __call__(self):return self.now
class FakeSalon:
 def __init__(self):self.hall=self;self.memberships=set()
 def info(self,code,uid):return dict(name='Private salon',owner_id=1) if code=='PRIVATE' else None
 def visible(self,code,uid,info=None):return uid<=4
 def member(self,code,uid):return (code,uid) in self.memberships
class ServiceTests(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.db=sqlite3.connect(':memory:');self.db.executescript('CREATE TABLE users(uid INTEGER PRIMARY KEY,name TEXT);CREATE TABLE wka_accounts(uid INTEGER PRIMARY KEY,done INTEGER,blocked INTEGER);CREATE TABLE wm70_blocks(actor INTEGER,target INTEGER);CREATE TABLE wm70_friends(a INTEGER,b INTEGER,state TEXT);CREATE TABLE wm_coin_accounts(uid INTEGER PRIMARY KEY,balance INTEGER);')
  for uid in range(1,33):self.db.execute('INSERT INTO users VALUES(?,?)',(uid,'Person'+str(uid)));self.db.execute('INSERT INTO wka_accounts VALUES(?,1,0)',(uid,));self.db.execute('INSERT INTO wm_coin_accounts VALUES(?,12345)',(uid,))
  for a in range(1,33):
   for b in range(a+1,33):self.db.execute("INSERT INTO wm70_friends VALUES(?,?,'accepted')",(a,b))
  self.db.commit();self.clock=Clock();self.salon=FakeSalon();me=types.SimpleNamespace(com=types.SimpleNamespace(row=lambda uid:dict(name='Person'+str(uid))),more=types.SimpleNamespace(can_see=lambda *a:True))
  def auth(fn):
   async def wrapped(req):
    try:uid=int(req.headers.get('X-Test-Uid','0'))
    except ValueError:uid=0
    if not uid:return web.json_response(dict(ok=False,err='auth'),status=401)
    req['u']=dict(id=uid);return await fn(req)
   return wrapped
  self.ns=dict(DB=self.db,WME=me,WKS_SALON=self.salon,auth=auth,J=lambda value,status=200:web.json_response(value,status=status));self.g=Games(self.ns,clock=self.clock,rng=random.Random(7),testing=True);app=web.Application();self.g.routes(app);self.client=TestClient(TestServer(app));await self.client.start_server()
 async def asyncTearDown(self):await self.client.close();self.db.close()
 def body(self,uid,**data):return dict(instance=f'{uid:032x}',action_id=uuid.uuid4().hex,**data)
 async def post(self,path,uid,body=None,ok=True):
  r=await self.client.post('/api/app/games'+path,headers={'X-Test-Uid':str(uid)},json=body or self.body(uid));v=await r.json()
  if ok:self.assertEqual(r.status,200,v);self.assertTrue(v.get('ok'),v)
  else:self.assertNotEqual(r.status,200,v)
  return v
 async def get(self,path,uid,ok=True):
  r=await self.client.get('/api/app/games'+path,headers={'X-Test-Uid':str(uid)});v=await r.json()
  if ok:self.assertEqual(r.status,200,v)
  else:self.assertNotEqual(r.status,200,v)
  return v
 async def create(self,game='chess',uid=1,public=True,**kw):return await self.post('/create',uid,self.body(uid,game=game,public=public,**kw))
 async def join(self,mid,uid,ok=True):return await self.post('/'+mid+'/join',uid,self.body(uid),ok)
 async def state(self,mid,uid):return await self.get('/'+mid+'?instance='+f'{uid:032x}',uid)
 async def action(self,mid,uid,action,body=None,ok=True):
  if body is None:s=await self.state(mid,uid);body=self.body(uid,expected_version=s['version'],action=action)
  return await self.post('/'+mid+'/action',uid,body,ok)
 async def start(self,mid,host=1):
  await self.action(mid,host,dict(type='start'));self.clock.now+=2.1;await self.g.tick();return await self.state(mid,host)
 async def socket(self,uid,instance=None):
  b=self.body(uid)
  if instance:b['instance']=instance
  r=await self.post('/socket',uid,b);ws=await self.client.ws_connect('/api/app/games/ws?ticket='+r['ticket']);await ws.receive_json();return ws,r
 async def read_until(self,ws,kind):
  for _ in range(50):
   v=await ws.receive_json(timeout=3)
   if v.get('type')==kind:return v
  self.fail('No '+kind)
 async def test_catalog_alias_private_and_origin_scope(self):
  cat=await self.get('/catalog',1);self.assertEqual(len(cat['games']),6);l=await self.create('hide',public=False,origin='PRIVATE');self.assertEqual(l['game'],'patpal');mid=l['id'];self.assertEqual((await self.get('/lobbies',5))['items'],[]);await self.get('/'+mid,5,False)
  await self.post('/'+mid+'/invite',1,self.body(1,expected_version=l['version'],targets=[5]));h=await self.get('/home',5);self.assertIsNone(h['invites'][0]['match']['origin']);self.assertNotIn('PRIVATE',json.dumps(h));iid=h['invites'][0]['id'];joined=await self.post('/invites/'+iid,5,self.body(5,accept=True));self.assertIsNone(joined['origin']);self.assertEqual(self.salon.memberships,set())
 async def test_last_seat_race_and_start_twice(self):
  l=await self.create('fiskot');mid=l['id'];await self.join(mid,2);await self.join(mid,3)
  async def attempt(uid):
   r=await self.client.post('/api/app/games/'+mid+'/join',headers={'X-Test-Uid':str(uid)},json=self.body(uid));return r.status,await r.json()
  outcomes=await asyncio.gather(attempt(4),attempt(5));self.assertEqual(sum(status==200 for status,_ in outcomes),1);l=await self.state(mid,1);self.assertEqual(l['count'],4)
  b1=self.body(1,expected_version=l['version'],action=dict(type='start'));b2=self.body(1,expected_version=l['version'],action=dict(type='start'));await self.action(mid,1,{},body=b1);await self.action(mid,1,{},body=b2,ok=False);self.clock.now+=2.1;await self.g.tick();s=self.g.load(mid)['state'];self.assertEqual(len(set(sum(s['hands'],[])+s['deck'])),52)
 async def test_create_and_move_receipts_survive_restart(self):
  b=self.body(1,game='fiskot',public=True);a=await self.post('/create',1,b);again=await self.post('/create',1,b);self.assertEqual(a['id'],again['id']);mid=a['id']
  for uid in [2,3,4]:await self.join(mid,uid)
  await self.start(mid);l=self.g.load(mid);seat=l['state']['turn'];uid=l['members'][seat]['uid'];s=await self.state(mid,uid);b=self.body(uid,expected_version=s['version'],action=dict(type='trump',suit='H'));await self.action(mid,uid,{},body=b);stored=copy.deepcopy(self.g.load(mid)['state']);v=await self.action(mid,uid,{},body=b);self.assertTrue(v['duplicate']);self.assertEqual(self.g.load(mid)['state'],stored)
  newer=Games(self.ns,clock=self.clock,rng=random.Random(1),testing=True);self.assertEqual(newer.load(mid)['state'],stored);self.assertTrue(newer.receipt(uid,b,'action',mid)[2]);self.assertNotIn('hands',(await self.state(mid,1))['state']);await self.get('/'+mid+'?instance='+f'{5:032x}',5,False)
 async def test_invite_expire_decline_resend_keeps_lobby(self):
  l=await self.create('patpal',public=False);mid=l['id'];await self.post('/'+mid+'/invite',1,self.body(1,expected_version=l['version'],targets=[2]));inv=(await self.get('/home',2))['invites'][0];await self.post('/invites/'+inv['id'],2,self.body(2,accept=False));self.assertEqual((await self.state(mid,1))['status'],'waiting');await self.post('/'+mid+'/invite',1,self.body(1,expected_version=l['version'],targets=[2]));new=(await self.get('/home',2))['invites'][0];self.assertNotEqual(new['id'],inv['id']);self.clock.now+=20.1;v=await self.post('/invites/'+new['id'],2,self.body(2,accept=True),False);self.assertEqual(v['err'],'invite_expired');self.assertEqual((await self.get('/home',2))['invites'],[])
 async def test_host_migration_compacts_only_before_start(self):
  l=await self.create('patpal');mid=l['id'];await self.join(mid,2);await self.join(mid,3);await self.action(mid,1,dict(type='leave'));self.assertEqual(self.g.load(mid)['host'],2);await self.join(mid,4);await self.join(mid,5);await self.start(mid,2);l=self.g.load(mid);self.assertEqual([m['seat'] for m in l['members']],[0,1,2,3]);uids=[m['uid'] for m in l['members']];await self.action(mid,3,dict(type='leave'));self.assertEqual([m['uid'] for m in self.g.load(mid)['members']],uids);await self.join(mid,6,False)
 async def test_waiting_one_needed_all_games_and_private_excluded(self):
  for game in ['patpal','bazaar','fiskot','ludo','chess','ono']:
   l=await self.create(game);mid=l['id'];minimum=l['minimum']
   for uid in range(2,minimum):await self.join(mid,uid)
   h=await self.get('/home',20);self.assertEqual(len(h['one_needed']),1);self.assertEqual(h['one_needed'][0]['count'],minimum-1);await self.join(mid,minimum);self.assertTrue((await self.state(mid,1))['can_start'])
   for uid in range(1,minimum+1):await self.action(mid,uid,dict(type='leave'))
 async def test_result_unique_no_wallet_changes_and_rematch(self):
  l=await self.create();mid=l['id'];await self.join(mid,2);await self.start(mid)
  for move in ['f2f3','e7e5','g2g4','d8h4']:
   l=self.g.load(mid);uid=l['members'][l['state']['turn']]['uid'];s=await self.state(mid,uid);b=self.body(uid,expected_version=s['version'],action=dict(type='move',move=move));await self.action(mid,uid,{},body=b);self.clock.now+=.1
  v=await self.action(mid,uid,{},body=b);self.assertTrue(v['duplicate']);self.assertEqual(self.db.execute('SELECT count(*) FROM wkg_results').fetchone()[0],1);self.assertEqual(self.db.execute('SELECT count(*) FROM wkg_result_people').fetchone()[0],2);self.assertEqual(self.db.execute('SELECT count(*) FROM wm_coin_accounts WHERE balance!=12345').fetchone()[0],0)
  self.assertEqual(self.g.load(mid)['state']['result']['reason'],'checkmate');b=self.body(1);n=await self.post('/'+mid+'/next',1,b);again=await self.post('/'+mid+'/next',1,b);self.assertEqual(n['id'],again['id']);self.assertEqual(n['count'],2);self.assertEqual(self.g.load(n['id'])['options']['white_seat'],1-self.g.load(mid)['state']['white'])
 async def test_leave_idempotent_and_member_reads_final_result(self):
  l=await self.create();mid=l['id'];await self.join(mid,2);await self.start(mid);s=await self.state(mid,1);b=self.body(1,expected_version=s['version'],action=dict(type='leave'));a=await self.action(mid,1,{},body=b);again=await self.action(mid,1,{},body=b);self.assertTrue(again['duplicate']);self.assertEqual(a['result'],again['result']);s=await self.state(mid,1);self.assertEqual(s['state']['result']['reason'],'resigned')
 async def test_socket_ticket_single_use_and_voice_member_scope(self):
  l=await self.create('patpal');mid=l['id'];await self.join(mid,2);w1,t1=await self.socket(1);w2,_=await self.socket(2);w3,_=await self.socket(3)
  for ws in (w1,w2):await ws.send_json(dict(type='watch',match=mid));await self.read_until(ws,'snapshot')
  await w1.send_json(dict(type='voice',target=3,payload=dict(type='offer',sdp='not a media connection')));e=await self.read_until(w1,'error');self.assertEqual(e['err'],'voice_forbidden')
  await w1.send_json(dict(type='voice',target=2,payload=dict(type='mute',muted=True)));v=await self.read_until(w2,'voice');self.assertEqual(v['source'],1);self.assertEqual(v['match'],mid)
  with self.assertRaises(Exception):await self.client.ws_connect('/api/app/games/ws?ticket='+t1['ticket'])
  for ws in (w1,w2,w3):await ws.close()
 async def test_disconnect_return_window_and_same_account_two_devices(self):
  l=await self.create('patpal');mid=l['id'];await self.join(mid,2);w1,_=await self.socket(1);await w1.send_json(dict(type='watch',match=mid));await self.read_until(w1,'snapshot')
  token=await self.post('/socket',1,dict(instance='a'*32))
  with self.assertRaises(Exception):await self.client.ws_connect('/api/app/games/ws?ticket='+token['ticket'])
  self.assertFalse(w1.closed);await w1.close();self.clock.now+=44;self.g.cache[mid]['members'][1]['seen']=self.clock.now;await self.g.tick();self.assertFalse(self.g.load(mid)['members'][0]['left']);self.clock.now+=2;self.g.cache[mid]['members'][1]['seen']=self.clock.now;await self.g.tick();self.assertTrue(self.g.load(mid)['members'][0]['left']);self.assertEqual(self.g.load(mid)['host'],2)
 async def test_all_disconnected_is_incomplete_not_awarded(self):
  l=await self.create();mid=l['id'];await self.join(mid,2);await self.start(mid);self.clock.now+=60;await self.g.tick();s=self.g.load(mid);self.assertEqual(s['state']['result']['reason'],'incomplete');self.assertEqual(self.db.execute("SELECT count(*) FROM wkg_result_people WHERE outcome='win'").fetchone()[0],0)

if __name__=='__main__':unittest.main()
