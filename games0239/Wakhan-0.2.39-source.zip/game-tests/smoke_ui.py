import asyncio,json,time
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).parent/'screenshots';OUT.mkdir(exist_ok=True)
BASE='http://127.0.0.1:8773'
async def main():
 errors=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
  api=await p.request.new_context(base_url=BASE);await api.post('/_test/control',data={'op':'reset'})
  pages=[];contexts=[]
  for uid in range(1,5):
   context=await b.new_context(viewport={'width':393,'height':852},has_touch=True,is_mobile=True);contexts.append(context);page=await context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.set_default_timeout(10000);await page.goto(BASE+'/?uid='+str(uid));await page.wait_for_function('window.fixtureReady');pages.append(page)
  page=pages[0];h=page.frame_locator('.wk-approved-home-frame');await h.locator('[data-open-game=fiskot]').tap();f=page.frame_locator('.wk-games-frame');await f.locator('[data-create]').tap();await f.locator('.dialog').get_by_role('button',name='ساخت لابی',exact=True).tap();await f.locator('[data-start]').wait_for();mid=await page.evaluate('WakhanGames.snapshot.id');print('created',mid,flush=True)
  for page in pages[1:]:
   await page.evaluate('(id)=>WakhanGames.openMatch(id,{join:true})',mid);await page.wait_for_timeout(500);print('join',await page.evaluate('({snapshot:WakhanGames.snapshot,body:document.body.className})'),errors,flush=True);await page.screenshot(path=str(OUT/'join-debug.png'));print(await page.frame_locator('.wk-games-frame').locator('body').inner_text(),flush=True);await page.frame_locator('.wk-games-frame').locator('.roster').wait_for()
  page=pages[0];f=page.frame_locator('.wk-games-frame');await f.locator('[data-start]').tap();await f.locator('.hand-strip').wait_for();await page.screenshot(path=str(OUT/'fiskot-trump.png'));print('trump ready',flush=True)
  turn=await page.evaluate('WakhanGames.snapshot.state.turn');turnPage=next(pg for pg in pages if asyncio.iscoroutine(None)) if False else pages[turn];await turnPage.frame_locator('.wk-games-frame').get_by_role('button',name='دل',exact=True).tap();await f.locator('[data-card]').nth(12).wait_for();await page.screenshot(path=str(OUT/'fiskot-full.png'));print('full hand',flush=True)
  print(json.dumps(errors),flush=True);await b.close()
asyncio.run(main())
