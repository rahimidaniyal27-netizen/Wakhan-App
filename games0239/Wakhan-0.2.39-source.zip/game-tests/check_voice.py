import asyncio,json,uuid
from pathlib import Path
from playwright.async_api import async_playwright
BASE='http://127.0.0.1:8773'
async def main():
 errors=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream'])
  api=await p.request.new_context(base_url=BASE);await api.post('/_test/control',data={'op':'reset'})
  pages=[];contexts=[]
  for uid in [1,2]:
   context=await browser.new_context(viewport={'width':393,'height':852},permissions=['microphone']);contexts.append(context);page=await context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.set_default_timeout(15000);await page.goto(BASE+'/?uid='+str(uid));await page.wait_for_function('window.fixtureReady');pages.append(page)
  a,b=pages;await a.evaluate('WakhanGames.open("chess")');f=a.frame_locator('.wk-games-frame');await f.locator('[data-create]').click();await f.locator('.dialog .primary').click();await f.locator('[data-start]').wait_for();mid=await a.evaluate('WakhanGames.snapshot.id');await b.evaluate('(id)=>WakhanGames.openMatch(id,{join:true})',mid);fb=b.frame_locator('.wk-games-frame');await fb.locator('.roster').wait_for();await f.get_by_role('button',name='مایکروفون').click();await fb.locator('audio').wait_for(state='attached');await b.wait_for_timeout(1500);tracks=await fb.locator('audio').evaluate('a=>a.srcObject?.getAudioTracks().map(t=>t.readyState)');assert tracks==['live'],tracks
  await a.evaluate('routeTo("c")');await b.wait_for_timeout(300);assert await fb.locator('audio').count()==0
  await a.evaluate('WakhanGames.openMatch(WakhanGames.snapshot.id)');await f.get_by_role('button',name='مایکروفون').wait_for();assert await f.get_by_role('button',name='مایکروفون').inner_text()=='مایک خاموش'
  result={'fake_microphone_peer_received_live_track':True,'route_exit_closes_receiver':True,'return_does_not_auto_enable_mic':True,'physical_microphone_tested':False,'errors':errors};assert not errors,errors;Path(__file__).with_name('voice-results.json').write_text(json.dumps(result,indent=2));print(result);await browser.close()
asyncio.run(main())
