import copy,math,random,sqlite3,types,unittest,uuid
import test_service as _service
from wakhan_games import world
from wakhan_games.common import GameError

class CompleteMatches(unittest.IsolatedAsyncioTestCase):
 async def fresh(self):
  for t in ('members','actions','invites','result_people','results','matches'):self.db.execute('DELETE FROM wkg_'+t)
  self.db.commit();self.g.cache.clear();self.g.rates.clear();self.g.last_persist.clear()
 async def pulse(self,mid):
  self.g.rates.clear();l=self.g.load(mid)
  for m in l['members']:m['seen']=self.clock();m['offline_since']=None
  with self.g.atomic():self.g.persist(l)
 async def setup_match(self,game,n):
  await self.fresh();l=await self.create(game)
  for uid in range(2,n+1):await self.join(l['id'],uid)
  await self.start(l['id']);return l['id']
 async def perform(self,mid,a,seat=None):
  await self.pulse(mid);l=self.g.load(mid);seat=l['state']['turn'] if seat is None else seat;uid=l['members'][seat]['uid'];r=await self.action(mid,uid,a);self.clock.now+=.02;return r
 async def test_complete_fiskot_full_match_via_four_private_sessions(self):
  mid=await self.setup_match('fiskot',4);played=0
  while self.g.load(mid)['status']!='finished':
   l=self.g.load(mid);s=l['state'];await self.pulse(mid)
   if s['phase']=='hand_end' or self.clock()<s['collect_until']:self.clock.now=s['deadline'] if s['phase']=='hand_end' else s['collect_until'];await self.g.tick();continue
   v=await self.state(mid,l['members'][s['turn']]['uid']);a=dict(type='trump',suit='H') if s['phase']=='trump' else dict(type='play',card=v['state']['legal'][0]);await self.perform(mid,a);played+=a['type']=='play';self.assertLess(played,800)
  r=self.g.load(mid)['state']['result'];self.assertGreaterEqual(max(r['details']['scores']),5);self.assertEqual(played%52,0);self.assertEqual(self.db.execute('SELECT count(*) FROM wkg_results').fetchone()[0],1)
 async def test_complete_ludo_minimum_and_maximum_sessions(self):
  for n in (2,4):
   mid=await self.setup_match('ludo',n);moves=0
   while self.g.load(mid)['status']!='finished':
    s=self.g.load(mid)['state'];seat=s['turn']
    if s['phase']=='roll':await self.perform(mid,dict(type='roll'))
    else:
     v=await self.state(mid,seat+1);legal=v['state']['legal'];token=max(legal,key=lambda t:s['tokens'][seat][t]);await self.perform(mid,dict(type='move',token=token));moves+=1
    self.assertLess(moves,6000)
   s=self.g.load(mid)['state'];self.assertTrue(all(x==56 for x in s['tokens'][s['result']['winners'][0]]));self.assertEqual(s['result']['reason'],'normal')
 async def test_complete_ono_minimum_and_maximum_sessions(self):
  for n in (2,6):
   mid=await self.setup_match('ono',n);steps=0
   while self.g.load(mid)['status']!='finished':
    s=self.g.load(mid)['state'];await self.pulse(mid)
    if s['phase']=='ono':self.clock.now=s['deadline'];await self.g.tick();continue
    if s['phase']=='challenge4':await self.perform(mid,dict(type='accept4'))
    else:
     v=(await self.state(mid,s['turn']+1))['state'];legal=v['legal']
     if legal:a=dict(type='play',card=legal[0],ono=True,color='r')
     else:a=dict(type='draw' if s['phase']=='turn' else 'pass')
     await self.perform(mid,a)
    steps+=1;self.assertLess(steps,3000)
   self.assertEqual(self.g.load(mid)['state']['result']['reason'],'normal');self.assertEqual(len(self.g.load(mid)['state']['hands'][self.g.load(mid)['state']['result']['winners'][0]]),0)
 async def test_world_minimum_maximum_and_role_bands_complete_by_clock(self):
  for game,n in [('patpal',4),('patpal',9),('patpal',13),('patpal',16),('bazaar',4),('bazaar',10)]:
   mid=await self.setup_match(game,n);l=self.g.load(mid);s=l['state']
   self.assertTrue(all(world.clear_position(s['map'],p['x'],p['z'],p['pose']) for p in s['people']))
   for m in l['members']:
    v=(await self.state(mid,m['uid']))['state'];self.assertEqual(v['entities'],[]);self.assertNotIn('people',v);self.assertNotIn('role_queue',v)
   self.clock.now=s['hide_until'];await self.pulse(mid);await self.g.tick();self.clock.now=s['ends'];await self.pulse(mid);await self.g.tick();final=self.g.load(mid);self.assertEqual(final['status'],'finished');self.assertEqual(final['state']['result']['reason'],'survived' if game=='patpal' else 'time')
 async def test_database_receipt_failure_rolls_back_result_and_cache(self):
  mid=await self.setup_match('chess',2);before=copy.deepcopy(self.g.load(mid));original=self.g.record
  def broken(*a):raise sqlite3.IntegrityError('injected receipt failure')
  self.g.record=broken
  with self.assertRaises(sqlite3.IntegrityError):await self.g.action(1,mid,self.body(1,expected_version=before['version'],action=dict(type='leave')))
  self.g.record=original;self.assertEqual(self.g.load(mid),before);self.assertEqual(self.db.execute('SELECT count(*) FROM wkg_results').fetchone()[0],0);self.assertEqual(self.db.execute('SELECT count(*) FROM wkg_result_people').fetchone()[0],0)
 async def test_old_world_input_does_not_replay_after_reconnect(self):
  mid=await self.setup_match('patpal',4);self.clock.now=self.g.load(mid)['state']['hide_until'];await self.pulse(mid);await self.g.tick();s=(await self.state(mid,1));a=dict(type='move',input_seq=1,x=0,z=0,yaw=0);body=self.body(1,expected_version=s['version'],action=a);await self.post('/'+mid+'/action',1,body);v=await self.post('/'+mid+'/action',1,body,False);self.assertEqual(v['err'],'stale_input')

for name in ("asyncSetUp","asyncTearDown","body","post","get","create","join","state","action","start","socket","read_until"):
 setattr(CompleteMatches,name,getattr(_service.ServiceTests,name))
