import importlib.util,hashlib,json,tempfile,types,unittest,zipfile,shutil
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('fixed',ROOT.parent/'sign-and-publish.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class FixTests(unittest.TestCase):
 def setup_fixture(self,root):
  source=root/'project';(source/'android').mkdir(parents=True);(source/'src').mkdir();(source/'src/main.mjs').write_text('approved client');(source/'android/gradle.properties').write_text('org.gradle.jvmargs=-Xmx1536m\nlocal.proxy.password=private-test-value\n');(root/'base0239.json').write_text(json.dumps({'src/main.mjs':m.sha(source/'src/main.mjs'),'android/gradle.properties':hashlib.sha256(b'org.gradle.jvmargs=-Xmx2048m\n').hexdigest()}));(root/'PACKAGE.json').write_text(json.dumps(dict(version=m.VERSION,build=m.BUILD,sha256={})))
  with zipfile.ZipFile(root/'app-release-unsigned.apk','w') as z:
   z.writestr('assets/public/wakhan-shell.json',Path('/workspace/wakhan-music-next/project/public/wakhan-shell.json').read_bytes());z.writestr('assets/public/wakhan-release.json',json.dumps(dict(version=m.VERSION,build=m.BUILD)))
  return source
 def test_preserves_changed_local_gradle_without_exposing_values(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);source=self.setup_fixture(root);before=(source/'android/gradle.properties').read_bytes();report={}
   with patch.object(m.os,'geteuid',return_value=0),patch.object(m,'SOURCE',source),patch.object(m,'STATE',root/'none'),patch.object(m.subprocess,'run',side_effect=RuntimeError('SOURCE_CHECK_PASSED')) as run,patch.object(m,'read_existing_configuration') as key:
    with self.assertRaisesRegex(RuntimeError,'SOURCE_CHECK_PASSED'):m.execute(root,report)
    run.assert_called_once();key.assert_not_called()
   self.assertEqual((source/'android/gradle.properties').read_bytes(),before);self.assertEqual(report['preserved_local_files']['android/gradle.properties'],hashlib.sha256(before).hexdigest());self.assertNotIn('private-test-value',json.dumps(report));self.assertNotIn('android/gradle.properties',m.PATCHES)
   stage=root/'stage';shutil.copytree(source,stage);self.assertEqual(m.sha(stage/'android/gradle.properties'),report['preserved_local_files']['android/gradle.properties'])
 def test_changed_client_still_stops_before_service_or_keys(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);source=self.setup_fixture(root);(source/'src/main.mjs').write_text('changed client')
   with patch.object(m.os,'geteuid',return_value=0),patch.object(m,'SOURCE',source),patch.object(m,'STATE',root/'none'),patch.object(m.subprocess,'run') as run,patch.object(m,'read_existing_configuration') as key:
    with self.assertRaisesRegex(RuntimeError,'CURRENT_SOURCE_CHANGED:src/main.mjs'):m.execute(root,{})
    run.assert_not_called();key.assert_not_called()
 def test_symlinked_properties_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);source=self.setup_fixture(root);p=source/'android/gradle.properties';p.unlink();other=root/'external';other.write_text('external');p.symlink_to(other)
   with patch.object(m.os,'geteuid',return_value=0),patch.object(m,'SOURCE',source),patch.object(m,'STATE',root/'none'),patch.object(m.subprocess,'run') as run:
    with self.assertRaisesRegex(RuntimeError,'CURRENT_SOURCE_CHANGED:android/gradle.properties'):m.execute(root,{})
    run.assert_not_called()
 def test_properties_overwrite_never_accepted(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);source=self.setup_fixture(root)
   with patch.object(m.os,'geteuid',return_value=0),patch.object(m,'SOURCE',source),patch.object(m,'STATE',root/'none'),patch.object(m,'PATCHES',m.PATCHES+['android/gradle.properties']),patch.object(m.subprocess,'run') as run:
    with self.assertRaisesRegex(RuntimeError,'BUILD_CONFIG_PATCH_CONFLICT'):m.execute(root,{})
    run.assert_not_called()
 def test_original_released_installer_is_immutable(self):
  self.assertEqual(hashlib.sha256(Path('/workspace/wakhan-next/delivery/sign-and-publish.py').read_bytes()).hexdigest(),'bbbcbf9f8867f2d666d94f27b39bedffe1edb1115cf01ee1732dddf944b5ef5f')
class FullPreflightTests(FixTests):
 def test_all_build_config_differences_preserved_together(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);source=self.setup_fixture(root);ruby=source/'ios-assets/native/add_files.rb';ruby.parent.mkdir(parents=True);ruby.write_text('local project setup script\n');build=source/'android/build.gradle';build.write_text('local Gradle version settings\n');base=json.loads((root/'base0239.json').read_text());base.update({'ios-assets/native/add_files.rb':'0'*64,'android/build.gradle':'0'*64});(root/'base0239.json').write_text(json.dumps(base));report={}
   with patch.object(m.os,'geteuid',return_value=0),patch.object(m,'SOURCE',source),patch.object(m,'STATE',root/'none'),patch.object(m.subprocess,'run',side_effect=RuntimeError('ALL_SOURCE_CHECKS_PASSED')) as run:
    with self.assertRaisesRegex(RuntimeError,'ALL_SOURCE_CHECKS_PASSED'):m.execute(root,report)
    run.assert_called_once()
   self.assertEqual(set(report['preserved_local_files']),{'android/gradle.properties','android/build.gradle','ios-assets/native/add_files.rb'});self.assertEqual(report['blocked_source_files'],[]);self.assertEqual(ruby.read_text(),'local project setup script\n')
 def test_all_runtime_differences_reported_in_one_pass(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);source=self.setup_fixture(root);base=json.loads((root/'base0239.json').read_text());(source/'src/main.mjs').write_text('changed main');(source/'src/auth-broker.mjs').write_text('changed auth');native=source/'ios-assets/native/WakhanLocalePlugin.swift';native.parent.mkdir(parents=True);native.write_text('changed native implementation');base.update({'src/auth-broker.mjs':'0'*64,'ios-assets/native/WakhanLocalePlugin.swift':'0'*64});(root/'base0239.json').write_text(json.dumps(base));report={}
   with patch.object(m.os,'geteuid',return_value=0),patch.object(m,'SOURCE',source),patch.object(m,'STATE',root/'none'),patch.object(m.subprocess,'run') as run,patch.object(m,'read_existing_configuration') as key:
    with self.assertRaisesRegex(RuntimeError,'CURRENT_SOURCE_CHANGED:'):m.execute(root,report)
    run.assert_not_called();key.assert_not_called()
   self.assertEqual(set(report['blocked_source_files']),{'src/main.mjs','src/auth-broker.mjs','ios-assets/native/WakhanLocalePlugin.swift'})
 def test_symlinked_parent_is_not_preserved(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);source=self.setup_fixture(root);other=root/'elsewhere';other.mkdir();(other/'add_files.rb').write_text('external');(source/'ios-assets').mkdir();(source/'ios-assets/native').symlink_to(other,target_is_directory=True);base=json.loads((root/'base0239.json').read_text());base['ios-assets/native/add_files.rb']='0'*64;(root/'base0239.json').write_text(json.dumps(base));report={}
   with patch.object(m.os,'geteuid',return_value=0),patch.object(m,'SOURCE',source),patch.object(m,'STATE',root/'none'),patch.object(m.subprocess,'run') as run:
    with self.assertRaisesRegex(RuntimeError,'CURRENT_SOURCE_CHANGED:ios-assets/native/add_files.rb'):m.execute(root,report)
    run.assert_not_called()

if __name__=='__main__':unittest.main()
