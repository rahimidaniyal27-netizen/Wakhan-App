import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 errors=[]
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--autoplay-policy=no-user-gesture-required']);page=await b.new_page(viewport={'width':393,'height':852});page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto('http://127.0.0.1:8784/review/music-shell-preview.html');await page.wait_for_function('window.shellMusicReady');await page.evaluate("document.getElementById('wm-intro-v2')?.remove()");await page.locator('#wk-music .track').first.wait_for();await page.wait_for_timeout(300)
  await page.evaluate("async()=>{window.chartData=await(await fetch('/api/app/music/chart')).json();window.musicSamples=chartData.items.filter(x=>x.provider==='archive').slice(0,2);await ui.queue.play(musicSamples);window.firstMusicId=ui.queue.state().current.id;au.dispatchEvent(new Event('ended'));au.dispatchEvent(new Event('ended'))}")
  await page.wait_for_function('!ui.queue.state().loading && !au.paused',timeout=30000);state=await page.evaluate('({current:ui.queue.state().current.id,next:musicSamples[1].id,legacy:CUR.wkMusic,loading:ui.queue.state().loading})');assert state['current']==state['next'],state;assert state['legacy'];assert not errors,errors
  await page.screenshot(path='/workspace/wakhan-music-next/screenshots/music-real-shell.png')
  Path('/workspace/wakhan-music-next/shell-results.json').write_text(json.dumps(dict(real_legacy_shell_loaded=True,autonext_capture_guard=True,no_double_advance=True,errors=errors,physical_device_verified=False),indent=2));print('PASS full shell',state,flush=True);await b.close()
asyncio.run(main())
